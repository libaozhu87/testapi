"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var main_1 = require("./core/main");
exports.flexbox = main_1.flexbox;
