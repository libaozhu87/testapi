"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MeasuredSizeType;
(function (MeasuredSizeType) {
    MeasuredSizeType["BY_TEXT"] = "BY_TEXT";
    MeasuredSizeType["BY_SKETCH_WIDTH"] = "BY_STRETCH_WIDTH";
    MeasuredSizeType["BY_INPUT"] = "BY_INPUT";
    MeasuredSizeType["BY_MARK"] = "BY_MARK";
    MeasuredSizeType["BY_CONFLICT"] = "BY_CONFLICT";
    MeasuredSizeType["BY_SPACE_BETWEEN"] = "BY_SPACE_BETWEEN";
    MeasuredSizeType["BY_IMAGE_AS_BACKGROUND"] = "BY_IMAGE_AS_BACKGROUND";
    MeasuredSizeType["BY_SHAPE_AS_BACKGROUND"] = "BY_SHAPE_AS_BACKGROUND";
    MeasuredSizeType["BY_GRID_LAYOUT_CHILD"] = "BY_GRID_LAYOUT_CHILD";
    MeasuredSizeType["BY_GRID_LAYOUT"] = "BY_GRID_LAYOUT";
    MeasuredSizeType["BY_EXTEND"] = "BY_EXTEND";
    MeasuredSizeType["BY_PRIMITIVE"] = "BY_PRIMITIVE";
    MeasuredSizeType["BY_DEFAULT"] = "BY_DEFAULT";
})(MeasuredSizeType = exports.MeasuredSizeType || (exports.MeasuredSizeType = {}));
