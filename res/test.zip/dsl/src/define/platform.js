"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Platform;
(function (Platform) {
    Platform["WEEX"] = "weex";
    Platform["FLUTTER"] = "flutter";
    Platform["ANDROID"] = "android";
    Platform["IOS"] = "iOS";
})(Platform = exports.Platform || (exports.Platform = {}));
