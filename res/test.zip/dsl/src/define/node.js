"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var NodeType;
(function (NodeType) {
    NodeType["TEXT"] = "text";
    NodeType["IMAGE"] = "image";
    NodeType["SHAPE"] = "shape";
    NodeType["GROUP"] = "group";
    NodeType["COMPONENT"] = "component";
})(NodeType = exports.NodeType || (exports.NodeType = {}));
