"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var SpecialLayout;
(function (SpecialLayout) {
    SpecialLayout[SpecialLayout["GRID"] = 0] = "GRID";
    SpecialLayout[SpecialLayout["SPACE_BETWEEN"] = 1] = "SPACE_BETWEEN";
})(SpecialLayout = exports.SpecialLayout || (exports.SpecialLayout = {}));
var SpecialAlign;
(function (SpecialAlign) {
    SpecialAlign[SpecialAlign["START"] = 0] = "START";
    SpecialAlign[SpecialAlign["CENTER"] = 1] = "CENTER";
    SpecialAlign[SpecialAlign["END"] = 2] = "END";
})(SpecialAlign = exports.SpecialAlign || (exports.SpecialAlign = {}));
