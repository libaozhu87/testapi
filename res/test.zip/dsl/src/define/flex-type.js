"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FlexDirection;
(function (FlexDirection) {
    FlexDirection["ROW"] = "row";
    FlexDirection["COLUMN"] = "column";
})(FlexDirection = exports.FlexDirection || (exports.FlexDirection = {}));
var JustifyContent;
(function (JustifyContent) {
    JustifyContent["SPACE_BETWEEN"] = "space-between";
    JustifyContent["SPACE_AROUND"] = "space-around";
    JustifyContent["CENTER"] = "center";
    JustifyContent["FLEX_END"] = "flex-end";
    JustifyContent["FLEX_START"] = "flex-start";
})(JustifyContent = exports.JustifyContent || (exports.JustifyContent = {}));
var AlignItems;
(function (AlignItems) {
    AlignItems["STRETCH"] = "stretch";
    AlignItems["CENTER"] = "center";
    AlignItems["FLEX_END"] = "flex-end";
    AlignItems["FLEX_START"] = "flex-start";
})(AlignItems = exports.AlignItems || (exports.AlignItems = {}));
var PositionType;
(function (PositionType) {
    PositionType["ABSOLUTE"] = "absolute";
    PositionType["RELATIVE"] = "relative";
})(PositionType = exports.PositionType || (exports.PositionType = {}));
var Transform;
(function (Transform) {
    Transform["X_50"] = "translateX(-50%)";
    Transform["Y_50"] = "translateY(-50%)";
    Transform["XY_50"] = "translate(-50%, -50%)";
})(Transform = exports.Transform || (exports.Transform = {}));
