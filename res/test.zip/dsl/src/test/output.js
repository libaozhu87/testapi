"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    name: 'auto-merge',
    id: 'g15',
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 144 },
    exactFrame: { x: 32, y: 37, width: 718, height: 107 },
    layers: [
        {
            name: 'auto-merge',
            id: 'g14',
            type: 'group',
            frame: { x: 32, y: 30, width: 686, height: 84 },
            exactFrame: { x: 32, y: 37, width: 686, height: 71 },
            layers: [
                {
                    name: 'auto-merge',
                    id: 'g9',
                    type: 'group',
                    frame: { x: 32, y: 30, width: 352, height: 84 },
                    exactFrame: { x: 32, y: 37, width: 352, height: 71 },
                    layers: [
                        {
                            name: '首次送出「免费送」宝贝',
                            Id: 44,
                            nameId: '1B6F6BA7-228F-4074-97FE-C73841F4613A',
                            frame: { x: 32, y: 30, width: 352, height: 45 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 32,
                                color: '#222222',
                                lineHeight: 45,
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '首次送出「免费送」宝贝',
                            type: 'text',
                            exactFrame: { x: 32, y: 37, width: 352, height: 32 },
                            zIndex: 6,
                            id: 't6'
                        },
                        {
                            name: '2018-05-09 10:56:15',
                            Id: 46,
                            nameId: '39F4B66C-B998-43FB-9F3A-AEEF370BC653',
                            frame: { x: 32, y: 74, width: 286, height: 40 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#888888',
                                lineHeight: 40,
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '2018-05-09  10:56:15',
                            type: 'text',
                            exactFrame: { x: 32, y: 80, width: 286, height: 28 },
                            zIndex: 8,
                            id: 't8'
                        }
                    ],
                    zIndex: 6
                },
                {
                    name: 'auto-merge',
                    id: 'g16',
                    type: 'group',
                    frame: { x: 563, y: 40, width: 155, height: 64 },
                    exactFrame: { x: 563, y: 40, width: 155, height: 64 },
                    layers: [
                        {
                            name: '+12',
                            Id: 45,
                            nameId: '7861B4DB-9C94-42FF-B214-59C7FE97FFCB',
                            frame: { x: 563, y: 52, width: 59, height: 50 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 36,
                                color: '#FF4444',
                                textAlign: 'right',
                                lineHeight: 50,
                                fontWeight: 'bold'
                            },
                            value: '+12',
                            type: 'text',
                            exactFrame: { x: 563, y: 59, width: 59, height: 36 },
                            zIndex: 7,
                            id: 't7'
                        },
                        {
                            name: 'auto-merge',
                            id: 'g12',
                            type: 'group',
                            frame: { x: 654, y: 40, width: 64, height: 64 },
                            exactFrame: { x: 654, y: 40, width: 64, height: 64 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 36,
                                    nameId: '40706C29-1F17-4736-A634-68776ECC5B42',
                                    frame: { x: 654, y: 40, width: 64, height: 64 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1TIWqrHSYBuNjSspiXXXNzpXa-64-64.png',
                                    exactFrame: { x: 654, y: 40, width: 64, height: 64 },
                                    zIndex: 2,
                                    id: 'i2'
                                },
                                {
                                    name: 'auto-merge',
                                    id: 'g11',
                                    type: 'group',
                                    frame: { x: 654, y: 40, width: 64, height: 63 },
                                    exactFrame: { x: 654, y: 40, width: 64, height: 63 },
                                    layers: [
                                        {
                                            name: 'Mask Copy',
                                            Id: 38,
                                            nameId: 'CA0C676F-57C1-4874-BF31-E29ACF6C061C',
                                            frame: { x: 658, y: 44, width: 56, height: 55 },
                                            styles: { fillType: 'gradient', borderRadius: 55.422680412371164 },
                                            type: 'shape',
                                            exactFrame: { x: 658, y: 44, width: 56, height: 55 },
                                            zIndex: 4,
                                            id: 's4'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 39,
                                            nameId: '299F8F39-8326-4A81-9DE1-45C9B76F98F4',
                                            frame: { x: 658, y: 44, width: 56, height: 58 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1rP1GrKuSBuNjSsplXXbe8pXa-56-58.png',
                                            exactFrame: { x: 658, y: 44, width: 56, height: 58 },
                                            zIndex: 5,
                                            id: 'i5'
                                        }
                                    ],
                                    styles: { fillType: 'gradient', borderRadius: 63.34020618556701 },
                                    zIndex: 3
                                }
                            ],
                            zIndex: 2
                        }
                    ],
                    zIndex: 2
                }
            ],
            zIndex: 2
        },
        {
            name: 'Bitmap',
            Id: 33,
            nameId: '23F1DEFA-7285-460E-8619-6538987A3C2E',
            frame: { x: 32, y: 142, width: 718, height: 2 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1XP1GrKuSBuNjSsplXXbe8pXa-718-2.png',
            exactFrame: { x: 32, y: 142, width: 718, height: 2 },
            zIndex: 1,
            id: 'i1'
        }
    ],
    styles: { backgroundColor: 'rgba(255,255,255,1)' },
    zIndex: 1
};
