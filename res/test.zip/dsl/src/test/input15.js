"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    type: 'group',
    frame: {
        width: 766,
        height: 338,
        x: 0,
        y: 0
    },
    layers: [
        {
            frame: {
                width: 766,
                height: 338,
                x: 0,
                y: 0
            },
            skecthName: 'Rectangle',
            objectID: 'D12DAAFB-9403-4549-B412-5293E8EE2A29',
            id: 0,
            layers: []
        }
    ]
};
