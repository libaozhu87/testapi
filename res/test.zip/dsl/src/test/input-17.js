"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Rectangle 224 Copy 4',
            nameId: '37448775-A2B3-400D-B8DF-A14FC678586F',
            frame: { y: 0, width: 750, x: 0, height: 16 },
            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524659388856.png',
            imageStyles: { resize: 'stretch' },
            type: 'image',
            id: 0
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#222222',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '22',
                lineHeight: '20',
                textAlign: 'center'
            },
            name: '免费',
            type: 'text',
            frame: { y: 51, width: 44, x: 449, height: 20 },
            value: '免费',
            nameId: '74AE68F7-3153-43F5-B703-214FC0C6F28B',
            id: 5
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#222222',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '32',
                lineHeight: '32',
                textAlign: 'left'
            },
            frame: { y: 46, x: 33, height: 32, width: 399 },
            type: 'text',
            id: 2,
            value: '快速建鱼塘 每月多赚1000元'
        },
        {
            name: 'Rectangle 14',
            nameId: '8065C8DD-4075-4464-9AC8-9530CF9B4005',
            frame: { y: 45, width: 56, x: 442, height: 32 },
            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524659390905.png',
            imageStyles: { resize: 'stretch' },
            type: 'image',
            id: 3
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#222222',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '22',
                lineHeight: '20',
                textAlign: 'center'
            },
            name: '免费',
            type: 'text',
            frame: { y: 51, width: 44, x: 449, height: 20 },
            value: '免费',
            nameId: '74AE68F7-3153-43F5-B703-214FC0C6F28B',
            id: 5
        },
        {
            frame: { y: 104, x: 32, height: 160, width: 296 },
            type: 'image',
            id: 5,
            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524659392900.png',
            imageStyles: { resize: 'stretch' }
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#FFFFFF',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '30',
                lineHeight: '42',
                textAlign: 'left'
            },
            name: '建鱼塘养宠物',
            type: 'text',
            frame: { y: 170, width: 180, x: 56, height: 42 },
            value: '建鱼塘养宠物',
            nameId: '30ED5623-53D0-4755-8BA2-9F04AB98DE7A',
            id: 7
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#FFFFFF',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                lineHeight: '36',
                textAlign: 'left'
            },
            name: '7天轻松赚2000元',
            type: 'text',
            frame: { y: 212, width: 223, x: 56, height: 36 },
            value: '7天轻松赚2000元',
            nameId: 'E056C6F3-94FF-4062-A674-EEEBAB947B8E',
            id: 8
        },
        {
            frame: { y: 104, x: 344, height: 160, width: 296 },
            type: 'image',
            id: 8,
            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524659394943.png',
            imageStyles: { resize: 'stretch' }
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#FFFFFF',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '30',
                lineHeight: '42',
                textAlign: 'left'
            },
            name: '建鱼塘卖水果',
            type: 'text',
            frame: { y: 170, width: 180, x: 368, height: 42 },
            value: '建鱼塘卖水果',
            nameId: '868D63F1-7376-417F-B0A4-3E0AD93A98BD',
            id: 10
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#FFFFFF',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                lineHeight: '36',
                textAlign: 'left'
            },
            name: '轻松多卖几百箱',
            type: 'text',
            frame: { y: 212, width: 196, x: 368, height: 36 },
            value: '轻松多卖几百箱',
            nameId: '2DF53E83-604B-44BC-9F62-1FCC653CEDB3',
            id: 11
        },
        {
            frame: { y: 104, x: 656, height: 160, width: 94 },
            type: 'image',
            id: 11,
            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524659397103.png',
            imageStyles: { resize: 'stretch' }
        },
        {
            styles: { fillType: 'color', backgroundColor: 'rgba(255,255,255,1)' },
            name: 'Rectangle 18',
            nameId: '804C197E-C312-4453-8CEF-29481DB4A785',
            frame: { y: 296, width: 750, x: 0, height: 88 },
            type: 'shape',
            id: 12
        },
        {
            textStyles: {
                fontWeight: 'normal',
                color: '#888888',
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                lineHeight: '28',
                textAlign: 'left'
            },
            frame: { y: 327, x: 276, height: 27, width: 166 },
            type: 'text',
            id: 13,
            value: '免费创建鱼塘'
        },
        {
            name: 'Combined Shape',
            nameId: '371AF631-2014-4094-971D-364EF3970DFF',
            frame: { y: 328, width: 14, x: 453, height: 24 },
            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524659399112.png',
            imageStyles: { resize: 'stretch' },
            type: 'image',
            id: 14
        },
        {
            name: 'Rectangle 224 Copy 7',
            nameId: '085B7764-9D5C-49CD-A78D-2373FE1A5C11',
            frame: { y: 384, width: 750, x: 0, height: 16 },
            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524659401008.png',
            imageStyles: { resize: 'stretch' },
            type: 'image',
            id: 15
        }
    ],
    type: 'group',
    frame: { y: 0, x: 0, height: 397, width: 750 },
    nameId: 1524659388856,
    id: 0
};
