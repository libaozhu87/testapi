"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Rectangle 201',
            Id: 2,
            nameId: 'FC93325C-C0D0-40CB-9D35-46D757BE1EDB',
            frame: {
                width: 750,
                height: 806,
                x: 0,
                y: -1
            },
            styles: {
                backgroundColor: 'rgba(255,255,255,1)'
            },
            type: 'shape'
        },
        {
            name: 'Navigation Bar',
            Id: 4,
            nameId: '62B429CC-9620-4C68-BD44-95B4C5740468',
            frame: {
                width: 750,
                height: 129,
                x: 0,
                y: 0
            },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 5,
                    nameId: 'E8E32C49-E098-4A6C-950A-C8D1E826E19F',
                    frame: {
                        width: 750,
                        height: 129,
                        x: 0,
                        y: 0
                    },
                    imageStyles: {
                        resize: 'stretch'
                    },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1nIy.weSSBuNjy0FlXXbBpVXa-750-129.png'
                },
                {
                    name: 'Status Bar black',
                    Id: 7,
                    nameId: '14A0C33F-6363-4D4A-95D6-B2BA72BB3CA5',
                    frame: {
                        width: 731,
                        height: 33,
                        x: 13,
                        y: 3
                    },
                    layers: [
                        {
                            name: 'Signal',
                            Id: 9,
                            nameId: '7AB2ED19-4540-441C-9165-3B6BA00426FC',
                            frame: {
                                width: 190,
                                height: 28,
                                x: 13,
                                y: 8
                            },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 10,
                                    nameId: 'D5B2B191-8EEE-414B-93B3-3B052F4E3886',
                                    frame: {
                                        width: 68,
                                        height: 11,
                                        x: 13,
                                        y: 15
                                    },
                                    imageStyles: {
                                        resize: 'stretch'
                                    },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB18aZnwamWBuNjy1XaXXXCbXXa-68-11.png'
                                },
                                {
                                    name: 'VIRGI',
                                    Id: 11,
                                    nameId: '11BC3D02-286A-489D-B060-A1356DBFC437',
                                    frame: {
                                        width: 62,
                                        height: 27,
                                        x: 89.40533333333315,
                                        y: 8
                                    },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 22,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '27',
                                        fontWeight: 'normal'
                                    },
                                    value: 'VIRGI',
                                    type: 'text'
                                },
                                {
                                    name: 'N',
                                    Id: 12,
                                    nameId: '0DD5AC3D-4969-4E38-BD5A-735347BCF2E8',
                                    frame: {
                                        width: 17,
                                        height: 27,
                                        x: 151.01133303333336,
                                        y: 8
                                    },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 22,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '27',
                                        fontWeight: 'normal'
                                    },
                                    value: 'N',
                                    type: 'text'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 13,
                                    nameId: 'F20D6C2A-FB47-4CFB-ADA9-8D5B919DC961',
                                    frame: {
                                        width: 25,
                                        height: 19,
                                        x: 178,
                                        y: 11
                                    },
                                    imageStyles: {
                                        resize: 'stretch'
                                    },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1xy5kwgmTBuNjy1XbXXaMrVXa-25-19.png'
                                }
                            ],
                            type: 'group',
                            objectID: '7AB2ED19-4540-441C-9165-3B6BA00426FC'
                        },
                        {
                            name: 'Bitmap',
                            Id: 14,
                            nameId: 'C6658CD5-A154-4DE5-8FE3-8165E164D1D3',
                            frame: {
                                width: 17,
                                height: 27,
                                x: 606,
                                y: 7
                            },
                            imageStyles: {
                                resize: 'stretch'
                            },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1qa3nwamWBuNjy1XaXXXCbXXa-17-27.png'
                        },
                        {
                            name: 'Battery',
                            Id: 16,
                            nameId: 'D7FF357E-CDDD-45C7-AFF1-29A074A499AB',
                            frame: {
                                width: 416,
                                height: 33,
                                x: 327.66933333333327,
                                y: 3
                            },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 17,
                                    nameId: 'A49BCFCD-5162-4CE5-BD21-DF6769166170',
                                    frame: {
                                        width: 4,
                                        height: 7,
                                        x: 739,
                                        y: 17
                                    },
                                    imageStyles: {
                                        resize: 'stretch'
                                    },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB14rknwamWBuNjy1XaXXXCbXXa-4-7.png'
                                },
                                {
                                    name: 'Shape',
                                    Id: 18,
                                    nameId: 'CFA488CE-BD97-413E-9CFB-AA0CD0140FD4',
                                    frame: {
                                        width: 14.074666666666417,
                                        height: 15,
                                        x: 695.6213333333335,
                                        y: 13
                                    },
                                    styles: {
                                        backgroundColor: 'rgba(0,0,0,1)',
                                        borderBottomLeftRadius: '1',
                                        borderBottomRightRadius: '0',
                                        borderTopLeftRadius: '1',
                                        borderTopRightRadius: '0'
                                    },
                                    type: 'shape'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 19,
                                    nameId: '41E10A77-B736-44D2-9E6A-6C0866F9CAF5',
                                    frame: {
                                        width: 46,
                                        height: 19,
                                        x: 693,
                                        y: 11
                                    },
                                    imageStyles: {
                                        resize: 'stretch'
                                    },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB18kvawkyWBuNjy0FpXXassXXa-46-19.png'
                                },
                                {
                                    name: '22',
                                    Id: 20,
                                    nameId: '7FFB85B0-8660-4D12-8BCA-8707BC585C3A',
                                    frame: {
                                        width: 28,
                                        height: 28,
                                        x: 636.3066666666664,
                                        y: 7
                                    },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue-Light',
                                        fontSize: 23,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '28',
                                        fontWeight: 'normal'
                                    },
                                    value: '22',
                                    type: 'text'
                                },
                                {
                                    name: '%',
                                    Id: 21,
                                    nameId: '851A4FA1-C925-4EAB-A935-57C5994A8226',
                                    frame: {
                                        width: 22,
                                        height: 28,
                                        x: 663.8826666666664,
                                        y: 7
                                    },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue-Light',
                                        fontSize: 23,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '28',
                                        fontWeight: 'normal'
                                    },
                                    value: '%',
                                    type: 'text'
                                },
                                {
                                    name: '4 21 PM',
                                    Id: 22,
                                    nameId: 'B920A829-0F74-4BC2-BBBE-3FEA22B359FB',
                                    frame: {
                                        width: 97,
                                        height: 30,
                                        x: 327.66933333333327,
                                        y: 6
                                    },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 24,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '29',
                                        fontWeight: 'normal'
                                    },
                                    value: '4 21 PM',
                                    type: 'text'
                                },
                                {
                                    name: ':',
                                    Id: 23,
                                    nameId: 'F8E9EDF8-9E70-4E64-8A22-81880134CFA8',
                                    frame: {
                                        width: 9,
                                        height: 33,
                                        x: 341.2413333333334,
                                        y: 3
                                    },
                                    textStyles: {
                                        fontFamily: 'AvenirNext-Regular',
                                        fontSize: 24,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '33',
                                        fontWeight: 'normal'
                                    },
                                    value: ':',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'D7FF357E-CDDD-45C7-AFF1-29A074A499AB'
                        }
                    ],
                    type: 'group',
                    objectID: '14A0C33F-6363-4D4A-95D6-B2BA72BB3CA5'
                },
                {
                    name: 'Bitmap',
                    Id: 24,
                    nameId: '9D5FDC6C-9A66-4358-9292-D1A3D9EFC23C',
                    frame: {
                        width: 36,
                        height: 36,
                        x: 40,
                        y: 65
                    },
                    imageStyles: {
                        resize: 'stretch'
                    },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1FzqkwgmTBuNjy1XbXXaMrVXa-36-36.png'
                },
                {
                    name: 'Louie 2',
                    Id: 25,
                    nameId: '72071DB0-06BC-493E-836A-BDAB0D49D4DC',
                    frame: {
                        width: 136,
                        height: 51,
                        x: 309,
                        y: 55.36149847412162
                    },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 34,
                        color: '#333333',
                        textAlign: 'center',
                        lineHeight: '50.40000152587891',
                        fontWeight: 'bold'
                    },
                    value: '一键转卖',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '62B429CC-9620-4C68-BD44-95B4C5740468'
        },
        {
            name: 'Group',
            Id: 27,
            nameId: 'BD21A429-D676-4EC8-9931-99BE97A649D9',
            frame: {
                width: 155,
                height: 155,
                x: 40,
                y: 551
            },
            layers: [
                {
                    name: 'IMG_6974',
                    Id: 29,
                    nameId: '33A7FD2F-77AC-4F1D-8562-04267A359073',
                    frame: {
                        width: 155,
                        height: 155,
                        x: 40,
                        y: 551
                    },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 30,
                            nameId: '44ADA069-7960-4CD0-BD70-C0246A3FEF4B',
                            frame: {
                                width: 155,
                                height: 155,
                                x: 40,
                                y: 551
                            },
                            imageStyles: {
                                resize: 'stretch'
                            },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1lQzawkyWBuNjy0FpXXassXXa-155-155.png'
                        }
                    ],
                    type: 'group',
                    objectID: '33A7FD2F-77AC-4F1D-8562-04267A359073'
                }
            ],
            type: 'group',
            objectID: 'BD21A429-D676-4EC8-9931-99BE97A649D9'
        },
        {
            name: 'Bitmap',
            Id: 31,
            nameId: '4ED07CB0-32C7-41D3-8BF3-5D2C2D550764',
            frame: {
                width: 18,
                height: 23,
                x: 40,
                y: 741
            },
            imageStyles: {
                resize: 'stretch'
            },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB11jZawf1TBuNjy0FjXXajyXXa-18-23.png'
        },
        {
            name: '浙江 杭州 余杭区',
            Id: 32,
            nameId: '0629AA5D-FA6C-4D9D-B28D-62AA5CC83713',
            frame: {
                width: 184,
                height: 34,
                x: 65,
                y: 736
            },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 24,
                color: '#888888',
                lineHeight: '33.59999847412109',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '浙江 杭州 余杭区',
            type: 'text'
        },
        {
            name: 'Group 8',
            Id: 34,
            nameId: '340406FF-3284-4EA0-AB3C-235A15DCE9B5',
            frame: {
                width: 750,
                height: 120,
                x: 0,
                y: 1174
            },
            layers: [
                {
                    name: 'Rectangle 63',
                    Id: 35,
                    nameId: '7F174F37-264B-467F-B675-AAE270FA8918',
                    frame: {
                        width: 750,
                        height: 120,
                        x: 0,
                        y: 1174
                    },
                    styles: {
                        backgroundColor: 'rgba(255,255,255,1)'
                    },
                    type: 'shape'
                },
                {
                    name: 'Bitmap',
                    Id: 36,
                    nameId: '884074A1-7E2C-4307-928A-D0401B5E4935',
                    frame: {
                        width: 710,
                        height: 80,
                        x: 20,
                        y: 1194
                    },
                    imageStyles: {
                        resize: 'stretch'
                    },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1IQzawkyWBuNjy0FpXXassXXa-710-80.png'
                },
                {
                    name: '转卖到闲鱼',
                    Id: 37,
                    nameId: '7658B609-119B-47AD-ABA5-D1C2C213B68B',
                    frame: {
                        width: 160,
                        height: 45,
                        x: 295,
                        y: 1212
                    },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#FFFFFF',
                        textAlign: 'center',
                        lineHeight: '45',
                        fontWeight: 'bold'
                    },
                    value: '转卖到闲鱼',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '340406FF-3284-4EA0-AB3C-235A15DCE9B5'
        },
        {
            name: 'Bitmap',
            Id: 38,
            nameId: '5C36595D-5C9E-4F37-B9A9-6F0707506045',
            frame: {
                width: 672,
                height: 2,
                x: 40,
                y: 226
            },
            imageStyles: {
                resize: 'stretch'
            },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB18bonwamWBuNjy1XaXXXCbXXa-672-2.png'
        },
        {
            name: '标题标题标题',
            Id: 39,
            nameId: '74298B93-83D0-466A-B02D-E61804EE2372',
            frame: {
                width: 168,
                height: 48,
                x: 39,
                y: 156
            },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 28,
                color: '#222222',
                lineHeight: '48',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '标题标题标题',
            type: 'text'
        },
        {
            name: '美国背回来的，因为买的太多了，还没来得及',
            Id: 40,
            nameId: '436033FF-FDCA-485F-9053-0CB25FD2B32D',
            frame: {
                width: 662,
                height: 240,
                x: 39,
                y: 250
            },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 28,
                color: '#888888',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '美国背回来的，因为买的太多了，还没来得及穿就小\n了！上身非常漂亮！适合110-140的女孩。割爱转让！\n国外价格已经比国内要低，还打特价时候买的！买到\n了还不赚了吗？国际邮费免了，只需要支付国内运费\n就能把名牌带回家噢！纯棉，色彩鲜艳，小宝宝穿好\n看，特别有活力~',
            type: 'text'
        },
        {
            name: 'Group 11',
            Id: 42,
            nameId: '061C27CC-01EF-43AD-A54E-04844D1D3440',
            frame: {
                width: 750,
                height: 177,
                x: 0,
                y: 821
            },
            layers: [
                {
                    name: 'Group 10',
                    Id: 44,
                    nameId: 'E3062511-AF3C-4B80-A0FE-DA91E384978F',
                    frame: {
                        width: 750,
                        height: 177,
                        x: 0,
                        y: 821
                    },
                    layers: [
                        {
                            name: 'Rectangle 12',
                            Id: 45,
                            nameId: 'AE702735-87B0-49C6-9340-8E2D9D248B05',
                            frame: {
                                width: 750,
                                height: 177,
                                x: 0,
                                y: 821
                            },
                            styles: {
                                backgroundColor: 'rgba(255,255,255,1)'
                            },
                            type: 'shape'
                        },
                        {
                            name: 'Bitmap',
                            Id: 46,
                            nameId: '275B3E9C-10A1-4E1C-883F-658FC6BAFD6D',
                            frame: {
                                width: 12,
                                height: 23,
                                x: 700,
                                y: 896
                            },
                            imageStyles: {
                                resize: 'stretch'
                            },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB107zawkyWBuNjy0FpXXassXXa-12-23.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'E3062511-AF3C-4B80-A0FE-DA91E384978F'
                }
            ],
            type: 'group',
            objectID: '061C27CC-01EF-43AD-A54E-04844D1D3440'
        },
        {
            name: '原价 ¥35.00 | 运费 ￥0.00',
            Id: 47,
            nameId: '3B10E4DD-A827-495C-9FE8-86BD299A6BC9',
            frame: {
                width: 261,
                height: 30,
                x: 39,
                y: 922
            },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 22,
                color: '#888888',
                lineHeight: '30',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '原价 ¥35.00 | 运费 ￥0.00',
            type: 'text'
        },
        {
            name: '¥',
            Id: 48,
            nameId: '45B6B7B3-A14C-4657-902F-A7BD80A21C70',
            frame: {
                width: 17,
                height: 51,
                x: 42,
                y: 866
            },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: 28,
                color: '#222222',
                textAlign: 'center',
                lineHeight: '50.40000152587891',
                fontWeight: 'bold'
            },
            value: '¥',
            type: 'text'
        },
        {
            name: '17.00',
            Id: 49,
            nameId: '8E14EFE7-C9B3-43BB-88A9-3766CA76C233',
            frame: {
                width: 88,
                height: 51,
                x: 58.80000000000018,
                y: 866
            },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: 36,
                color: '#222222',
                textAlign: 'center',
                lineHeight: '50.40000152587891',
                fontWeight: 'bold'
            },
            value: '17.00',
            type: 'text'
        }
    ],
    nameId: 1528365536418,
    Id: 1,
    type: 'group',
    frame: {
        x: 0,
        y: 0,
        width: 750,
        height: 1294
    },
    styles: {
        backgroundColor: 'rgba(243,245,249,1)'
    }
};
