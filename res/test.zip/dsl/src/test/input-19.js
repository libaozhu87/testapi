"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Rectangle Copy',
            Id: 3,
            nameId: 'A0A8C17F-E686-4DFD-BF43-94FE0F24C187',
            frame: { width: 750, height: 120, x: 0, y: 8 },
            layers: [
                {
                    name: 'Rectangle Copy',
                    Id: 4,
                    nameId: 'C739E776-C69E-4674-A53D-1EDC0E22CB8A',
                    frame: { width: 750, height: 88, x: 0, y: 40 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 6,
                    nameId: 'CE10A922-5CDC-430C-A24F-843A0C26B904',
                    frame: { width: 702, height: 64, x: 32, y: 52 },
                    layers: [
                        {
                            name: 'ic_share',
                            Id: 7,
                            nameId: '5FBBE29E-27F6-4085-8A5E-7E7C19C97959',
                            frame: { width: 72, height: 64, x: 662, y: 52 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1ZINipTtYBeNjy1XdXXXXyVXa-72-64.png'
                        },
                        {
                            name: 'ic_share copy',
                            Id: 8,
                            nameId: '827224F9-9140-4AE4-A4D9-8C4326FB1ABD',
                            frame: { width: 74, height: 62, x: 581, y: 52 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1Fpjtpr9YBuNjy0FgXXcxcXXa-74-62.png'
                        },
                        {
                            name: 'ic_backarrow',
                            Id: 9,
                            nameId: 'EE0B74F5-FCCA-4172-BB4D-E5EB3DB4EE88',
                            frame: { width: 40, height: 40, x: 32, y: 64 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1kHbnpACWBuNjy0FaXXXUlXXa-40-40.png'
                        },
                        {
                            name: 'Page 1',
                            Id: 10,
                            nameId: '97EC28DF-13DC-4A71-8513-A6F03C089DED',
                            frame: { width: 161, height: 39, x: 322, y: 64 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1JVChpwmTBuNjy1XbXXaMrVXa-161-39.png'
                        },
                        {
                            name: 'Group 3',
                            Id: 11,
                            nameId: 'EA209CBC-F0E0-4BE4-B4D6-243CB3684526',
                            frame: { width: 48, height: 48, x: 264, y: 60 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1QXChpwmTBuNjy1XbXXaMrVXa-48-48.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'CE10A922-5CDC-430C-A24F-843A0C26B904'
                },
                {
                    name: 'Time',
                    Id: 12,
                    nameId: '6B80F97F-CA08-49BD-A99F-32924D0621A1',
                    frame: { width: 90, height: 33, x: 330, y: 8 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#000000',
                        textAlign: 'center',
                        lineHeight: '33',
                        fontWeight: 'normal'
                    },
                    value: '9:41 AM',
                    type: 'text'
                },
                {
                    name: 'Carrier',
                    Id: 13,
                    nameId: '9EA8A291-708A-41D6-970C-CAC43BB4C7EA',
                    frame: { width: 86, height: 33, x: 88, y: 8 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#000000',
                        textAlign: 'left',
                        lineHeight: '33',
                        fontWeight: 'normal'
                    },
                    value: 'SanityD',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: 'A0A8C17F-E686-4DFD-BF43-94FE0F24C187'
        },
        {
            name: 'Group 34',
            Id: 15,
            nameId: 'ED51C6E6-70A3-4525-8865-D0BC6C7C9DA1',
            frame: { width: 750, height: 200, x: 0, y: 128 },
            layers: [
                {
                    name: 'Group 34',
                    Id: 16,
                    nameId: '430F7155-B791-442D-ADF8-2E271B55F441',
                    frame: { width: 750, height: 200, x: 0, y: 128 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1t1PLpqmWBuNjy1XaXXXCbXXa-750-200.png'
                },
                {
                    name: 'Group 29',
                    Id: 17,
                    nameId: 'DAD8D172-FD62-49C4-9CB7-D7BBFE284CCD',
                    frame: { width: 522, height: 37, x: 114, y: 184 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1ciWoprSYBuNjSspiXXXNzpXa-522-37.png'
                },
                {
                    name: 'Group',
                    Id: 19,
                    nameId: '1CA724A4-FEE1-43EA-AB5B-B6BEE09DFCF0',
                    frame: { width: 604, height: 40, x: 73, y: 248 },
                    layers: [
                        {
                            name: '在线估价',
                            Id: 20,
                            nameId: '3DC9311F-A834-4D28-A199-10893D813538',
                            frame: { width: 112, height: 40, x: 73, y: 248 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FFFFFF',
                                textAlign: 'right',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '在线估价',
                            type: 'text'
                        },
                        {
                            name: 'Combined Shape',
                            Id: 21,
                            nameId: '9CDD1C31-EF51-4736-B90C-1CB91F7A99C3',
                            frame: { width: 14, height: 24, x: 194.8033008588991, y: 256.1066017177982 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1J.fIpx9YBuNjy0FfXXXIsVXa-14-24.png'
                        },
                        {
                            name: '等待质检',
                            Id: 22,
                            nameId: '076AC0C4-993A-4435-8483-D76417EE426A',
                            frame: { width: 112, height: 40, x: 419, y: 248 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FFFFFF',
                                textAlign: 'right',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '等待质检',
                            type: 'text'
                        },
                        {
                            name: 'Combined Shape',
                            Id: 23,
                            nameId: 'FFF18023-6BEA-4C47-AD4E-FCE0A116FD41',
                            frame: { width: 14, height: 24, x: 540.8033008588991, y: 256.1066017177982 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1ZKPLpqmWBuNjy1XaXXXCbXXa-14-24.png'
                        },
                        {
                            name: '结算尾款',
                            Id: 24,
                            nameId: 'AF60781C-B8BB-4E51-8204-CC4808F1B4EA',
                            frame: { width: 112, height: 40, x: 565, y: 248 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FFFFFF',
                                textAlign: 'right',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '结算尾款',
                            type: 'text'
                        },
                        {
                            name: '下单收预付款',
                            Id: 25,
                            nameId: 'F72019EE-D1D6-46F6-800F-96A1ED637E86',
                            frame: { width: 168, height: 40, x: 217, y: 248 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FFFFFF',
                                textAlign: 'right',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '下单收预付款',
                            type: 'text'
                        },
                        {
                            name: 'Combined Shape',
                            Id: 26,
                            nameId: 'AF327F41-0429-4B37-BFFE-23FF69DB5638',
                            frame: { width: 14, height: 24, x: 394.8033008588991, y: 256.1066017177982 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB19uPLpqmWBuNjy1XaXXXCbXXa-14-24.png'
                        }
                    ],
                    type: 'group',
                    objectID: '1CA724A4-FEE1-43EA-AB5B-B6BEE09DFCF0'
                }
            ],
            type: 'group',
            objectID: 'ED51C6E6-70A3-4525-8865-D0BC6C7C9DA1'
        },
        {
            name: 'Rectangle 2',
            Id: 28,
            nameId: '391C531D-74DA-4022-A4B8-67B7747F2BD2',
            frame: { width: 750, height: 412, x: 0, y: 328 },
            layers: [
                {
                    name: 'Rectangle 2',
                    Id: 29,
                    nameId: 'B8F8983C-A0CC-4365-9CE0-5B47BA0476F1',
                    frame: { width: 750, height: 412, x: 0, y: 328 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Rectangle 2 Copy',
                    Id: 31,
                    nameId: '68F04E8A-0515-4B93-AC77-8C6DC3CBFAE0',
                    frame: { width: 724, height: 412, x: 26, y: 328 },
                    layers: [
                        {
                            name: 'Rectangle 2 Copy',
                            Id: 32,
                            nameId: 'C23AA60B-F67B-483D-9635-6D00FDC06664',
                            frame: { width: 719.9999999999998, height: 412, x: 30, y: 328 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                            type: 'shape'
                        },
                        {
                            name: 'Group',
                            Id: 34,
                            nameId: '41EE5025-8D64-4668-8838-07DEE6D0CCED',
                            frame: { width: 668, height: 112, x: 40, y: 362 },
                            layers: [
                                {
                                    name: 'Mask',
                                    Id: 36,
                                    nameId: 'E65EA2B3-C74A-4945-8383-C1EAB7566EF8',
                                    frame: { width: 112, height: 112, x: 40, y: 362 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 37,
                                            nameId: '4227540A-A840-45F2-9A65-C91AF74E1BC1',
                                            frame: { width: 112, height: 112, x: 40, y: 362 },
                                            styles: { backgroundColor: 'rgba(244,231,229,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 38,
                                            nameId: '68DA922E-E739-4B49-AE33-4F80D2FCD9BC',
                                            frame: { width: 66, height: 92, x: 64, y: 382 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1JrfnpACWBuNjy0FaXXXUlXXa-66-92.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'E65EA2B3-C74A-4945-8383-C1EAB7566EF8'
                                },
                                {
                                    name: 'Mask',
                                    Id: 40,
                                    nameId: '99F47ACA-27BD-43F5-BE92-4932FDF8C7DA',
                                    frame: { width: 112, height: 112, x: 226, y: 362 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 41,
                                            nameId: '7B66FC73-0A68-4C7F-B94F-D46EED8C3215',
                                            frame: { width: 112, height: 112, x: 226, y: 362 },
                                            styles: { backgroundColor: 'rgba(232,234,240,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 42,
                                            nameId: '4A80F0C2-1612-4E8A-B94D-BA7F74AE7EC1',
                                            frame: { width: 82, height: 90, x: 240, y: 384 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1Be5_pAyWBuNjy0FpXXassXXa-82-90.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '99F47ACA-27BD-43F5-BE92-4932FDF8C7DA'
                                },
                                {
                                    name: 'Mask',
                                    Id: 44,
                                    nameId: '084B7589-DDDB-489C-A3FD-CEEB13E681E4',
                                    frame: { width: 112, height: 112, x: 412, y: 362 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 45,
                                            nameId: '514CEADE-B718-47D5-B241-7C502A0E4ED8',
                                            frame: { width: 112, height: 112, x: 412, y: 362 },
                                            styles: { backgroundColor: 'rgba(245,233,232,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 46,
                                            nameId: 'C04DFDFD-7B6A-4993-ABCE-4390D4E7BF71',
                                            frame: { width: 96, height: 66, x: 420, y: 386 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1_bHopxSYBuNjSspjXXX73VXa-96-66.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '084B7589-DDDB-489C-A3FD-CEEB13E681E4'
                                },
                                {
                                    name: 'Mask',
                                    Id: 48,
                                    nameId: '7AE3D6E0-4355-41B0-A63A-A044BADB4563',
                                    frame: { width: 112, height: 112, x: 596, y: 362 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 49,
                                            nameId: '25667948-11CF-4FDD-8F74-D1AD3AEB6599',
                                            frame: { width: 112, height: 112, x: 596, y: 362 },
                                            styles: { backgroundColor: 'rgba(230,239,230,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap Copy',
                                            Id: 50,
                                            nameId: 'A6291200-6D59-4904-B472-1D887F7FC01D',
                                            frame: { width: 82, height: 84, x: 612, y: 378 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1Re5_pAyWBuNjy0FpXXassXXa-82-84.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '7AE3D6E0-4355-41B0-A63A-A044BADB4563'
                                }
                            ],
                            type: 'group',
                            objectID: '41EE5025-8D64-4668-8838-07DEE6D0CCED'
                        },
                        {
                            name: 'Group',
                            Id: 52,
                            nameId: '1A73F9C4-ED55-455D-84BD-35AD1D77D1FC',
                            frame: { width: 642, height: 40, x: 54, y: 480 },
                            layers: [
                                {
                                    name: '卖手机',
                                    Id: 53,
                                    nameId: 'C6A1E13B-EEEE-4F96-B770-8B740CE80073',
                                    frame: { width: 84, height: 40, x: 54, y: 480 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖手机',
                                    type: 'text'
                                },
                                {
                                    name: '卖平板',
                                    Id: 54,
                                    nameId: '8BAAA016-8E7D-4E31-A0B4-CF8C5AA76BFE',
                                    frame: { width: 84, height: 40, x: 240, y: 480 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖平板',
                                    type: 'text'
                                },
                                {
                                    name: '卖电脑',
                                    Id: 55,
                                    nameId: 'E258B9EA-942F-475E-B8D7-C94FDAC7BA4A',
                                    frame: { width: 84, height: 40, x: 426, y: 480 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖电脑',
                                    type: 'text'
                                },
                                {
                                    name: '卖相机',
                                    Id: 56,
                                    nameId: '801ECC6D-0698-439B-ADC0-1EE9C898668A',
                                    frame: { width: 84, height: 40, x: 612, y: 480 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖相机',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '1A73F9C4-ED55-455D-84BD-35AD1D77D1FC'
                        },
                        {
                            name: 'Group',
                            Id: 58,
                            nameId: '4AE6B62B-B981-496D-8A4A-41B9B475A983',
                            frame: { width: 670, height: 112, x: 40, y: 548 },
                            layers: [
                                {
                                    name: 'Mask',
                                    Id: 60,
                                    nameId: 'E3AD0A21-6484-4AD8-A509-B91CB2C283DC',
                                    frame: { width: 112, height: 112, x: 228, y: 548 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 61,
                                            nameId: '7119CEC9-E598-4007-A29C-95DDF69881D2',
                                            frame: { width: 112, height: 112, x: 228, y: 548 },
                                            styles: { backgroundColor: 'rgba(234,234,234,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 62,
                                            nameId: 'CFCEC4F9-DA59-4FDD-A535-000B47BEA84C',
                                            frame: { width: 70, height: 84, x: 248, y: 564 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB16e5_pAyWBuNjy0FpXXassXXa-70-84.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'E3AD0A21-6484-4AD8-A509-B91CB2C283DC'
                                },
                                {
                                    name: 'Mask',
                                    Id: 64,
                                    nameId: '8EB26416-51CE-4B70-8AF4-7B6B6CB32C99',
                                    frame: { width: 112, height: 112, x: 40, y: 548 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 65,
                                            nameId: '95AC1B81-7C0A-475F-83C0-DF9E86C0A4AF',
                                            frame: { width: 112, height: 112, x: 40, y: 548 },
                                            styles: { backgroundColor: 'rgba(245,239,232,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 66,
                                            nameId: 'A28B2638-458E-42B0-9516-E7F5CA4DA7AF',
                                            frame: { width: 66, height: 90, x: 62, y: 570 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1gz5HprGYBuNjy0FoXXciBFXa-66-90.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '8EB26416-51CE-4B70-8AF4-7B6B6CB32C99'
                                },
                                {
                                    name: 'Mask',
                                    Id: 68,
                                    nameId: 'F0F0AAA8-E5F5-4E8D-AC7A-FFC42D793467',
                                    frame: { width: 112, height: 112, x: 422, y: 548 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 69,
                                            nameId: '2675486A-3C30-4F8B-8E5B-0F15B9603A75',
                                            frame: { width: 112, height: 112, x: 422, y: 548 },
                                            styles: { backgroundColor: 'rgba(244,232,226,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 70,
                                            nameId: 'BFBF294F-844D-42F9-B638-C91A362628E9',
                                            frame: { width: 88, height: 94, x: 446, y: 564 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB12H.npCtYBeNjSspkXXbU8VXa-88-94.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'F0F0AAA8-E5F5-4E8D-AC7A-FFC42D793467'
                                },
                                {
                                    name: 'Mask',
                                    Id: 72,
                                    nameId: '08C34AC3-5F7E-4A77-A1A1-FB22E10C8FDA',
                                    frame: { width: 112, height: 112, x: 598, y: 548 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 73,
                                            nameId: '2D864F6D-3C1B-4BE8-A579-2CACDDE08355',
                                            frame: { width: 112, height: 112, x: 598, y: 548 },
                                            styles: { backgroundColor: 'rgba(235,235,235,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 74,
                                            nameId: '77794411-8CFD-4A6A-B4D4-3A316B222B46',
                                            frame: { width: 94, height: 94, x: 610, y: 566 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1TsmApv9TBuNjy0FcXXbeiFXa-94-94.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '08C34AC3-5F7E-4A77-A1A1-FB22E10C8FDA'
                                }
                            ],
                            type: 'group',
                            objectID: '4AE6B62B-B981-496D-8A4A-41B9B475A983'
                        },
                        {
                            name: 'Group',
                            Id: 76,
                            nameId: '26E2ACC8-00C1-4AF0-8DC5-11BA7C08DA63',
                            frame: { width: 484, height: 40, x: 212, y: 670 },
                            layers: [
                                {
                                    name: '卖智能设备',
                                    Id: 77,
                                    nameId: 'CACCD988-48EB-4317-8352-AF0C39513EBD',
                                    frame: { width: 140, height: 40, x: 212, y: 670 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖智能设备',
                                    type: 'text'
                                },
                                {
                                    name: '卖运动器材',
                                    Id: 78,
                                    nameId: 'B75E35E8-B51E-4B47-84A6-CBC300C748EF',
                                    frame: { width: 140, height: 40, x: 408, y: 670 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖运动器材',
                                    type: 'text'
                                },
                                {
                                    name: '卖乐器',
                                    Id: 79,
                                    nameId: '0C5EBCBB-FD28-4BF3-A10B-8290F33BF41A',
                                    frame: { width: 84, height: 40, x: 612, y: 670 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖乐器',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '26E2ACC8-00C1-4AF0-8DC5-11BA7C08DA63'
                        },
                        {
                            name: '卖家具家电',
                            Id: 80,
                            nameId: '0F677FC8-78C6-4587-A30D-70A9D10EDD9B',
                            frame: { width: 140, height: 40, x: 26, y: 670 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '卖家具家电',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '68F04E8A-0515-4B93-AC77-8C6DC3CBFAE0'
                }
            ],
            type: 'group',
            objectID: '391C531D-74DA-4022-A4B8-67B7747F2BD2'
        },
        {
            name: 'Rectangle 64',
            Id: 82,
            nameId: '396F3CBF-F603-487F-9ACC-06F1BB42C69E',
            frame: { width: 750, height: 88, x: 0, y: 740 },
            layers: [
                {
                    name: 'Rectangle 64',
                    Id: 83,
                    nameId: '6FDF9B91-E212-4816-A537-7BE3CCCEA876',
                    frame: { width: 750, height: 88, x: 0, y: 740 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 85,
                    nameId: 'C229D149-85C6-4D23-B02D-C46197960B74',
                    frame: { width: 690, height: 56, x: 30, y: 756 },
                    layers: [
                        {
                            name: 'Rectangle 12',
                            Id: 86,
                            nameId: '132F3FAF-BB6F-45D5-BC0A-4CCB1E9F4EB6',
                            frame: { width: 56, height: 56, x: 30, y: 756 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1ZcfopxSYBuNjSspjXXX73VXa-56-56.png'
                        },
                        {
                            name: '卖了iPhone 7，赚了',
                            Id: 87,
                            nameId: 'F5C46A89-3512-4E2F-A94F-98D93B5D178A',
                            frame: { width: 235, height: 37, x: 106, y: 766 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '26',
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '卖了iPhone 7，赚了',
                            type: 'text'
                        },
                        {
                            name: 'tag_tangzhu copy 35',
                            Id: 88,
                            nameId: '043A9989-00A1-4121-AE56-0D7D0E20CC19',
                            frame: { width: 148, height: 28, x: 436, y: 770 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1G1i0puSSBuNjy0FlXXbBpVXa-148-28.png'
                        },
                        {
                            name: '3分钟前',
                            Id: 89,
                            nameId: '04C9ED4F-AB7D-4F41-98F4-363651047D88',
                            frame: { width: 72, height: 28, x: 648, y: 770 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '20',
                                color: '#888888',
                                textAlign: 'right',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '3分钟前',
                            type: 'text'
                        },
                        {
                            name: '￥2654',
                            Id: 90,
                            nameId: 'D4698988-F387-498B-8999-30A0165AE5A5',
                            frame: { width: 89, height: 37, x: 342, y: 766 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '26',
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥2654',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'C229D149-85C6-4D23-B02D-C46197960B74'
                }
            ],
            type: 'group',
            objectID: '396F3CBF-F603-487F-9ACC-06F1BB42C69E'
        },
        {
            name: 'Rectangle 5 Copy 6',
            Id: 91,
            nameId: '9F8FD881-3875-42A2-83BB-36042F67991B',
            frame: { width: 750, height: 10, x: 0, y: 828 },
            styles: { backgroundColor: 'rgba(243,245,249,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle 5 Copy 8',
            Id: 92,
            nameId: 'C979283F-C9E0-4569-A228-88E31BF379F1',
            frame: { width: 750, height: 10, x: 0, y: 1296 },
            styles: { backgroundColor: 'rgba(243,245,249,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle 5 Copy 5',
            Id: 94,
            nameId: '7DD7CCC0-7A3F-4310-922D-ABAD99998370',
            frame: { width: 750, height: 88, x: 0, y: 848 },
            layers: [
                {
                    name: 'Rectangle 5 Copy 5',
                    Id: 95,
                    nameId: '898832C8-4AC9-4AF9-BB4D-F4E7E49C981D',
                    frame: { width: 750, height: 88, x: 0, y: 848 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 97,
                    nameId: '764E7FE2-90FE-4B1D-A852-5F2A7943CC8C',
                    frame: { width: 276, height: 50, x: 30, y: 870 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 98,
                            nameId: '4D4D96F9-7C0F-4CBD-82CD-9CFEB63C1F5C',
                            frame: { width: 40, height: 40, x: 266, y: 872 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1WXWCpuuSBuNjSsplXXbe8pXa-40-40.png'
                        },
                        {
                            name: '今日品牌速卖',
                            Id: 99,
                            nameId: '9C922BB4-EF82-459A-B450-85D0CA4FEDEE',
                            frame: { width: 217, height: 50, x: 30, y: 870 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '36',
                                color: '#222222',
                                lineHeight: '50',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '今日品牌速卖',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '764E7FE2-90FE-4B1D-A852-5F2A7943CC8C'
                }
            ],
            type: 'group',
            objectID: '7DD7CCC0-7A3F-4310-922D-ABAD99998370'
        },
        {
            name: 'Rectangle 5 Copy 7',
            Id: 100,
            nameId: 'E7C6389F-D731-44E3-95EF-B3E0B657FCA0',
            frame: { width: 750, height: 10, x: 0, y: 838 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle 4',
            Id: 102,
            nameId: 'EFD5A3C9-0B7B-494E-9E6A-BB04B91EEAEE',
            frame: { width: 822, height: 360, x: 0, y: 936 },
            layers: [
                {
                    name: 'Rectangle 4',
                    Id: 103,
                    nameId: '8B086EEA-10FE-4C40-99DB-1973886D19C3',
                    frame: { width: 750, height: 360, x: 0, y: 936 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 105,
                    nameId: '2DB7BDFC-F419-4B7C-9537-F891B17CBFB0',
                    frame: { width: 758, height: 128, x: 42, y: 956 },
                    layers: [
                        {
                            name: 'Mask',
                            Id: 107,
                            nameId: '016F7252-EE66-4E22-9168-7194B35CF4B1',
                            frame: { width: 128, height: 128, x: 42, y: 956 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 109,
                                    nameId: '856A7580-EAC5-4FBA-82F3-6B2F1238AA0A',
                                    frame: { width: 102, height: 128, x: 56, y: 956 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1FaDKpxGYBuNjy0FnXXX5lpXa-102-128.png'
                                }
                            ],
                            type: 'group',
                            objectID: '016F7252-EE66-4E22-9168-7194B35CF4B1'
                        },
                        {
                            name: 'Mask',
                            Id: 111,
                            nameId: '2B298624-02D7-4243-AAE0-F5E8BC9D2E92',
                            frame: { width: 128, height: 128, x: 252, y: 956 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 113,
                                    nameId: '79ED42A6-208D-4ABB-9EC4-C60B62EE8644',
                                    frame: { width: 128, height: 96, x: 252, y: 974 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1gcMnpCtYBeNjSspkXXbU8VXa-128-96.png'
                                }
                            ],
                            type: 'group',
                            objectID: '2B298624-02D7-4243-AAE0-F5E8BC9D2E92'
                        },
                        {
                            name: 'Bitmap',
                            Id: 114,
                            nameId: '4D12F45A-2E3F-4D3E-B493-C8E4E595E08C',
                            frame: { width: 170, height: 126, x: 442, y: 958 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1_VYypv1TBuNjy0FjXXajyXXa-170-126.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 115,
                            nameId: 'A1C51F8F-64F2-426C-A304-EC09768F2E14',
                            frame: { width: 122, height: 86, x: 678, y: 976 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB18Dfipv5TBuNjSspmXXaDRVXa-122-86.png'
                        }
                    ],
                    type: 'group',
                    objectID: '2DB7BDFC-F419-4B7C-9537-F891B17CBFB0'
                },
                {
                    name: 'Group',
                    Id: 117,
                    nameId: 'C7620F17-7FA1-458A-A991-9A01C575AF0C',
                    frame: { width: 772, height: 40, x: 36, y: 1100 },
                    layers: [
                        {
                            name: '小白摄像头',
                            Id: 118,
                            nameId: '94E7DCA4-9F16-4FAA-8B23-BE86BD2FF7C4',
                            frame: { width: 140, height: 40, x: 36, y: 1100 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '28',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '40',
                                fontWeight: 'bold'
                            },
                            value: '小白摄像头',
                            type: 'text'
                        },
                        {
                            name: '小米扫地机',
                            Id: 119,
                            nameId: 'B2943ADB-59DF-4AB6-9B85-17382B0F027E',
                            frame: { width: 140, height: 40, x: 246, y: 1100 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '28',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '40',
                                fontWeight: 'bold'
                            },
                            value: '小米扫地机',
                            type: 'text'
                        },
                        {
                            name: '小米Note2',
                            Id: 120,
                            nameId: 'E28DBD5F-E40A-4889-BCF8-86769DFA9238',
                            frame: { width: 136, height: 40, x: 460, y: 1100 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '28',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '40',
                                fontWeight: 'bold'
                            },
                            value: '小米Note2',
                            type: 'text'
                        },
                        {
                            name: '小米Note2',
                            Id: 121,
                            nameId: '5DB50886-2552-41C7-889B-0C72745EAE61',
                            frame: { width: 136, height: 40, x: 672, y: 1100 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '28',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '40',
                                fontWeight: 'bold'
                            },
                            value: '小米Note2',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'C7620F17-7FA1-458A-A991-9A01C575AF0C'
                },
                {
                    name: 'Group',
                    Id: 123,
                    nameId: '873C0DE9-B91A-4DDC-A4B8-1B75186C47F9',
                    frame: { width: 792, height: 37, x: 30, y: 1146 },
                    layers: [
                        {
                            name: '最高价',
                            Id: 124,
                            nameId: '27427980-63A6-4E9D-9855-8B8A6AAA74E0',
                            frame: { width: 79, height: 37, x: 30, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '26',
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '最高价',
                            type: 'text'
                        },
                        {
                            name: '￥254',
                            Id: 125,
                            nameId: 'D521FD72-E5F9-4EDC-ACB5-D838CD93C5AC',
                            frame: { width: 73, height: 37, x: 110, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '26',
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥254',
                            type: 'text'
                        },
                        {
                            name: '最高价',
                            Id: 126,
                            nameId: '00EF116B-E057-41F6-AD6D-8AD83D3C9AD9',
                            frame: { width: 79, height: 37, x: 232, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '26',
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '最高价',
                            type: 'text'
                        },
                        {
                            name: '￥1200',
                            Id: 127,
                            nameId: 'F3ACBBC0-6CF1-4EE6-9233-FAC8E9B89B1E',
                            frame: { width: 84, height: 37, x: 312, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '26',
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥1200',
                            type: 'text'
                        },
                        {
                            name: '最高价',
                            Id: 128,
                            nameId: '21C1DDAA-9628-4576-AA8B-7134CE1563EF',
                            frame: { width: 79, height: 37, x: 446, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '26',
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '最高价',
                            type: 'text'
                        },
                        {
                            name: '￥1200',
                            Id: 129,
                            nameId: '21FD312F-426A-4EC6-A340-8870565213B9',
                            frame: { width: 84, height: 37, x: 526, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '26',
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥1200',
                            type: 'text'
                        },
                        {
                            name: '最高价',
                            Id: 130,
                            nameId: '02501017-ECB7-4BFD-9855-89E696EB6F12',
                            frame: { width: 79, height: 37, x: 658, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '26',
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '最高价',
                            type: 'text'
                        },
                        {
                            name: '￥1200',
                            Id: 131,
                            nameId: '8A5A239E-5BCF-4A73-B964-1AD0DA80F555',
                            frame: { width: 84, height: 37, x: 738, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '26',
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥1200',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '873C0DE9-B91A-4DDC-A4B8-1B75186C47F9'
                },
                {
                    name: 'Group',
                    Id: 133,
                    nameId: 'D93D4532-399D-4A4E-8729-CC9C25E42FC3',
                    frame: { width: 778, height: 64, x: 34, y: 1202 },
                    layers: [
                        {
                            name: 'Rectangle',
                            Id: 135,
                            nameId: '17D94ADD-54ED-4496-9762-E236F76CCFF2',
                            frame: { width: 144, height: 64, x: 34, y: 1202 },
                            layers: [
                                {
                                    name: 'Rectangle',
                                    Id: 136,
                                    nameId: '2EC4B1E1-035C-4131-A89A-DC8435376596',
                                    frame: { width: 144, height: 64, x: 34, y: 1202 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB121C0puSSBuNjy0FlXXbBpVXa-144-64.png'
                                },
                                {
                                    name: '立即速卖',
                                    Id: 137,
                                    nameId: 'BEC272F1-481A-4F52-93F7-65AA92E5CE2D',
                                    frame: { width: 112, height: 40, x: 50, y: 1214 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '28',
                                        color: '#FFFFFF',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'bold'
                                    },
                                    value: '立即速卖',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '17D94ADD-54ED-4496-9762-E236F76CCFF2'
                        },
                        {
                            name: 'Rectangle',
                            Id: 139,
                            nameId: 'F09FA56A-85ED-47BD-B7E2-E6D1454F0DC2',
                            frame: { width: 144, height: 64, x: 244, y: 1202 },
                            layers: [
                                {
                                    name: 'Rectangle',
                                    Id: 140,
                                    nameId: '89C34EC8-CC5B-4990-8457-3A6C404124BA',
                                    frame: { width: 144, height: 64, x: 244, y: 1202 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1.eC0puSSBuNjy0FlXXbBpVXa-144-64.png'
                                },
                                {
                                    name: '立即速卖',
                                    Id: 141,
                                    nameId: '124B59AB-8907-463B-A003-E5A73F0F4C13',
                                    frame: { width: 112, height: 40, x: 260, y: 1214 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '28',
                                        color: '#FFFFFF',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'bold'
                                    },
                                    value: '立即速卖',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'F09FA56A-85ED-47BD-B7E2-E6D1454F0DC2'
                        },
                        {
                            name: 'Rectangle',
                            Id: 143,
                            nameId: '4615C081-6BDB-4E23-850E-CD984635DED4',
                            frame: { width: 144, height: 64, x: 456, y: 1202 },
                            layers: [
                                {
                                    name: 'Rectangle',
                                    Id: 144,
                                    nameId: 'A23788EE-F3C7-47E6-B680-A5C1A4DBDDAE',
                                    frame: { width: 144, height: 64, x: 456, y: 1202 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1_IbnpACWBuNjy0FaXXXUlXXa-144-64.png'
                                },
                                {
                                    name: '立即速卖',
                                    Id: 145,
                                    nameId: '5F4547D7-872D-4795-84D9-BC5356914B54',
                                    frame: { width: 112, height: 40, x: 472, y: 1214 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '28',
                                        color: '#FFFFFF',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'bold'
                                    },
                                    value: '立即速卖',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '4615C081-6BDB-4E23-850E-CD984635DED4'
                        },
                        {
                            name: 'Rectangle',
                            Id: 147,
                            nameId: 'EAF96D27-77E4-4051-9570-63E309795AE4',
                            frame: { width: 144, height: 64, x: 668, y: 1202 },
                            layers: [
                                {
                                    name: 'Rectangle',
                                    Id: 148,
                                    nameId: '9EEC3A47-7D9D-4023-9ACD-562C3DFAF15C',
                                    frame: { width: 144, height: 64, x: 668, y: 1202 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1vqiCpuuSBuNjSsplXXbe8pXa-144-64.png'
                                },
                                {
                                    name: '立即速卖',
                                    Id: 149,
                                    nameId: '480CF494-B430-43C7-BFF6-E9E4C38E1C92',
                                    frame: { width: 112, height: 40, x: 684, y: 1214 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '28',
                                        color: '#FFFFFF',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'bold'
                                    },
                                    value: '立即速卖',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'EAF96D27-77E4-4051-9570-63E309795AE4'
                        }
                    ],
                    type: 'group',
                    objectID: 'D93D4532-399D-4A4E-8729-CC9C25E42FC3'
                }
            ],
            type: 'group',
            objectID: 'EFD5A3C9-0B7B-494E-9E6A-BB04B91EEAEE'
        },
        {
            name: 'Rectangle 5 Copy 5',
            Id: 150,
            nameId: '6188151D-94CB-4BD5-8A8B-AAE056ECDCA4',
            frame: { width: 750, height: 88, x: 0, y: 1316 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle 5 Copy 7',
            Id: 151,
            nameId: '405E0988-542E-4A49-9195-6BAC4D0D0442',
            frame: { width: 750, height: 10, x: 0, y: 1306 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle Copy 2',
            Id: 153,
            nameId: '5CD6D56D-4EE3-4B40-92CC-5E101D4FE851',
            frame: { width: 750, height: 40, x: 0, y: 0 },
            layers: [
                {
                    name: 'Rectangle Copy 2',
                    Id: 154,
                    nameId: 'D32B18FC-7152-4F7F-A993-3E7B13B5656A',
                    frame: { width: 750, height: 40, x: 0, y: 0 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 156,
                    nameId: '54000474-A52B-4463-95E0-FE9F39E8775F',
                    frame: { width: 725, height: 28, x: 14, y: 8 },
                    layers: [
                        {
                            name: 'Battery',
                            Id: 157,
                            nameId: '5D3B298F-FBD1-4C6B-ABEE-FC79478EB245',
                            frame: { width: 49, height: 19, x: 690, y: 10 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1jBCWppOWBuNjy0FiXXXFxVXa-49-19.png'
                        },
                        {
                            name: '100%',
                            Id: 158,
                            nameId: '6B04FCAD-F5F1-4BC9-856A-2F52479728A1',
                            frame: { width: 66, height: 28, x: 618, y: 8 },
                            textStyles: {
                                fontFamily: '.SFNSDisplay',
                                fontSize: '24',
                                color: '#000000',
                                textAlign: 'right',
                                lineHeight: '28',
                                maxWidth: 66,
                                maxHeight: 28,
                                fontWeight: 'normal'
                            },
                            value: '100%',
                            type: 'text'
                        },
                        {
                            name: 'Wi-Fi',
                            Id: 159,
                            nameId: '0598F7B3-8090-4F1C-8B11-E93B96FE8ED6',
                            frame: { width: 26, height: 18, x: 176, y: 10 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1Hui3ppuWBuNjSspnXXX1NVXa-26-18.png'
                        },
                        {
                            name: 'Mobile Signal',
                            Id: 160,
                            nameId: '136A4A72-8E7F-48F4-B884-DB84CDC99419',
                            frame: { width: 67, height: 11, x: 14, y: 14 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1qGTypv1TBuNjy0FjXXajyXXa-67-11.png'
                        }
                    ],
                    type: 'group',
                    objectID: '54000474-A52B-4463-95E0-FE9F39E8775F'
                }
            ],
            type: 'group',
            objectID: '5CD6D56D-4EE3-4B40-92CC-5E101D4FE851'
        }
    ],
    nameId: 1525328642304,
    Id: 1,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 1334 },
    styles: { backgroundColor: 'rgba(255,255,255,1)' }
};
