"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Rectangle Copy',
            Id: 133,
            nameId: '1BD5BF47-04D3-4274-9B60-2245B64B5FE3',
            frame: { width: 750, height: 88, x: 0, y: 40 },
            layers: [
                {
                    name: 'Rectangle Copy',
                    Id: 134,
                    nameId: 'F385876D-7A16-487E-A9D6-454932DA1C3A',
                    frame: { width: 750, height: 88, x: 0, y: 40 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 136,
                    nameId: 'FA51E8C6-9FF4-4E6D-8FA3-3D2190023D28',
                    frame: { width: 412, height: 48, x: 32, y: 62 },
                    layers: [
                        {
                            name: '确认订单',
                            Id: 137,
                            nameId: 'E460395B-0828-48D6-A041-5F5D0EACD68B',
                            frame: { width: 136, height: 48, x: 308, y: 62 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '34',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '48',
                                fontWeight: 'bold'
                            },
                            value: '确认订单',
                            type: 'text'
                        },
                        {
                            name: 'ic_backarrow',
                            Id: 138,
                            nameId: 'D26764DF-2852-40A1-9F2B-E67DE24F0B81',
                            frame: { width: 40, height: 40, x: 32, y: 64 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1wninpVOWBuNjy0FiXXXFxVXa-40-40.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'FA51E8C6-9FF4-4E6D-8FA3-3D2190023D28'
                }
            ],
            type: 'group',
            objectID: '1BD5BF47-04D3-4274-9B60-2245B64B5FE3'
        },
        {
            name: 'Rectangle 11',
            Id: 140,
            nameId: 'E0606032-59FE-49D2-AFA2-8400683CD196',
            frame: { width: 750, height: 112, x: 0, y: 128 },
            layers: [
                {
                    name: 'Rectangle 11',
                    Id: 141,
                    nameId: 'D19CCA48-3F38-478A-8D7D-87A421AFAC27',
                    frame: { width: 750, height: 112, x: 0, y: 128 },
                    styles: { backgroundColor: 'rgba(255,248,217,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 143,
                    nameId: '53AC4861-B952-488C-9A39-084F558F1A6D',
                    frame: { width: 610, height: 44, x: 32, y: 164 },
                    layers: [
                        {
                            name: 'ic_smile',
                            Id: 144,
                            nameId: '5DD05F8B-02CA-4712-8389-70D834758CA6',
                            frame: { width: 40, height: 40, x: 32, y: 164 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1qBO4p21TBuNjy0FjXXajyXXa-40-40.png'
                        },
                        {
                            name: '恭喜您通过评估！可享受',
                            Id: 145,
                            nameId: '15D8B5DD-9C24-4DBA-B619-FA9D8FD90403',
                            frame: { width: 308, height: 40, x: 88, y: 164 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#888888',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '恭喜您通过评估！可享受',
                            type: 'text'
                        },
                        {
                            name: '芝麻信用·先拿钱',
                            Id: 146,
                            nameId: 'F23C7018-9EC5-4950-835C-DBEE5415163B',
                            frame: { width: 210, height: 40, x: 432, y: 168 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#1CCFC9',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '芝麻信用·先拿钱',
                            type: 'text'
                        },
                        {
                            name: 'Fill 1',
                            Id: 148,
                            nameId: 'CFFF6B8A-9BF5-4CE4-A768-EAEA27715AE8',
                            frame: { width: 24, height: 28, x: 404, y: 170 },
                            layers: [
                                {
                                    name: 'Fill 1',
                                    Id: 149,
                                    nameId: '2293FAB9-1BE2-4550-B354-097F7FC61A36',
                                    frame: { width: 23.97898916967506, height: 27.994327328004147, x: 404, y: 170.00008562691164 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1sCPepWmWBuNjy1XaXXXCbXXa-24-28.png'
                                },
                                {
                                    name: 'Fill 4',
                                    Id: 150,
                                    nameId: '57DAA9ED-84B2-4E58-9EB5-D270012440FE',
                                    frame: { width: 7, height: 17, x: 405.9690028075295, y: 174.61401834862409 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1gSCVpY9YBuNjy0FgXXcxcXXa-7-17.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'CFFF6B8A-9BF5-4CE4-A768-EAEA27715AE8'
                        }
                    ],
                    type: 'group',
                    objectID: '53AC4861-B952-488C-9A39-084F558F1A6D'
                }
            ],
            type: 'group',
            objectID: 'E0606032-59FE-49D2-AFA2-8400683CD196'
        },
        {
            name: 'Rectangle Copy 2',
            Id: 152,
            nameId: 'CCCE30D9-25CF-4F0C-AED4-B614E39D186B',
            frame: { width: 750, height: 41, x: 0, y: 0 },
            layers: [
                {
                    name: 'Rectangle Copy 2',
                    Id: 153,
                    nameId: '109EE4B8-D6D1-4DDE-9D89-A71AFDC1D342',
                    frame: { width: 750, height: 40, x: 0, y: 0 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 155,
                    nameId: '71288524-5000-40F9-BB9A-E4A860B3E0AD',
                    frame: { width: 725, height: 33, x: 14, y: 8 },
                    layers: [
                        {
                            name: 'Battery',
                            Id: 156,
                            nameId: '686C2A13-8ECF-450A-B726-0BE93F8B7D76',
                            frame: { width: 49, height: 19, x: 690, y: 10 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1KSPepWmWBuNjy1XaXXXCbXXa-49-19.png'
                        },
                        {
                            name: '100%',
                            Id: 157,
                            nameId: '48D7F848-250A-4625-9D4D-B1C700E055E9',
                            frame: { width: 66, height: 28, x: 618, y: 8 },
                            textStyles: {
                                fontFamily: '.SFNSDisplay',
                                fontSize: '24',
                                color: '#000000',
                                textAlign: 'right',
                                lineHeight: '28',
                                maxWidth: 66,
                                maxHeight: 28,
                                fontWeight: 'normal'
                            },
                            value: '100%',
                            type: 'text'
                        },
                        {
                            name: 'Time',
                            Id: 158,
                            nameId: '3F339911-696F-4494-822C-AA8BC5FBAB27',
                            frame: { width: 90, height: 33, x: 330, y: 8 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '24',
                                color: '#000000',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'normal'
                            },
                            value: '9:41 AM',
                            type: 'text'
                        },
                        {
                            name: 'Wi-Fi',
                            Id: 159,
                            nameId: 'FEACA7B4-9AB5-4585-A9FF-08FD8CD17D5E',
                            frame: { width: 26, height: 18, x: 176, y: 10 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1d_mnpVOWBuNjy0FiXXXFxVXa-26-18.png'
                        },
                        {
                            name: 'Carrier',
                            Id: 160,
                            nameId: 'CF2E8784-725B-4084-AE64-01121E011936',
                            frame: { width: 86, height: 33, x: 88, y: 8 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '24',
                                color: '#000000',
                                textAlign: 'left',
                                lineHeight: '33',
                                fontWeight: 'normal'
                            },
                            value: 'SanityD',
                            type: 'text'
                        },
                        {
                            name: 'Mobile Signal',
                            Id: 161,
                            nameId: '627D4865-D0C1-4E5A-95F3-B1CD7EB1440A',
                            frame: { width: 67, height: 11, x: 14, y: 14 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1CSCVpY9YBuNjy0FgXXcxcXXa-67-11.png'
                        }
                    ],
                    type: 'group',
                    objectID: '71288524-5000-40F9-BB9A-E4A860B3E0AD'
                }
            ],
            type: 'group',
            objectID: 'CCCE30D9-25CF-4F0C-AED4-B614E39D186B'
        },
        {
            name: 'Rectangle 5',
            Id: 163,
            nameId: '70A4276D-022F-4647-9A23-1315518259BF',
            frame: { width: 750, height: 56, x: 0, y: 260 },
            layers: [
                {
                    name: 'Rectangle 5',
                    Id: 164,
                    nameId: '24BB6326-315C-45A2-9F77-760E407F7318',
                    frame: { width: 750, height: 56, x: 0, y: 260 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 166,
                    nameId: '9C643DD3-6035-465F-9D07-7DFA2B5030A6',
                    frame: { width: 312, height: 45, x: 30, y: 266 },
                    layers: [
                        {
                            name: '（免运费）',
                            Id: 167,
                            nameId: '37D1CAD0-0790-4F68-AFD9-58CA54EDB442',
                            frame: { width: 120, height: 33, x: 222, y: 276 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '24',
                                color: '#888888',
                                lineHeight: '33',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '（免运费）',
                            type: 'text'
                        },
                        {
                            name: '顺丰上门取件',
                            Id: 168,
                            nameId: 'D1E5CA48-EC40-4F59-9EC8-3B5405F0A20D',
                            frame: { width: 192, height: 45, x: 30, y: 266 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '32',
                                color: '#222222',
                                lineHeight: '45',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '顺丰上门取件',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '9C643DD3-6035-465F-9D07-7DFA2B5030A6'
                }
            ],
            type: 'group',
            objectID: '70A4276D-022F-4647-9A23-1315518259BF'
        },
        {
            name: 'Rectangle 5 Copy 5',
            Id: 169,
            nameId: '9CB84CF9-5557-498B-B474-07126AC04FF4',
            frame: { width: 750, height: 20, x: 0, y: 240 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle 68',
            Id: 171,
            nameId: 'E55F4E74-EB08-4E08-95BD-751FF86443A6',
            frame: { width: 750, height: 88, x: 0, y: 316 },
            layers: [
                {
                    name: 'Rectangle 68',
                    Id: 172,
                    nameId: 'ACE97095-FE9B-43A4-910E-6F4982CDF47B',
                    frame: { width: 750, height: 88, x: 0, y: 316 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 174,
                    nameId: '07A03AF2-AD02-4A47-9647-0DFA02048E47',
                    frame: { width: 720, height: 88, x: 30, y: 316 },
                    layers: [
                        {
                            name: 'ic_shiren',
                            Id: 175,
                            nameId: 'ED996FA7-80B1-4535-AF76-09E253303F98',
                            frame: { width: 32, height: 32, x: 30, y: 344 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1wTmnpVOWBuNjy0FiXXXFxVXa-32-32.png'
                        },
                        {
                            name: 'Rectangle Copy',
                            Id: 177,
                            nameId: 'D02AED5F-7825-4D48-B5FD-900D09648A0D',
                            frame: { width: 658, height: 88, x: 92, y: 316 },
                            layers: [
                                {
                                    name: 'Rectangle Copy',
                                    Id: 178,
                                    nameId: '73C8952A-900A-4D26-BD89-C0502058E2B0',
                                    frame: { width: 657.9999999999994, height: 88, x: 92, y: 316 },
                                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                                    type: 'shape'
                                },
                                {
                                    name: 'Group',
                                    Id: 180,
                                    nameId: '3A6D4E44-BF9F-4FF3-ACAA-291879A7347E',
                                    frame: { width: 628, height: 42, x: 92, y: 338 },
                                    layers: [
                                        {
                                            name: 'Rectangle 4',
                                            Id: 182,
                                            nameId: 'D441D4EA-78BC-4B7B-B769-5B0E930014EB',
                                            frame: { width: 32, height: 32, x: 688, y: 344 },
                                            layers: [
                                                {
                                                    name: 'Combined Shape',
                                                    Id: 183,
                                                    nameId: '3BAF8C67-0924-4022-9993-20C9419B7994',
                                                    frame: { width: 14, height: 24, x: 697.8033008588991, y: 348.1066017177982 },
                                                    imageStyles: { resize: 'stretch' },
                                                    type: 'image',
                                                    value: 'https://gw.alicdn.com/tfs/TB1tzCCp7yWBuNjy0FpXXassXXa-14-24.png'
                                                }
                                            ],
                                            type: 'group',
                                            objectID: 'D441D4EA-78BC-4B7B-B769-5B0E930014EB'
                                        },
                                        {
                                            name: '预约取件时间',
                                            Id: 184,
                                            nameId: 'ABF6148C-F4CD-4B0D-839C-91406AD17B18',
                                            frame: { width: 180, height: 42, x: 92, y: 338 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Medium',
                                                fontSize: '30',
                                                color: '#D5A458',
                                                lineHeight: '42',
                                                textAlign: 'left',
                                                fontWeight: 'bold'
                                            },
                                            value: '预约取件时间',
                                            type: 'text'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '3A6D4E44-BF9F-4FF3-ACAA-291879A7347E'
                                }
                            ],
                            type: 'group',
                            objectID: 'D02AED5F-7825-4D48-B5FD-900D09648A0D'
                        }
                    ],
                    type: 'group',
                    objectID: '07A03AF2-AD02-4A47-9647-0DFA02048E47'
                }
            ],
            type: 'group',
            objectID: 'E55F4E74-EB08-4E08-95BD-751FF86443A6'
        },
        {
            name: 'Rectangle 68',
            Id: 186,
            nameId: 'EC412009-4B59-4B0D-AF69-E902DFF784A3',
            frame: { width: 750, height: 128, x: 0, y: 404 },
            layers: [
                {
                    name: 'Rectangle 68',
                    Id: 187,
                    nameId: '1759B5BE-ACB5-416A-BD0F-EB6987782390',
                    frame: { width: 750, height: 128, x: 0, y: 404 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 189,
                    nameId: 'BB69C3CD-04D9-4F1B-B660-C4F3D5EEB773',
                    frame: { width: 690, height: 90, x: 30, y: 422 },
                    layers: [
                        {
                            name: 'ic_shiren',
                            Id: 190,
                            nameId: 'D75694F3-3AEC-4A57-8873-D7FCFC8C4FD2',
                            frame: { width: 32, height: 32, x: 30, y: 428 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1q5Lbp49YBuNjy0FfXXXIsVXa-32-32.png'
                        },
                        {
                            name: 'Group',
                            Id: 192,
                            nameId: '2098AACF-D1ED-4287-B580-4472C4070D32',
                            frame: { width: 516, height: 90, x: 92, y: 422 },
                            layers: [
                                {
                                    name: 'Group',
                                    Id: 194,
                                    nameId: '4E67ABFD-0425-4FAA-AC6F-8B707520CD41',
                                    frame: { width: 449, height: 42, x: 92, y: 422 },
                                    layers: [
                                        {
                                            name: '取件地址：王二小',
                                            Id: 195,
                                            nameId: 'E01018C6-E77E-454A-9260-05F4FB144211',
                                            frame: { width: 240, height: 42, x: 92, y: 422 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Regular',
                                                fontSize: '30',
                                                color: '#222222',
                                                lineHeight: '42',
                                                textAlign: 'left',
                                                fontWeight: 'normal'
                                            },
                                            value: '取件地址：王二小',
                                            type: 'text'
                                        },
                                        {
                                            name: '18899887766',
                                            Id: 196,
                                            nameId: 'A08FA838-44DA-4B92-8FE0-70E2814CCC92',
                                            frame: { width: 189, height: 42, x: 352, y: 422 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Regular',
                                                fontSize: '30',
                                                color: '#222222',
                                                lineHeight: '42',
                                                textAlign: 'left',
                                                fontWeight: 'normal'
                                            },
                                            value: '18899887766',
                                            type: 'text'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '4E67ABFD-0425-4FAA-AC6F-8B707520CD41'
                                },
                                {
                                    name: '浙江省杭州市文一西路969号6号楼小邮局',
                                    Id: 197,
                                    nameId: '98F6853E-79F5-45E7-AEC6-814635E0B98A',
                                    frame: { width: 516, height: 40, x: 92, y: 472 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#888888',
                                        lineHeight: '40',
                                        textAlign: 'left',
                                        fontWeight: 'normal'
                                    },
                                    value: '浙江省杭州市文一西路969号6号楼小邮局',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '2098AACF-D1ED-4287-B580-4472C4070D32'
                        },
                        {
                            name: 'List_Arrow',
                            Id: 198,
                            nameId: '284F649A-EC07-4636-B2B0-1FF3FDD0D943',
                            frame: { width: 32, height: 32, x: 688, y: 452 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1I6CCp7yWBuNjy0FpXXassXXa-32-32.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'BB69C3CD-04D9-4F1B-B660-C4F3D5EEB773'
                }
            ],
            type: 'group',
            objectID: 'EC412009-4B59-4B0D-AF69-E902DFF784A3'
        },
        {
            name: 'Group 22 Copy',
            Id: 199,
            nameId: 'F61A2B7A-1CFE-41EE-9583-707F63DB1B98',
            frame: { width: 750, height: 20, x: 0, y: 930 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1a9GVpY9YBuNjy0FgXXcxcXXa-750-20.png'
        },
        {
            name: 'Rectangle 68',
            Id: 201,
            nameId: 'DCD68404-908D-4B1C-B896-95A3175ED0F5',
            frame: { width: 750, height: 64, x: 0, y: 802 },
            layers: [
                {
                    name: 'Rectangle 68',
                    Id: 202,
                    nameId: '8ECA48DF-D612-4A03-86ED-868BBDD351CF',
                    frame: { width: 750, height: 64, x: 0, y: 802 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Rectangle Copy',
                    Id: 204,
                    nameId: '5F2B96FD-D595-4F06-B3C9-4DE32ACCF3A7',
                    frame: { width: 720, height: 64, x: 30, y: 802 },
                    layers: [
                        {
                            name: 'Group',
                            Id: 206,
                            nameId: '7A3E0D76-E4BE-450C-BBFC-F899E68680CB',
                            frame: { width: 690, height: 46, x: 30, y: 814 },
                            layers: [
                                {
                                    name: '￥2100',
                                    Id: 207,
                                    nameId: 'EBB5A093-1AD1-433A-82BE-32AF4E29CEDD',
                                    frame: { width: 90, height: 40, x: 630, y: 819.5999999999999 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '28',
                                        color: '#FF4444',
                                        textAlign: 'right',
                                        lineHeight: '40',
                                        maxWidth: 90,
                                        maxHeight: 40,
                                        fontWeight: 'bold'
                                    },
                                    value: '￥2100',
                                    type: 'text'
                                },
                                {
                                    name: '下单后到账预付款',
                                    Id: 208,
                                    nameId: 'D437DB0E-7E92-439E-AA83-40B717BC9720',
                                    frame: { width: 224, height: 40, x: 30, y: 814.4727272727273 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        lineHeight: '40',
                                        textAlign: 'left',
                                        fontWeight: 'normal'
                                    },
                                    value: '下单后到账预付款',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '7A3E0D76-E4BE-450C-BBFC-F899E68680CB'
                        }
                    ],
                    type: 'group',
                    objectID: '5F2B96FD-D595-4F06-B3C9-4DE32ACCF3A7'
                }
            ],
            type: 'group',
            objectID: 'DCD68404-908D-4B1C-B896-95A3175ED0F5'
        },
        {
            name: 'Rectangle 68 Copy',
            Id: 209,
            nameId: '08D081A5-85ED-4968-9D6A-6674B581C1D7',
            frame: { width: 750, height: 10, x: 0, y: 792 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle 68',
            Id: 211,
            nameId: 'EAE32AE0-0BAD-4BA3-A237-5BFD893CEBB7',
            frame: { width: 750, height: 64, x: 0, y: 866 },
            layers: [
                {
                    name: 'Rectangle 68',
                    Id: 212,
                    nameId: '9960293D-4474-41EF-9C66-40F6A6B56DEE',
                    frame: { width: 750, height: 64, x: 0, y: 866 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Rectangle Copy',
                    Id: 214,
                    nameId: '5C0471DC-A4B2-4575-BA1B-1654FC4D8DD6',
                    frame: { width: 720, height: 64, x: 30, y: 866 },
                    layers: [
                        {
                            name: 'Group',
                            Id: 216,
                            nameId: 'EF4B2A94-EEFC-4B5C-A8C3-6546F82196AC',
                            frame: { width: 690, height: 46, x: 30, y: 878 },
                            layers: [
                                {
                                    name: '￥1000',
                                    Id: 217,
                                    nameId: '710CB444-A6E1-41A4-982B-4E2ED978FA08',
                                    frame: { width: 90, height: 40, x: 630, y: 883.5999999999999 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#888888',
                                        textAlign: 'right',
                                        lineHeight: '40',
                                        maxWidth: 90,
                                        maxHeight: 40,
                                        fontWeight: 'normal'
                                    },
                                    value: '￥1000',
                                    type: 'text'
                                },
                                {
                                    name: '收货后支付尾款',
                                    Id: 218,
                                    nameId: '63FF13A1-ABA8-440A-9FC5-D2000DD68C08',
                                    frame: { width: 196, height: 40, x: 30, y: 878.4727272727273 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#888888',
                                        lineHeight: '40',
                                        textAlign: 'left',
                                        fontWeight: 'normal'
                                    },
                                    value: '收货后支付尾款',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'EF4B2A94-EEFC-4B5C-A8C3-6546F82196AC'
                        }
                    ],
                    type: 'group',
                    objectID: '5C0471DC-A4B2-4575-BA1B-1654FC4D8DD6'
                }
            ],
            type: 'group',
            objectID: 'EAE32AE0-0BAD-4BA3-A237-5BFD893CEBB7'
        },
        {
            name: 'Group 22',
            Id: 220,
            nameId: '2E67C94C-2094-49CA-A3D7-DA872068A688',
            frame: { width: 750, height: 82, x: 0, y: 542 },
            layers: [
                {
                    name: 'Group 22',
                    Id: 221,
                    nameId: '6B0B7E13-FE4F-4402-9092-BB0A8CA13CDA',
                    frame: { width: 750, height: 20, x: 0, y: 542 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1NOLbp49YBuNjy0FfXXXIsVXa-750-20.png'
                },
                {
                    name: 'Rectangle 68',
                    Id: 223,
                    nameId: '0D4FEA3F-3D68-4861-9784-93183ABC1573',
                    frame: { width: 750, height: 64, x: 0, y: 560 },
                    layers: [
                        {
                            name: 'Rectangle 68',
                            Id: 224,
                            nameId: 'AACFEC37-E84E-4D0D-AE6B-2EFD26487ECC',
                            frame: { width: 750, height: 64, x: 0, y: 560 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                            type: 'shape'
                        },
                        {
                            name: 'Rectangle Copy',
                            Id: 226,
                            nameId: 'DCF7CABA-83A5-4CCF-8DA4-A29DE3D8A265',
                            frame: { width: 720, height: 64, x: 30, y: 560 },
                            layers: [
                                {
                                    name: 'Group',
                                    Id: 228,
                                    nameId: '56473B87-9C60-4EC6-8C96-3FACA18B04D3',
                                    frame: { width: 690, height: 46, x: 30, y: 572 },
                                    layers: [
                                        {
                                            name: '￥3000',
                                            Id: 229,
                                            nameId: 'A019F501-2783-433A-820B-5E2516200C1D',
                                            frame: { width: 110, height: 40, x: 610, y: 577.5999999999999 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Regular',
                                                fontSize: '28',
                                                color: '#888888',
                                                textAlign: 'right',
                                                lineHeight: '40',
                                                maxWidth: 110,
                                                maxHeight: 40,
                                                fontWeight: 'normal'
                                            },
                                            value: '￥3000',
                                            type: 'text'
                                        },
                                        {
                                            name: '评估价',
                                            Id: 230,
                                            nameId: '88FDF531-900C-4D97-A48E-FC7A26F72E15',
                                            frame: { width: 120, height: 40, x: 30, y: 572.0727272727272 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Regular',
                                                fontSize: '28',
                                                color: '#888888',
                                                lineHeight: '40',
                                                maxWidth: 120,
                                                maxHeight: 40,
                                                textAlign: 'left',
                                                fontWeight: 'normal'
                                            },
                                            value: '评估价',
                                            type: 'text'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '56473B87-9C60-4EC6-8C96-3FACA18B04D3'
                                }
                            ],
                            type: 'group',
                            objectID: 'DCF7CABA-83A5-4CCF-8DA4-A29DE3D8A265'
                        }
                    ],
                    type: 'group',
                    objectID: '0D4FEA3F-3D68-4861-9784-93183ABC1573'
                }
            ],
            type: 'group',
            objectID: '2E67C94C-2094-49CA-A3D7-DA872068A688'
        },
        {
            name: 'Rectangle 68',
            Id: 232,
            nameId: 'D4318BE4-5BEB-4EA8-8FDA-2F65A077CB02',
            frame: { width: 750, height: 64, x: 0, y: 624 },
            layers: [
                {
                    name: 'Rectangle 68',
                    Id: 233,
                    nameId: 'DACEE271-CA85-4115-A397-B350771104E3',
                    frame: { width: 750, height: 64, x: 0, y: 624 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Rectangle Copy',
                    Id: 235,
                    nameId: 'DA42413B-0737-47D0-B386-A415CC845578',
                    frame: { width: 720, height: 64, x: 30, y: 624 },
                    layers: [
                        {
                            name: 'Group',
                            Id: 237,
                            nameId: 'F5B1D251-368E-484B-B2CB-E818D1D00B4D',
                            frame: { width: 690, height: 46, x: 30, y: 636 },
                            layers: [
                                {
                                    name: '￥100',
                                    Id: 238,
                                    nameId: 'E37CFDCD-ECF1-46BB-8F5E-033E4D863B09',
                                    frame: { width: 84, height: 40, x: 636, y: 641.5999999999999 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#888888',
                                        textAlign: 'right',
                                        lineHeight: '40',
                                        maxWidth: 84,
                                        maxHeight: 40,
                                        fontWeight: 'normal'
                                    },
                                    value: '￥100',
                                    type: 'text'
                                },
                                {
                                    name: '使用加价券',
                                    Id: 239,
                                    nameId: 'E56F9ABE-F1E3-41D7-BCCA-A88AF5C16B68',
                                    frame: { width: 140, height: 40, x: 30, y: 636.0727272727272 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#888888',
                                        lineHeight: '40',
                                        textAlign: 'left',
                                        fontWeight: 'normal'
                                    },
                                    value: '使用加价券',
                                    type: 'text'
                                },
                                {
                                    name: 'Group 6',
                                    Id: 240,
                                    nameId: '7FA0AEEC-AB8E-4661-9EE1-C3F5F0AFC1A5',
                                    frame: { width: 40, height: 28, x: 180, y: 642.0727272727272 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1q9GVpY9YBuNjy0FgXXcxcXXa-40-28.png'
                                },
                                {
                                    name: 'Combined Shape',
                                    Id: 241,
                                    nameId: '1CD8E89B-05DF-4EAD-B836-363354718995',
                                    frame: { width: 32, height: 32, x: 240, y: 640.0727272727272 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1ADaXpYGYBuNjy0FoXXciBFXa-32-32.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'F5B1D251-368E-484B-B2CB-E818D1D00B4D'
                        }
                    ],
                    type: 'group',
                    objectID: 'DA42413B-0737-47D0-B386-A415CC845578'
                }
            ],
            type: 'group',
            objectID: 'D4318BE4-5BEB-4EA8-8FDA-2F65A077CB02'
        },
        {
            name: 'Rectangle 68',
            Id: 243,
            nameId: 'B0AB4FD6-A244-4435-913B-4A77745781D3',
            frame: { width: 752, height: 104, x: 0, y: 688 },
            layers: [
                {
                    name: 'Rectangle 68',
                    Id: 244,
                    nameId: '6FF18642-174F-4875-A901-4D8D133AFF80',
                    frame: { width: 750, height: 104, x: 0, y: 688 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Combined Shape',
                    Id: 246,
                    nameId: '42103440-217B-4B1F-9FD6-B1D95855347B',
                    frame: { width: 722, height: 104, x: 30, y: 688 },
                    layers: [
                        {
                            name: 'Group 13',
                            Id: 247,
                            nameId: '3CC40308-736C-47B1-B34B-20AB345BADB9',
                            frame: { width: 720, height: 12, x: 32, y: 780 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1yrYNp9BYBeNjy0FeXXbnmFXa-720-12.png'
                        },
                        {
                            name: 'Group',
                            Id: 249,
                            nameId: 'DBE1B8BF-F552-4063-A0A7-CF2B10714EAC',
                            frame: { width: 690, height: 55, x: 30, y: 718 },
                            layers: [
                                {
                                    name: '￥3100',
                                    Id: 250,
                                    nameId: '36DB7839-512B-42CD-9FC3-3DFC8D7193E1',
                                    frame: { width: 116, height: 50, x: 604, y: 722.3636363636365 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '36',
                                        color: '#222222',
                                        textAlign: 'right',
                                        lineHeight: '50',
                                        maxWidth: 116,
                                        maxHeight: 50,
                                        fontWeight: 'bold'
                                    },
                                    value: '￥3100',
                                    type: 'text'
                                },
                                {
                                    name: '本单共可收入',
                                    Id: 251,
                                    nameId: 'AD444FF2-5787-4B3B-A17B-9FEB364501FA',
                                    frame: { width: 192, height: 45, x: 30, y: 718 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '32',
                                        color: '#222222',
                                        lineHeight: '45',
                                        textAlign: 'left',
                                        fontWeight: 'bold'
                                    },
                                    value: '本单共可收入',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'DBE1B8BF-F552-4063-A0A7-CF2B10714EAC'
                        }
                    ],
                    type: 'group',
                    objectID: '42103440-217B-4B1F-9FD6-B1D95855347B'
                }
            ],
            type: 'group',
            objectID: 'B0AB4FD6-A244-4435-913B-4A77745781D3'
        },
        {
            name: '* 单个用户每月仅限2笔信用速卖订单（包',
            Id: 252,
            nameId: 'D914D508-1723-42B7-8D39-4269E60777F9',
            frame: { width: 587, height: 33, x: 30, y: 970 },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#888888',
                lineHeight: '33',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '* 单个用户每月仅限2笔信用速卖订单（包含交易关闭）',
            type: 'text'
        },
        {
            name: '* 提交即表示同意',
            Id: 254,
            nameId: '01477CE8-E2CA-4F83-BC35-C6C5B78EDC3E',
            frame: { width: 424, height: 35, x: 30, y: 1014 },
            layers: [
                {
                    name: '* 提交即表示同意',
                    Id: 255,
                    nameId: '6183F1E9-4858-4829-9517-E50FB7D8836A',
                    frame: { width: 189, height: 33, x: 30, y: 1014 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#888888',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '* 提交即表示同意',
                    type: 'text'
                },
                {
                    name: '《信用速卖用户协议》',
                    Id: 256,
                    nameId: 'D55E7472-CB7C-4C6C-944A-762911F131AF',
                    frame: { width: 240, height: 33, x: 214, y: 1016 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#D5A458',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '《信用速卖用户协议》',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '01477CE8-E2CA-4F83-BC35-C6C5B78EDC3E'
        },
        {
            name: 'Rectangle 13 Copy',
            Id: 258,
            nameId: '4A2144D3-92C3-45A5-B80D-3736E7156660',
            frame: { width: 750, height: 96, x: 0, y: 1238 },
            layers: [
                {
                    name: 'Rectangle 13 Copy',
                    Id: 259,
                    nameId: '50E56ECA-7E91-402C-9837-CB782EBF9976',
                    frame: { width: 750, height: 96, x: 0, y: 1238 },
                    styles: { backgroundColor: 'rgba(215,215,215,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: '提交订单',
                    Id: 260,
                    nameId: 'E9D72ED3-CF98-40A2-A93A-4481F497F80B',
                    frame: { width: 198, height: 45, x: 278, y: 1266 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '32',
                        color: '#EBEBEB',
                        textAlign: 'center',
                        lineHeight: '45',
                        maxWidth: 198,
                        maxHeight: 45,
                        fontWeight: 'bold'
                    },
                    value: '提交订单',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '4A2144D3-92C3-45A5-B80D-3736E7156660'
        }
    ],
    nameId: 1525575630832,
    Id: 131,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 1334 },
    styles: { backgroundColor: 'rgba(243,245,249,1)' }
};
