"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Group',
            Id: 72,
            nameId: '1B1550BC-BF02-4F73-B226-FCAE458FEFAB',
            frame: { width: 686, height: 80, x: 32, y: 0 },
            layers: [
                {
                    name: '¥',
                    Id: 73,
                    nameId: 'F78C8667-B9EC-4DC1-BA9F-E0986CF64C47',
                    frame: { width: 15, height: 34, x: 610, y: 10 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '34',
                        fontWeight: 'normal'
                    },
                    value: '¥',
                    type: 'text'
                },
                {
                    name: '6000',
                    Id: 74,
                    nameId: '206C19F5-EAD0-43A3-87CB-5545E7BAB2D8',
                    frame: { width: 87, height: 50, x: 631, y: 4 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '36',
                        color: '#FF4444',
                        textAlign: 'right',
                        lineHeight: '50',
                        fontWeight: 'bold'
                    },
                    value: '6000',
                    type: 'text'
                },
                {
                    name: 'Group 6',
                    Id: 75,
                    nameId: '742EBEB6-E3B6-45A3-9E02-550A51425D64',
                    frame: { width: 80, height: 80, x: 32, y: 0 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1YwTOpuSSBuNjy0FlXXbBpVXa-80-80.png'
                },
                {
                    name: 'Group',
                    Id: 77,
                    nameId: 'EA6D7A0B-75BB-4BA8-BA37-F952DDCCD64F',
                    frame: { width: 413, height: 78, x: 136, y: 2 },
                    layers: [
                        {
                            name: 'Group',
                            Id: 79,
                            nameId: '6F862071-6341-4279-AAC6-08678C9D33D3',
                            frame: { width: 192, height: 42, x: 136, y: 2 },
                            layers: [
                                {
                                    name: '摄影大大Qiu',
                                    Id: 80,
                                    nameId: '8238C7F5-5FA4-4983-829A-F7822A8FC4E9',
                                    frame: { width: 169, height: 42, x: 136, y: 2 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '30',
                                        color: '#222222',
                                        lineHeight: '42',
                                        textAlign: 'left',
                                        fontWeight: 'bold'
                                    },
                                    value: '摄影大大Qiu',
                                    type: 'text'
                                },
                                {
                                    name: 'tag_tangzhu copy 35',
                                    Id: 81,
                                    nameId: '4B223E81-1072-426C-8AFF-CBD9C1F2D173',
                                    frame: { width: 76, height: 28, x: 314, y: 6 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1GtB_pTtYBeNjy1XdXXXXyVXa-76-28.png'
                                },
                                {
                                    name: 'tag_tangzhu copy 36',
                                    Id: 82,
                                    nameId: 'DCFB35EC-8BFB-49DB-B124-48E269F71165',
                                    frame: { width: 126, height: 28, x: 394, y: 6 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1vUAhpr9YBuNjy0FgXXcxcXXa-126-28.png'
                                }
                            ],
                            type: 'group',
                            objectID: '6F862071-6341-4279-AAC6-08678C9D33D3'
                        },
                        {
                            name: 'Group',
                            Id: 84,
                            nameId: 'CEEF6B2D-1679-4ED1-A15F-1BA278DDB447',
                            frame: { width: 413, height: 34, x: 136, y: 46 },
                            layers: [
                                {
                                    name: '5分钟前来过·杭州 阿里巴巴西溪园区',
                                    Id: 85,
                                    nameId: 'D27B0ADF-95FC-4E70-987E-2C95989FFB81',
                                    frame: { width: 395, height: 34, x: 154, y: 46 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '24',
                                        color: '#888888',
                                        lineHeight: '34',
                                        textAlign: 'left',
                                        fontWeight: 'normal'
                                    },
                                    value: '5分钟前来过·杭州 阿里巴巴西溪园区',
                                    type: 'text'
                                },
                                {
                                    name: 'Oval 3',
                                    Id: 86,
                                    nameId: '4B06E39C-6067-4BDE-82DF-E05AA0B4841C',
                                    frame: { width: 12, height: 12, x: 136, y: 58 },
                                    styles: { backgroundColor: 'rgba(85,207,105,1)', fillType: 'color', borderRadius: 12 },
                                    type: 'shape'
                                }
                            ],
                            type: 'group',
                            objectID: 'CEEF6B2D-1679-4ED1-A15F-1BA278DDB447'
                        }
                    ],
                    type: 'group',
                    objectID: 'EA6D7A0B-75BB-4BA8-BA37-F952DDCCD64F'
                }
            ],
            type: 'group',
            objectID: '1B1550BC-BF02-4F73-B226-FCAE458FEFAB'
        },
        {
            name: 'Group 14',
            Id: 87,
            nameId: '543F27CA-B91F-4A50-B730-B9876AAFB480',
            frame: { width: 614, height: 216, x: 136, y: 192 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1VtB_pTtYBeNjy1XdXXXXyVXa-614-216.png'
        },
        {
            name: '玛米亚RB67 超级大全套预售 不多解释',
            Id: 89,
            nameId: '079E981B-5451-4E56-ADF1-92803176DFB3',
            frame: { width: 594, height: 80, x: 134, y: 96 },
            layers: [
                {
                    name: '玛米亚RB67 超级大全套预售 不多解释',
                    Id: 90,
                    nameId: '10B69A57-15C2-4675-8E39-91371A6CE357',
                    frame: { width: 594, height: 80, x: 134, y: 96 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '28',
                        color: '#222222',
                        lineHeight: '40',
                        maxWidth: 594,
                        maxHeight: 80,
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '玛米亚RB67 超级大全套预售 不多解释，我只问全国能不能找到我这样的一套。',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '079E981B-5451-4E56-ADF1-92803176DFB3'
        },
        {
            name: 'Group',
            Id: 92,
            nameId: '70EF17B8-F1D8-4E94-B4A5-1E25090CE10A',
            frame: { width: 590, height: 48, x: 136, y: 428 },
            layers: [
                {
                    name: '786',
                    Id: 93,
                    nameId: 'BC44FF6B-B335-4673-AEAC-6CECB12427C3',
                    frame: { width: 42, height: 34, x: 176, y: 436 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#888888',
                        lineHeight: '34',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '786',
                    type: 'text'
                },
                {
                    name: 'ic_view',
                    Id: 94,
                    nameId: '6369FD9D-0F04-4B29-AF57-F5D7B7473A33',
                    frame: { width: 32, height: 32, x: 136, y: 436 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1ogYOpuSSBuNjy0FlXXbBpVXa-32-32.png'
                },
                {
                    name: '265',
                    Id: 95,
                    nameId: 'F89EDBDD-267F-4981-BCF4-93F43C038AC5',
                    frame: { width: 44, height: 34, x: 278, y: 436 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#888888',
                        lineHeight: '34',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '265',
                    type: 'text'
                },
                {
                    name: 'ic_comments',
                    Id: 96,
                    nameId: '758F84C4-E0CF-41A8-B85F-B5AC3AF6717F',
                    frame: { width: 32, height: 32, x: 238, y: 436 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1tgYOpuSSBuNjy0FlXXbBpVXa-32-32.png'
                },
                {
                    name: 'foot',
                    Id: 97,
                    nameId: '2B06740C-5446-4E16-ACDE-DE7821601B81',
                    frame: { width: 48, height: 48, x: 678, y: 428 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1Ycgnpv1TBuNjy0FjXXajyXXa-48-48.png'
                }
            ],
            type: 'group',
            objectID: '70EF17B8-F1D8-4E94-B4A5-1E25090CE10A'
        },
        {
            name: 'Mask',
            Id: 99,
            nameId: '8EAC7DEE-5B59-4537-BDDD-276BB4B6C877',
            frame: { width: 750, height: 704, x: 0, y: 496 },
            layers: [
                {
                    name: 'Rectangle 5 Copy',
                    Id: 101,
                    nameId: 'E4EDCF4D-26B5-4E75-B266-5F7099C985F7',
                    frame: { width: 750, height: 392, x: 0, y: 720 },
                    layers: [
                        {
                            name: 'Mask',
                            Id: 103,
                            nameId: 'E6CB8733-B3A8-4C77-8044-1C8B3E200CD3',
                            frame: { width: 392, height: 392, x: 136, y: 720 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 105,
                                    nameId: 'A5E0642B-0D16-4015-8ABD-DB6DCDF6E91C',
                                    frame: { width: 392, height: 392, x: 136, y: 720 },
                                    layers: [
                                        {
                                            name: 'Bitmap',
                                            Id: 106,
                                            nameId: 'FC6B227E-79AD-42A8-B085-126245D7AFFB',
                                            frame: { width: 392, height: 392, x: 136, y: 720 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB144UgpuuSBuNjy1XcXXcYjFXa-392-392.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'A5E0642B-0D16-4015-8ABD-DB6DCDF6E91C'
                                }
                            ],
                            type: 'group',
                            objectID: 'E6CB8733-B3A8-4C77-8044-1C8B3E200CD3'
                        }
                    ],
                    type: 'group',
                    objectID: 'E4EDCF4D-26B5-4E75-B266-5F7099C985F7'
                },
                {
                    name: 'Group 9',
                    Id: 108,
                    nameId: '0CA9287E-E364-4B7F-9868-8D3764B1C252',
                    frame: { width: 750, height: 88, x: 0, y: 1112 },
                    layers: [
                        {
                            name: 'Rectangle 11 Copy 14',
                            Id: 110,
                            nameId: '8A618D72-3A24-4FEA-9280-8550B0215E92',
                            frame: { width: 750, height: 88, x: 0, y: 1112 },
                            layers: [
                                {
                                    name: 'Rectangle 11 Copy 14',
                                    Id: 111,
                                    nameId: '486AD172-F485-4F98-8DDA-E6738A559657',
                                    frame: { width: 750, height: 88, x: 0, y: 1112 },
                                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                                    type: 'shape'
                                },
                                {
                                    name: 'Group',
                                    Id: 113,
                                    nameId: '15B096BA-3E33-47B2-B919-A3EC8C4C3D3F',
                                    frame: { width: 592, height: 48, x: 136, y: 1132 },
                                    layers: [
                                        {
                                            name: '265',
                                            Id: 115,
                                            nameId: 'C0FAC4EC-7EAC-458D-962E-7D6E229C4CF5',
                                            frame: { width: 186, height: 34, x: 136, y: 1140 },
                                            layers: [
                                                {
                                                    name: '888浏览·72想要',
                                                    Id: 116,
                                                    nameId: 'E4E6C68A-AA66-498B-8CF2-1669C557A23A',
                                                    frame: { width: 179, height: 34, x: 136, y: 1140 },
                                                    textStyles: {
                                                        fontFamily: 'PingFangSC-Regular',
                                                        fontSize: '24',
                                                        color: '#888888',
                                                        lineHeight: '34',
                                                        textAlign: 'left',
                                                        fontWeight: 'normal'
                                                    },
                                                    value: '888浏览·72想要',
                                                    type: 'text'
                                                }
                                            ],
                                            type: 'group',
                                            objectID: 'C0FAC4EC-7EAC-458D-962E-7D6E229C4CF5'
                                        },
                                        {
                                            name: 'foot',
                                            Id: 117,
                                            nameId: '2541EDE6-0301-4CFA-995C-B9E7093F19A5',
                                            frame: { width: 48, height: 48, x: 680, y: 1132 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB14cQypx9YBuNjy0FfXXXIsVXa-48-48.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '15B096BA-3E33-47B2-B919-A3EC8C4C3D3F'
                                }
                            ],
                            type: 'group',
                            objectID: '8A618D72-3A24-4FEA-9280-8550B0215E92'
                        }
                    ],
                    type: 'group',
                    objectID: '0CA9287E-E364-4B7F-9868-8D3764B1C252'
                },
                {
                    name: 'Rectangle 5 Copy 5',
                    Id: 119,
                    nameId: 'C1E2E31D-2253-455B-A924-EEB60A31F0E1',
                    frame: { width: 750, height: 80, x: 0, y: 624 },
                    layers: [
                        {
                            name: 'Ducati Mgnster 821 国',
                            Id: 120,
                            nameId: '3C373C5F-453D-40BF-A1E6-057C499167D1',
                            frame: { width: 594, height: 80, x: 134, y: 624 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#222222',
                                lineHeight: '40',
                                maxWidth: 594,
                                maxHeight: 80,
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: 'Ducati Mgnster 821 国行大贸易 全国过户提档喜欢的盆友看看~',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'C1E2E31D-2253-455B-A924-EEB60A31F0E1'
                },
                {
                    name: 'Rectangle 5',
                    Id: 122,
                    nameId: '9BCEE9A5-2B13-4184-B36F-73F856E14AB6',
                    frame: { width: 750, height: 112, x: 0, y: 512 },
                    layers: [
                        {
                            name: 'Group',
                            Id: 124,
                            nameId: '9507009B-392E-4E47-929D-7BFD1AA9ED02',
                            frame: { width: 688, height: 80, x: 32, y: 528 },
                            layers: [
                                {
                                    name: '¥',
                                    Id: 125,
                                    nameId: '4ECFD0A1-AA3E-494C-AC6E-6148B472C1BD',
                                    frame: { width: 15, height: 34, x: 576, y: 538 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '24',
                                        color: '#FF4444',
                                        textAlign: 'left',
                                        lineHeight: '34',
                                        fontWeight: 'normal'
                                    },
                                    value: '¥',
                                    type: 'text'
                                },
                                {
                                    name: '/月',
                                    Id: 126,
                                    nameId: '6B5B7A88-FBC7-4C91-BD87-8B2015D4FC4A',
                                    frame: { width: 36, height: 34, x: 684, y: 540 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '24',
                                        color: '#FF4444',
                                        textAlign: 'left',
                                        lineHeight: '34',
                                        fontWeight: 'normal'
                                    },
                                    value: '/月',
                                    type: 'text'
                                },
                                {
                                    name: '6000',
                                    Id: 127,
                                    nameId: 'AC8A8A31-A13A-4D85-AE37-750D644883AA',
                                    frame: { width: 87, height: 50, x: 597, y: 532 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '36',
                                        color: '#FF4444',
                                        textAlign: 'right',
                                        lineHeight: '50',
                                        fontWeight: 'bold'
                                    },
                                    value: '6000',
                                    type: 'text'
                                },
                                {
                                    name: 'Group 6',
                                    Id: 128,
                                    nameId: '5D3D9535-71C1-4CD1-B1CA-C2B0DD68B816',
                                    frame: { width: 80, height: 80, x: 32, y: 528 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1e4ZgpuuSBuNjy1XcXXcYjFXa-80-80.png'
                                },
                                {
                                    name: 'Group',
                                    Id: 130,
                                    nameId: 'E95E194A-0D7F-4753-BF62-8F606518F406',
                                    frame: { width: 413, height: 78, x: 136, y: 530 },
                                    layers: [
                                        {
                                            name: 'Group',
                                            Id: 132,
                                            nameId: '9BAC6727-D95F-4BE1-AB6C-9C5002DF5ED1',
                                            frame: { width: 234, height: 42, x: 136, y: 530 },
                                            layers: [
                                                {
                                                    name: '西溪包租婆',
                                                    Id: 133,
                                                    nameId: 'A615CA09-6FF3-42B2-9175-3A38C9BCA887',
                                                    frame: { width: 150, height: 42, x: 136, y: 530 },
                                                    textStyles: {
                                                        fontFamily: 'PingFangSC-Medium',
                                                        fontSize: '30',
                                                        color: '#222222',
                                                        lineHeight: '42',
                                                        textAlign: 'left',
                                                        fontWeight: 'bold'
                                                    },
                                                    value: '西溪包租婆',
                                                    type: 'text'
                                                },
                                                {
                                                    name: 'tag_tangzhu copy 35',
                                                    Id: 134,
                                                    nameId: 'A5ABEC82-6B48-4A6C-A49D-85DB4CD0BBD7',
                                                    frame: { width: 76, height: 28, x: 294, y: 534 },
                                                    imageStyles: { resize: 'stretch' },
                                                    type: 'image',
                                                    value: 'https://gw.alicdn.com/tfs/TB1lsknpv1TBuNjy0FjXXajyXXa-76-28.png'
                                                }
                                            ],
                                            type: 'group',
                                            objectID: '9BAC6727-D95F-4BE1-AB6C-9C5002DF5ED1'
                                        },
                                        {
                                            name: 'Group',
                                            Id: 136,
                                            nameId: 'A5E9E187-EAA3-4C15-A5D4-7814FE00CA6D',
                                            frame: { width: 413, height: 34, x: 136, y: 574 },
                                            layers: [
                                                {
                                                    name: '5分钟前来过·杭州 阿里巴巴西溪园区',
                                                    Id: 137,
                                                    nameId: 'C1675EF8-964D-4DC2-BF45-99C6A5C2E9D8',
                                                    frame: { width: 395, height: 34, x: 154, y: 574 },
                                                    textStyles: {
                                                        fontFamily: 'PingFangSC-Regular',
                                                        fontSize: '24',
                                                        color: '#888888',
                                                        lineHeight: '34',
                                                        textAlign: 'left',
                                                        fontWeight: 'normal'
                                                    },
                                                    value: '5分钟前来过·杭州 阿里巴巴西溪园区',
                                                    type: 'text'
                                                },
                                                {
                                                    name: 'Oval 3',
                                                    Id: 138,
                                                    nameId: '90B8288D-32D7-4BB3-94A7-3EFEC59F512E',
                                                    frame: { width: 12, height: 12, x: 136, y: 586 },
                                                    styles: { backgroundColor: 'rgba(34,34,34,0.2)', fillType: 'color', borderRadius: 12 },
                                                    type: 'shape'
                                                }
                                            ],
                                            type: 'group',
                                            objectID: 'A5E9E187-EAA3-4C15-A5D4-7814FE00CA6D'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'E95E194A-0D7F-4753-BF62-8F606518F406'
                                }
                            ],
                            type: 'group',
                            objectID: '9507009B-392E-4E47-929D-7BFD1AA9ED02'
                        }
                    ],
                    type: 'group',
                    objectID: '9BCEE9A5-2B13-4184-B36F-73F856E14AB6'
                }
            ],
            type: 'group',
            objectID: '8EAC7DEE-5B59-4537-BDDD-276BB4B6C877'
        }
    ],
    nameId: 1525347533647,
    Id: 70,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 1200 },
    styles: { backgroundColor: 'rgba(255,255,255,1)' }
};
