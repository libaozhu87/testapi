"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var index_1 = require("./../index");
var input_50_1 = require("./input-50");
function test() {
    index_1.flexbox(input_50_1.default, { debug: false });
}
test();
