"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Group 10',
            Id: 199,
            nameId: '51CE6A8F-56AC-4986-BB41-78DD44502CEB',
            frame: { width: 750, height: 412, x: 0, y: 0 },
            layers: [
                {
                    name: 'Rectangle 2',
                    Id: 200,
                    nameId: '33F44B50-A130-45F3-AEAD-F16DFB9ED84D',
                    frame: { width: 750, height: 412, x: 0, y: 0 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Bitmap',
                    Id: 201,
                    nameId: '97F83F7A-1F04-4453-805D-1664942ED22E',
                    frame: { width: 720, height: 412, x: 30, y: 0 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1qNYzqmBYBeNjy0FeXXbnmFXa-720-412.png'
                },
                {
                    name: 'Group 9',
                    Id: 203,
                    nameId: 'B19B51E1-9700-459E-9926-ABD0D8AC8B04',
                    frame: { width: 684, height: 348, x: 26, y: 34 },
                    layers: [
                        {
                            name: 'Group 7 Copy 10',
                            Id: 205,
                            nameId: '8B61291E-7943-4FCD-825C-1300FA7F27F8',
                            frame: { width: 140, height: 162, x: 212, y: 220 },
                            layers: [
                                {
                                    name: 'Group 8',
                                    Id: 207,
                                    nameId: 'C6333DAD-2C96-4797-82A2-ABF9FD85E83C',
                                    frame: { width: 112, height: 112, x: 228, y: 220 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 208,
                                            nameId: '7298097C-1423-4E05-90D5-50E253A2F3C7',
                                            frame: { width: 112, height: 112, x: 228, y: 220 },
                                            styles: { backgroundColor: 'rgba(234,234,234,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 209,
                                            nameId: '506B6DDA-22F7-4969-9D77-608F5441986E',
                                            frame: { width: 70, height: 84, x: 248, y: 236 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1CjO0qh9YBuNjy0FfXXXIsVXa-70-84.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'C6333DAD-2C96-4797-82A2-ABF9FD85E83C'
                                },
                                {
                                    name: '卖智能设备',
                                    Id: 210,
                                    nameId: '5817DABD-F408-44A0-9A42-A77E0F9814C8',
                                    frame: { width: 140, height: 40, x: 212, y: 342 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖智能设备',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '8B61291E-7943-4FCD-825C-1300FA7F27F8'
                        },
                        {
                            name: 'Group 7 Copy 6',
                            Id: 212,
                            nameId: 'C55A29D9-6A9B-451E-8716-7A1F491088AC',
                            frame: { width: 140, height: 162, x: 26, y: 220 },
                            layers: [
                                {
                                    name: 'Group 8',
                                    Id: 214,
                                    nameId: 'C9FC9CE7-C074-4D46-98C6-0A4DF18F0A88',
                                    frame: { width: 112, height: 112, x: 40, y: 220 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 215,
                                            nameId: '4E1D9144-0BFD-450C-AEF6-A98EA5366380',
                                            frame: { width: 112, height: 112, x: 40, y: 220 },
                                            styles: { backgroundColor: 'rgba(245,239,232,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 216,
                                            nameId: '117D494E-7C46-4262-8D01-47EC65A39CDD',
                                            frame: { width: 66, height: 90, x: 62, y: 242 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1FhYzqmBYBeNjy0FeXXbnmFXa-66-90.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'C9FC9CE7-C074-4D46-98C6-0A4DF18F0A88'
                                },
                                {
                                    name: '卖家具家电',
                                    Id: 217,
                                    nameId: 'B8981540-DB9D-4257-BD0C-150A075AABAB',
                                    frame: { width: 140, height: 40, x: 26, y: 342 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖家具家电',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'C55A29D9-6A9B-451E-8716-7A1F491088AC'
                        },
                        {
                            name: 'Group 39',
                            Id: 219,
                            nameId: 'D6974ED0-E8D5-4872-8B2B-F08FF7FB1BB8',
                            frame: { width: 668, height: 158, x: 40, y: 34 },
                            layers: [
                                {
                                    name: 'Group 7',
                                    Id: 221,
                                    nameId: '123368A6-CE05-4651-936C-1C38BFED59E7',
                                    frame: { width: 112, height: 158, x: 40, y: 34 },
                                    layers: [
                                        {
                                            name: 'Group 8',
                                            Id: 223,
                                            nameId: '836875B1-5FD9-4E0E-BE6B-B3C840086EF0',
                                            frame: { width: 112, height: 112, x: 40, y: 34 },
                                            layers: [
                                                {
                                                    name: 'Mask',
                                                    Id: 224,
                                                    nameId: '3EA976F6-5CAA-4B54-B46C-D72862AC02D3',
                                                    frame: { width: 112, height: 112, x: 40, y: 34 },
                                                    styles: { backgroundColor: 'rgba(244,231,229,1)', fillType: 'color', borderRadius: 112 },
                                                    type: 'shape'
                                                },
                                                {
                                                    name: 'Bitmap',
                                                    Id: 225,
                                                    nameId: '54CF832C-FFB8-401A-8E26-31C4BE247599',
                                                    frame: { width: 66, height: 92, x: 64, y: 54 },
                                                    imageStyles: { resize: 'stretch' },
                                                    type: 'image',
                                                    value: 'https://gw.alicdn.com/tfs/TB1KJedqeSSBuNjy0FlXXbBpVXa-66-92.png'
                                                }
                                            ],
                                            type: 'group',
                                            objectID: '836875B1-5FD9-4E0E-BE6B-B3C840086EF0'
                                        },
                                        {
                                            name: '卖手机',
                                            Id: 226,
                                            nameId: 'C4120805-1182-4824-AF95-717C58B57101',
                                            frame: { width: 84, height: 40, x: 54, y: 152 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Regular',
                                                fontSize: '28',
                                                color: '#222222',
                                                textAlign: 'center',
                                                lineHeight: '40',
                                                fontWeight: 'normal'
                                            },
                                            value: '卖手机',
                                            type: 'text'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '123368A6-CE05-4651-936C-1C38BFED59E7'
                                },
                                {
                                    name: 'Group 7 Copy',
                                    Id: 228,
                                    nameId: '3A28564D-B16E-49C4-9A39-D738A385E820',
                                    frame: { width: 112, height: 158, x: 226, y: 34 },
                                    layers: [
                                        {
                                            name: 'Group 8',
                                            Id: 230,
                                            nameId: 'DFD8AC96-4DA9-4D3B-8D4F-9ED1386A374F',
                                            frame: { width: 112, height: 112, x: 226, y: 34 },
                                            layers: [
                                                {
                                                    name: 'Mask',
                                                    Id: 231,
                                                    nameId: 'ECC93698-B11E-4CC2-A244-21496E5A779F',
                                                    frame: { width: 112, height: 112, x: 226, y: 34 },
                                                    styles: { backgroundColor: 'rgba(232,234,240,1)', fillType: 'color', borderRadius: 112 },
                                                    type: 'shape'
                                                },
                                                {
                                                    name: 'Bitmap',
                                                    Id: 232,
                                                    nameId: '3D3C068B-72C9-45B2-97F7-14EBF7442581',
                                                    frame: { width: 82, height: 90, x: 240, y: 56 },
                                                    imageStyles: { resize: 'stretch' },
                                                    type: 'image',
                                                    value: 'https://gw.alicdn.com/tfs/TB1SNYzqmBYBeNjy0FeXXbnmFXa-82-90.png'
                                                }
                                            ],
                                            type: 'group',
                                            objectID: 'DFD8AC96-4DA9-4D3B-8D4F-9ED1386A374F'
                                        },
                                        {
                                            name: '卖平板',
                                            Id: 233,
                                            nameId: '04C4B4DA-23EE-4384-9EAD-DC4B0B67ED5E',
                                            frame: { width: 84, height: 40, x: 240, y: 152 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Regular',
                                                fontSize: '28',
                                                color: '#222222',
                                                textAlign: 'center',
                                                lineHeight: '40',
                                                fontWeight: 'normal'
                                            },
                                            value: '卖平板',
                                            type: 'text'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '3A28564D-B16E-49C4-9A39-D738A385E820'
                                },
                                {
                                    name: 'Group 7 Copy 2',
                                    Id: 235,
                                    nameId: '070F8FDF-23B0-49BB-96F5-9FD9B98868BF',
                                    frame: { width: 112, height: 158, x: 412, y: 34 },
                                    layers: [
                                        {
                                            name: 'Group 8',
                                            Id: 237,
                                            nameId: '01059210-16A3-4703-AE17-A3865604E606',
                                            frame: { width: 112, height: 112, x: 412, y: 34 },
                                            layers: [
                                                {
                                                    name: 'Mask',
                                                    Id: 238,
                                                    nameId: 'A43BAF46-CDD9-47E7-A780-424079B99A44',
                                                    frame: { width: 112, height: 112, x: 412, y: 34 },
                                                    styles: { backgroundColor: 'rgba(245,233,232,1)', fillType: 'color', borderRadius: 112 },
                                                    type: 'shape'
                                                },
                                                {
                                                    name: 'Bitmap',
                                                    Id: 239,
                                                    nameId: 'BD477637-F704-4875-AEBB-158260B34837',
                                                    frame: { width: 96, height: 66, x: 420, y: 58 },
                                                    imageStyles: { resize: 'stretch' },
                                                    type: 'image',
                                                    value: 'https://gw.alicdn.com/tfs/TB1BEiQqf1TBuNjy0FjXXajyXXa-96-66.png'
                                                }
                                            ],
                                            type: 'group',
                                            objectID: '01059210-16A3-4703-AE17-A3865604E606'
                                        },
                                        {
                                            name: '卖电脑',
                                            Id: 240,
                                            nameId: '65F9B58A-0D6B-4A78-BA27-E4CB8394375E',
                                            frame: { width: 84, height: 40, x: 426, y: 152 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Regular',
                                                fontSize: '28',
                                                color: '#222222',
                                                textAlign: 'center',
                                                lineHeight: '40',
                                                fontWeight: 'normal'
                                            },
                                            value: '卖电脑',
                                            type: 'text'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '070F8FDF-23B0-49BB-96F5-9FD9B98868BF'
                                },
                                {
                                    name: 'Group 7 Copy 3',
                                    Id: 242,
                                    nameId: 'D9CDB701-2D54-4065-B75A-ADC57236E604',
                                    frame: { width: 112, height: 158, x: 596, y: 34 },
                                    layers: [
                                        {
                                            name: 'Group 8',
                                            Id: 244,
                                            nameId: '8505C4FF-3256-43DD-819A-B8E2E682B31B',
                                            frame: { width: 112, height: 112, x: 596, y: 34 },
                                            layers: [
                                                {
                                                    name: 'Mask',
                                                    Id: 245,
                                                    nameId: '024A889D-2F0E-48FA-8634-0F848C490576',
                                                    frame: { width: 112, height: 112, x: 596, y: 34 },
                                                    styles: { backgroundColor: 'rgba(230,239,230,1)', fillType: 'color', borderRadius: 112 },
                                                    type: 'shape'
                                                },
                                                {
                                                    name: 'Bitmap Copy',
                                                    Id: 246,
                                                    nameId: 'FE1790CF-F6F3-47C2-8928-C5700EE66666',
                                                    frame: { width: 82, height: 84, x: 612, y: 50 },
                                                    imageStyles: { resize: 'stretch' },
                                                    type: 'image',
                                                    value: 'https://gw.alicdn.com/tfs/TB1OR5rqeOSBuNjy0FdXXbDnVXa-82-84.png'
                                                }
                                            ],
                                            type: 'group',
                                            objectID: '8505C4FF-3256-43DD-819A-B8E2E682B31B'
                                        },
                                        {
                                            name: '卖相机',
                                            Id: 247,
                                            nameId: '05038046-8FC1-4D57-92DA-B3D740746C87',
                                            frame: { width: 84, height: 40, x: 612, y: 152 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Regular',
                                                fontSize: '28',
                                                color: '#222222',
                                                textAlign: 'center',
                                                lineHeight: '40',
                                                fontWeight: 'normal'
                                            },
                                            value: '卖相机',
                                            type: 'text'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'D9CDB701-2D54-4065-B75A-ADC57236E604'
                                }
                            ],
                            type: 'group',
                            objectID: 'D6974ED0-E8D5-4872-8B2B-F08FF7FB1BB8'
                        },
                        {
                            name: 'Group 7 Copy 8',
                            Id: 249,
                            nameId: '273EC9E3-F389-43A3-B6C6-F5B0EE54AB7A',
                            frame: { width: 140, height: 162, x: 408, y: 220 },
                            layers: [
                                {
                                    name: 'Group 8',
                                    Id: 251,
                                    nameId: '455FECDF-CD17-4EF1-B856-1C92904777B1',
                                    frame: { width: 112, height: 112, x: 422, y: 220 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 252,
                                            nameId: 'ECF99561-0D39-461C-B4CC-D09E1B080E36',
                                            frame: { width: 112, height: 112, x: 422, y: 220 },
                                            styles: { backgroundColor: 'rgba(244,232,226,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 253,
                                            nameId: 'A141CE90-0E52-49AD-99DC-6B7299D9149C',
                                            frame: { width: 81, height: 88, x: 446, y: 236 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1.xYzqmBYBeNjy0FeXXbnmFXa-81-88.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '455FECDF-CD17-4EF1-B856-1C92904777B1'
                                },
                                {
                                    name: '卖运动器材',
                                    Id: 254,
                                    nameId: 'F5452BAA-A5DE-4F7B-8F5E-6A9B27322650',
                                    frame: { width: 140, height: 40, x: 408, y: 342 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖运动器材',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '273EC9E3-F389-43A3-B6C6-F5B0EE54AB7A'
                        },
                        {
                            name: 'Group 7 Copy 9',
                            Id: 256,
                            nameId: '3046D719-1E52-49D6-B181-8230582759E0',
                            frame: { width: 112, height: 162, x: 598, y: 220 },
                            layers: [
                                {
                                    name: 'Group 8',
                                    Id: 258,
                                    nameId: '90FD9DE5-4D16-411F-94A1-D55B0CAEF5F3',
                                    frame: { width: 112, height: 112, x: 598, y: 220 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 259,
                                            nameId: '84D7C0BB-FF08-45B2-87F3-995A95C51681',
                                            frame: { width: 112, height: 112, x: 598, y: 220 },
                                            styles: { backgroundColor: 'rgba(235,235,235,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 260,
                                            nameId: 'A2DB0E55-557A-4143-A0F1-8AC4E7F2772B',
                                            frame: { width: 94, height: 94, x: 610, y: 238 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB16l5rqeOSBuNjy0FdXXbDnVXa-94-94.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '90FD9DE5-4D16-411F-94A1-D55B0CAEF5F3'
                                },
                                {
                                    name: '卖乐器',
                                    Id: 261,
                                    nameId: '1465A05A-40F4-40EF-8E09-FCB9CDC73C4F',
                                    frame: { width: 84, height: 40, x: 612, y: 342 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖乐器',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '3046D719-1E52-49D6-B181-8230582759E0'
                        }
                    ],
                    type: 'group',
                    objectID: 'B19B51E1-9700-459E-9926-ABD0D8AC8B04'
                }
            ],
            type: 'group',
            objectID: '51CE6A8F-56AC-4986-BB41-78DD44502CEB'
        }
    ],
    nameId: 1525687692937,
    Id: 197,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 412 },
    styles: { backgroundColor: 'rgba(255,255,255,1)' }
};
