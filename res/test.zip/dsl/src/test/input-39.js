"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Group 2',
            Id: 29,
            nameId: '40448049-3E5D-4136-866D-909B2925A557',
            frame: {
                width: 304,
                height: 488,
                x: 0,
                y: 0
            },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 31,
                    nameId: '39703305-0F47-4535-9368-2C3A43C96F75',
                    frame: {
                        width: 304,
                        height: 304,
                        x: 0,
                        y: 0
                    },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 32,
                            nameId: 'D1AF026C-0971-4000-96ED-809EB105B780',
                            frame: {
                                width: 304,
                                height: 304,
                                x: 0,
                                y: 0
                            },
                            imageStyles: {
                                resize: 'stretch'
                            },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1ixvPvHSYBuNjSspfXXcZCpXa-304-304.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 34,
                            nameId: '0ABE2035-EF97-4B0B-AA65-10A937B7D5C1',
                            frame: {
                                width: 304,
                                height: 304,
                                x: 0,
                                y: 0
                            },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 35,
                                    nameId: 'BC04D0A1-265D-4819-B28C-9854EB9D00A5',
                                    frame: {
                                        width: 304,
                                        height: 304,
                                        x: 0,
                                        y: 0
                                    },
                                    imageStyles: {
                                        resize: 'stretch'
                                    },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1FFunvMmTBuNjy1XbXXaMrVXa-304-304.png'
                                }
                            ],
                            type: 'group',
                            objectID: '0ABE2035-EF97-4B0B-AA65-10A937B7D5C1'
                        },
                        {
                            name: 'Bitmap',
                            Id: 36,
                            nameId: '0BFABE02-ECA5-47A5-9685-91A0CC311925',
                            frame: {
                                width: 304,
                                height: 100,
                                x: 0,
                                y: 0
                            },
                            imageStyles: {
                                resize: 'stretch'
                            },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1dka7vFuWBuNjSszbXXcS7FXa-304-100.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 37,
                            nameId: '849895A7-1CF0-4CDA-880E-D473C07A3255',
                            frame: {
                                width: 304,
                                height: 100,
                                x: 0,
                                y: 204
                            },
                            imageStyles: {
                                resize: 'stretch'
                            },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1.XunvMmTBuNjy1XbXXaMrVXa-304-100.png'
                        }
                    ],
                    type: 'group',
                    objectID: '39703305-0F47-4535-9368-2C3A43C96F75'
                },
                {
                    name: 'Bitmap',
                    Id: 38,
                    nameId: '4E5DAFC1-BF4C-4D32-B41B-7E04886C4D3F',
                    frame: {
                        width: 60,
                        height: 56,
                        x: 224,
                        y: 0
                    },
                    imageStyles: {
                        resize: 'stretch'
                    },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1z7a7vFuWBuNjSszbXXcS7FXa-60-56.png'
                },
                {
                    name: 'Group',
                    Id: 40,
                    nameId: '91BB7CA0-9FE4-4BAA-8810-795414A45E95',
                    frame: {
                        width: 112,
                        height: 60,
                        x: 20,
                        y: 18
                    },
                    layers: [
                        {
                            name: 'Rectangle 5',
                            Id: 41,
                            nameId: '81F487A4-415C-4FD4-92B7-328B23AB4E23',
                            frame: {
                                width: 112,
                                height: 60,
                                x: 20,
                                y: 18
                            },
                            styles: {
                                borderColor: 'rgba(255,255,255,1)',
                                borderStyle: 'solid',
                                borderWidth: 1,
                                borderRadius: 6
                            },
                            type: 'shape'
                        },
                        {
                            name: 'Rectangle 6',
                            Id: 42,
                            nameId: '0D5E6D2E-B485-4D35-BC88-59B918B345A8',
                            frame: {
                                width: 112,
                                height: 30,
                                x: 20,
                                y: 18
                            },
                            styles: {
                                backgroundColor: 'rgba(255,255,255,1)',
                                borderBottomLeftRadius: '0',
                                borderBottomRightRadius: '0',
                                borderTopLeftRadius: '6',
                                borderTopRightRadius: '6'
                            },
                            type: 'shape'
                        },
                        {
                            name: '票数 3330',
                            Id: 43,
                            nameId: '14EC2E21-77C8-484B-9527-FAD66A2CA0FC',
                            frame: {
                                width: 95,
                                height: 28,
                                x: 28,
                                y: 19
                            },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 20,
                                color: '#222222',
                                lineHeight: '28',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '票数 3330',
                            type: 'text'
                        },
                        {
                            name: '排名 287',
                            Id: 44,
                            nameId: '4833D3B4-516C-423E-AEDD-49E61E41C2BF',
                            frame: {
                                width: 82,
                                height: 28,
                                x: 28,
                                y: 48
                            },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 20,
                                color: '#FFFFFF',
                                lineHeight: '28',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '排名 287',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '91BB7CA0-9FE4-4BAA-8810-795414A45E95'
                },
                {
                    name: '钢铁侠全球限量款手办全球限量款40台…',
                    Id: 45,
                    nameId: 'C75587C4-A2EE-41AE-B5FD-24BB6301FB34',
                    frame: {
                        width: 264,
                        height: 80,
                        x: 20,
                        y: 317
                    },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 28,
                        color: '#222222',
                        lineHeight: '40',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '钢铁侠全球限量款手办全球限量款40台…',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 46,
                    nameId: 'EF69AD70-A59F-425F-AFA8-FC19861C8830',
                    frame: {
                        width: 264,
                        height: 54,
                        x: 20,
                        y: 414
                    },
                    imageStyles: {
                        resize: 'stretch'
                    },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1uXynvMmTBuNjy1XbXXaMrVXa-264-54.png'
                },
                {
                    name: '投票分1亿',
                    Id: 47,
                    nameId: '250BF853-32E8-44CF-97CA-DB9CEF47202F',
                    frame: {
                        width: 124,
                        height: 40,
                        x: 90,
                        y: 421
                    },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 28,
                        color: '#925715',
                        lineHeight: '40',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '投票分1亿',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 48,
                    nameId: '0AB2C047-F875-43C6-BE45-0769A7E28837',
                    frame: {
                        width: 56,
                        height: 56,
                        x: 20,
                        y: 228
                    },
                    imageStyles: {
                        resize: 'stretch'
                    },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1ZQa7vFuWBuNjSszbXXcS7FXa-56-56.png'
                },
                {
                    name: '淘大王池',
                    Id: 49,
                    nameId: '98BEA6A2-541F-4F36-963E-27E8C0D8EABE',
                    frame: {
                        width: 96,
                        height: 33,
                        x: 86,
                        y: 225
                    },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FFFFFF',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '淘大王池',
                    type: 'text'
                },
                {
                    name: '漫威复仇者集中营',
                    Id: 50,
                    nameId: 'EC3B6E6B-C57E-44CD-A13B-4296B3E36C26',
                    frame: {
                        width: 160,
                        height: 28,
                        x: 88,
                        y: 260
                    },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#FFDA44',
                        lineHeight: '28',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '漫威复仇者集中营',
                    type: 'text'
                },
                {
                    name: 'Rectangle 4',
                    Id: 51,
                    nameId: '3775AE70-6CD0-401A-9713-1C20E0E71F77',
                    frame: {
                        width: 90,
                        height: 24,
                        x: 191,
                        y: 229
                    },
                    styles: {
                        backgroundColor: 'rgba(255,34,34,1)',
                        borderRadius: 4
                    },
                    type: 'shape'
                },
                {
                    name: '我参赛的',
                    Id: 52,
                    nameId: 'FAC554AE-0816-4ABF-855F-B18B84D7D5EF',
                    frame: {
                        width: 80,
                        height: 28,
                        x: 196,
                        y: 226
                    },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#FFFFFF',
                        lineHeight: '28',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '我参赛的',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '40448049-3E5D-4136-866D-909B2925A557'
        }
    ],
    nameId: 1528183028761,
    Id: 27,
    type: 'group',
    frame: {
        x: 0,
        y: 0,
        width: 304,
        height: 488
    },
    styles: {
        backgroundColor: 'rgba(255,255,255,1)'
    }
};
