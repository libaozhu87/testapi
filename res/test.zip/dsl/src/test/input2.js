"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: "Rectangle 5",
            Id: 2,
            nameId: "28B1D17F-1E33-490C-B2FB-2A0177D82113",
            frame: { width: 750, height: 108, x: 0, y: 0 },
            layers: [
                {
                    name: "Group",
                    Id: 4,
                    nameId: "35C5FA47-6E13-4B90-9F5D-D210D58BD480",
                    frame: { width: 690, height: 82, x: 30, y: 26 },
                    layers: [
                        {
                            name: "Rectangle 11",
                            Id: 5,
                            nameId: "232EE54D-BDF5-47CD-A108-04C157F7FEF2",
                            frame: { width: 80, height: 80, x: 30, y: 26 },
                            imageStyles: { resize: "stretch" },
                            type: "image",
                            value: "https://gw.alicdn.com/tfs/TB1Xiv.kYSYBuNjSspfXXcZCpXa-80-80.png"
                        },
                        {
                            name: "Group",
                            Id: 7,
                            nameId: "C959EFCA-D838-4B8E-B285-F7DB645DF580",
                            frame: { width: 365, height: 80, x: 130, y: 28 },
                            layers: [
                                {
                                    name: "Group",
                                    Id: 9,
                                    nameId: "7B7DE161-F707-4FBE-9ACE-6842AF808EFD",
                                    frame: { width: 234, height: 36, x: 130, y: 28 },
                                    layers: [
                                        {
                                            name: "西溪包租婆",
                                            Id: 10,
                                            nameId: "63711B16-767D-44B3-8C4F-9C621BA0AC2E",
                                            frame: { width: 150, height: 36, x: 130, y: 28 },
                                            textStyles: {
                                                fontFamily: "PingFangSC-Medium",
                                                fontSize: "30",
                                                color: "#222222",
                                                lineHeight: "36",
                                                textAlign: "left",
                                                fontWeight: "bold"
                                            },
                                            value: "西溪包租婆",
                                            type: "text"
                                        },
                                        {
                                            name: "Bitmap",
                                            Id: 11,
                                            nameId: "7CF064FB-AD51-4681-A8B3-6C9C21DB43EA",
                                            frame: { width: 76, height: 28, x: 288, y: 32 },
                                            imageStyles: { resize: "stretch" },
                                            type: "image",
                                            value: "https://gw.alicdn.com/tfs/TB13YbYk1uSBuNjSsziXXbq8pXa-76-28.png"
                                        }
                                    ],
                                    type: "group",
                                    objectID: "7B7DE161-F707-4FBE-9ACE-6842AF808EFD"
                                },
                                {
                                    name: "Group",
                                    Id: 13,
                                    nameId: "C0525FF8-B276-4E64-B736-617F62702660",
                                    frame: { width: 365, height: 36, x: 130, y: 72 },
                                    layers: [
                                        {
                                            name: "Oval 3",
                                            Id: 14,
                                            nameId: "49E56A39-034A-4577-89DA-80E3EB13691B",
                                            frame: { width: 12, height: 12, x: 130, y: 84 },
                                            styles: { backgroundColor: "rgba(85,207,105,1)", fillType: "color", borderRadius: 12, opacity: 1 },
                                            type: "shape"
                                        },
                                        {
                                            name: "5分钟前·杭州 阿里巴巴西溪园区",
                                            Id: 15,
                                            nameId: "9B5A7FB7-E81A-4B3F-B9BC-7D6BE267F421",
                                            frame: { width: 347, height: 36, x: 148, y: 72 },
                                            textStyles: {
                                                fontFamily: "PingFangSC-Regular",
                                                fontSize: "24",
                                                color: "#888888",
                                                lineHeight: "36",
                                                textAlign: "left",
                                                fontWeight: "normal"
                                            },
                                            value: "5分钟前·杭州 阿里巴巴西溪园区",
                                            type: "text"
                                        }
                                    ],
                                    type: "group",
                                    objectID: "C0525FF8-B276-4E64-B736-617F62702660"
                                }
                            ],
                            type: "group",
                            objectID: "C959EFCA-D838-4B8E-B285-F7DB645DF580"
                        },
                        {
                            name: "¥",
                            Id: 16,
                            nameId: "B28370DC-AEB2-4CE9-AABC-9B7CC1889E8B",
                            frame: { width: 15, height: 28, x: 576, y: 38 },
                            textStyles: {
                                fontFamily: "PingFangSC-Regular",
                                fontSize: "24",
                                color: "#FF4444",
                                textAlign: "left",
                                lineHeight: "28",
                                fontWeight: "normal"
                            },
                            value: "¥",
                            type: "text"
                        },
                        {
                            name: "6000",
                            Id: 17,
                            nameId: "2F1B126C-FEA3-48CD-86E3-4DE50AB7B7DE",
                            frame: { width: 87, height: 36, x: 597, y: 30 },
                            textStyles: {
                                fontFamily: "PingFangSC-Medium",
                                fontSize: "36",
                                color: "#FF4444",
                                textAlign: "right",
                                lineHeight: "36",
                                fontWeight: "bold"
                            },
                            value: "6000",
                            type: "text"
                        },
                        {
                            name: "/月",
                            Id: 18,
                            nameId: "96EE9519-0357-4F83-ACA5-CA2023D8F99D",
                            frame: { width: 36, height: 28, x: 684, y: 38 },
                            textStyles: {
                                fontFamily: "PingFangSC-Regular",
                                fontSize: "24",
                                color: "#FF4444",
                                textAlign: "left",
                                lineHeight: "28",
                                fontWeight: "normal"
                            },
                            value: "/月",
                            type: "text"
                        }
                    ],
                    type: "group",
                    objectID: "35C5FA47-6E13-4B90-9F5D-D210D58BD480"
                },
                {
                    name: "padding",
                    Id: 19,
                    nameId: "12A7990A-D199-4166-92E6-52AC9F77CAEB",
                    frame: { width: 750, height: 10, x: 0, y: 0 },
                    styles: { backgroundColor: "rgba(255,255,255,1)", fillType: "color", opacity: 1 },
                    type: "shape"
                }
            ],
            type: "group",
            objectID: "28B1D17F-1E33-490C-B2FB-2A0177D82113"
        },
        {
            name: "Rectangle 5 Copy 5",
            Id: 21,
            nameId: "1D1ACB44-57C0-431B-AF61-371CCE91C3CD",
            frame: { width: 594, height: 80, x: 130, y: 122 },
            layers: [
                {
                    name: "Ducati Monster 821 国",
                    Id: 22,
                    nameId: "32FE67CA-A86D-4128-8156-324B6C38DCB3",
                    frame: { width: 594, height: 80, x: 130, y: 122 },
                    textStyles: {
                        fontFamily: "PingFangSC-Regular",
                        fontSize: "28",
                        color: "#222222",
                        letterSpacing: "0",
                        lineHeight: "40",
                        maxWidth: 594,
                        maxHeight: 80,
                        textAlign: "left",
                        fontWeight: "normal"
                    },
                    value: "Ducati Monster 821 国行大贸易 全国过户提档喜欢的盆友看看~",
                    type: "text"
                }
            ],
            type: "group",
            objectID: "1D1ACB44-57C0-431B-AF61-371CCE91C3CD"
        },
        {
            name: "Rectangle 5 Copy 8",
            Id: 23,
            nameId: "F911E338-3F71-4CC0-802E-C0C72E94EDBB",
            frame: { width: 750, height: 20, x: 0, y: 202 },
            styles: { backgroundColor: "rgba(255,255,255,1)", fillType: "color", opacity: 1 },
            type: "shape"
        },
        {
            name: "Rectangle 5 Copy",
            Id: 25,
            nameId: "33896AC1-B6B3-4BAF-9BBE-E0FB4C24895B",
            frame: { width: 392, height: 392, x: 130, y: 222 },
            layers: [
                {
                    name: "Mask",
                    Id: 27,
                    nameId: "033153F3-8AE7-4639-9AED-822C12005045",
                    frame: { width: 392, height: 392, x: 130, y: 222 },
                    layers: [
                        {
                            name: "Mask",
                            Id: 28,
                            nameId: "CFCC5F99-448D-452C-A29A-40BA4313435A",
                            frame: { width: 392, height: 392, x: 130, y: 222 },
                            imageStyles: { resize: "stretch" },
                            type: "image",
                            value: "https://gw.alicdn.com/tfs/TB1ATDpkVuWBuNjSszbXXcS7FXa-392-392.png"
                        }
                    ],
                    type: "group",
                    objectID: "033153F3-8AE7-4639-9AED-822C12005045"
                }
            ],
            type: "group",
            objectID: "33896AC1-B6B3-4BAF-9BBE-E0FB4C24895B"
        },
        {
            name: "Group 9",
            Id: 30,
            nameId: "897B17A6-BEBF-4C11-8D0F-54658BA8177D",
            frame: { width: 590, height: 32, x: 130, y: 642 },
            layers: [
                {
                    name: "Rectangle 11 Copy 14",
                    Id: 32,
                    nameId: "6144F97C-25F9-4DFA-9979-2E3271F4A618",
                    frame: { width: 590, height: 32, x: 130, y: 642 },
                    layers: [
                        {
                            name: "Group",
                            Id: 34,
                            nameId: "90C78010-EF13-4B54-83E5-92545EFF9948",
                            frame: { width: 590, height: 32, x: 130, y: 642 },
                            layers: [
                                {
                                    name: "160个超赞·33人收藏",
                                    Id: 35,
                                    nameId: "AE19EE9B-2B9B-49CE-9ED7-E39FFA966EBB",
                                    frame: { width: 224, height: 32, x: 130, y: 642 },
                                    textStyles: {
                                        fontFamily: "PingFangSC-Regular",
                                        fontSize: "24",
                                        color: "#888888",
                                        letterSpacing: "0",
                                        lineHeight: "32",
                                        textAlign: "left",
                                        fontWeight: "normal"
                                    },
                                    value: "160个超赞·33人收藏",
                                    type: "text"
                                },
                                {
                                    name: "Bitmap",
                                    Id: 36,
                                    nameId: "BB11773B-A478-4BAC-8974-67FBD483E6C9",
                                    frame: { width: 32, height: 32, x: 688, y: 642 },
                                    imageStyles: { resize: "stretch" },
                                    type: "image",
                                    value: "https://gw.alicdn.com/tfs/TB1rXLzkWSWBuNjSsrbXXa0mVXa-32-32.png"
                                }
                            ],
                            type: "group",
                            objectID: "90C78010-EF13-4B54-83E5-92545EFF9948"
                        }
                    ],
                    type: "group",
                    objectID: "6144F97C-25F9-4DFA-9979-2E3271F4A618"
                }
            ],
            type: "group",
            objectID: "897B17A6-BEBF-4C11-8D0F-54658BA8177D"
        }
    ],
    nameId: 1523429975433,
    Id: 0,
    type: "group",
    frame: { x: 0, y: 0, width: 750, height: 702 }
};
