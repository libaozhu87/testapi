"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    type: 'group',
    frame: {
        width: 336,
        height: 240,
        x: 0,
        y: 0
    },
    layers: [
        {
            frame: {
                width: 336,
                height: 240,
                x: 0,
                y: 0
            },
            skecthName: 'Mask',
            objectID: '803EBBB2-19D4-41FB-9433-D5D00E675B73',
            id: 0,
            layers: []
        },
        {
            frame: {
                width: 120,
                height: 120,
                x: 38,
                y: 100
            },
            skecthName: 'Mask',
            objectID: '167E36C7-7666-4897-827C-4D325061293F',
            id: 1,
            layers: []
        },
        {
            frame: {
                width: 74,
                height: 32,
                x: 38,
                y: 188
            },
            skecthName: 'Rectangle 14',
            objectID: '352CA5DB-6179-4588-9E2F-DBF1BFA0B5EC',
            id: 2,
            layers: []
        },
        {
            frame: {
                width: 62,
                height: 28,
                x: 44,
                y: 194
            },
            skecthName: '0.5Km',
            objectID: '0B9E0C2C-D1A2-4AB3-B4A1-01F21568178A',
            id: 3,
            layers: []
        },
        {
            frame: {
                width: 120,
                height: 120,
                x: 178,
                y: 100
            },
            skecthName: 'Mask',
            objectID: '3239A671-8D8E-45F5-B38F-C169AD32F3A5',
            id: 4,
            layers: []
        },
        {
            frame: {
                width: 164,
                height: 122,
                x: 162,
                y: 100
            },
            skecthName: 'Bitmap',
            objectID: '493C9C3B-99CD-474A-A3AA-82506740F1DA',
            id: 5,
            layers: []
        },
        {
            frame: {
                width: 128,
                height: 45,
                x: 24,
                y: 20
            },
            skecthName: '闲鱼租房',
            objectID: '9B8A7764-2C7B-4245-8A1B-57DA3D0BF9A9',
            id: 6,
            layers: []
        },
        {
            frame: {
                width: 209,
                height: 37,
                x: 24,
                y: 60
            },
            skecthName: '真实房东免中介费',
            objectID: '896A4839-C8BB-42F5-81EE-40247B74E171',
            id: 7,
            layers: []
        },
        {
            frame: {
                width: 100,
                height: 32,
                x: 160,
                y: 20
            },
            skecthName: 'Rectangle 14',
            objectID: 'DAD69CC8-3899-4BB9-A3F8-6E3D8B3C9E92',
            id: 8,
            layers: []
        },
        {
            frame: {
                width: 88,
                height: 30,
                x: 166,
                y: 26
            },
            skecthName: '免中介费',
            objectID: '2556D41A-0FA5-4A68-B5C2-D137049F0733',
            id: 9,
            layers: []
        }
    ]
};
