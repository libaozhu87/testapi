"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        { frame: { y: 26, x: 30, height: 80, width: 80 }, type: 'image', id: 1, value: 'http://47.100.92.83:8081/ui/30_26_80_80_image.png' },
        {
            textStyles: { color: '#222222', lineHeight: 31, fontSize: 31 },
            frame: { y: 32, x: 131, height: 31, width: 149 },
            type: 'text',
            id: 2,
            value: '\u897f\u6eaa\u5305\u79df\u5a46'
        },
        {
            styles: { opacity: 1, borderStyle: 'solid', backgroundColor: 'rgba(242,252,252,1)' },
            frame: { y: 32, x: 288, height: 28, width: 76 },
            type: 'shape',
            id: 5
        },
        { frame: { y: 36, x: 294, height: 20, width: 18 }, type: 'image', id: 3, value: 'http://47.100.92.83:8081/ui/294_36_18_20_icon.png' },
        {
            textStyles: { color: '#3bd7d0', lineHeight: 19, fontSize: 19 },
            frame: { y: 37, x: 316, height: 19, width: 40 },
            type: 'text',
            id: 4,
            value: '\u4f18'
        },
        {
            styles: {
                opacity: 1,
                borderColor: 'rgba(100,210,118,1)',
                borderRadius: 4,
                borderWidth: 2,
                backgroundColor: 'rgba(85,207,105,1)',
                borderStyle: 'solid'
            },
            frame: { y: 84, x: 131, height: 12, width: 12 },
            type: 'shape',
            id: 6
        },
        {
            textStyles: { color: '#888888', lineHeight: 25, fontSize: 25 },
            frame: { y: 79, x: 150, height: 25, width: 345 },
            type: 'text',
            id: 7,
            value: '5\u5206\u949f\u524d\u00b7\u676d\u5dde \u963f\u91cc\u5df4\u5df4\u897f\u6eaal\u533a'
        },
        {
            textStyles: { color: '#ff4444', lineHeight: 25, fontSize: 25 },
            frame: { y: 40, x: 576, height: 25, width: 15 },
            type: 'text',
            id: 8,
            value: '\u00a5'
        },
        {
            textStyles: { color: '#ff4444', lineHeight: 29, fontSize: 29 },
            frame: { y: 34, x: 598, height: 31, width: 98 },
            type: 'text',
            id: 9,
            value: '6000/'
        },
        {
            textStyles: { color: '#ff4444', lineHeight: 24, fontSize: 24 },
            frame: { y: 42, x: 699, height: 24, width: 18 },
            type: 'text',
            id: 10,
            value: '\u6708'
        },
        {
            textStyles: { color: '#222222', lineHeight: 28, fontSize: 28 },
            frame: { y: 129, x: 132, height: 28, width: 578 },
            type: 'text',
            id: 11,
            value: 'Ducati Monster 821 \u540c\u884c\u5927\u8d38\u6613 \u5168\u540c\u8fc7\u6237\u63d0\u6863'
        },
        {
            textStyles: { color: '#222222', lineHeight: 28, fontSize: 28 },
            frame: { y: 168, x: 131, height: 28, width: 210 },
            type: 'text',
            id: 12,
            value: '\u559c\u6b22\u7684\u76c6\u53cb\u770b\u770b~'
        },
        {
            frame: { y: 222, x: 130, height: 392, width: 392 },
            type: 'image',
            id: 13,
            value: 'http://47.100.92.83:8081/ui/130_222_392_392_image.png'
        },
        {
            textStyles: { color: '#888888', lineHeight: 26, fontSize: 26 },
            frame: { y: 646, x: 131, height: 26, width: 222 },
            type: 'text',
            id: 14,
            value: '160\u4e2a\u8d85\u8d5e\u00b733\u4eba\u6536\u85cf'
        },
        {
            textStyles: { color: '#000000', lineHeight: 27, fontSize: 27 },
            frame: { y: 642, x: 700, height: 32, width: 8 },
            type: 'text',
            id: 15,
            value: 'l'
        }
    ],
    frame: { y: 0, x: 0, height: 702, width: 750 },
    type: 'group',
    id: 0
};
