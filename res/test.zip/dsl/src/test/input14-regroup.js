"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    type: 'group',
    frame: { width: 756, height: 520, x: 0, y: 0 },
    layers: [
        {
            frame: { width: 597.9042262399894, height: 48, x: 40.547886880005535, y: 70 },
            skecthName: 'Rectangle 3',
            objectID: '0A0F0909-947F-4C62-BB9D-9F4A45E040F3',
            id: 0,
            layers: []
        },
        {
            frame: { width: 616.95012437888, height: 50, x: 33.524937810560004, y: 61 },
            skecthName: 'Rectangle 3',
            objectID: '31AEBB78-7AA3-478A-AF1F-55612DA5CEB8',
            id: 1,
            layers: []
        },
        {
            frame: { width: 20, height: 22, x: 52, y: 76 },
            skecthName: 'Fill 1',
            objectID: '121E1753-584E-4EF6-AF0F-8B113290895A',
            id: 2,
            layers: []
        },
        {
            frame: { width: 364, height: 40, x: 83, y: 66 },
            skecthName: '附近的妈妈都在这些鱼塘交流',
            objectID: '7581950F-1493-4406-BA0E-178B861F49DD',
            id: 3,
            layers: []
        },
        {
            frame: { width: 123, height: 79, x: 595, y: 33 },
            skecthName: 'Group 9',
            objectID: '55512862-AEB9-44F3-B941-C24CA2B1CE41',
            id: 4,
            layers: []
        },
        {
            frame: { width: 102, height: 95, x: 603, y: 23 },
            skecthName: '7a62e3ce4dc9d8741198f727155556cfdb09baa23a9ca2-uV3faN_fw658',
            objectID: '9F271AAE-E933-46C5-BADC-FED41785B7B0',
            id: 5,
            layers: []
        },
        {
            frame: { width: 104, height: 104, x: 33, y: 147 },
            skecthName: 'Mask',
            objectID: '318E1D44-1BC5-40A7-BFF0-8A522834E7D8',
            id: 6,
            layers: []
        },
        {
            frame: { width: 52, height: 52, x: 33, y: 147 },
            skecthName: 'Mask Copy 6',
            objectID: 'C6E868B8-E9DB-4558-97D0-8CA7546292FE',
            id: 7,
            layers: []
        },
        {
            frame: { width: 51, height: 52, x: 86, y: 147 },
            skecthName: 'Mask Copy 7',
            objectID: '36B3BEE8-8E5B-4AF7-B74F-F050094466DC',
            id: 8,
            layers: []
        },
        {
            frame: { width: 51, height: 51, x: 33, y: 200 },
            skecthName: 'Mask Copy 8',
            objectID: '1CBFFCEB-5E2F-4024-9A48-9060D6E9F791',
            id: 9,
            layers: []
        },
        {
            frame: { width: 51, height: 51, x: 86, y: 200 },
            skecthName: 'Mask Copy 9',
            objectID: '8DFF995B-6686-41C6-A5F5-6EC6C2CD20B4',
            id: 10,
            layers: []
        },
        {
            frame: { width: 1, height: 104.00000000000045, x: 85, y: 147 },
            skecthName: 'Rectangle 58',
            objectID: '56F5E3A5-9A53-4834-80D4-15E55E225B71',
            id: 11,
            layers: []
        },
        {
            frame: { width: 104, height: 1, x: 32.99999999999909, y: 198.99999999999864 },
            skecthName: 'Rectangle 58 Copy',
            objectID: '2D28D4E2-51BC-4A99-A212-FF7AA98ED08D',
            id: 12,
            layers: []
        },
        {
            frame: { width: 118, height: 64, x: 605, y: 167 },
            skecthName: 'Rectangle',
            objectID: '65731FBB-B87B-4D6D-8EE7-5A3E92A26225',
            id: 13,
            layers: []
        },
        {
            frame: { width: 56, height: 40, x: 637, y: 179 },
            skecthName: '加入',
            objectID: '33C6F122-F1D3-42D5-8B61-858A3B759AF2',
            id: 14,
            layers: []
        },
        {
            frame: { width: 313, height: 42, x: 158, y: 158 },
            skecthName: '💗新锐宝妈团💗(337人)',
            objectID: 'FF6525F6-43EE-40CE-96DB-4727FF744650',
            id: 15,
            layers: []
        },
        {
            frame: { width: 20, height: 24, x: 159, y: 214 },
            skecthName: 'Group 43',
            objectID: 'A37DF104-21D8-4CAE-B03B-4D175A6AB4C9',
            id: 16,
            layers: []
        },
        {
            frame: { width: 193, height: 42, x: 186, y: 205 },
            skecthName: '杭州 473件闲置',
            objectID: '59B88ACD-414F-48A6-938D-E0D528247E1B',
            id: 17,
            layers: []
        },
        {
            frame: { width: 4, height: 4, x: 245, y: 223 },
            skecthName: 'Oval',
            objectID: '952C03F8-3F8A-401C-A863-5C1CEF3A06D4',
            id: 18,
            layers: []
        },
        {
            frame: { width: 104, height: 104, x: 33, y: 287 },
            skecthName: 'Mask',
            objectID: '83D00C7B-3D8E-4778-B52D-BD9963E517F0',
            id: 19,
            layers: []
        },
        {
            frame: { width: 52, height: 52, x: 33, y: 287 },
            skecthName: 'Mask Copy 6',
            objectID: '540474D2-483C-47F7-BB16-D0F69FD30FF0',
            id: 20,
            layers: []
        },
        {
            frame: { width: 52, height: 52, x: 85, y: 287 },
            skecthName: 'Mask Copy 7',
            objectID: 'E2F9D4FE-4AF5-40DB-BE7E-2556811741B2',
            id: 21,
            layers: []
        },
        {
            frame: { width: 52, height: 52, x: 33, y: 339 },
            skecthName: 'Mask Copy 8',
            objectID: 'DC9825CD-EF4A-4407-A1B4-91D3955C0546',
            id: 22,
            layers: []
        },
        {
            frame: { width: 52, height: 52, x: 85, y: 339 },
            skecthName: 'Mask Copy 9',
            objectID: '38F93F5E-383D-4273-9EE0-F8E750E16A21',
            id: 23,
            layers: []
        },
        {
            frame: { width: 1.0833333333330302, height: 104.00000000000045, x: 85, y: 287 },
            skecthName: 'Rectangle 58',
            objectID: '95828572-34D2-4586-8A91-8FC40AE93EA4',
            id: 24,
            layers: []
        },
        {
            frame: { width: 104, height: 1.0833333333330302, x: 33, y: 339 },
            skecthName: 'Rectangle 58 Copy',
            objectID: '5ED6E459-C0FE-4B4A-A2EA-C54736117CF9',
            id: 25,
            layers: []
        },
        {
            frame: { width: 118, height: 64, x: 605, y: 307 },
            skecthName: 'Rectangle',
            objectID: '9F12FB38-D489-4342-A347-059BDC9801FF',
            id: 26,
            layers: []
        },
        {
            frame: { width: 56, height: 40, x: 637, y: 319 },
            skecthName: '加入',
            objectID: '55BD789F-080B-4921-B6DB-739F35178504',
            id: 27,
            layers: []
        },
        {
            frame: { width: 309, height: 42, x: 159, y: 297 },
            skecthName: '美少女妈妈群👶(193人)',
            objectID: 'C33E714A-9382-42C4-873A-14B6EDCBEF51',
            id: 28,
            layers: []
        },
        {
            frame: { width: 20, height: 24, x: 160, y: 353 },
            skecthName: 'Group 43',
            objectID: '80475A56-7472-481F-8463-DDE45496249D',
            id: 29,
            layers: []
        },
        {
            frame: { width: 231, height: 42, x: 187, y: 344 },
            skecthName: '大华风情 89件闲置',
            objectID: '8438587A-6CFF-415B-9C0B-B7AF89839BEE',
            id: 30,
            layers: []
        },
        {
            frame: { width: 4, height: 4, x: 298, y: 362 },
            skecthName: 'Oval',
            objectID: '1CA7DEC7-C335-4800-A624-BB1DC6FFF2B8',
            id: 31,
            layers: []
        },
        {
            frame: { width: 750, height: 88, x: 3, y: 421 },
            skecthName: 'Rectangle 3',
            objectID: 'E3EFA896-2C0C-40C2-874F-7EE3C4EDD682',
            id: 32,
            layers: []
        },
        {
            frame: { width: 112, height: 40, x: 314, y: 445 },
            skecthName: '更多鱼塘',
            objectID: '37D4C7E6-D716-479A-B763-864E13586181',
            id: 33,
            layers: []
        },
        {
            frame: { width: 7, height: 14, x: 434.5, y: 458.5 },
            skecthName: 'Path 3',
            objectID: 'F516F0AF-85ED-40F4-94A4-F5A381BBC031',
            id: 34,
            layers: []
        },
        {
            frame: { width: 753, height: 10, x: 0, y: 510 },
            skecthName: 'Rectangle 224 Copy 7',
            objectID: '3836A451-CFF4-4158-88FE-9053D59490F1',
            id: 35,
            layers: []
        },
        {
            frame: { width: 753, height: 10, x: 3, y: 0 },
            skecthName: 'Rectangle 224 Copy 4',
            objectID: '0541C808-6B15-4CD0-90E0-60E8C2D71651',
            id: 36,
            layers: []
        }
    ]
};
