"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Background',
            Id: 8,
            nameId: '503BB162-5A74-46C0-84BE-DB4DB57460A3',
            frame: { width: 228, height: 81.68644067796595, x: 0, y: 0.3135593220338251 },
            styles: { backgroundColor: 'rgba(99,99,99,1)', fillType: 'color', opacity: 1 },
            type: 'shape'
        },
        {
            name: '精品套装专区',
            Id: 9,
            nameId: '60862899-F85B-47FC-8328-F42A8A14BAD0',
            frame: { width: 170, height: 40, x: 30, y: 21 },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                color: '#FFFFFF',
                letterSpacing: '0.27',
                lineHeight: '40',
                textAlign: 'left',
                fontWeight: 'bold'
            },
            value: '精品套装专区',
            type: 'text'
        }
    ],
    nameId: 1523617068649,
    Id: 7,
    type: 'group',
    frame: { x: 0, y: 0, width: 228, height: 82 }
};
