"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Navigation Bar',
            Id: 230,
            nameId: 'A71D3463-8A66-48EC-B773-FDFA764C1DE5',
            frame: { width: 750, height: 134, x: 0, y: 0 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 231,
                    nameId: '4B2A9AB6-D663-4D2E-830A-750016166621',
                    frame: { width: 750, height: 134, x: 0, y: 0 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1Un.grNWYBuNjy1zkXXXGGpXa-750-134.png'
                },
                {
                    name: 'Louie',
                    Id: 232,
                    nameId: 'C2315FB1-E92B-40D2-9797-D34B3992869A',
                    frame: { width: 170, height: 48, x: 290.5, y: 60 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 34,
                        color: '#333333',
                        textAlign: 'center',
                        lineHeight: '48',
                        fontWeight: 'bold'
                    },
                    value: '卖闲置换钱',
                    type: 'text'
                },
                {
                    name: 'Status Bar black',
                    Id: 234,
                    nameId: '6E67A33B-5A81-467D-83F4-AC531607C5D1',
                    frame: { width: 726, height: 33, x: 13, y: 3 },
                    layers: [
                        {
                            name: 'Signal',
                            Id: 236,
                            nameId: 'E2D90DA5-436B-4F33-9E13-E38C98CE5118',
                            frame: { width: 189, height: 28, x: 13, y: 8 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 237,
                                    nameId: '0489BA90-F790-454B-BCCF-66F36E47318A',
                                    frame: { width: 68, height: 11, x: 13, y: 15 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1akzrrFuWBuNjSszbXXcS7FXa-68-11.png'
                                },
                                {
                                    name: 'VIRGI',
                                    Id: 238,
                                    nameId: '1E114C33-77AF-466F-9BB2-2E96E1D5B09E',
                                    frame: { width: 62, height: 27, x: 89, y: 8 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 22,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '27',
                                        fontWeight: 'normal'
                                    },
                                    value: 'VIRGI',
                                    type: 'text'
                                },
                                {
                                    name: 'N',
                                    Id: 239,
                                    nameId: '61C1A04C-66E6-40A3-A5C3-51530FC2D480',
                                    frame: { width: 17, height: 27, x: 150.606, y: 8 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 22,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '27',
                                        fontWeight: 'normal'
                                    },
                                    value: 'N',
                                    type: 'text'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 240,
                                    nameId: '86EE8D7B-CA10-496F-ABFE-05B3D09E548B',
                                    frame: { width: 24, height: 19, x: 178, y: 11 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1__.grNWYBuNjy1zkXXXGGpXa-24-19.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'E2D90DA5-436B-4F33-9E13-E38C98CE5118'
                        },
                        {
                            name: 'Bitmap',
                            Id: 241,
                            nameId: '0E9A5F34-5128-4275-A5FA-73FFDB148C91',
                            frame: { width: 16, height: 27, x: 603, y: 7 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1v_jzrQ9WBuNjSspeXXaz5VXa-16-27.png'
                        },
                        {
                            name: 'Battery',
                            Id: 243,
                            nameId: '00E6C00E-531D-4A9F-8F05-08E93B09B29F',
                            frame: { width: 413, height: 33, x: 326, y: 3 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 244,
                                    nameId: '9026897B-0E4C-4875-A4BB-44235D7FA01C',
                                    frame: { width: 3, height: 7, x: 736, y: 17 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB16BcDrTlYBeNjSszcXXbwhFXa-3-7.png'
                                },
                                {
                                    name: 'Shape',
                                    Id: 245,
                                    nameId: '987F4C32-A883-4907-A8E1-7A42A909A9D8',
                                    frame: { width: 14, height: 15, x: 692, y: 13 },
                                    styles: {
                                        backgroundColor: 'rgba(0,0,0,1)',
                                        borderBottomLeftRadius: '1',
                                        borderBottomRightRadius: '0',
                                        borderTopLeftRadius: '1',
                                        borderTopRightRadius: '0'
                                    },
                                    type: 'shape'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 246,
                                    nameId: '7C3AA678-42FB-4F00-9E50-72DECC11762A',
                                    frame: { width: 45, height: 19, x: 690, y: 11 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1EQzrrFuWBuNjSszbXXcS7FXa-45-19.png'
                                },
                                {
                                    name: '22',
                                    Id: 247,
                                    nameId: '202A65D9-DFC3-4FD5-95EC-A5725A51C889',
                                    frame: { width: 28, height: 28, x: 633, y: 7 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue-Light',
                                        fontSize: 23,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '28',
                                        fontWeight: 'normal'
                                    },
                                    value: '22',
                                    type: 'text'
                                },
                                {
                                    name: '%',
                                    Id: 248,
                                    nameId: '05BAAFC6-4105-49D6-9E2C-2164DE25D3C5',
                                    frame: { width: 22, height: 28, x: 660.576, y: 7 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue-Light',
                                        fontSize: 23,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '28',
                                        fontWeight: 'normal'
                                    },
                                    value: '%',
                                    type: 'text'
                                },
                                {
                                    name: '4 21 PM',
                                    Id: 249,
                                    nameId: '44939BAD-24E2-430D-B136-044CBE8C5971',
                                    frame: { width: 97, height: 30, x: 326, y: 6 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 24,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '29',
                                        fontWeight: 'normal'
                                    },
                                    value: '4 21 PM',
                                    type: 'text'
                                },
                                {
                                    name: ':',
                                    Id: 250,
                                    nameId: '7598F98E-979D-45E8-BE22-4FB1624C96DC',
                                    frame: { width: 9, height: 33, x: 339.5, y: 3 },
                                    textStyles: {
                                        fontFamily: 'AvenirNext-Regular',
                                        fontSize: 24,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '33',
                                        fontWeight: 'normal'
                                    },
                                    value: ':',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '00E6C00E-531D-4A9F-8F05-08E93B09B29F'
                        }
                    ],
                    type: 'group',
                    objectID: '6E67A33B-5A81-467D-83F4-AC531607C5D1'
                }
            ],
            type: 'group',
            objectID: 'A71D3463-8A66-48EC-B773-FDFA764C1DE5'
        },
        {
            name: 'Bitmap',
            Id: 251,
            nameId: '86DF75E6-9C81-47E9-95EF-14B13339568D',
            frame: { width: 18, height: 33, x: 35, y: 67 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1f8gDrTlYBeNjSszcXXbwhFXa-18-33.png'
        },
        {
            name: 'Rectangle 4',
            Id: 252,
            nameId: '380BC6A0-781A-4890-8776-83CD67CBA65B',
            frame: { width: 750, height: 1205, x: 0, y: 647 },
            styles: { backgroundColor: 'rgba(255,255,255,1)' },
            type: 'shape'
        },
        {
            name: '淘宝买多了 卖了回本 + 近一年你在淘宝买的宝贝卖掉可回血 + 22878元 + Rectangle 7 Mask',
            Id: 254,
            nameId: '880B0098-099C-44D6-8DDD-FF1AF8CA3F0F',
            frame: { width: 750, height: 88, x: 0, y: 559 },
            layers: [
                {
                    name: 'Mask',
                    Id: 255,
                    nameId: '16C57BE5-6294-4EEC-AD08-4D2EAD224646',
                    frame: { width: 750, height: 88, x: 0, y: 559 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)' },
                    type: 'shape'
                },
                {
                    name: '我的闲置',
                    Id: 256,
                    nameId: 'BA14273E-B55D-4322-8B49-372C1959548D',
                    frame: { width: 128, height: 44, x: 311, y: 581 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#222222',
                        lineHeight: '44',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '我的闲置',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 257,
                    nameId: '40A45EBC-BAED-4745-ACE3-E58267B4EC7C',
                    frame: { width: 224, height: 4, x: 262, y: 603 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1VTa5rQKWBuNjy1zjXXcOypXa-224-4.png'
                }
            ],
            type: 'group',
            objectID: '880B0098-099C-44D6-8DDD-FF1AF8CA3F0F'
        },
        {
            name: 'Bitmap',
            Id: 258,
            nameId: 'F108E49F-B017-498B-86C7-E8BED6C93DC6',
            frame: { width: 750, height: 1, x: 0, y: 645 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1v8gDrTlYBeNjSszcXXbwhFXa-750-1.png'
        },
        {
            name: 'Group 3',
            Id: 260,
            nameId: 'F0940CFB-593C-4AFA-8E82-D386EAC7F37A',
            frame: { width: 159, height: 1206, x: 0, y: 650 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 261,
                    nameId: '8E226DC0-0C4D-42D0-9B83-B4092F9DF8F0',
                    frame: { width: 1, height: 1206, x: 158, y: 650 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB11wn9rHSYBuNjSspfXXcZCpXa-1-1206.png'
                },
                {
                    name: '热门转卖',
                    Id: 262,
                    nameId: 'E364EBB3-13C0-4E0B-840D-DCAEB75EE15C',
                    frame: { width: 112, height: 40, x: 26, y: 684.5999984741211 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 28,
                        color: '#333333',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'bold'
                    },
                    value: '热门转卖',
                    type: 'text'
                },
                {
                    name: '男士服装',
                    Id: 263,
                    nameId: 'D8B89045-F6F8-4ADE-AA69-99C6A18519B8',
                    frame: { width: 112, height: 40, x: 26, y: 786.5999984741211 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '男士服装',
                    type: 'text'
                },
                {
                    name: '家具/饰品',
                    Id: 264,
                    nameId: 'CCA8CA6D-2C6C-40CE-A634-0C27C1EFD90D',
                    frame: { width: 126, height: 40, x: 19.5, y: 891.5999984741211 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '家具/饰品',
                    type: 'text'
                },
                {
                    name: '运动户外',
                    Id: 265,
                    nameId: '9CD17D60-8E18-4053-9007-3702A4DCF328',
                    frame: { width: 112, height: 40, x: 26, y: 994.5999984741211 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '运动户外',
                    type: 'text'
                },
                {
                    name: '3C数码',
                    Id: 266,
                    nameId: 'E7DC2912-0E0D-4396-B352-0BF0A44EBBEE',
                    frame: { width: 94, height: 40, x: 35, y: 1100.599998474121 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '3C数码',
                    type: 'text'
                },
                {
                    name: '个人美妆',
                    Id: 267,
                    nameId: '3267917D-9AF8-4AFF-B07C-3F70D0C36AC8',
                    frame: { width: 112, height: 40, x: 26, y: 1204.599998474121 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '个人美妆',
                    type: 'text'
                },
                {
                    name: '箱包',
                    Id: 268,
                    nameId: '06C5E6A1-9D1A-41D9-8BB8-BCD5B802C386',
                    frame: { width: 56, height: 40, x: 54, y: 1306.599998474121 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '箱包',
                    type: 'text'
                },
                {
                    name: 'Rectangle 7',
                    Id: 269,
                    nameId: '08F2C099-9138-4898-AA10-A59113FBF13A',
                    frame: { width: 8, height: 56, x: 0, y: 677 },
                    styles: { backgroundColor: 'rgba(255,218,68,1)' },
                    type: 'shape'
                }
            ],
            type: 'group',
            objectID: 'F0940CFB-593C-4AFA-8E82-D386EAC7F37A'
        },
        {
            name: 'Bitmap',
            Id: 270,
            nameId: 'F5EA84FC-474C-4E95-AB61-DA0D0596D573',
            frame: { width: 20, height: 36, x: 36, y: 66 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1ySYxrL9TBuNjy1zbXXXpepXa-20-36.png'
        },
        {
            name: 'Group 4',
            Id: 272,
            nameId: '0953B598-2C47-44B3-BB58-834EBDD19785',
            frame: { width: 590, height: 212, x: 160, y: 722 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 273,
                    nameId: 'F5F56403-727B-4104-BD0F-4F84DA209609',
                    frame: { width: 571, height: 2, x: 179, y: 932 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1nDe5rQKWBuNjy1zjXXcOypXa-571-2.png'
                },
                {
                    name: 'Bitmap',
                    Id: 275,
                    nameId: 'E78FD32A-1BAF-442E-BB15-8C19F95B1009',
                    frame: { width: 148, height: 148, x: 180, y: 754 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 277,
                            nameId: 'AE7B1E6B-93EF-4BD8-AE41-F82DD6049808',
                            frame: { width: 148, height: 148, x: 180, y: 754 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 278,
                                    nameId: '520F1FE9-9898-4CC6-AECD-985A654852D2',
                                    frame: { width: 148, height: 148, x: 180, y: 754 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1NCYxrL9TBuNjy1zbXXXpepXa-148-148.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'AE7B1E6B-93EF-4BD8-AE41-F82DD6049808'
                        }
                    ],
                    type: 'group',
                    objectID: 'E78FD32A-1BAF-442E-BB15-8C19F95B1009'
                },
                {
                    name: '转手卖  ',
                    Id: 279,
                    nameId: 'ACF598E3-41F5-40B7-AED6-C6C187AE6AFD',
                    frame: { width: 74, height: 28, x: 344, y: 859 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#333333',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '转手卖  ',
                    type: 'text'
                },
                {
                    name: '￥280.00',
                    Id: 280,
                    nameId: '43631FA6-9E89-4BCA-95FC-0AA8ADBF2A35',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 859 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '￥280.00',
                    type: 'text'
                },
                {
                    name: '聊一聊',
                    Id: 282,
                    nameId: 'D36E3F1E-70E2-4DC4-8A36-FC3E34B00590',
                    frame: { width: 132, height: 56, x: 598, y: 832 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 283,
                            nameId: 'D0CF4041-246C-46B7-AB00-88F2556D4719',
                            frame: { width: 132, height: 56, x: 598, y: 832 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1Q6DprH1YBuNjSszeXXablFXa-132-56.png'
                        },
                        {
                            name: '卖了换钱',
                            Id: 284,
                            nameId: 'AAC2521E-BF5D-4881-B36E-E984B7FE247C',
                            frame: { width: 96.00000000000011, height: 33, x: 616.2941176470588, y: 843 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖了换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'D36E3F1E-70E2-4DC4-8A36-FC3E34B00590'
                },
                {
                    name: '入手价  ',
                    Id: 285,
                    nameId: '1934CF7E-B5E1-46CF-A3EC-899E7B7A6C86',
                    frame: { width: 74, height: 28, x: 344, y: 825 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '入手价  ',
                    type: 'text'
                },
                {
                    name: '￥500.00',
                    Id: 286,
                    nameId: 'D495EE91-72AB-436C-8A7F-4A2FE307E62A',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 825 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '￥500.00',
                    type: 'text'
                },
                {
                    name: '全球首款触控Wifi音箱实木打造温...',
                    Id: 287,
                    nameId: '442F518F-8F38-483A-8CF1-61CAE064D3F8',
                    frame: { width: 375, height: 33, x: 344, y: 764 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '全球首款触控Wifi音箱实木打造温...',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '0953B598-2C47-44B3-BB58-834EBDD19785'
        },
        {
            name: 'Group 4',
            Id: 289,
            nameId: '337F29E5-CFC2-4D0D-B043-FE39638F45DF',
            frame: { width: 590, height: 212, x: 160, y: 934 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 290,
                    nameId: 'EA0859B3-34F7-44BC-8E77-8A9D78634E77',
                    frame: { width: 571, height: 2, x: 179, y: 1144 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1zQHFrN1YBuNjy1zcXXbNcXXa-571-2.png'
                },
                {
                    name: 'Bitmap',
                    Id: 292,
                    nameId: '60A547E6-0094-49EB-9687-A591FC9A9BA9',
                    frame: { width: 148, height: 148, x: 180, y: 966 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 294,
                            nameId: '935CCADC-0666-40CE-B7DD-3AF036BD52D1',
                            frame: { width: 148, height: 148, x: 180, y: 966 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 295,
                                    nameId: '664218C5-59E2-4C2C-B1DC-68CDE14D1FC1',
                                    frame: { width: 148, height: 148, x: 180, y: 966 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1Q7DrrFuWBuNjSszbXXcS7FXa-148-148.png'
                                }
                            ],
                            type: 'group',
                            objectID: '935CCADC-0666-40CE-B7DD-3AF036BD52D1'
                        }
                    ],
                    type: 'group',
                    objectID: '60A547E6-0094-49EB-9687-A591FC9A9BA9'
                },
                {
                    name: '转手卖  ',
                    Id: 296,
                    nameId: 'A1D14C85-62CE-4628-93D9-4A8C53E5EBBD',
                    frame: { width: 74, height: 28, x: 344, y: 1071 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#333333',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '转手卖  ',
                    type: 'text'
                },
                {
                    name: '￥280.00',
                    Id: 297,
                    nameId: '762A9750-2422-47EA-8088-6C268B7AB891',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1071 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '￥280.00',
                    type: 'text'
                },
                {
                    name: '聊一聊',
                    Id: 299,
                    nameId: '5D884F1E-F443-4543-AB87-7A9F5FA7F7DF',
                    frame: { width: 132, height: 56, x: 598, y: 1044 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 300,
                            nameId: 'BC2999B0-3225-4CDB-9F47-A51F013F651C',
                            frame: { width: 132, height: 56, x: 598, y: 1044 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1Q7HFrN1YBuNjy1zcXXbNcXXa-132-56.png'
                        },
                        {
                            name: '卖了换钱',
                            Id: 301,
                            nameId: 'D9CBD6C7-6E3E-455F-A004-739D2FBAC5A3',
                            frame: { width: 96.00000000000011, height: 33, x: 616.2941176470588, y: 1055 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖了换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '5D884F1E-F443-4543-AB87-7A9F5FA7F7DF'
                },
                {
                    name: '入手价  ',
                    Id: 302,
                    nameId: '2E1AA168-C3DE-494B-9206-7A1139CF0BD1',
                    frame: { width: 74, height: 28, x: 344, y: 1037 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '入手价  ',
                    type: 'text'
                },
                {
                    name: '￥500.00',
                    Id: 303,
                    nameId: 'F972A504-905D-4235-BDFB-BEDCD91FCEFC',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1037 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '￥500.00',
                    type: 'text'
                },
                {
                    name: '全球首款触控Wifi音箱实木打造温...',
                    Id: 304,
                    nameId: '194A9093-E557-4A5D-BC9D-C73C7C2A5367',
                    frame: { width: 375, height: 33, x: 344, y: 976 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '全球首款触控Wifi音箱实木打造温...',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '337F29E5-CFC2-4D0D-B043-FE39638F45DF'
        },
        {
            name: 'Group 4',
            Id: 306,
            nameId: '0F0BF21A-D57A-4E14-B37E-64CE74368965',
            frame: { width: 590, height: 212, x: 160, y: 1428 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 307,
                    nameId: 'A19D4849-B9A8-45B8-B537-217FD49ED000',
                    frame: { width: 571, height: 2, x: 179, y: 1638 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1izHprH1YBuNjSszeXXablFXa-571-2.png'
                },
                {
                    name: 'Bitmap',
                    Id: 309,
                    nameId: 'D6C70505-04C3-44FF-AB1A-DC5A404BF872',
                    frame: { width: 148, height: 148, x: 180, y: 1460 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 311,
                            nameId: '7513E0B5-A977-4996-960A-F11A54075A07',
                            frame: { width: 148, height: 148, x: 180, y: 1460 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 312,
                                    nameId: '4DC96B08-8158-4A7A-B591-E7D5D3F3FD0D',
                                    frame: { width: 148, height: 148, x: 180, y: 1460 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB147HFrN1YBuNjy1zcXXbNcXXa-148-148.png'
                                }
                            ],
                            type: 'group',
                            objectID: '7513E0B5-A977-4996-960A-F11A54075A07'
                        }
                    ],
                    type: 'group',
                    objectID: 'D6C70505-04C3-44FF-AB1A-DC5A404BF872'
                },
                {
                    name: '转手卖  ',
                    Id: 313,
                    nameId: '6A2CCD3E-54F8-4BA9-9456-6D3C7ECFA7B7',
                    frame: { width: 74, height: 28, x: 344, y: 1565 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#333333',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '转手卖  ',
                    type: 'text'
                },
                {
                    name: '￥280.00',
                    Id: 314,
                    nameId: '6723A258-C901-4F3F-8F35-091B8DE6DB02',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1565 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '￥280.00',
                    type: 'text'
                },
                {
                    name: '聊一聊',
                    Id: 316,
                    nameId: 'DD1DF5E3-85E2-4876-99F4-396EBF234CC7',
                    frame: { width: 132, height: 56, x: 598, y: 1538 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 317,
                            nameId: 'A043B7AE-A755-4D58-850F-2647409780B2',
                            frame: { width: 132, height: 56, x: 598, y: 1538 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1bokgrNWYBuNjy1zkXXXGGpXa-132-56.png'
                        },
                        {
                            name: '卖了换钱',
                            Id: 318,
                            nameId: '33A98E2A-4577-480A-A099-B9EAFA40AA43',
                            frame: { width: 96.00000000000011, height: 33, x: 616.2941176470588, y: 1549 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖了换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'DD1DF5E3-85E2-4876-99F4-396EBF234CC7'
                },
                {
                    name: '入手价  ',
                    Id: 319,
                    nameId: 'ADFAAB4E-80A9-4468-B37F-BB16067D08F6',
                    frame: { width: 74, height: 28, x: 344, y: 1531 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '入手价  ',
                    type: 'text'
                },
                {
                    name: '￥500.00',
                    Id: 320,
                    nameId: '6024B503-13AB-42A6-9004-0F176D4011FB',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1531 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '￥500.00',
                    type: 'text'
                },
                {
                    name: '全球首款触控Wifi音箱实木打造温...',
                    Id: 321,
                    nameId: '46648E3C-1B43-48ED-9927-FB7DCC5501B8',
                    frame: { width: 375, height: 33, x: 344, y: 1470 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '全球首款触控Wifi音箱实木打造温...',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '0F0BF21A-D57A-4E14-B37E-64CE74368965'
        },
        {
            name: 'Group 4',
            Id: 323,
            nameId: 'BABA8923-70B5-4778-89B1-A9326E010E4B',
            frame: { width: 590, height: 212, x: 160, y: 1640 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 325,
                    nameId: '524EF2B5-4118-4949-BB38-8C2D896797B5',
                    frame: { width: 148, height: 148, x: 180, y: 1672 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 327,
                            nameId: 'A899B0E2-F34B-4938-AD79-8B6BC4E111ED',
                            frame: { width: 148, height: 148, x: 180, y: 1672 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 328,
                                    nameId: 'B92CC113-0D3E-4681-93EB-112A2E1AA3C0',
                                    frame: { width: 148, height: 148, x: 180, y: 1672 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1i8rHrKySBuNjy1zdXXXPxFXa-148-148.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'A899B0E2-F34B-4938-AD79-8B6BC4E111ED'
                        }
                    ],
                    type: 'group',
                    objectID: '524EF2B5-4118-4949-BB38-8C2D896797B5'
                },
                {
                    name: '转手卖  ',
                    Id: 329,
                    nameId: '13D9D483-6E61-4F83-AB6D-7BD25C4B43B7',
                    frame: { width: 74, height: 28, x: 344, y: 1777 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#333333',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '转手卖  ',
                    type: 'text'
                },
                {
                    name: '￥280.00',
                    Id: 330,
                    nameId: 'B6218FCD-8E94-432F-AA01-83DE2CED3B36',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1777 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '￥280.00',
                    type: 'text'
                },
                {
                    name: '聊一聊',
                    Id: 332,
                    nameId: '6BD1A871-3307-4A8C-B71F-94D1E1162AC8',
                    frame: { width: 132, height: 56, x: 598, y: 1750 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 333,
                            nameId: '64AF97C0-C5E2-475A-B9CC-390A9DC1FAAE',
                            frame: { width: 132, height: 56, x: 598, y: 1750 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1J_i5rQKWBuNjy1zjXXcOypXa-132-56.png'
                        },
                        {
                            name: '卖了换钱',
                            Id: 334,
                            nameId: '4DB9AD7B-1BC3-40BC-A114-6482D47D42E6',
                            frame: { width: 96.00000000000011, height: 33, x: 616.2941176470588, y: 1761 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖了换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '6BD1A871-3307-4A8C-B71F-94D1E1162AC8'
                },
                {
                    name: '入手价  ',
                    Id: 335,
                    nameId: '37F20959-EEF9-453F-A9BB-E39335A937D5',
                    frame: { width: 74, height: 28, x: 344, y: 1743 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '入手价  ',
                    type: 'text'
                },
                {
                    name: '￥500.00',
                    Id: 336,
                    nameId: 'E2DC31C2-D9C2-4E3C-B5B0-3F1548A77612',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1743 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '￥500.00',
                    type: 'text'
                },
                {
                    name: '全球首款触控Wifi音箱实木打造温...',
                    Id: 337,
                    nameId: 'AB6492AA-73C8-486C-AC6F-373DC1C654CA',
                    frame: { width: 375, height: 33, x: 344, y: 1682 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '全球首款触控Wifi音箱实木打造温...',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: 'BABA8923-70B5-4778-89B1-A9326E010E4B'
        },
        {
            name: 'Group 4',
            Id: 339,
            nameId: 'F080A9D4-8195-4AD4-AEAB-E6436A191FAC',
            frame: { width: 590, height: 212, x: 160, y: 1146 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 340,
                    nameId: '84E08D37-A673-4149-B08D-1AFACF1F6E72',
                    frame: { width: 571, height: 2, x: 179, y: 1356 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1ClrHrKySBuNjy1zdXXXPxFXa-571-2.png'
                },
                {
                    name: 'Bitmap',
                    Id: 342,
                    nameId: '0EEC78E2-E557-4FB8-A748-53F56C83E57E',
                    frame: { width: 148, height: 148, x: 180, y: 1178 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 344,
                            nameId: 'FF9BA1AD-CFCC-4EED-B455-9797594F4542',
                            frame: { width: 148, height: 148, x: 180, y: 1178 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 345,
                                    nameId: '66ABDF6A-E187-4CDF-8839-AA6E91D1B896',
                                    frame: { width: 148, height: 148, x: 180, y: 1178 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1PEkgrNWYBuNjy1zkXXXGGpXa-148-148.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'FF9BA1AD-CFCC-4EED-B455-9797594F4542'
                        }
                    ],
                    type: 'group',
                    objectID: '0EEC78E2-E557-4FB8-A748-53F56C83E57E'
                },
                {
                    name: '转手卖  ',
                    Id: 346,
                    nameId: '2422C5AD-85CC-4816-AA1A-3E4E49EEC804',
                    frame: { width: 74, height: 28, x: 344, y: 1283 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#333333',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '转手卖  ',
                    type: 'text'
                },
                {
                    name: '￥280.00',
                    Id: 347,
                    nameId: '684BF0F0-2DE0-40DC-9E74-6DF90D99EF38',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1283 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '￥280.00',
                    type: 'text'
                },
                {
                    name: '聊一聊',
                    Id: 349,
                    nameId: 'A959F7EE-282B-48C8-B6FE-62FB62BCC1B2',
                    frame: { width: 132, height: 56, x: 598, y: 1256 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 350,
                            nameId: '600A5FC6-5697-4118-A14F-9968909BD744',
                            frame: { width: 132, height: 56, x: 598, y: 1256 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1RBrHrKySBuNjy1zdXXXPxFXa-132-56.png'
                        },
                        {
                            name: '卖了换钱',
                            Id: 351,
                            nameId: '506A12C8-7BB0-4148-A261-6A1F97A0D42A',
                            frame: { width: 96.00000000000011, height: 33, x: 616.2941176470588, y: 1267 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖了换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'A959F7EE-282B-48C8-B6FE-62FB62BCC1B2'
                },
                {
                    name: '入手价  ',
                    Id: 352,
                    nameId: '80F7F8C1-0BB9-47B7-920E-24BDD758BF5C',
                    frame: { width: 74, height: 28, x: 344, y: 1249 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '入手价  ',
                    type: 'text'
                },
                {
                    name: '￥500.00',
                    Id: 353,
                    nameId: '19FB4323-ADCF-4CC8-B14D-48151E65B6AE',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1249 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '￥500.00',
                    type: 'text'
                },
                {
                    name: '全球首款触控Wifi音箱实木打造温...',
                    Id: 354,
                    nameId: 'FD604863-6257-4AA2-8607-FE34E73C3090',
                    frame: { width: 375, height: 33, x: 344, y: 1188 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '全球首款触控Wifi音箱实木打造温...',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: 'F080A9D4-8195-4AD4-AEAB-E6436A191FAC'
        },
        {
            name: '热门转卖（3）',
            Id: 355,
            nameId: 'FBA6D51C-0AA6-47A8-9F31-5662B3F9E603',
            frame: { width: 159, height: 40, x: 180, y: 682 },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 24,
                color: '#888888',
                lineHeight: '39.20000076293945',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '热门转卖（3）',
            type: 'text'
        },
        {
            name: '男士服装（12）',
            Id: 356,
            nameId: '9A9A5B78-837E-4B5D-AB07-341FD7227AEE',
            frame: { width: 169, height: 40, x: 180, y: 1388 },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 24,
                color: '#888888',
                lineHeight: '39.20000076293945',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '男士服装（12）',
            type: 'text'
        },
        {
            name: ' icon',
            Id: 358,
            nameId: '662758E5-8EAC-4BD4-833D-B84395111FC1',
            frame: { width: 750, height: 141, x: 0, y: 400 },
            layers: [
                {
                    name: 'Line + Line Mask',
                    Id: 360,
                    nameId: '57DB706E-F534-42CC-93F3-1E671DC10533',
                    frame: { width: 750, height: 141, x: 0, y: 400 },
                    layers: [
                        {
                            name: 'Mask',
                            Id: 361,
                            nameId: '73D37746-19B2-4A13-8177-EC3D2F3F155C',
                            frame: { width: 750, height: 141, x: 0, y: 400 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)' },
                            type: 'shape'
                        },
                        {
                            name: 'Line',
                            Id: 363,
                            nameId: 'D038AE22-5F93-4899-8A97-904C80111731',
                            frame: { width: 750, height: 1, x: 0, y: 540 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 364,
                                    nameId: '8F2D3233-6411-4786-9F84-FA5B875E0D0D',
                                    frame: { width: 750, height: 1, x: 0, y: 540 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1HloDrTlYBeNjSszcXXbwhFXa-750-1.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'D038AE22-5F93-4899-8A97-904C80111731'
                        },
                        {
                            name: 'Line',
                            Id: 366,
                            nameId: 'AAD66352-B989-40AB-A396-034B3CE639C1',
                            frame: { width: 1, height: 141, x: 375, y: 400 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 367,
                                    nameId: '8E851377-0C87-49CC-8B11-12A0B0D8C428',
                                    frame: { width: 1, height: 141, x: 375, y: 400 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB17SXzr_JYBeNjy1zeXXahzVXa-1-141.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'AAD66352-B989-40AB-A396-034B3CE639C1'
                        }
                    ],
                    type: 'group',
                    objectID: '57DB706E-F534-42CC-93F3-1E671DC10533'
                },
                {
                    name: '闲置估价',
                    Id: 368,
                    nameId: '06E35AD2-B79F-423D-A7C4-90FCC0BF7495',
                    frame: { width: 112, height: 36, x: 503, y: 434 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 28,
                        color: '#333333',
                        lineHeight: '36',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '闲置估价',
                    type: 'text'
                },
                {
                    name: '闲置拍照, 帮你估价',
                    Id: 369,
                    nameId: '5C790873-3876-4E58-B70D-59FCFB3D428B',
                    frame: { width: 172, height: 36, x: 505.0160000000001, y: 470 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        lineHeight: '36',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '闲置拍照, 帮你估价',
                    type: 'text'
                },
                {
                    name: '信用速卖',
                    Id: 370,
                    nameId: '0BB2B008-138D-4D46-9276-59F77D2DBB84',
                    frame: { width: 112, height: 36, x: 128, y: 436 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 28,
                        color: '#333333',
                        lineHeight: '36',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '信用速卖',
                    type: 'text'
                },
                {
                    name: '1秒卖闲置，加价10%',
                    Id: 371,
                    nameId: 'B169E841-79E7-4287-B890-B5BF3F796E34',
                    frame: { width: 188, height: 36, x: 130.01599999999996, y: 472 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        lineHeight: '36',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '1秒卖闲置，加价10%',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 372,
                    nameId: '3B16C4D8-CCC9-470A-8B58-87114841E518',
                    frame: { width: 52, height: 57, x: 54, y: 441 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1K6LprH1YBuNjSszeXXablFXa-52-57.png'
                },
                {
                    name: 'Bitmap',
                    Id: 373,
                    nameId: '992EFA2E-B25A-4101-B899-F7A8E9F1BF4B',
                    frame: { width: 55, height: 49, x: 426, y: 445 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1kmdzr_JYBeNjy1zeXXahzVXa-55-49.png'
                }
            ],
            type: 'group',
            objectID: '662758E5-8EAC-4BD4-833D-B84395111FC1'
        },
        {
            name: '闲鱼1',
            Id: 375,
            nameId: '837C94EB-39D5-4211-AF43-112A9FBE0F8E',
            frame: { width: 750, height: 272, x: 0, y: 127 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 376,
                    nameId: 'D9D0C30C-CF3E-4F70-90FB-365C70C20704',
                    frame: { width: 750, height: 272, x: 0, y: 127 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1plsDrTlYBeNjSszcXXbwhFXa-750-272.png'
                },
                {
                    name: 'Oval',
                    Id: 378,
                    nameId: '310C5BFB-CF1D-4621-85B4-472950059B5D',
                    frame: { width: 537, height: 272, x: 32, y: 127 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 379,
                            nameId: '513359BB-0327-4003-9BA5-BA2801356669',
                            frame: { width: 537, height: 272, x: 32, y: 127 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1Zmdzr_JYBeNjy1zeXXahzVXa-537-272.png'
                        }
                    ],
                    type: 'group',
                    objectID: '310C5BFB-CF1D-4621-85B4-472950059B5D'
                },
                {
                    name: 'Oval',
                    Id: 381,
                    nameId: 'EDBF0219-AFE3-4638-AF57-F6415332E133',
                    frame: { width: 371, height: 175, x: 304, y: 224 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 382,
                            nameId: 'C44ECF60-BA92-4577-BAAD-43D856671EE6',
                            frame: { width: 371, height: 175, x: 304, y: 224 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1Lm_xrL9TBuNjy1zbXXXpepXa-371-175.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'EDBF0219-AFE3-4638-AF57-F6415332E133'
                },
                {
                    name: 'Oval',
                    Id: 384,
                    nameId: '9747418E-0414-4BC7-8E79-D5D1D71CFE2E',
                    frame: { width: 169, height: 78, x: 581, y: 127 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 385,
                            nameId: '5839440C-E259-4155-A4AE-191B1F337C0A',
                            frame: { width: 169, height: 78, x: 581, y: 127 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1N_ocrQSWBuNjSszdXXbeSpXa-169-78.png'
                        }
                    ],
                    type: 'group',
                    objectID: '9747418E-0414-4BC7-8E79-D5D1D71CFE2E'
                },
                {
                    name: 'Rectangle 13 Copy',
                    Id: 386,
                    nameId: 'AB72C51A-1E1F-40AC-B6C7-CBF988DBA7E6',
                    frame: { width: 2, height: 80, x: 375, y: 280 },
                    styles: { backgroundColor: 'rgba(159,94,42,0.27)' },
                    type: 'shape'
                },
                {
                    name: 'Bitmap',
                    Id: 387,
                    nameId: '93213ED6-A9B8-4609-A999-2B7660CDF5D6',
                    frame: { width: 80, height: 80, x: 32, y: 164 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1AosgrNWYBuNjy1zkXXXGGpXa-80-80.png'
                },
                {
                    name: 'Group 10',
                    Id: 389,
                    nameId: '70A1265C-BA8E-474F-9183-83EE275475DF',
                    frame: { width: 146, height: 96, x: 128, y: 278 },
                    layers: [
                        {
                            name: 'Group 15',
                            Id: 391,
                            nameId: 'A7E934E6-4F34-4BD1-8F91-87859019965D',
                            frame: { width: 146, height: 96, x: 128, y: 278 },
                            layers: [
                                {
                                    name: 'Group 13',
                                    Id: 393,
                                    nameId: 'ECE4A3A1-32C9-4696-8294-AC812C86ACF9',
                                    frame: { width: 146, height: 53, x: 128, y: 321 },
                                    layers: [
                                        {
                                            name: '件',
                                            Id: 394,
                                            nameId: 'F8BE3942-72BD-4D41-86D6-9D4A9789412B',
                                            frame: { width: 24, height: 48, x: 250, y: 326 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Regular',
                                                fontSize: 24,
                                                color: '#222222',
                                                lineHeight: '48',
                                                textAlign: 'left',
                                                fontWeight: 'normal'
                                            },
                                            value: '件',
                                            type: 'text'
                                        },
                                        {
                                            name: '8765',
                                            Id: 395,
                                            nameId: '82740AC1-82ED-4A3E-8FC4-D149C4D8CB77',
                                            frame: { width: 113, height: 48, x: 128, y: 321 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Medium',
                                                fontSize: 48,
                                                color: '#222222',
                                                lineHeight: '48',
                                                textAlign: 'left',
                                                fontWeight: 'bold'
                                            },
                                            value: '8765',
                                            type: 'text'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'ECE4A3A1-32C9-4696-8294-AC812C86ACF9'
                                },
                                {
                                    name: '买入宝贝',
                                    Id: 396,
                                    nameId: 'B8FED1D3-DF26-4ADA-BEC9-19016D0451D0',
                                    frame: { width: 96, height: 33, x: 128, y: 278 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: 24,
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '33',
                                        fontWeight: 'normal'
                                    },
                                    value: '买入宝贝',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'A7E934E6-4F34-4BD1-8F91-87859019965D'
                        }
                    ],
                    type: 'group',
                    objectID: '70A1265C-BA8E-474F-9183-83EE275475DF'
                },
                {
                    name: 'Group 10 Copy',
                    Id: 398,
                    nameId: '577C25AD-C775-4DEA-92B3-6BFCF7F2E2E5',
                    frame: { width: 162, height: 95, x: 477, y: 277 },
                    layers: [
                        {
                            name: 'Group 16',
                            Id: 400,
                            nameId: 'BB89864C-5DFA-459F-B2DB-0E479FC7A6F4',
                            frame: { width: 162, height: 52, x: 477, y: 320 },
                            layers: [
                                {
                                    name: '元',
                                    Id: 401,
                                    nameId: '3C791174-FE60-4D7A-AAC7-DC36A1905FF0',
                                    frame: { width: 24, height: 48, x: 615, y: 324 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: 24,
                                        color: '#222222',
                                        lineHeight: '48',
                                        textAlign: 'left',
                                        fontWeight: 'normal'
                                    },
                                    value: '元',
                                    type: 'text'
                                },
                                {
                                    name: '19873',
                                    Id: 402,
                                    nameId: '85876EA4-9055-4727-87DF-48F31945D551',
                                    frame: { width: 133, height: 48, x: 477, y: 320 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: 48,
                                        color: '#222222',
                                        lineHeight: '48',
                                        textAlign: 'left',
                                        fontWeight: 'bold'
                                    },
                                    value: '19873',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'BB89864C-5DFA-459F-B2DB-0E479FC7A6F4'
                        },
                        {
                            name: '全部卖掉可赚',
                            Id: 403,
                            nameId: '24B9E875-9E72-4C83-98A0-08977F58B5BF',
                            frame: { width: 144, height: 33, x: 477, y: 277 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'normal'
                            },
                            value: '全部卖掉可赚',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '577C25AD-C775-4DEA-92B3-6BFCF7F2E2E5'
                },
                {
                    name: 'Group 17',
                    Id: 405,
                    nameId: 'D9239404-F60F-48D3-86B2-836689A8D475',
                    frame: { width: 356, height: 42, x: 129, y: 181 },
                    layers: [
                        {
                            name: 'Rebecca',
                            Id: 406,
                            nameId: 'A2F5B06F-DA9A-4E04-A192-0C70DFD0C864',
                            frame: { width: 124, height: 42, x: 129, y: 181 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 30,
                                color: '#000000',
                                lineHeight: '42',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: 'Rebecca',
                            type: 'text'
                        },
                        {
                            name: '你过去1年在淘宝',
                            Id: 407,
                            nameId: '448F5261-4911-4697-BE23-B29853B3B224',
                            frame: { width: 223, height: 42, x: 262, y: 181 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 30,
                                color: '#222222',
                                lineHeight: '42',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '你过去1年在淘宝',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'D9239404-F60F-48D3-86B2-836689A8D475'
                }
            ],
            type: 'group',
            objectID: '837C94EB-39D5-4211-AF43-112A9FBE0F8E'
        },
        {
            name: 'IMG_2704',
            Id: 408,
            nameId: 'CA58A1EA-7AB1-429D-832F-53FCFA103642',
            frame: { width: 750, height: 1240, x: 0, y: 1855 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1mDscrQSWBuNjSszdXXbeSpXa-750-1240.png'
        },
        {
            name: 'Group 11',
            Id: 410,
            nameId: 'BF6B300E-2DF8-45E6-B01D-BED602205A7B',
            frame: { width: 695, height: 88, x: 28, y: 2176 },
            layers: [
                {
                    name: 'Rectangle 10',
                    Id: 411,
                    nameId: '43567CEA-EEF9-4A4C-AFFD-2FBC8985DCDB',
                    frame: { width: 695, height: 88, x: 28, y: 2176 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)' },
                    type: 'shape'
                },
                {
                    name: '聊一聊',
                    Id: 413,
                    nameId: 'AD1D88F5-8D83-44C6-A0C5-2C99BCEDBACF',
                    frame: { width: 132, height: 56, x: 46, y: 2192 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 414,
                            nameId: '7A3B981F-6FB1-4B0F-904C-9843DE7617A1',
                            frame: { width: 132, height: 56, x: 46, y: 2192 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1ODbxrL9TBuNjy1zbXXXpepXa-132-56.png'
                        },
                        {
                            name: '上门回收',
                            Id: 415,
                            nameId: '8E13CFB5-C665-4018-A95E-F5CD8A99B813',
                            frame: { width: 96, height: 33, x: 64.29411764705884, y: 2203 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '上门回收',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'AD1D88F5-8D83-44C6-A0C5-2C99BCEDBACF'
                },
                {
                    name: '聊一聊',
                    Id: 417,
                    nameId: 'D82B6A90-6F9A-49FC-A2C0-29FF54F7B222',
                    frame: { width: 132, height: 56, x: 306, y: 2192 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 418,
                            nameId: '39A19D45-ECB3-4308-B0BC-E295DB956842',
                            frame: { width: 132, height: 56, x: 306, y: 2192 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1I_scrQSWBuNjSszdXXbeSpXa-132-56.png'
                        },
                        {
                            name: '卖衣换钱',
                            Id: 419,
                            nameId: 'BFCD3381-BE73-4907-AA3C-51DCCD4ED34E',
                            frame: { width: 95.99999999999994, height: 33, x: 324.29411764705884, y: 2203 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖衣换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'D82B6A90-6F9A-49FC-A2C0-29FF54F7B222'
                },
                {
                    name: '聊一聊',
                    Id: 421,
                    nameId: '8EA69019-7DD7-44D6-911C-9E4CBD5BB857',
                    frame: { width: 132, height: 56, x: 576, y: 2192 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 422,
                            nameId: '6D064E79-89C1-4BA2-8765-2EB01ED9B086',
                            frame: { width: 132, height: 56, x: 576, y: 2192 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1CQYFrN1YBuNjy1zcXXbNcXXa-132-56.png'
                        },
                        {
                            name: '免费送衣',
                            Id: 423,
                            nameId: '16AA99D6-B6FE-40D6-951B-82DAE4B9FA92',
                            frame: { width: 96, height: 33, x: 594.2941176470589, y: 2203 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '免费送衣',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '8EA69019-7DD7-44D6-911C-9E4CBD5BB857'
                }
            ],
            type: 'group',
            objectID: 'BF6B300E-2DF8-45E6-B01D-BED602205A7B'
        },
        {
            name: 'tabbar',
            Id: 425,
            nameId: '51585CC9-D6A8-43F8-B5B2-43BFF7A5D02D',
            frame: { width: 752, height: 151, x: 0, y: 2523 },
            layers: [
                {
                    name: 'Toolbar',
                    Id: 427,
                    nameId: 'F2BC611F-F049-4D68-BDB2-E2DBCC531C8F',
                    frame: { width: 752, height: 151, x: 0, y: 2523 },
                    layers: [
                        {
                            name: 'Rectangle 2',
                            Id: 428,
                            nameId: 'B98B8043-BEF3-4EB3-AFDF-17AA3124614E',
                            frame: { width: 150, height: 98, x: 2, y: 2564 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)' },
                            type: 'shape'
                        },
                        {
                            name: 'Rectangle 2 Copy 3',
                            Id: 429,
                            nameId: 'DFA2C8A7-1F7A-4C39-824B-0747106A6101',
                            frame: { width: 150, height: 98, x: 452, y: 2564 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)' },
                            type: 'shape'
                        },
                        {
                            name: 'Bitmap',
                            Id: 430,
                            nameId: '272584FD-0D8A-4756-95E8-44483EA40F22',
                            frame: { width: 47, height: 43, x: 504, y: 2581 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1wly0rMaTBuNjSszfXXXgfpXa-47-43.png'
                        },
                        {
                            name: 'Rectangle 2 Copy 4',
                            Id: 431,
                            nameId: '81E08999-68FF-4BB1-BE35-5196AF394B68',
                            frame: { width: 150, height: 98, x: 602, y: 2564 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)' },
                            type: 'shape'
                        },
                        {
                            name: 'Bitmap',
                            Id: 432,
                            nameId: '82481C5B-D2E9-43DB-B9CF-114B92DBC846',
                            frame: { width: 750, height: 1, x: 0, y: 2564 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1qBADrTlYBeNjSszcXXbwhFXa-750-1.png'
                        },
                        {
                            name: 'Rectangle 2 Copy 2',
                            Id: 433,
                            nameId: 'AFBE4700-03D1-435E-81DF-5D2EEB5C9F61',
                            frame: { width: 150, height: 96, x: 302, y: 2565 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)' },
                            type: 'shape'
                        },
                        {
                            name: '闲置转卖',
                            Id: 434,
                            nameId: 'FB08760C-FCA9-44A7-84F4-049386F27FD2',
                            frame: { width: 73, height: 42, x: 91, y: 2632 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 18,
                                color: '#333333',
                                textAlign: 'center',
                                lineHeight: '42',
                                fontWeight: 'normal'
                            },
                            value: '闲置转卖',
                            type: 'text'
                        },
                        {
                            name: '我的',
                            Id: 435,
                            nameId: '7ED3602E-0680-4AAF-A5B4-940638E39E44',
                            frame: { width: 37, height: 18, x: 609, y: 2636 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 18,
                                color: '#333333',
                                textAlign: 'center',
                                lineHeight: '18',
                                fontWeight: 'normal'
                            },
                            value: '我的',
                            type: 'text'
                        },
                        {
                            name: '卖闲置',
                            Id: 436,
                            nameId: 'F30E172A-41C3-472B-9EC6-B0DC54103003',
                            frame: { width: 55, height: 42, x: 348.5, y: 2632 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 18,
                                color: '#333333',
                                textAlign: 'center',
                                lineHeight: '42',
                                fontWeight: 'normal'
                            },
                            value: '卖闲置',
                            type: 'text'
                        },
                        {
                            name: '发布',
                            Id: 437,
                            nameId: '10E39352-5A17-4448-A226-BE61BECA49F3',
                            frame: { width: 107, height: 111, x: 322, y: 2523 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1P8y0rMaTBuNjSszfXXXgfpXa-107-111.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'F2BC611F-F049-4D68-BDB2-E2DBCC531C8F'
                },
                {
                    name: 'Bitmap',
                    Id: 438,
                    nameId: '8EA9FD75-E474-49E3-95F0-4FD6277A87BF',
                    frame: { width: 39, height: 40, x: 608, y: 2577 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1d72FrN1YBuNjy1zcXXbNcXXa-39-40.png'
                },
                {
                    name: 'Group 9',
                    Id: 440,
                    nameId: '9FF9FD76-997B-4D2D-9899-5696CC48ADB3',
                    frame: { width: 36, height: 40, x: 109, y: 2577 },
                    layers: [
                        {
                            name: 'Group 2',
                            Id: 442,
                            nameId: '6F5B188C-D5AE-4AC3-860E-590B3DD8A9F4',
                            frame: { width: 36, height: 40, x: 109, y: 2577 },
                            layers: [
                                {
                                    name: 'Group 4',
                                    Id: 444,
                                    nameId: '6BF5EFE4-A294-43D9-B75C-5461B0CFF928',
                                    frame: { width: 36, height: 40, x: 109, y: 2577 },
                                    layers: [
                                        {
                                            name: 'Group 14',
                                            Id: 446,
                                            nameId: '5449EAD8-CBFB-4296-9E0F-94A8A8660499',
                                            frame: { width: 36, height: 36, x: 109, y: 2577 },
                                            layers: [
                                                {
                                                    name: '出租房屋icon',
                                                    Id: 448,
                                                    nameId: '14BADA90-EA53-471C-A82A-DE82BED64BB1',
                                                    frame: { width: 36, height: 36, x: 109, y: 2577 },
                                                    layers: [
                                                        {
                                                            name: 'Bitmap',
                                                            Id: 449,
                                                            nameId: 'C6089F33-CD76-43C3-89CF-782FD632C07F',
                                                            frame: { width: 36, height: 17, x: 109, y: 2577 },
                                                            imageStyles: { resize: 'stretch' },
                                                            type: 'image',
                                                            value: 'https://gw.alicdn.com/tfs/TB1mi_rrHuWBuNjSszgXXb8jVXa-36-17.png'
                                                        },
                                                        {
                                                            name: 'Bitmap',
                                                            Id: 450,
                                                            nameId: 'F62E3D40-08F4-4AF5-A5E8-CD916CA58A0A',
                                                            frame: { width: 3, height: 21, x: 109, y: 2592 },
                                                            imageStyles: { resize: 'stretch' },
                                                            type: 'image',
                                                            value: 'https://gw.alicdn.com/tfs/TB1hRHHrKySBuNjy1zdXXXPxFXa-3-21.png'
                                                        },
                                                        {
                                                            name: 'Bitmap',
                                                            Id: 451,
                                                            nameId: 'F1E04FFD-875D-4B8D-9DDC-EFDCFA2802BA',
                                                            frame: { width: 3, height: 21, x: 142, y: 2592 },
                                                            imageStyles: { resize: 'stretch' },
                                                            type: 'image',
                                                            value: 'https://gw.alicdn.com/tfs/TB1C5_rrHuWBuNjSszgXXb8jVXa-3-21.png'
                                                        }
                                                    ],
                                                    type: 'group',
                                                    objectID: '14BADA90-EA53-471C-A82A-DE82BED64BB1'
                                                }
                                            ],
                                            type: 'group',
                                            objectID: '5449EAD8-CBFB-4296-9E0F-94A8A8660499'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 452,
                                            nameId: '4E776EA5-805A-4B79-9A55-499B86371199',
                                            frame: { width: 36, height: 5, x: 109, y: 2612 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1gTjxrL9TBuNjy1zbXXXpepXa-36-5.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '6BF5EFE4-A294-43D9-B75C-5461B0CFF928'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 453,
                                    nameId: 'F6DC4458-99D3-4446-B35A-FBE63D77739F',
                                    frame: { width: 26, height: 28, x: 114, y: 2584 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1Yi_rrHuWBuNjSszgXXb8jVXa-26-28.png'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 454,
                                    nameId: '695B6CB7-B8A3-480E-A493-54ABD7C2B9A2',
                                    frame: { width: 4, height: 7, x: 125, y: 2603 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1SRHHrKySBuNjy1zdXXXPxFXa-4-7.png'
                                }
                            ],
                            type: 'group',
                            objectID: '6F5B188C-D5AE-4AC3-860E-590B3DD8A9F4'
                        }
                    ],
                    type: 'group',
                    objectID: '9FF9FD76-997B-4D2D-9899-5696CC48ADB3'
                }
            ],
            type: 'group',
            objectID: '51585CC9-D6A8-43F8-B5B2-43BFF7A5D02D'
        }
    ],
    nameId: 1526465024367,
    Id: 228,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 2662 },
    styles: { backgroundColor: 'rgba(243,245,249,1)' }
};
