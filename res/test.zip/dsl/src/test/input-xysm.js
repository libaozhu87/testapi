"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Rectangle Copy',
            Id: 3,
            nameId: 'A17B5C90-FB8E-444E-B1A3-EFA60D9C72E1',
            frame: { width: 750, height: 88, x: 0, y: 40 },
            layers: [
                {
                    name: 'Rectangle Copy',
                    Id: 4,
                    nameId: '1CEFC930-3112-4865-BC18-48013BAF2453',
                    frame: { width: 750, height: 88, x: 0, y: 40 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 6,
                    nameId: '77FDB763-B54D-45D9-B5A9-7AF73995E0A9',
                    frame: { width: 702, height: 64, x: 32, y: 52 },
                    layers: [
                        {
                            name: 'ic_share',
                            Id: 7,
                            nameId: 'E96A4A65-E463-4600-BE54-5DFA73512CB9',
                            frame: { width: 72, height: 64, x: 662, y: 52 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233800703.png'
                        },
                        {
                            name: 'ic_share copy',
                            Id: 8,
                            nameId: 'ECA24E76-53CC-45DA-BF23-1477DB15F677',
                            frame: { width: 74, height: 62, x: 581, y: 52 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233800845.png'
                        },
                        {
                            name: 'ic_backarrow',
                            Id: 9,
                            nameId: 'DD238957-D66D-49D1-AB8E-57893B50493A',
                            frame: { width: 40, height: 40, x: 32, y: 64 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233800985.png'
                        },
                        {
                            name: 'Page 1',
                            Id: 10,
                            nameId: '8483D4DC-4743-46A2-B8F6-0DA739C2F251',
                            frame: { width: 161, height: 39, x: 322, y: 64 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233801061.png'
                        },
                        {
                            name: 'Group 3',
                            Id: 11,
                            nameId: 'DD02E877-F33B-42F2-8C09-08808AFC6072',
                            frame: { width: 48, height: 48, x: 264, y: 60 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233801161.png'
                        }
                    ],
                    type: 'group',
                    objectID: '77FDB763-B54D-45D9-B5A9-7AF73995E0A9'
                }
            ],
            type: 'group',
            objectID: 'A17B5C90-FB8E-444E-B1A3-EFA60D9C72E1'
        },
        {
            name: 'Group 34',
            Id: 13,
            nameId: '95F9A307-C2DA-49F5-940A-9621F65A12F0',
            frame: { width: 750, height: 200, x: 0, y: 128 },
            layers: [
                {
                    name: 'Group 34',
                    Id: 14,
                    nameId: 'A1CEC25E-23FF-4CD8-A329-1272E69F15DD',
                    frame: { width: 750, height: 200, x: 0, y: 128 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233801296.png'
                },
                {
                    name: 'Group 29',
                    Id: 15,
                    nameId: '14E5CFE0-A4BD-46FA-B20D-B32690A5FA9D',
                    frame: { width: 522, height: 37, x: 114, y: 184 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233801544.png'
                },
                {
                    name: 'Group',
                    Id: 17,
                    nameId: '1AEE1AC8-340B-4171-9828-1D9290163883',
                    frame: { width: 604, height: 40, x: 73, y: 248 },
                    layers: [
                        {
                            name: '在线估价',
                            Id: 18,
                            nameId: '5ED9C81C-A5C7-4E65-9266-8F30E9F17C9E',
                            frame: { width: 112, height: 40, x: 73, y: 248 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FFFFFF',
                                textAlign: 'right',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '在线估价',
                            type: 'text'
                        },
                        {
                            name: 'Combined Shape',
                            Id: 19,
                            nameId: '18A7DD3B-49AD-4129-A62E-5E32CF2DF089',
                            frame: { width: 14, height: 24, x: 194.8033008588991, y: 256.1066017177982 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233801656.png'
                        },
                        {
                            name: '等待质检',
                            Id: 20,
                            nameId: 'F2655B43-E33C-4F06-8729-E66267A9B50D',
                            frame: { width: 112, height: 40, x: 419, y: 248 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FFFFFF',
                                textAlign: 'right',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '等待质检',
                            type: 'text'
                        },
                        {
                            name: 'Combined Shape',
                            Id: 21,
                            nameId: 'D12C13E5-8E2C-4D38-AA16-AF020746E2F9',
                            frame: { width: 14, height: 24, x: 540.8033008588991, y: 256.1066017177982 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233801741.png'
                        },
                        {
                            name: '结算尾款',
                            Id: 22,
                            nameId: '4ABA826D-837A-405E-923A-C98A11A8BCA1',
                            frame: { width: 112, height: 40, x: 565, y: 248 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FFFFFF',
                                textAlign: 'right',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '结算尾款',
                            type: 'text'
                        },
                        {
                            name: '下单收预付款',
                            Id: 23,
                            nameId: '5FB4A8FB-A4A5-4EE3-AA11-5F84DC43478F',
                            frame: { width: 168, height: 40, x: 217, y: 248 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FFFFFF',
                                textAlign: 'right',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '下单收预付款',
                            type: 'text'
                        },
                        {
                            name: 'Combined Shape',
                            Id: 24,
                            nameId: '6CEAD99B-34FD-49A7-B9B0-37A1ED833AD0',
                            frame: { width: 14, height: 24, x: 394.8033008588991, y: 256.1066017177982 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233801827.png'
                        }
                    ],
                    type: 'group',
                    objectID: '1AEE1AC8-340B-4171-9828-1D9290163883'
                }
            ],
            type: 'group',
            objectID: '95F9A307-C2DA-49F5-940A-9621F65A12F0'
        },
        {
            name: 'Rectangle 2',
            Id: 26,
            nameId: '040BA6AB-B39C-4FF8-AE76-9C51EEE5BA8D',
            frame: { width: 750, height: 412, x: 0, y: 328 },
            layers: [
                {
                    name: 'Rectangle 2',
                    Id: 27,
                    nameId: '252A47CA-BC3A-4506-8CD4-F235E07A061B',
                    frame: { width: 750, height: 412, x: 0, y: 328 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Rectangle 2 Copy',
                    Id: 29,
                    nameId: 'BDB5916C-0BE0-438F-997F-5A64DC691F68',
                    frame: { width: 724, height: 412, x: 26, y: 328 },
                    layers: [
                        {
                            name: 'Rectangle 2 Copy',
                            Id: 30,
                            nameId: 'EB47367A-F337-4211-AC1D-651D8CDF0A0D',
                            frame: { width: 720, height: 412, x: 30, y: 328 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                            type: 'shape'
                        },
                        {
                            name: 'Group',
                            Id: 32,
                            nameId: '2ECB1129-A70C-44C7-8D3C-44D700F4ABE8',
                            frame: { width: 668, height: 112, x: 40, y: 362 },
                            layers: [
                                {
                                    name: 'Mask',
                                    Id: 34,
                                    nameId: '26C845D4-C967-42EA-8B1D-7F396B8D9F1F',
                                    frame: { width: 112, height: 112, x: 40, y: 362 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 35,
                                            nameId: 'A13AE06C-5142-44E3-AF24-FC5D31957057',
                                            frame: { width: 112, height: 112, x: 40, y: 362 },
                                            styles: { backgroundColor: 'rgba(244,231,229,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 36,
                                            nameId: 'DE6AF5FA-B0B2-44D1-85E4-4FC48B2C75CF',
                                            frame: { width: 66, height: 92, x: 64, y: 382 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233801936.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '26C845D4-C967-42EA-8B1D-7F396B8D9F1F'
                                },
                                {
                                    name: 'Mask',
                                    Id: 38,
                                    nameId: '1A8FBF80-4C2A-46FC-8D57-45412406DFCF',
                                    frame: { width: 112, height: 112, x: 226, y: 362 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 39,
                                            nameId: '379BFE6B-8EB1-4D76-837B-7E15396C5829',
                                            frame: { width: 112, height: 112, x: 226, y: 362 },
                                            styles: { backgroundColor: 'rgba(232,234,240,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 40,
                                            nameId: '9CCEC426-4F32-457F-86B0-B2898382B6B8',
                                            frame: { width: 82, height: 90, x: 240, y: 384 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233802075.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '1A8FBF80-4C2A-46FC-8D57-45412406DFCF'
                                },
                                {
                                    name: 'Mask',
                                    Id: 42,
                                    nameId: 'E1BCDEFF-CC71-4D97-B847-15B47C535F50',
                                    frame: { width: 112, height: 112, x: 412, y: 362 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 43,
                                            nameId: '5185C30F-E865-4329-ACBD-C51A0063A40E',
                                            frame: { width: 112, height: 112, x: 412, y: 362 },
                                            styles: { backgroundColor: 'rgba(245,233,232,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 44,
                                            nameId: '549E8778-D6A0-4B5D-925C-E486115CB300',
                                            frame: { width: 96, height: 66, x: 420, y: 386 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233802187.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'E1BCDEFF-CC71-4D97-B847-15B47C535F50'
                                },
                                {
                                    name: 'Mask',
                                    Id: 46,
                                    nameId: 'D0DA71E6-140B-42A0-B587-D5F9A3CB0F35',
                                    frame: { width: 112, height: 112, x: 596, y: 362 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 47,
                                            nameId: '0C145B04-4404-43E5-A072-262A9900404B',
                                            frame: { width: 112, height: 112, x: 596, y: 362 },
                                            styles: { backgroundColor: 'rgba(230,239,230,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap Copy',
                                            Id: 48,
                                            nameId: 'D788F87F-45E7-4439-8FB9-760583764CF5',
                                            frame: { width: 82, height: 84, x: 612, y: 378 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233802314.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'D0DA71E6-140B-42A0-B587-D5F9A3CB0F35'
                                }
                            ],
                            type: 'group',
                            objectID: '2ECB1129-A70C-44C7-8D3C-44D700F4ABE8'
                        },
                        {
                            name: 'Group',
                            Id: 50,
                            nameId: 'CFA80D94-6B5E-4D43-8445-EE600CC39E2C',
                            frame: { width: 642, height: 40, x: 54, y: 480 },
                            layers: [
                                {
                                    name: '卖手机',
                                    Id: 51,
                                    nameId: 'E16D3B43-2859-445E-8540-181C8E54FFE4',
                                    frame: { width: 84, height: 40, x: 54, y: 480 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖手机',
                                    type: 'text'
                                },
                                {
                                    name: '卖平板',
                                    Id: 52,
                                    nameId: '4150CF6F-D976-4F02-8D31-A7ACF0BA982B',
                                    frame: { width: 84, height: 40, x: 240, y: 480 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖平板',
                                    type: 'text'
                                },
                                {
                                    name: '卖电脑',
                                    Id: 53,
                                    nameId: '93D938D5-762A-43BD-84EA-1702F403E3F1',
                                    frame: { width: 84, height: 40, x: 426, y: 480 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖电脑',
                                    type: 'text'
                                },
                                {
                                    name: '卖相机',
                                    Id: 54,
                                    nameId: 'AEA14224-89C2-45C8-B72B-7B50E6F1C538',
                                    frame: { width: 84, height: 40, x: 612, y: 480 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖相机',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'CFA80D94-6B5E-4D43-8445-EE600CC39E2C'
                        },
                        {
                            name: 'Group',
                            Id: 56,
                            nameId: '196DBEE5-630A-4D7C-BA8B-78696B40490B',
                            frame: { width: 670, height: 112, x: 40, y: 548 },
                            layers: [
                                {
                                    name: 'Mask',
                                    Id: 58,
                                    nameId: 'BFC8B195-EA65-4A9E-BFC7-83D9737F9BE6',
                                    frame: { width: 112, height: 112, x: 228, y: 548 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 59,
                                            nameId: '070B8C41-0B7F-417E-A419-E6A3558807D5',
                                            frame: { width: 112, height: 112, x: 228, y: 548 },
                                            styles: { backgroundColor: 'rgba(234,234,234,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 60,
                                            nameId: '76950D2D-DB18-4BA4-A981-A233DB836361',
                                            frame: { width: 70, height: 84, x: 248, y: 564 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233802456.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'BFC8B195-EA65-4A9E-BFC7-83D9737F9BE6'
                                },
                                {
                                    name: 'Mask',
                                    Id: 62,
                                    nameId: '7AC421FF-73C9-4AB7-B1E7-74F20D88142C',
                                    frame: { width: 112, height: 112, x: 40, y: 548 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 63,
                                            nameId: 'F10171E6-E539-47C8-9F69-2609B7C81DD7',
                                            frame: { width: 112, height: 112, x: 40, y: 548 },
                                            styles: { backgroundColor: 'rgba(245,239,232,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 64,
                                            nameId: '5B295AB9-E5EE-43F2-9C47-AEDDFF5A8CAD',
                                            frame: { width: 66, height: 90, x: 62, y: 570 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233802569.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '7AC421FF-73C9-4AB7-B1E7-74F20D88142C'
                                },
                                {
                                    name: 'Mask',
                                    Id: 66,
                                    nameId: '2CFD14AB-A947-4596-A95B-DFEAFBA55D67',
                                    frame: { width: 112, height: 112, x: 422, y: 548 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 67,
                                            nameId: '16B702A1-F1E4-47AF-BE3A-2100AC67CF6C',
                                            frame: { width: 112, height: 112, x: 422, y: 548 },
                                            styles: { backgroundColor: 'rgba(244,232,226,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 68,
                                            nameId: '4223CE2C-3AE3-4CE0-BFC7-820E0911AFAD',
                                            frame: { width: 88, height: 94, x: 446, y: 564 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233802700.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '2CFD14AB-A947-4596-A95B-DFEAFBA55D67'
                                },
                                {
                                    name: 'Mask',
                                    Id: 70,
                                    nameId: '58AAA248-1610-4B1D-8FB7-9CE62ADE992C',
                                    frame: { width: 112, height: 112, x: 598, y: 548 },
                                    layers: [
                                        {
                                            name: 'Mask',
                                            Id: 71,
                                            nameId: '8997C3C6-DA40-45F8-BDB6-B203872C4E3B',
                                            frame: { width: 112, height: 112, x: 598, y: 548 },
                                            styles: { backgroundColor: 'rgba(235,235,235,1)', fillType: 'color', borderRadius: 112 },
                                            type: 'shape'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 72,
                                            nameId: '6D1A7303-DEE9-4C26-ADB5-767C0B2D68D7',
                                            frame: { width: 94, height: 94, x: 610, y: 566 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233802851.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '58AAA248-1610-4B1D-8FB7-9CE62ADE992C'
                                }
                            ],
                            type: 'group',
                            objectID: '196DBEE5-630A-4D7C-BA8B-78696B40490B'
                        },
                        {
                            name: 'Group',
                            Id: 74,
                            nameId: '45F12693-391E-4B9D-A2FB-8A06563576D3',
                            frame: { width: 484, height: 40, x: 212, y: 670 },
                            layers: [
                                {
                                    name: '卖智能设备',
                                    Id: 75,
                                    nameId: 'E79C5CDF-2BA2-4CE6-A816-00C22FB3AA4F',
                                    frame: { width: 140, height: 40, x: 212, y: 670 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖智能设备',
                                    type: 'text'
                                },
                                {
                                    name: '卖运动器材',
                                    Id: 76,
                                    nameId: 'CA6A29CA-0D0B-45F0-B9C4-F2535A756347',
                                    frame: { width: 140, height: 40, x: 408, y: 670 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖运动器材',
                                    type: 'text'
                                },
                                {
                                    name: '卖乐器',
                                    Id: 77,
                                    nameId: '4BC6FCC2-7126-4242-9D7D-AE34ACE2C359',
                                    frame: { width: 84, height: 40, x: 612, y: 670 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: '28',
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'normal'
                                    },
                                    value: '卖乐器',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '45F12693-391E-4B9D-A2FB-8A06563576D3'
                        },
                        {
                            name: '卖家具家电',
                            Id: 78,
                            nameId: 'A3BBCBB7-7CEC-4D7D-9024-AF63578331AB',
                            frame: { width: 140, height: 40, x: 26, y: 670 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '卖家具家电',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'BDB5916C-0BE0-438F-997F-5A64DC691F68'
                }
            ],
            type: 'group',
            objectID: '040BA6AB-B39C-4FF8-AE76-9C51EEE5BA8D'
        },
        {
            name: 'Rectangle 64',
            Id: 80,
            nameId: '7A566CFB-381B-4934-87C2-9DAD905151DC',
            frame: { width: 750, height: 88, x: 0, y: 740 },
            layers: [
                {
                    name: 'Rectangle 64',
                    Id: 81,
                    nameId: '083F2316-D787-43C2-9792-129CB3DF4662',
                    frame: { width: 750, height: 88, x: 0, y: 740 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 83,
                    nameId: '73C03F07-58D1-4A94-89D8-A9A18657D1C6',
                    frame: { width: 690, height: 56, x: 30, y: 756 },
                    layers: [
                        {
                            name: 'Rectangle 12',
                            Id: 84,
                            nameId: '0FCEA08C-E8ED-4671-BE52-CC548DFEDD46',
                            frame: { width: 56, height: 56, x: 30, y: 756 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233803003.png'
                        },
                        {
                            name: '卖了iPhone 7，赚了',
                            Id: 85,
                            nameId: '731933B1-B430-4A5B-BC88-17FF03905ED0',
                            frame: { width: 235, height: 37, x: 106, y: 766 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '26',
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '卖了iPhone 7，赚了',
                            type: 'text'
                        },
                        {
                            name: 'tag_tangzhu copy 35',
                            Id: 86,
                            nameId: 'BBBC6196-C968-4531-975A-0BD3112C0E1E',
                            frame: { width: 148, height: 28, x: 436, y: 770 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233803148.png'
                        },
                        {
                            name: '3分钟前',
                            Id: 87,
                            nameId: '518419D4-2604-4508-BE91-BC91F0C046E2',
                            frame: { width: 72, height: 28, x: 648, y: 770 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '20',
                                color: '#888888',
                                textAlign: 'right',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '3分钟前',
                            type: 'text'
                        },
                        {
                            name: '￥2654',
                            Id: 88,
                            nameId: 'A57DCC4A-3890-46AA-8F69-E24E2906705D',
                            frame: { width: 89, height: 37, x: 342, y: 766 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '26',
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥2654',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '73C03F07-58D1-4A94-89D8-A9A18657D1C6'
                }
            ],
            type: 'group',
            objectID: '7A566CFB-381B-4934-87C2-9DAD905151DC'
        },
        {
            name: 'Rectangle 5 Copy 6',
            Id: 89,
            nameId: '4C094890-BCD9-4D01-91D4-89A0658F3FF8',
            frame: { width: 750, height: 10, x: 0, y: 828 },
            styles: { backgroundColor: 'rgba(243,245,249,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle 5 Copy 8',
            Id: 90,
            nameId: '85FA4088-34E4-4F37-A80E-6CDC91ED8E7E',
            frame: { width: 750, height: 10, x: 0, y: 1296 },
            styles: { backgroundColor: 'rgba(243,245,249,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle 5 Copy 5',
            Id: 92,
            nameId: '0DC15388-DC52-4391-8605-B4C1FFC61F77',
            frame: { width: 750, height: 88, x: 0, y: 848 },
            layers: [
                {
                    name: 'Rectangle 5 Copy 5',
                    Id: 93,
                    nameId: 'C4EB68D9-C751-4875-9E26-C20115FA1B16',
                    frame: { width: 750, height: 88, x: 0, y: 848 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 95,
                    nameId: 'C19EB261-F84E-436A-9EB1-2F5140856DCE',
                    frame: { width: 276, height: 50, x: 30, y: 870 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 96,
                            nameId: 'A76E79E4-5CC0-4D5E-94C6-EBE1C36B7E1E',
                            frame: { width: 40, height: 40, x: 266, y: 872 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233803291.png'
                        },
                        {
                            name: '今日品牌速卖',
                            Id: 97,
                            nameId: '6E97B607-89D1-4F74-B8C9-98829E704B06',
                            frame: { width: 217, height: 50, x: 30, y: 870 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '36',
                                color: '#222222',
                                lineHeight: '50',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '今日品牌速卖',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'C19EB261-F84E-436A-9EB1-2F5140856DCE'
                }
            ],
            type: 'group',
            objectID: '0DC15388-DC52-4391-8605-B4C1FFC61F77'
        },
        {
            name: 'Rectangle 5 Copy 7',
            Id: 98,
            nameId: 'BB4D1966-EB8D-4B2E-9B9F-62E695B309AE',
            frame: { width: 750, height: 10, x: 0, y: 838 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle 4',
            Id: 100,
            nameId: 'B01A9526-1CC7-4CAC-96E1-632292337BE3',
            frame: { width: 822, height: 360, x: 0, y: 936 },
            layers: [
                {
                    name: 'Rectangle 4',
                    Id: 101,
                    nameId: '661EAD73-4B2A-414C-9F34-90654EDD76B4',
                    frame: { width: 750, height: 360, x: 0, y: 936 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 103,
                    nameId: 'FFEE4C43-43C8-419F-8BDA-192E9F208E5F',
                    frame: { width: 758, height: 128, x: 42, y: 956 },
                    layers: [
                        {
                            name: 'Mask',
                            Id: 105,
                            nameId: '0FFF58C0-2C6A-4E68-A4A8-18E36AE067C2',
                            frame: { width: 128, height: 128, x: 42, y: 956 },
                            layers: [
                                {
                                    name: 'Mask',
                                    Id: 106,
                                    nameId: '5CED4DD0-117A-4DBD-9E4A-F7EDEF41F47F',
                                    frame: { width: 128, height: 128, x: 42, y: 956 },
                                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                                    type: 'shape'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 107,
                                    nameId: 'DE29CF0E-00A8-453F-9071-F4622E732214',
                                    frame: { width: 102, height: 128, x: 56, y: 956 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233803403.png'
                                }
                            ],
                            type: 'group',
                            objectID: '0FFF58C0-2C6A-4E68-A4A8-18E36AE067C2'
                        },
                        {
                            name: 'Mask',
                            Id: 109,
                            nameId: 'C5013B4C-B5A3-405C-A431-A3DB72118D6D',
                            frame: { width: 128, height: 128, x: 252, y: 956 },
                            layers: [
                                {
                                    name: 'Mask',
                                    Id: 110,
                                    nameId: '47428366-AB75-4630-8AD6-0CD585B28345',
                                    frame: { width: 128, height: 128, x: 252, y: 956 },
                                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                                    type: 'shape'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 111,
                                    nameId: 'E25ADEB3-2ED7-4183-95B5-29EC00D00362',
                                    frame: { width: 128, height: 96, x: 252, y: 974 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233803544.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'C5013B4C-B5A3-405C-A431-A3DB72118D6D'
                        },
                        {
                            name: 'Bitmap',
                            Id: 112,
                            nameId: '37C8FCC8-166B-4F1A-B3FA-810F4505E7BC',
                            frame: { width: 170, height: 126, x: 442, y: 958 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233803675.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 113,
                            nameId: 'F8042A8D-DDC0-4EBE-82AD-F8A7FD0B5C6F',
                            frame: { width: 122, height: 86, x: 678, y: 976 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233803813.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'FFEE4C43-43C8-419F-8BDA-192E9F208E5F'
                },
                {
                    name: 'Group',
                    Id: 115,
                    nameId: '3EAD1FA7-85F0-4A09-97CF-BA6592690D03',
                    frame: { width: 772, height: 40, x: 36, y: 1100 },
                    layers: [
                        {
                            name: '小白摄像头',
                            Id: 116,
                            nameId: 'F10F945E-209B-4C12-A53B-818A0231BE72',
                            frame: { width: 140, height: 40, x: 36, y: 1100 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '28',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '40',
                                fontWeight: 'bold'
                            },
                            value: '小白摄像头',
                            type: 'text'
                        },
                        {
                            name: '小米扫地机',
                            Id: 117,
                            nameId: '2BA96F67-3E65-45E6-ACD4-D6D8B93E341C',
                            frame: { width: 140, height: 40, x: 246, y: 1100 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '28',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '40',
                                fontWeight: 'bold'
                            },
                            value: '小米扫地机',
                            type: 'text'
                        },
                        {
                            name: '小米Note2',
                            Id: 118,
                            nameId: '2BA2E522-3C30-4C6D-A51E-B745FB313290',
                            frame: { width: 136, height: 40, x: 460, y: 1100 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '28',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '40',
                                fontWeight: 'bold'
                            },
                            value: '小米Note2',
                            type: 'text'
                        },
                        {
                            name: '小米Note2',
                            Id: 119,
                            nameId: 'C559A9C6-F966-4CA3-AA8A-BEC20FB064FA',
                            frame: { width: 136, height: 40, x: 672, y: 1100 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '28',
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '40',
                                fontWeight: 'bold'
                            },
                            value: '小米Note2',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '3EAD1FA7-85F0-4A09-97CF-BA6592690D03'
                },
                {
                    name: 'Group',
                    Id: 121,
                    nameId: '74217439-9EC9-48E0-B8CF-4C353C713A04',
                    frame: { width: 792, height: 37, x: 30, y: 1146 },
                    layers: [
                        {
                            name: '最高价',
                            Id: 122,
                            nameId: 'E51DFADD-4A01-464E-AAA5-BE457B57C784',
                            frame: { width: 79, height: 37, x: 30, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '26',
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '最高价',
                            type: 'text'
                        },
                        {
                            name: '￥254',
                            Id: 123,
                            nameId: '23FD4E31-7C3D-42DB-B96C-C2D36DE4E859',
                            frame: { width: 73, height: 37, x: 110, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '26',
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥254',
                            type: 'text'
                        },
                        {
                            name: '最高价',
                            Id: 124,
                            nameId: 'FDA3E784-2C6A-47BC-8699-8FAEBC03E4C3',
                            frame: { width: 79, height: 37, x: 232, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '26',
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '最高价',
                            type: 'text'
                        },
                        {
                            name: '￥1200',
                            Id: 125,
                            nameId: '21878307-F577-43C3-8CB8-1477770082DA',
                            frame: { width: 84, height: 37, x: 312, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '26',
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥1200',
                            type: 'text'
                        },
                        {
                            name: '最高价',
                            Id: 126,
                            nameId: '6A9DCB6A-E558-4B9E-BE86-3EF4F25B9677',
                            frame: { width: 79, height: 37, x: 446, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '26',
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '最高价',
                            type: 'text'
                        },
                        {
                            name: '￥1200',
                            Id: 127,
                            nameId: '6DB76D2D-3B69-429A-A02F-FB4A0C813DA1',
                            frame: { width: 84, height: 37, x: 526, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '26',
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥1200',
                            type: 'text'
                        },
                        {
                            name: '最高价',
                            Id: 128,
                            nameId: '96FE4554-8347-46EE-900F-35AD7AE1B36A',
                            frame: { width: 79, height: 37, x: 658, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '26',
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '最高价',
                            type: 'text'
                        },
                        {
                            name: '￥1200',
                            Id: 129,
                            nameId: 'ED392DF8-CE76-413A-8729-47B492CECF64',
                            frame: { width: 84, height: 37, x: 738, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '26',
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥1200',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '74217439-9EC9-48E0-B8CF-4C353C713A04'
                },
                {
                    name: 'Group',
                    Id: 131,
                    nameId: '7F3677AC-7318-49E7-9CC8-4A979F22E7A7',
                    frame: { width: 778, height: 64, x: 34, y: 1202 },
                    layers: [
                        {
                            name: 'Rectangle',
                            Id: 133,
                            nameId: '8F53F48F-9A2D-41F8-A852-A5FC90D48853',
                            frame: { width: 144, height: 64, x: 34, y: 1202 },
                            layers: [
                                {
                                    name: 'Rectangle',
                                    Id: 134,
                                    nameId: 'A142EB65-56E1-4561-AD3A-4DBACF2F1BD9',
                                    frame: { width: 144, height: 64, x: 34, y: 1202 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233803974.png'
                                },
                                {
                                    name: '立即速卖',
                                    Id: 135,
                                    nameId: 'DBDD4689-6F1A-439F-807F-044096D5400F',
                                    frame: { width: 112, height: 40, x: 50, y: 1214 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '28',
                                        color: '#FFFFFF',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'bold'
                                    },
                                    value: '立即速卖',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '8F53F48F-9A2D-41F8-A852-A5FC90D48853'
                        },
                        {
                            name: 'Rectangle',
                            Id: 137,
                            nameId: 'AADF52AB-BB57-4213-8C12-ECDC20B1E6C7',
                            frame: { width: 144, height: 64, x: 244, y: 1202 },
                            layers: [
                                {
                                    name: 'Rectangle',
                                    Id: 138,
                                    nameId: 'CA8A0A46-B338-429D-9776-ECFCD5BCCDBA',
                                    frame: { width: 144, height: 64, x: 244, y: 1202 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233804100.png'
                                },
                                {
                                    name: '立即速卖',
                                    Id: 139,
                                    nameId: '5DFDEFAA-7744-4CA1-B0AD-382D06E8B2B5',
                                    frame: { width: 112, height: 40, x: 260, y: 1214 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '28',
                                        color: '#FFFFFF',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'bold'
                                    },
                                    value: '立即速卖',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'AADF52AB-BB57-4213-8C12-ECDC20B1E6C7'
                        },
                        {
                            name: 'Rectangle',
                            Id: 141,
                            nameId: 'D53184E0-3793-4A8C-A686-E62C0068D653',
                            frame: { width: 144, height: 64, x: 456, y: 1202 },
                            layers: [
                                {
                                    name: 'Rectangle',
                                    Id: 142,
                                    nameId: '80CE4A09-6377-46C3-AE83-3B71D3367DD6',
                                    frame: { width: 144, height: 64, x: 456, y: 1202 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233804215.png'
                                },
                                {
                                    name: '立即速卖',
                                    Id: 143,
                                    nameId: 'E01374C9-ED77-423A-B00E-902A3CA01405',
                                    frame: { width: 112, height: 40, x: 472, y: 1214 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '28',
                                        color: '#FFFFFF',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'bold'
                                    },
                                    value: '立即速卖',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'D53184E0-3793-4A8C-A686-E62C0068D653'
                        },
                        {
                            name: 'Rectangle',
                            Id: 145,
                            nameId: '952068D9-13AB-43D1-8EB0-E2000CA6850E',
                            frame: { width: 144, height: 64, x: 668, y: 1202 },
                            layers: [
                                {
                                    name: 'Rectangle',
                                    Id: 146,
                                    nameId: 'ACB9062F-8A56-4B00-9ECF-51246A4AFEF4',
                                    frame: { width: 144, height: 64, x: 668, y: 1202 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233804345.png'
                                },
                                {
                                    name: '立即速卖',
                                    Id: 147,
                                    nameId: 'EFAFD447-B7B9-4F67-82FF-1D904D23394E',
                                    frame: { width: 112, height: 40, x: 684, y: 1214 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: '28',
                                        color: '#FFFFFF',
                                        textAlign: 'center',
                                        lineHeight: '40',
                                        fontWeight: 'bold'
                                    },
                                    value: '立即速卖',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '952068D9-13AB-43D1-8EB0-E2000CA6850E'
                        }
                    ],
                    type: 'group',
                    objectID: '7F3677AC-7318-49E7-9CC8-4A979F22E7A7'
                }
            ],
            type: 'group',
            objectID: 'B01A9526-1CC7-4CAC-96E1-632292337BE3'
        },
        {
            name: 'Rectangle 5 Copy 5',
            Id: 148,
            nameId: '005FCD42-2B11-4656-AFD9-5F8254483595',
            frame: { width: 750, height: 88, x: 0, y: 1316 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle 5 Copy 7',
            Id: 149,
            nameId: '2674797F-5A47-4DA1-8DF6-B49BDD2D1339',
            frame: { width: 750, height: 10, x: 0, y: 1306 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
            type: 'shape'
        },
        {
            name: 'Rectangle Copy 2',
            Id: 151,
            nameId: '703CF735-5E81-417E-A58A-2E7FAC2F8DE3',
            frame: { width: 750, height: 41, x: 0, y: 0 },
            layers: [
                {
                    name: 'Rectangle Copy 2',
                    Id: 152,
                    nameId: '4FB0622E-C682-4A30-A6DB-D03C685D9CE4',
                    frame: { width: 750, height: 40, x: 0, y: 0 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Group',
                    Id: 154,
                    nameId: 'AA469411-18DC-4E7D-B719-3EA7C5B22D45',
                    frame: { width: 725, height: 33, x: 14, y: 8 },
                    layers: [
                        {
                            name: 'Battery',
                            Id: 155,
                            nameId: '06450F9D-DF7C-42FE-9138-197706A520EC',
                            frame: { width: 49, height: 19, x: 690, y: 10 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233804479.png'
                        },
                        {
                            name: '100%',
                            Id: 156,
                            nameId: 'DDE9FC3A-76E2-4B5F-98F1-B380991E2A48',
                            frame: { width: 66, height: 28, x: 618, y: 8 },
                            textStyles: {
                                fontFamily: '.SFNSDisplay',
                                fontSize: '24',
                                color: '#000000',
                                textAlign: 'right',
                                lineHeight: '28',
                                maxWidth: 66,
                                maxHeight: 28,
                                fontWeight: 'normal'
                            },
                            value: '100%',
                            type: 'text'
                        },
                        {
                            name: 'Time',
                            Id: 157,
                            nameId: 'BD7C2AE4-737D-4F24-800E-DEE3418D113C',
                            frame: { width: 90, height: 33, x: 330, y: 8 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '24',
                                color: '#000000',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'normal'
                            },
                            value: '9:41 AM',
                            type: 'text'
                        },
                        {
                            name: 'Wi-Fi',
                            Id: 158,
                            nameId: 'B7363B0F-60B2-4C55-9C68-9918910FF315',
                            frame: { width: 26, height: 18, x: 176, y: 10 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233804580.png'
                        },
                        {
                            name: 'Carrier',
                            Id: 159,
                            nameId: 'DEAC56B8-0203-4E7A-BA5A-4CD9BF38E326',
                            frame: { width: 86, height: 33, x: 88, y: 8 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '24',
                                color: '#000000',
                                textAlign: 'left',
                                lineHeight: '33',
                                fontWeight: 'normal'
                            },
                            value: 'SanityD',
                            type: 'text'
                        },
                        {
                            name: 'Mobile Signal',
                            Id: 160,
                            nameId: '9A4EC7D1-E2A0-4405-A3B8-321E3D936D90',
                            frame: { width: 67, height: 11, x: 14, y: 14 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525233804678.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'AA469411-18DC-4E7D-B719-3EA7C5B22D45'
                }
            ],
            type: 'group',
            objectID: '703CF735-5E81-417E-A58A-2E7FAC2F8DE3'
        }
    ],
    nameId: 1525233800692,
    Id: 1,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 1334 },
    styles: { backgroundColor: 'rgba(255,255,255,1)' }
};
