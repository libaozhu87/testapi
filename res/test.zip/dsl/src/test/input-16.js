"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            frame: { y: 17, x: 85, height: 203, width: 88 },
            type: 'image',
            id: 0,
            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524651356367.png',
            imageStyles: { resize: 'stretch' }
        },
        {
            frame: { y: 17, x: 325, height: 203, width: 88 },
            type: 'image',
            id: 1,
            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524651358270.png',
            imageStyles: { resize: 'stretch' }
        },
        {
            frame: { y: 17, x: 565, height: 203, width: 88 },
            type: 'image',
            id: 2,
            value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524651360097.png',
            imageStyles: { resize: 'stretch' }
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#414141',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                lineHeight: '28',
                textAlign: 'left'
            },
            frame: { y: 253, x: 31, height: 27, width: 200 },
            type: 'text',
            id: 3,
            value: '风味发酵乳黄桃'
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#414141',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                lineHeight: '28',
                textAlign: 'left'
            },
            frame: { y: 253, x: 271, height: 27, width: 200 },
            type: 'text',
            id: 4,
            value: '风味发酵乳黄桃'
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#414141',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                lineHeight: '28',
                textAlign: 'left'
            },
            frame: { y: 253, x: 511, height: 27, width: 200 },
            type: 'text',
            id: 5,
            value: '风味发酵乳黄桃'
        },
        {
            textStyles: {
                fontWeight: 'normal',
                color: '#FF4444',
                fontFamily: 'PingFangSC-Regular',
                fontSize: '20',
                lineHeight: '20',
                textAlign: 'left'
            },
            frame: { y: 308, x: 32, height: 16, width: 13 },
            type: 'text',
            id: 6,
            value: '¥'
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#FF4444',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '36',
                lineHeight: '36',
                textAlign: 'left'
            },
            frame: { y: 298, x: 49, height: 29, width: 66 },
            type: 'text',
            id: 7,
            value: '19.8'
        },
        {
            styles: { borderColor: 'rgba(155,155,155,1)', borderStyle: 'solid', borderWidth: 2 },
            name: 'Line 7',
            nameId: '63597208-EA9A-4EF2-B7C0-AF4659CD72AF',
            frame: { y: 315, width: 48, x: 131, height: 4 },
            type: 'shape',
            id: 8
        },
        {
            textStyles: {
                maxWidth: 89.53335252891019,
                fontWeight: 'normal',
                color: '#9B9B9B',
                maxHeight: 31.57652815457702,
                fontFamily: 'PingFangSC-Regular',
                fontSize: '22',
                lineHeight: '30',
                textAlign: 'left'
            },
            name: '¥68',
            type: 'text',
            frame: { y: 300, width: 89.5333525289102, x: 134, height: 31.576528154577318 },
            value: '¥68\n',
            nameId: 'C6ECBA00-614A-4717-889F-9274362659F4',
            id: 10
        },
        {
            textStyles: {
                fontWeight: 'normal',
                color: '#FF4444',
                fontFamily: 'PingFangSC-Regular',
                fontSize: '20',
                lineHeight: '20',
                textAlign: 'left'
            },
            frame: { y: 308, x: 272, height: 16, width: 13 },
            type: 'text',
            id: 10,
            value: '¥'
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#FF4444',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '36',
                lineHeight: '36',
                textAlign: 'left'
            },
            frame: { y: 298, x: 289, height: 29, width: 66 },
            type: 'text',
            id: 11,
            value: '19.8'
        },
        {
            styles: { borderColor: 'rgba(155,155,155,1)', borderStyle: 'solid', borderWidth: 2 },
            name: 'Line 7',
            nameId: 'A8759CF3-E4E5-4563-97AB-69297303AC44',
            frame: { y: 315, width: 48, x: 371, height: 4 },
            type: 'shape',
            id: 12
        },
        {
            textStyles: {
                maxWidth: 89.53335252891019,
                fontWeight: 'normal',
                color: '#9B9B9B',
                maxHeight: 31.57652815457702,
                fontFamily: 'PingFangSC-Regular',
                fontSize: '22',
                lineHeight: '30',
                textAlign: 'left'
            },
            name: '¥68',
            type: 'text',
            frame: { y: 300, width: 89.5333525289102, x: 374, height: 31.576528154577318 },
            value: '¥68\n',
            nameId: '3F62B00F-FFB1-4E18-B28F-2B553F9F442D',
            id: 14
        },
        {
            textStyles: {
                fontWeight: 'normal',
                color: '#FF4444',
                fontFamily: 'PingFangSC-Regular',
                fontSize: '20',
                lineHeight: '20',
                textAlign: 'left'
            },
            frame: { y: 308, x: 512, height: 16, width: 13 },
            type: 'text',
            id: 14,
            value: '¥'
        },
        {
            textStyles: {
                fontWeight: 'bold',
                color: '#FF4444',
                fontFamily: 'PingFangSC-Medium',
                fontSize: '36',
                lineHeight: '36',
                textAlign: 'left'
            },
            frame: { y: 298, x: 529, height: 29, width: 66 },
            type: 'text',
            id: 15,
            value: '19.8'
        },
        {
            styles: { borderColor: 'rgba(155,155,155,1)', borderStyle: 'solid', borderWidth: 2 },
            name: 'Line 7',
            nameId: '5A05966F-2616-4899-AB06-4EF68E287C07',
            frame: { y: 315, width: 48, x: 611, height: 4 },
            type: 'shape',
            id: 16
        },
        {
            textStyles: {
                maxWidth: 89.53335252891019,
                fontWeight: 'normal',
                color: '#9B9B9B',
                maxHeight: 31.57652815457702,
                fontFamily: 'PingFangSC-Regular',
                fontSize: '22',
                lineHeight: '30',
                textAlign: 'left'
            },
            name: '¥68',
            type: 'text',
            frame: { y: 300, width: 89.5333525289102, x: 614, height: 31.576528154577318 },
            value: '¥68\n',
            nameId: 'BCD026CE-30EB-48BE-89A6-7BDDC54D9327',
            id: 18
        },
        {
            styles: { borderColor: 'rgba(136,136,136,1)', cornerRadiusString: '4', borderStyle: 'solid', borderWidth: 1, borderRadius: 4 },
            name: 'Rectangle 9',
            nameId: 'B0B795AE-C011-47A6-AAB1-62FFE7492831',
            frame: { y: 342, width: 144, x: 30, height: 32 },
            type: 'shape',
            id: 18
        },
        {
            textStyles: {
                opacity: '0.5',
                fontWeight: 'normal',
                color: '#888888',
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                lineHeight: '36',
                textAlign: 'left'
            },
            name: '3个月到期',
            type: 'text',
            frame: { y: 340, width: 116, x: 44, height: 36 },
            value: '3个月到期',
            nameId: '3D6BBA2E-0EBC-4B11-A8CA-4267E8A8BEDF',
            id: 20
        },
        {
            styles: { borderColor: 'rgba(136,136,136,1)', cornerRadiusString: '4', borderStyle: 'solid', borderWidth: 1, borderRadius: 4 },
            name: 'Rectangle 9',
            nameId: '094F45A5-6FF4-4844-A6FE-1CEC2C2CFD8E',
            frame: { y: 342, width: 144, x: 270, height: 32 },
            type: 'shape',
            id: 20
        },
        {
            textStyles: {
                opacity: '0.5',
                fontWeight: 'normal',
                color: '#888888',
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                lineHeight: '36',
                textAlign: 'left'
            },
            name: '3个月到期',
            type: 'text',
            frame: { y: 340, width: 116, x: 284, height: 36 },
            value: '3个月到期',
            nameId: 'EF83D2DB-460F-4D74-93B6-46538A633667',
            id: 22
        },
        {
            styles: { borderColor: 'rgba(136,136,136,1)', cornerRadiusString: '4', borderStyle: 'solid', borderWidth: 1, borderRadius: 4 },
            name: 'Rectangle 9',
            nameId: 'E115918C-30F6-48C1-ABEA-BC88A846611E',
            frame: { y: 342, width: 144, x: 510, height: 32 },
            type: 'shape',
            id: 22
        },
        {
            textStyles: {
                opacity: '0.5',
                fontWeight: 'normal',
                color: '#888888',
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                lineHeight: '36',
                textAlign: 'left'
            },
            name: '3个月到期',
            type: 'text',
            frame: { y: 340, width: 116, x: 524, height: 36 },
            value: '3个月到期',
            nameId: '9F16EF39-5CD2-4ABC-BFA0-3CB7D105AE7A',
            id: 24
        }
    ],
    type: 'group',
    frame: { y: 0, x: 0, height: 404, width: 750 },
    nameId: 1524651356354,
    id: 0
};
