"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Navigation Bar',
            Id: 3,
            nameId: 'C23CD112-5218-42EF-B824-68F98AE6D3C5',
            frame: { width: 750, height: 134, x: 0, y: 0 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 4,
                    nameId: 'AAED3C37-AEEB-43DC-9B81-FA5CFBC0F204',
                    frame: { width: 750, height: 134, x: 0, y: 0 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1HTQqwntYBeNjy1XdXXXXyVXa-750-134.png'
                },
                {
                    name: 'Louie',
                    Id: 5,
                    nameId: 'E4EA0F2F-181B-4C96-9745-00C5E629CBF3',
                    frame: { width: 170, height: 48, x: 290.5, y: 60 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 34,
                        color: '#333333',
                        textAlign: 'center',
                        lineHeight: '48',
                        fontWeight: 'bold'
                    },
                    value: '卖闲置换钱',
                    type: 'text'
                },
                {
                    name: 'Status Bar black',
                    Id: 7,
                    nameId: '2FEA75C1-358B-4280-9242-3D1AD14707DB',
                    frame: { width: 726, height: 33, x: 13, y: 3 },
                    layers: [
                        {
                            name: 'Signal',
                            Id: 9,
                            nameId: '95CD34F7-332B-4C49-8875-CF453DF858C1',
                            frame: { width: 189, height: 28, x: 13, y: 8 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 10,
                                    nameId: '3564DB82-5C7F-47B7-B6BC-BFE9C9C6803C',
                                    frame: { width: 68, height: 11, x: 13, y: 15 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1D7KDwf5TBuNjSspmXXaDRVXa-68-11.png'
                                },
                                {
                                    name: 'VIRGI',
                                    Id: 11,
                                    nameId: '505AD37B-62BE-42A8-AEC4-7D5B2DB9B5EB',
                                    frame: { width: 62, height: 27, x: 89, y: 8 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 22,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '27',
                                        fontWeight: 'normal'
                                    },
                                    value: 'VIRGI',
                                    type: 'text'
                                },
                                {
                                    name: 'N',
                                    Id: 12,
                                    nameId: 'B5EFD7B4-E796-42AE-B701-80D9E23B5F5D',
                                    frame: { width: 17, height: 27, x: 150.606, y: 8 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 22,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '27',
                                        fontWeight: 'normal'
                                    },
                                    value: 'N',
                                    type: 'text'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 13,
                                    nameId: 'C670027C-99C2-4AAB-85C9-7DF40E668784',
                                    frame: { width: 24, height: 19, x: 178, y: 11 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB16nQqwntYBeNjy1XdXXXXyVXa-24-19.png'
                                }
                            ],
                            type: 'group',
                            objectID: '95CD34F7-332B-4C49-8875-CF453DF858C1'
                        },
                        {
                            name: 'Bitmap',
                            Id: 14,
                            nameId: '1192B5A9-0BE8-4982-881B-85067703DC7A',
                            frame: { width: 16, height: 27, x: 603, y: 7 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1KwyEwkOWBuNjSsppXXXPgpXa-16-27.png'
                        },
                        {
                            name: 'Battery',
                            Id: 16,
                            nameId: '8F2B5CE9-9119-4033-B2F0-FE7670322B2C',
                            frame: { width: 413, height: 33, x: 326, y: 3 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 17,
                                    nameId: 'BEBB440D-CA33-45B6-B1CB-DBFAC13082F1',
                                    frame: { width: 3, height: 7, x: 736, y: 17 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1SnUqwntYBeNjy1XdXXXXyVXa-3-7.png'
                                },
                                {
                                    name: 'Shape',
                                    Id: 18,
                                    nameId: 'FA361C57-1157-4FFF-843C-ED7ABC8C228D',
                                    frame: { width: 14, height: 15, x: 692, y: 13 },
                                    styles: {
                                        backgroundColor: 'rgba(0,0,0,1)',
                                        borderBottomLeftRadius: '1',
                                        borderBottomRightRadius: '0',
                                        borderTopLeftRadius: '1',
                                        borderTopRightRadius: '0'
                                    },
                                    type: 'shape'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 19,
                                    nameId: '2EAAC084-B173-483B-88BA-73EBB85E7DF1',
                                    frame: { width: 45, height: 19, x: 690, y: 11 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1O9vWwmtYBeNjSspkXXbU8VXa-45-19.png'
                                },
                                {
                                    name: '22',
                                    Id: 20,
                                    nameId: 'D079802A-28DB-4F35-8E29-C36CAA1B8D24',
                                    frame: { width: 28, height: 28, x: 633, y: 7 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue-Light',
                                        fontSize: 23,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '28',
                                        fontWeight: 'normal'
                                    },
                                    value: '22',
                                    type: 'text'
                                },
                                {
                                    name: '%',
                                    Id: 21,
                                    nameId: '2FA7B132-3AAA-43B8-B3FC-678DCD411DBC',
                                    frame: { width: 22, height: 28, x: 660.576, y: 7 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue-Light',
                                        fontSize: 23,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '28',
                                        fontWeight: 'normal'
                                    },
                                    value: '%',
                                    type: 'text'
                                },
                                {
                                    name: '4 21 PM',
                                    Id: 22,
                                    nameId: '3E4E8FF6-8B9F-4E10-B4EC-3F7B4CECC815',
                                    frame: { width: 97, height: 30, x: 326, y: 6 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 24,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '29',
                                        fontWeight: 'normal'
                                    },
                                    value: '4 21 PM',
                                    type: 'text'
                                },
                                {
                                    name: ':',
                                    Id: 23,
                                    nameId: '6CB64994-C63B-421D-B54C-3CB6BBC35A8B',
                                    frame: { width: 9, height: 33, x: 339.5, y: 3 },
                                    textStyles: {
                                        fontFamily: 'AvenirNext-Regular',
                                        fontSize: 24,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '33',
                                        fontWeight: 'normal'
                                    },
                                    value: ':',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '8F2B5CE9-9119-4033-B2F0-FE7670322B2C'
                        }
                    ],
                    type: 'group',
                    objectID: '2FEA75C1-358B-4280-9242-3D1AD14707DB'
                }
            ],
            type: 'group',
            objectID: 'C23CD112-5218-42EF-B824-68F98AE6D3C5'
        },
        {
            name: 'Bitmap',
            Id: 24,
            nameId: 'AF985E1C-1339-4986-9F89-0F7E73001CA2',
            frame: { width: 18, height: 33, x: 35, y: 67 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1enZqwntYBeNjy1XdXXXXyVXa-18-33.png'
        },
        {
            name: 'Rectangle 4',
            Id: 25,
            nameId: '775A241A-7222-4D01-86E5-0FB210463078',
            frame: { width: 750, height: 1205, x: 0, y: 647 },
            styles: { backgroundColor: 'rgba(255,255,255,1)' },
            type: 'shape'
        },
        {
            name: '淘宝买多了 卖了回本 + 近一年你在淘宝买的宝贝卖掉可回血 + 22878元 + Rectangle 7 Mask',
            Id: 27,
            nameId: '14C879F4-C5A9-4F24-A27C-5776DC38BBB6',
            frame: { width: 750, height: 88, x: 0, y: 559 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 28,
                    nameId: '86CEC222-A406-4730-B8F1-BB05AB93B88C',
                    frame: { width: 750, height: 88, x: 0, y: 559 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1B._owf1TBuNjy0FjXXajyXXa-750-88.png'
                },
                {
                    name: '我的闲置',
                    Id: 29,
                    nameId: 'C5B6CADF-FB30-41E6-BE84-7BE50932F2D2',
                    frame: { width: 128, height: 44, x: 311, y: 581 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#222222',
                        lineHeight: '44',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '我的闲置',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 30,
                    nameId: 'FA819E86-DC64-4E22-97C0-8C796FD1FF6E',
                    frame: { width: 224, height: 4, x: 262, y: 603 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1p_SCweuSBuNjy1XcXXcYjFXa-224-4.png'
                }
            ],
            type: 'group',
            objectID: '14C879F4-C5A9-4F24-A27C-5776DC38BBB6'
        },
        {
            name: 'Bitmap',
            Id: 31,
            nameId: 'B9FF217C-8A01-4CCB-B3CD-A6DF79591E18',
            frame: { width: 750, height: 1, x: 0, y: 645 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB183CEwkOWBuNjSsppXXXPgpXa-750-1.png'
        },
        {
            name: 'Group 3',
            Id: 33,
            nameId: 'E5988BEB-80FE-44F5-AAED-B16BFBAAFD10',
            frame: { width: 159, height: 1206, x: 0, y: 650 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 34,
                    nameId: 'EB7CBA9E-4530-447F-B740-4292D8B5103D',
                    frame: { width: 1, height: 1206, x: 158, y: 650 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB15TSCweuSBuNjy1XcXXcYjFXa-1-1206.png'
                },
                {
                    name: '热门转卖',
                    Id: 35,
                    nameId: '3519731D-40CD-4D4B-B474-E661D76DE2FF',
                    frame: { width: 112, height: 40, x: 26, y: 684.5999984741211 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 28,
                        color: '#333333',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'bold'
                    },
                    value: '热门转卖',
                    type: 'text'
                },
                {
                    name: '男士服装',
                    Id: 36,
                    nameId: '2B99474D-D316-4E06-8157-B7EDC8AAC808',
                    frame: { width: 112, height: 40, x: 26, y: 786.5999984741211 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '男士服装',
                    type: 'text'
                },
                {
                    name: '家具/饰品',
                    Id: 37,
                    nameId: '1911B610-99B6-4652-B876-BE7E83131221',
                    frame: { width: 126, height: 40, x: 19.5, y: 891.5999984741211 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '家具/饰品',
                    type: 'text'
                },
                {
                    name: '运动户外',
                    Id: 38,
                    nameId: 'AC973AC0-FB38-4B6E-8D56-32AC12BC7408',
                    frame: { width: 112, height: 40, x: 26, y: 994.5999984741211 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '运动户外',
                    type: 'text'
                },
                {
                    name: '3C数码',
                    Id: 39,
                    nameId: 'DDAB43F9-9859-4B49-B1F7-1C8F382E548A',
                    frame: { width: 94, height: 40, x: 35, y: 1100.599998474121 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '3C数码',
                    type: 'text'
                },
                {
                    name: '个人美妆',
                    Id: 40,
                    nameId: 'E3566894-167B-4F54-B3BA-5CDA04149B90',
                    frame: { width: 112, height: 40, x: 26, y: 1204.599998474121 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '个人美妆',
                    type: 'text'
                },
                {
                    name: '箱包',
                    Id: 41,
                    nameId: '0C8186C1-4CFF-4B40-95D8-46E0BC43D6A6',
                    frame: { width: 56, height: 40, x: 54, y: 1306.599998474121 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#999999',
                        textAlign: 'center',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '箱包',
                    type: 'text'
                },
                {
                    name: 'Rectangle 7',
                    Id: 42,
                    nameId: '1FD49FCE-3D8D-4007-915F-4AF95821AFE2',
                    frame: { width: 8, height: 56, x: 0, y: 677 },
                    styles: { backgroundColor: 'rgba(255,218,68,1)' },
                    type: 'shape'
                }
            ],
            type: 'group',
            objectID: 'E5988BEB-80FE-44F5-AAED-B16BFBAAFD10'
        },
        {
            name: 'Bitmap',
            Id: 43,
            nameId: 'C7D9F364-ACCB-4ABC-B311-A568BD7F5410',
            frame: { width: 20, height: 36, x: 36, y: 66 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1CH9swb5YBuNjSspoXXbeNFXa-20-36.png'
        },
        {
            name: 'Group 4',
            Id: 45,
            nameId: 'F4FF44C6-200D-40A5-80EC-B7A4D6C2317D',
            frame: { width: 590, height: 212, x: 160, y: 722 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 46,
                    nameId: '5DD8F901-82B2-4015-A0CF-517E874A3E3C',
                    frame: { width: 571, height: 2, x: 179, y: 932 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1p_WCweuSBuNjy1XcXXcYjFXa-571-2.png'
                },
                {
                    name: 'Bitmap',
                    Id: 48,
                    nameId: '3DEF72E3-718C-47CF-8C72-16B21373BEC3',
                    frame: { width: 148, height: 148, x: 180, y: 754 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 50,
                            nameId: '2E120252-E673-4AF6-B50B-38C53C42561D',
                            frame: { width: 148, height: 148, x: 180, y: 754 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 51,
                                    nameId: '0FA1C111-11E6-4BAE-9989-DDC08C739F3F',
                                    frame: { width: 148, height: 148, x: 180, y: 754 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1lliXweuSBuNjSsplXXbe8pXa-148-148.png'
                                }
                            ],
                            type: 'group',
                            objectID: '2E120252-E673-4AF6-B50B-38C53C42561D'
                        }
                    ],
                    type: 'group',
                    objectID: '3DEF72E3-718C-47CF-8C72-16B21373BEC3'
                },
                {
                    name: '转手卖  ',
                    Id: 52,
                    nameId: '473F9454-1F3A-4B2B-BB56-53F8F0374244',
                    frame: { width: 74, height: 28, x: 344, y: 859 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#333333',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '转手卖  ',
                    type: 'text'
                },
                {
                    name: '￥280.00',
                    Id: 53,
                    nameId: '70A0BDFC-4130-438D-B361-B7AB163C52FA',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 859 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '￥280.00',
                    type: 'text'
                },
                {
                    name: '聊一聊',
                    Id: 55,
                    nameId: '944E2E21-D3D0-4939-B98C-946ADF4AE608',
                    frame: { width: 132, height: 56, x: 598, y: 832 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 56,
                            nameId: 'B07ABE2F-8E95-42BC-BA23-95907B500488',
                            frame: { width: 132, height: 56, x: 598, y: 832 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1HTWCweuSBuNjy1XcXXcYjFXa-132-56.png'
                        },
                        {
                            name: '卖了换钱',
                            Id: 57,
                            nameId: '6B462A72-94E5-4933-9DC8-C6F3C386EFF0',
                            frame: { width: 96, height: 33, x: 616.2941176470586, y: 843 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖了换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '944E2E21-D3D0-4939-B98C-946ADF4AE608'
                },
                {
                    name: '入手价  ',
                    Id: 58,
                    nameId: '499C31CC-6211-41EF-996F-49109B3DFC00',
                    frame: { width: 74, height: 28, x: 344, y: 825 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '入手价  ',
                    type: 'text'
                },
                {
                    name: '￥500.00',
                    Id: 59,
                    nameId: 'AE3540CD-E741-4815-829E-A3B284917520',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 825 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '￥500.00',
                    type: 'text'
                },
                {
                    name: '全球首款触控Wifi音箱实木打造温...',
                    Id: 60,
                    nameId: 'B24CE178-B04A-4D32-8E9B-55073C29AD97',
                    frame: { width: 375, height: 33, x: 344, y: 764 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '全球首款触控Wifi音箱实木打造温...',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: 'F4FF44C6-200D-40A5-80EC-B7A4D6C2317D'
        },
        {
            name: 'Group 4',
            Id: 62,
            nameId: '67EC4574-CAED-4E84-868A-50913A2783C4',
            frame: { width: 590, height: 212, x: 160, y: 934 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 63,
                    nameId: '88BEDAA2-EDF1-4C68-ADB0-2CC367FD2E5A',
                    frame: { width: 571, height: 2, x: 179, y: 1144 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1CmidwXOWBuNjy0FiXXXFxVXa-571-2.png'
                },
                {
                    name: 'Bitmap',
                    Id: 65,
                    nameId: '2894AD24-AE37-4231-8A0E-E926F35D0E2A',
                    frame: { width: 148, height: 148, x: 180, y: 966 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 67,
                            nameId: '41BFCDD1-5ACE-4849-9F14-87D7C16A3335',
                            frame: { width: 148, height: 148, x: 180, y: 966 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 68,
                                    nameId: '498BA002-3755-46E8-83C7-254D2DC2008F',
                                    frame: { width: 148, height: 148, x: 180, y: 966 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1fH4zwgmTBuNjy1XbXXaMrVXa-148-148.png'
                                }
                            ],
                            type: 'group',
                            objectID: '41BFCDD1-5ACE-4849-9F14-87D7C16A3335'
                        }
                    ],
                    type: 'group',
                    objectID: '2894AD24-AE37-4231-8A0E-E926F35D0E2A'
                },
                {
                    name: '转手卖  ',
                    Id: 69,
                    nameId: '8B391306-9C70-4286-937F-896C134CD3A9',
                    frame: { width: 74, height: 28, x: 344, y: 1071 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#333333',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '转手卖  ',
                    type: 'text'
                },
                {
                    name: '￥280.00',
                    Id: 70,
                    nameId: '10A227D4-72F6-4D80-8090-85F132B1A99B',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1071 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '￥280.00',
                    type: 'text'
                },
                {
                    name: '聊一聊',
                    Id: 72,
                    nameId: 'B59C0AB6-031A-409A-B1B5-061AC767D8CA',
                    frame: { width: 132, height: 56, x: 598, y: 1044 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 73,
                            nameId: 'AA9B5B6F-EEC7-48A0-AE0B-DFC9ED675432',
                            frame: { width: 132, height: 56, x: 598, y: 1044 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1QbaNwb9YBuNjy0FgXXcxcXXa-132-56.png'
                        },
                        {
                            name: '卖了换钱',
                            Id: 74,
                            nameId: '468F2211-70D7-4F01-8E5E-30C90E1247A6',
                            frame: { width: 96, height: 33, x: 616.2941176470586, y: 1055 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖了换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'B59C0AB6-031A-409A-B1B5-061AC767D8CA'
                },
                {
                    name: '入手价  ',
                    Id: 75,
                    nameId: '0CE3B489-7A14-4752-8AFD-A5B3778EE890',
                    frame: { width: 74, height: 28, x: 344, y: 1037 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '入手价  ',
                    type: 'text'
                },
                {
                    name: '￥500.00',
                    Id: 76,
                    nameId: '8B740A89-0A94-47B6-805F-3E6F47659D79',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1037 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '￥500.00',
                    type: 'text'
                },
                {
                    name: '全球首款触控Wifi音箱实木打造温...',
                    Id: 77,
                    nameId: '0DA4EAD4-DC7B-4D52-BCDB-E8820CD56EA4',
                    frame: { width: 375, height: 33, x: 344, y: 976 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '全球首款触控Wifi音箱实木打造温...',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '67EC4574-CAED-4E84-868A-50913A2783C4'
        },
        {
            name: 'Group 4',
            Id: 79,
            nameId: '362336EA-4D58-431D-A7C6-6AB9F83D3A8E',
            frame: { width: 590, height: 212, x: 160, y: 1428 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 80,
                    nameId: 'DB75AC07-BAD7-401B-8899-4B59B916E794',
                    frame: { width: 571, height: 2, x: 179, y: 1638 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1JIFzwgmTBuNjy1XbXXaMrVXa-571-2.png'
                },
                {
                    name: 'Bitmap',
                    Id: 82,
                    nameId: '0CF95AB7-8EDB-4BA1-8407-AB070514C4E8',
                    frame: { width: 148, height: 148, x: 180, y: 1460 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 84,
                            nameId: '5B6D3C76-C93E-4285-B732-6E1339E9A86C',
                            frame: { width: 148, height: 148, x: 180, y: 1460 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 85,
                                    nameId: 'C0FEA9C8-1E65-418E-A173-CC147BB92674',
                                    frame: { width: 148, height: 148, x: 180, y: 1460 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1XieEwkOWBuNjSsppXXXPgpXa-148-148.png'
                                }
                            ],
                            type: 'group',
                            objectID: '5B6D3C76-C93E-4285-B732-6E1339E9A86C'
                        }
                    ],
                    type: 'group',
                    objectID: '0CF95AB7-8EDB-4BA1-8407-AB070514C4E8'
                },
                {
                    name: '转手卖  ',
                    Id: 86,
                    nameId: '0DA67C46-2DF7-464B-B9A4-80DFD8290B5D',
                    frame: { width: 74, height: 28, x: 344, y: 1565 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#333333',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '转手卖  ',
                    type: 'text'
                },
                {
                    name: '￥280.00',
                    Id: 87,
                    nameId: '8F9F0B01-1E08-44EA-9E0D-112C877B36EA',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1565 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '￥280.00',
                    type: 'text'
                },
                {
                    name: '聊一聊',
                    Id: 89,
                    nameId: '10F7CB02-3419-48C4-A162-113E6DD5429B',
                    frame: { width: 132, height: 56, x: 598, y: 1538 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 90,
                            nameId: 'C9DCED77-33B2-4766-B061-975366E7B36F',
                            frame: { width: 132, height: 56, x: 598, y: 1538 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1b8vBwamWBuNjy1XaXXXCbXXa-132-56.png'
                        },
                        {
                            name: '卖了换钱',
                            Id: 91,
                            nameId: 'F34EBD7E-A1CE-4046-9DE9-9331F319DB21',
                            frame: { width: 96, height: 33, x: 616.2941176470586, y: 1549 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖了换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '10F7CB02-3419-48C4-A162-113E6DD5429B'
                },
                {
                    name: '入手价  ',
                    Id: 92,
                    nameId: '85FE1F3A-1EF0-41E1-845A-1D83EDF66AB3',
                    frame: { width: 74, height: 28, x: 344, y: 1531 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '入手价  ',
                    type: 'text'
                },
                {
                    name: '￥500.00',
                    Id: 93,
                    nameId: '32AD1F6A-6DB9-4207-B443-D337FEA91AE2',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1531 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '￥500.00',
                    type: 'text'
                },
                {
                    name: '全球首款触控Wifi音箱实木打造温...',
                    Id: 94,
                    nameId: '369697A3-FE0E-4E4F-A319-500DF2E1985E',
                    frame: { width: 375, height: 33, x: 344, y: 1470 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '全球首款触控Wifi音箱实木打造温...',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '362336EA-4D58-431D-A7C6-6AB9F83D3A8E'
        },
        {
            name: 'Group 4',
            Id: 96,
            nameId: 'CC03F59B-E315-402D-9480-AAABE1B5B8F0',
            frame: { width: 590, height: 212, x: 160, y: 1640 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 98,
                    nameId: '5F8F617D-C159-4AD4-8CB8-D4351C31892D',
                    frame: { width: 148, height: 148, x: 180, y: 1672 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 100,
                            nameId: '628637FE-C1C4-4E74-90E9-15F21EF39636',
                            frame: { width: 148, height: 148, x: 180, y: 1672 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 101,
                                    nameId: '5DA2B944-F68D-4140-A465-A5373C73B85A',
                                    frame: { width: 148, height: 148, x: 180, y: 1672 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1Nkn_wmtYBeNjSspaXXaOOFXa-148-148.png'
                                }
                            ],
                            type: 'group',
                            objectID: '628637FE-C1C4-4E74-90E9-15F21EF39636'
                        }
                    ],
                    type: 'group',
                    objectID: '5F8F617D-C159-4AD4-8CB8-D4351C31892D'
                },
                {
                    name: '转手卖  ',
                    Id: 102,
                    nameId: '94B8E20C-92C6-4E3F-8BF4-CB50B8B891FA',
                    frame: { width: 74, height: 28, x: 344, y: 1777 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#333333',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '转手卖  ',
                    type: 'text'
                },
                {
                    name: '￥280.00',
                    Id: 103,
                    nameId: 'AA625589-EACF-4FCE-ADD1-7B4A3E05A170',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1777 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '￥280.00',
                    type: 'text'
                },
                {
                    name: '聊一聊',
                    Id: 105,
                    nameId: 'D0F7820B-FE08-48AF-9439-A459F982CD63',
                    frame: { width: 132, height: 56, x: 598, y: 1750 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 106,
                            nameId: '35B275E2-84DD-47D6-8B09-46996BB6D07F',
                            frame: { width: 132, height: 56, x: 598, y: 1750 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1HlvBwamWBuNjy1XaXXXCbXXa-132-56.png'
                        },
                        {
                            name: '卖了换钱',
                            Id: 107,
                            nameId: 'DDCD7F50-5E03-4821-A8A0-5385B5B96317',
                            frame: { width: 96, height: 33, x: 616.2941176470586, y: 1761 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖了换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'D0F7820B-FE08-48AF-9439-A459F982CD63'
                },
                {
                    name: '入手价  ',
                    Id: 108,
                    nameId: '2BA51336-3622-4438-969C-6D272F821B80',
                    frame: { width: 74, height: 28, x: 344, y: 1743 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '入手价  ',
                    type: 'text'
                },
                {
                    name: '￥500.00',
                    Id: 109,
                    nameId: '75843A63-CC2F-4EF3-99DA-C781A6D218A1',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1743 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '￥500.00',
                    type: 'text'
                },
                {
                    name: '全球首款触控Wifi音箱实木打造温...',
                    Id: 110,
                    nameId: 'F07EB320-9FED-482A-B7B7-FBC3DD817436',
                    frame: { width: 375, height: 33, x: 344, y: 1682 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '全球首款触控Wifi音箱实木打造温...',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: 'CC03F59B-E315-402D-9480-AAABE1B5B8F0'
        },
        {
            name: 'Group 4',
            Id: 112,
            nameId: '6E74319F-E4AE-4B21-987F-8ECF5ED266AD',
            frame: { width: 590, height: 212, x: 160, y: 1146 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 113,
                    nameId: '215664BD-76EA-4D58-87C0-7248475AF3BC',
                    frame: { width: 571, height: 2, x: 179, y: 1356 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1iJ1swb5YBuNjSspoXXbeNFXa-571-2.png'
                },
                {
                    name: 'Bitmap',
                    Id: 115,
                    nameId: '2EECA2E7-8D20-406F-AE2E-AF0021B7758A',
                    frame: { width: 148, height: 148, x: 180, y: 1178 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 117,
                            nameId: '44C04E25-1C30-4A75-A64A-BACA24EFDD41',
                            frame: { width: 148, height: 148, x: 180, y: 1178 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 118,
                                    nameId: 'F244B8A0-43DF-4782-A23A-D5DFEEEE7FF4',
                                    frame: { width: 148, height: 148, x: 180, y: 1178 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1zIapwkyWBuNjy0FpXXassXXa-148-148.png'
                                }
                            ],
                            type: 'group',
                            objectID: '44C04E25-1C30-4A75-A64A-BACA24EFDD41'
                        }
                    ],
                    type: 'group',
                    objectID: '2EECA2E7-8D20-406F-AE2E-AF0021B7758A'
                },
                {
                    name: '转手卖  ',
                    Id: 119,
                    nameId: '50D71BBF-3CC0-441B-A87B-EEFB8FB170D2',
                    frame: { width: 74, height: 28, x: 344, y: 1283 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#333333',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '转手卖  ',
                    type: 'text'
                },
                {
                    name: '￥280.00',
                    Id: 120,
                    nameId: '5B480E16-78A5-4F00-8BED-0AE69CE594E2',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1283 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'bold'
                    },
                    value: '￥280.00',
                    type: 'text'
                },
                {
                    name: '聊一聊',
                    Id: 122,
                    nameId: '766C9143-FDA0-41A1-B56B-2D2B6C78B24D',
                    frame: { width: 132, height: 56, x: 598, y: 1256 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 123,
                            nameId: '7CAABF74-66BC-497F-84EC-5B1AA01FD431',
                            frame: { width: 132, height: 56, x: 598, y: 1256 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB16ER0whSYBuNjSsphXXbGvVXa-132-56.png'
                        },
                        {
                            name: '卖了换钱',
                            Id: 124,
                            nameId: '407BFA69-A66A-482C-99C0-1501A85DADA3',
                            frame: { width: 96, height: 33, x: 616.2941176470586, y: 1267 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖了换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '766C9143-FDA0-41A1-B56B-2D2B6C78B24D'
                },
                {
                    name: '入手价  ',
                    Id: 125,
                    nameId: 'DD03436C-9669-4D20-81A9-2CB5C38F8FDD',
                    frame: { width: 74, height: 28, x: 344, y: 1249 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '入手价  ',
                    type: 'text'
                },
                {
                    name: '￥500.00',
                    Id: 126,
                    nameId: '921024CA-CFC1-444B-8076-26A6B62C022F',
                    frame: { width: 103, height: 28, x: 417.0319999999999, y: 1249 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '28',
                        fontWeight: 'normal'
                    },
                    value: '￥500.00',
                    type: 'text'
                },
                {
                    name: '全球首款触控Wifi音箱实木打造温...',
                    Id: 127,
                    nameId: 'F1E3BDBB-2C7C-45E5-8A98-860BD5DB55B9',
                    frame: { width: 375, height: 33, x: 344, y: 1188 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '全球首款触控Wifi音箱实木打造温...',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '6E74319F-E4AE-4B21-987F-8ECF5ED266AD'
        },
        {
            name: '热门转卖（3）',
            Id: 128,
            nameId: '486F7038-7CDC-4652-9ACB-28ACA3BA9019',
            frame: { width: 159, height: 40, x: 180, y: 682 },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 24,
                color: '#888888',
                lineHeight: '39.20000076293945',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '热门转卖（3）',
            type: 'text'
        },
        {
            name: '男士服装（12）',
            Id: 129,
            nameId: '1DA8898C-7110-40F8-BC1A-A24DFA67414A',
            frame: { width: 169, height: 40, x: 180, y: 1388 },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 24,
                color: '#888888',
                lineHeight: '39.20000076293945',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '男士服装（12）',
            type: 'text'
        },
        {
            name: ' icon',
            Id: 131,
            nameId: '8C7A3291-1B06-4948-B479-09A83AC43026',
            frame: { width: 750, height: 141, x: 0, y: 400 },
            layers: [
                {
                    name: 'Line + Line Mask',
                    Id: 133,
                    nameId: 'CC2E7FC1-4A06-46D6-B3EF-ABB2AC314BF4',
                    frame: { width: 750, height: 141, x: 0, y: 400 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 134,
                            nameId: '9BB1FF0B-A7C2-412A-A98D-3153ECF88430',
                            frame: { width: 750, height: 141, x: 0, y: 400 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1NcKpwkyWBuNjy0FpXXassXXa-750-141.png'
                        },
                        {
                            name: 'Line',
                            Id: 136,
                            nameId: 'BD64801D-6ECD-4FAC-AC87-5C7AC615789D',
                            frame: { width: 750, height: 1, x: 0, y: 540 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 137,
                                    nameId: '6CF867A1-BE3B-4721-BFEB-8CBFD2DB4229',
                                    frame: { width: 750, height: 1, x: 0, y: 540 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1JOKtweOSBuNjy0FdXXbDnVXa-750-1.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'BD64801D-6ECD-4FAC-AC87-5C7AC615789D'
                        },
                        {
                            name: 'Line',
                            Id: 139,
                            nameId: 'BD31EFD2-72E6-41D8-BA32-CC0FF515D479',
                            frame: { width: 1, height: 141, x: 375, y: 400 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 140,
                                    nameId: 'BBFA3DE3-609E-4B6A-AFBA-5486CD777B16',
                                    frame: { width: 1, height: 141, x: 375, y: 400 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB16ZKpwkyWBuNjy0FpXXassXXa-1-141.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'BD31EFD2-72E6-41D8-BA32-CC0FF515D479'
                        }
                    ],
                    type: 'group',
                    objectID: 'CC2E7FC1-4A06-46D6-B3EF-ABB2AC314BF4'
                },
                {
                    name: '闲置估价',
                    Id: 141,
                    nameId: 'AF8018BA-1EF8-40E8-9001-F6A8D251E1D6',
                    frame: { width: 112, height: 36, x: 503, y: 434 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 28,
                        color: '#333333',
                        lineHeight: '36',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '闲置估价',
                    type: 'text'
                },
                {
                    name: '闲置拍照, 帮你估价',
                    Id: 142,
                    nameId: '92E750CF-3000-4F0B-A382-D83E926C0D11',
                    frame: { width: 172, height: 36, x: 505.0160000000001, y: 470 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        lineHeight: '36',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '闲置拍照, 帮你估价',
                    type: 'text'
                },
                {
                    name: '信用速卖',
                    Id: 143,
                    nameId: '0F8471A0-43DF-4A14-9B3A-C667359E9F45',
                    frame: { width: 112, height: 36, x: 128, y: 436 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 28,
                        color: '#333333',
                        lineHeight: '36',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '信用速卖',
                    type: 'text'
                },
                {
                    name: '1秒卖闲置，加价10%',
                    Id: 144,
                    nameId: '6708C4F2-8AE1-4CAC-B62E-919CA792A299',
                    frame: { width: 188, height: 36, x: 130.01600000000008, y: 472 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 20,
                        color: '#999999',
                        lineHeight: '36',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '1秒卖闲置，加价10%',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 145,
                    nameId: '1C74AE55-D764-4ACE-8121-DA37FBC20F66',
                    frame: { width: 52, height: 57, x: 54, y: 441 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1HxWbwf5TBuNjSspcXXbnGFXa-52-57.png'
                },
                {
                    name: 'Bitmap',
                    Id: 146,
                    nameId: 'A7CDEF8E-BB0B-405D-8D1B-FF92CCBC8A5F',
                    frame: { width: 55, height: 49, x: 426, y: 445 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB10YeawbGYBuNjy0FoXXciBFXa-55-49.png'
                }
            ],
            type: 'group',
            objectID: '8C7A3291-1B06-4948-B479-09A83AC43026'
        },
        {
            name: '闲鱼1',
            Id: 148,
            nameId: 'D8412EF9-411A-4615-B237-05DFA11C9683',
            frame: { width: 750, height: 272, x: 0, y: 127 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 149,
                    nameId: '338139CB-4365-4584-8627-65E5B5C24AF0',
                    frame: { width: 750, height: 272, x: 0, y: 127 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1XT0zwXmWBuNjSspdXXbugXXa-750-272.png'
                },
                {
                    name: 'Oval',
                    Id: 151,
                    nameId: 'C87A29A5-2EFE-4CC8-9B66-A40F20CDFD11',
                    frame: { width: 537, height: 272, x: 32, y: 127 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 152,
                            nameId: '115B5E88-CE1E-4CD3-83D9-D3D99F0D1485',
                            frame: { width: 537, height: 272, x: 32, y: 127 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1nbqawbGYBuNjy0FoXXciBFXa-537-272.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'C87A29A5-2EFE-4CC8-9B66-A40F20CDFD11'
                },
                {
                    name: 'Oval',
                    Id: 154,
                    nameId: '04B19957-7DA2-468B-9604-C3041D8C6B52',
                    frame: { width: 371, height: 175, x: 304, y: 224 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 155,
                            nameId: '5B966DAC-97BB-4264-B55D-EDA63494B10F',
                            frame: { width: 371, height: 175, x: 304, y: 224 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1o.NzwXmWBuNjSspdXXbugXXa-371-175.png'
                        }
                    ],
                    type: 'group',
                    objectID: '04B19957-7DA2-468B-9604-C3041D8C6B52'
                },
                {
                    name: 'Oval',
                    Id: 157,
                    nameId: '3EB02E7A-2575-4851-9818-EDE61660A657',
                    frame: { width: 169, height: 78, x: 581, y: 127 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 158,
                            nameId: '3EDDB978-6C0F-4157-BBEE-3EA32317CA15',
                            frame: { width: 169, height: 78, x: 581, y: 127 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB14Xu0whGYBuNjy0FnXXX5lpXa-169-78.png'
                        }
                    ],
                    type: 'group',
                    objectID: '3EB02E7A-2575-4851-9818-EDE61660A657'
                },
                {
                    name: 'Rectangle 13 Copy',
                    Id: 159,
                    nameId: '1F8923B1-9C02-4C8C-84A6-8A04C312D80A',
                    frame: { width: 2, height: 80, x: 375, y: 280 },
                    styles: { backgroundColor: 'rgba(159,94,42,0.27)' },
                    type: 'shape'
                },
                {
                    name: 'Bitmap',
                    Id: 160,
                    nameId: '4874BCF8-B1C0-42B2-B183-51C4482637C8',
                    frame: { width: 80, height: 80, x: 32, y: 164 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1ARiswk9WBuNjSspeXXaz5VXa-80-80.png'
                },
                {
                    name: 'Group 10',
                    Id: 162,
                    nameId: '78E43643-91A5-418E-8CF9-2C3689A9A070',
                    frame: { width: 146, height: 96, x: 128, y: 278 },
                    layers: [
                        {
                            name: 'Group 15',
                            Id: 164,
                            nameId: '6E66E9EB-33C2-4EE9-A5EE-6D1340583123',
                            frame: { width: 146, height: 96, x: 128, y: 278 },
                            layers: [
                                {
                                    name: 'Group 13',
                                    Id: 166,
                                    nameId: '1A444707-F280-4A6B-A8C9-CB561F605E5C',
                                    frame: { width: 146, height: 53, x: 128, y: 321 },
                                    layers: [
                                        {
                                            name: '件',
                                            Id: 167,
                                            nameId: '31425BF8-569C-46D2-8B6B-4BEBA6FDF843',
                                            frame: { width: 24, height: 48, x: 250, y: 326 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Regular',
                                                fontSize: 24,
                                                color: '#222222',
                                                lineHeight: '48',
                                                textAlign: 'left',
                                                fontWeight: 'normal'
                                            },
                                            value: '件',
                                            type: 'text'
                                        },
                                        {
                                            name: '8765',
                                            Id: 168,
                                            nameId: '328E8CD3-6A2C-47E0-A75E-C5D2C68D2666',
                                            frame: { width: 113, height: 48, x: 128, y: 321 },
                                            textStyles: {
                                                fontFamily: 'PingFangSC-Medium',
                                                fontSize: 48,
                                                color: '#222222',
                                                lineHeight: '48',
                                                textAlign: 'left',
                                                fontWeight: 'bold'
                                            },
                                            value: '8765',
                                            type: 'text'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '1A444707-F280-4A6B-A8C9-CB561F605E5C'
                                },
                                {
                                    name: '买入宝贝',
                                    Id: 169,
                                    nameId: 'A13A6705-3C03-4016-9133-1B1A85DA7FD7',
                                    frame: { width: 96, height: 33, x: 128, y: 278 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: 24,
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '33',
                                        fontWeight: 'normal'
                                    },
                                    value: '买入宝贝',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '6E66E9EB-33C2-4EE9-A5EE-6D1340583123'
                        }
                    ],
                    type: 'group',
                    objectID: '78E43643-91A5-418E-8CF9-2C3689A9A070'
                },
                {
                    name: 'Group 10 Copy',
                    Id: 171,
                    nameId: '785E8E4D-E145-466E-91B9-2DFB4C89E085',
                    frame: { width: 162, height: 95, x: 477, y: 277 },
                    layers: [
                        {
                            name: 'Group 16',
                            Id: 173,
                            nameId: '94CF57EC-37DE-4B24-9166-977776A2A9A2',
                            frame: { width: 162, height: 52, x: 477, y: 320 },
                            layers: [
                                {
                                    name: '元',
                                    Id: 174,
                                    nameId: '9D71D22D-CFBF-4543-9587-6EF782764BCB',
                                    frame: { width: 24, height: 48, x: 615, y: 324 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: 24,
                                        color: '#222222',
                                        lineHeight: '48',
                                        textAlign: 'left',
                                        fontWeight: 'normal'
                                    },
                                    value: '元',
                                    type: 'text'
                                },
                                {
                                    name: '19873',
                                    Id: 175,
                                    nameId: 'EC4F1A5B-9417-4E0B-9605-98C5683085AB',
                                    frame: { width: 133, height: 48, x: 477, y: 320 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: 48,
                                        color: '#222222',
                                        lineHeight: '48',
                                        textAlign: 'left',
                                        fontWeight: 'bold'
                                    },
                                    value: '19873',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '94CF57EC-37DE-4B24-9166-977776A2A9A2'
                        },
                        {
                            name: '全部卖掉可赚',
                            Id: 176,
                            nameId: '3BF94263-4082-4535-90EE-875FCC333A35',
                            frame: { width: 144, height: 33, x: 477, y: 277 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'normal'
                            },
                            value: '全部卖掉可赚',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '785E8E4D-E145-466E-91B9-2DFB4C89E085'
                },
                {
                    name: 'Group 17',
                    Id: 178,
                    nameId: 'EDB43E84-F17A-4C66-AEEB-C6003ED85735',
                    frame: { width: 356, height: 42, x: 129, y: 181 },
                    layers: [
                        {
                            name: 'Rebecca',
                            Id: 179,
                            nameId: 'F4977A17-4F6C-4FE6-A574-B09655666EE4',
                            frame: { width: 124, height: 42, x: 129, y: 181 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 30,
                                color: '#000000',
                                lineHeight: '42',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: 'Rebecca',
                            type: 'text'
                        },
                        {
                            name: '你过去1年在淘宝',
                            Id: 180,
                            nameId: '6A847566-4D72-4D14-AE6E-000396DB5129',
                            frame: { width: 223, height: 42, x: 262, y: 181 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 30,
                                color: '#222222',
                                lineHeight: '42',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '你过去1年在淘宝',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'EDB43E84-F17A-4C66-AEEB-C6003ED85735'
                }
            ],
            type: 'group',
            objectID: 'D8412EF9-411A-4615-B237-05DFA11C9683'
        },
        {
            name: 'IMG_2704',
            Id: 181,
            nameId: 'C28BC38F-B639-4226-AE7E-645F49D318CC',
            frame: { width: 750, height: 1240, x: 0, y: 1855 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1upy0whGYBuNjy0FnXXX5lpXa-750-1240.png'
        },
        {
            name: 'Group 11',
            Id: 183,
            nameId: 'D2EFCEA4-C57C-46AD-840B-BF2FCF232642',
            frame: { width: 695, height: 88, x: 31, y: 2165 },
            layers: [
                {
                    name: 'Rectangle 10',
                    Id: 184,
                    nameId: '6C7799B0-9C08-4F62-99E9-15592D9D0A88',
                    frame: { width: 695, height: 88, x: 31, y: 2165 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)' },
                    type: 'shape'
                },
                {
                    name: '聊一聊',
                    Id: 186,
                    nameId: 'ECE1F5C5-7760-4CA3-B16D-25AF02D942EA',
                    frame: { width: 132, height: 56, x: 49, y: 2181 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 187,
                            nameId: '2DD58CBD-36B3-4C7D-8E18-56FE85C0B0BC',
                            frame: { width: 132, height: 56, x: 49, y: 2181 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1NVKeweGSBuNjSspbXXciipXa-132-56.png'
                        },
                        {
                            name: '上门回收',
                            Id: 188,
                            nameId: '76935C82-95E6-45CF-BACA-EF5F8FDCBF1E',
                            frame: { width: 96, height: 33, x: 67.29411764705878, y: 2192 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '上门回收',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'ECE1F5C5-7760-4CA3-B16D-25AF02D942EA'
                },
                {
                    name: '聊一聊',
                    Id: 190,
                    nameId: 'A804EE57-1D72-443F-8890-C380F8CECCCE',
                    frame: { width: 132, height: 56, x: 309, y: 2181 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 191,
                            nameId: 'ED975D81-38D1-467E-B3E4-195FBAB95F69',
                            frame: { width: 132, height: 56, x: 309, y: 2181 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1QVy0whGYBuNjy0FnXXX5lpXa-132-56.png'
                        },
                        {
                            name: '卖衣换钱',
                            Id: 192,
                            nameId: '15DD054B-D110-4BB9-9EA9-963DF2BB60A7',
                            frame: { width: 96, height: 33, x: 327.2941176470588, y: 2192 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '卖衣换钱',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'A804EE57-1D72-443F-8890-C380F8CECCCE'
                },
                {
                    name: '聊一聊',
                    Id: 194,
                    nameId: 'B7B8B1E2-A56B-4C38-98E8-21BF0E329260',
                    frame: { width: 132, height: 56, x: 579, y: 2181 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 195,
                            nameId: '8DB56DAC-33DF-4DC1-B4F7-B6BC8707A725',
                            frame: { width: 132, height: 56, x: 579, y: 2181 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1wJlYwXGWBuNjy0FbXXb4sXXa-132-56.png'
                        },
                        {
                            name: '免费送衣',
                            Id: 196,
                            nameId: '3D9795BD-1A00-4571-A709-9F8E2D5E9432',
                            frame: { width: 95.99999999999955, height: 33, x: 597.294117647059, y: 2192 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#222222',
                                textAlign: 'center',
                                lineHeight: '33',
                                fontWeight: 'bold'
                            },
                            value: '免费送衣',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'B7B8B1E2-A56B-4C38-98E8-21BF0E329260'
                }
            ],
            type: 'group',
            objectID: 'D2EFCEA4-C57C-46AD-840B-BF2FCF232642'
        },
        {
            name: 'tabbar',
            Id: 198,
            nameId: '43ACCB39-7DDF-40A0-A330-555B9278690A',
            frame: { width: 752, height: 151, x: 0, y: 2523 },
            layers: [
                {
                    name: 'Toolbar',
                    Id: 200,
                    nameId: 'EF9843A9-DF07-4461-88D7-533333C42500',
                    frame: { width: 752, height: 151, x: 0, y: 2523 },
                    layers: [
                        {
                            name: 'Rectangle 2',
                            Id: 201,
                            nameId: '9FAB2FF4-E102-4F49-AAA8-A225F82CE1F5',
                            frame: { width: 150, height: 98, x: 2, y: 2564 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)' },
                            type: 'shape'
                        },
                        {
                            name: 'Rectangle 2 Copy 3',
                            Id: 202,
                            nameId: 'CCE1EBFD-F394-49F0-ACEF-F79CF48AB1DB',
                            frame: { width: 150, height: 98, x: 452, y: 2564 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)' },
                            type: 'shape'
                        },
                        {
                            name: 'Bitmap',
                            Id: 203,
                            nameId: 'AD17BD4F-C3CC-4BBE-B097-032311524635',
                            frame: { width: 47, height: 43, x: 504, y: 2581 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1llumweSSBuNjy0FlXXbBpVXa-47-43.png'
                        },
                        {
                            name: 'Rectangle 2 Copy 4',
                            Id: 204,
                            nameId: '8AD1681D-2173-448A-B844-9E2547664EEF',
                            frame: { width: 150, height: 98, x: 602, y: 2564 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)' },
                            type: 'shape'
                        },
                        {
                            name: 'Bitmap',
                            Id: 205,
                            nameId: 'B35C651A-06D2-449F-9446-47E609B7EA22',
                            frame: { width: 750, height: 1, x: 0, y: 2564 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1cRqswk9WBuNjSspeXXaz5VXa-750-1.png'
                        },
                        {
                            name: 'Rectangle 2 Copy 2',
                            Id: 206,
                            nameId: '5067CAC5-E890-40F6-9B47-5E8242B518B4',
                            frame: { width: 150, height: 96, x: 302, y: 2565 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)' },
                            type: 'shape'
                        },
                        {
                            name: '闲置转卖',
                            Id: 207,
                            nameId: 'D1C26B66-8E7A-4879-A71C-B7989C77DA67',
                            frame: { width: 73, height: 42, x: 91, y: 2632 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 18,
                                color: '#333333',
                                textAlign: 'center',
                                lineHeight: '42',
                                fontWeight: 'normal'
                            },
                            value: '闲置转卖',
                            type: 'text'
                        },
                        {
                            name: '我的',
                            Id: 208,
                            nameId: '418108CB-6E53-4A47-AD13-E1D014A143E1',
                            frame: { width: 37, height: 18, x: 609, y: 2636 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 18,
                                color: '#333333',
                                textAlign: 'center',
                                lineHeight: '18',
                                fontWeight: 'normal'
                            },
                            value: '我的',
                            type: 'text'
                        },
                        {
                            name: '卖闲置',
                            Id: 209,
                            nameId: '56CEEB06-0D5E-4DB9-B94C-DDF79057A3CF',
                            frame: { width: 55, height: 42, x: 348.5, y: 2632 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 18,
                                color: '#333333',
                                textAlign: 'center',
                                lineHeight: '42',
                                fontWeight: 'normal'
                            },
                            value: '卖闲置',
                            type: 'text'
                        },
                        {
                            name: '发布',
                            Id: 210,
                            nameId: '4E5219C9-E476-4053-9D29-622B4842C20A',
                            frame: { width: 107, height: 111, x: 322, y: 2523 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1LlumweSSBuNjy0FlXXbBpVXa-107-111.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'EF9843A9-DF07-4461-88D7-533333C42500'
                },
                {
                    name: 'Bitmap',
                    Id: 211,
                    nameId: '72981E4D-3E6D-4B8E-B296-17E7EC1484D6',
                    frame: { width: 39, height: 40, x: 608, y: 2577 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1jYW2wbSYBuNjSspfXXcZCpXa-39-40.png'
                },
                {
                    name: 'Group 9',
                    Id: 213,
                    nameId: 'D935CFD4-E6C9-4F29-AB46-76EB629ECD86',
                    frame: { width: 36, height: 40, x: 109, y: 2577 },
                    layers: [
                        {
                            name: 'Group 2',
                            Id: 215,
                            nameId: '76B68E16-DAFE-4955-8713-0AF06659147F',
                            frame: { width: 36, height: 40, x: 109, y: 2577 },
                            layers: [
                                {
                                    name: 'Group 4',
                                    Id: 217,
                                    nameId: '7970E295-27AA-4684-B023-2474EA3862DF',
                                    frame: { width: 36, height: 40, x: 109, y: 2577 },
                                    layers: [
                                        {
                                            name: 'Group 14',
                                            Id: 219,
                                            nameId: 'A4D4CCE6-3A14-4F59-92EA-3A2194CC0BBD',
                                            frame: { width: 36, height: 36, x: 109, y: 2577 },
                                            layers: [
                                                {
                                                    name: '出租房屋icon',
                                                    Id: 221,
                                                    nameId: 'D64147DD-FA31-425E-8C64-21CB6782E048',
                                                    frame: { width: 36, height: 36, x: 109, y: 2577 },
                                                    layers: [
                                                        {
                                                            name: 'Bitmap',
                                                            Id: 222,
                                                            nameId: '31D7382D-ECBD-4179-8103-4004D8AA9C7C',
                                                            frame: { width: 36, height: 17, x: 109, y: 2577 },
                                                            imageStyles: { resize: 'stretch' },
                                                            type: 'image',
                                                            value: 'https://gw.alicdn.com/tfs/TB15W2YwmtYBeNjSspkXXbU8VXa-36-17.png'
                                                        },
                                                        {
                                                            name: 'Bitmap',
                                                            Id: 223,
                                                            nameId: '85B4065C-79BB-4153-A952-871BDC93CE14',
                                                            frame: { width: 3, height: 21, x: 109, y: 2592 },
                                                            imageStyles: { resize: 'stretch' },
                                                            type: 'image',
                                                            value: 'https://gw.alicdn.com/tfs/TB1CPmbwf5TBuNjSspcXXbnGFXa-3-21.png'
                                                        },
                                                        {
                                                            name: 'Bitmap',
                                                            Id: 224,
                                                            nameId: '0AC25122-FF2B-49A7-B1A4-BCBD32898A26',
                                                            frame: { width: 3, height: 21, x: 142, y: 2592 },
                                                            imageStyles: { resize: 'stretch' },
                                                            type: 'image',
                                                            value: 'https://gw.alicdn.com/tfs/TB16A9EwkOWBuNjSsppXXXPgpXa-3-21.png'
                                                        }
                                                    ],
                                                    type: 'group',
                                                    objectID: 'D64147DD-FA31-425E-8C64-21CB6782E048'
                                                }
                                            ],
                                            type: 'group',
                                            objectID: 'A4D4CCE6-3A14-4F59-92EA-3A2194CC0BBD'
                                        },
                                        {
                                            name: 'Bitmap',
                                            Id: 225,
                                            nameId: '7F5B8834-FCFF-478B-BC99-2F644828EB4B',
                                            frame: { width: 36, height: 5, x: 109, y: 2612 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1mG1ewXOWBuNjy0FiXXXFxVXa-36-5.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '7970E295-27AA-4684-B023-2474EA3862DF'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 226,
                                    nameId: 'CC1BCA40-692D-4E27-AB71-AAC4A34A7ED9',
                                    frame: { width: 26, height: 28, x: 114, y: 2584 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1HIngwkSWBuNjSszdXXbeSpXa-26-28.png'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 227,
                                    nameId: '04AB8459-BA4B-4F2C-99F0-4A33F20D8810',
                                    frame: { width: 4, height: 7, x: 125, y: 2603 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1BIiJwhSYBuNjSspjXXX73VXa-4-7.png'
                                }
                            ],
                            type: 'group',
                            objectID: '76B68E16-DAFE-4955-8713-0AF06659147F'
                        }
                    ],
                    type: 'group',
                    objectID: 'D935CFD4-E6C9-4F29-AB46-76EB629ECD86'
                }
            ],
            type: 'group',
            objectID: '43ACCB39-7DDF-40A0-A330-555B9278690A'
        }
    ],
    nameId: 1528353254495,
    Id: 1,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 2662 },
    styles: { backgroundColor: 'rgba(243,245,249,1)' }
};
