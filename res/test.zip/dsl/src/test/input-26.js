"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Bitmap',
            Id: 47,
            nameId: '59DCFB05-D4B8-45B5-980C-C8E18B4D0FC5',
            frame: { width: 750, height: 582, x: 0, y: 0 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1IU7rqkyWBuNjy0FpXXassXXa-750-582.png'
        },
        {
            name: 'Bitmap',
            Id: 48,
            nameId: '2F7F0805-662F-4706-BF15-90336C669965',
            frame: { width: 173, height: 186, x: 289, y: 275 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1CTk8qamWBuNjy1XaXXXCbXXa-173-186.png'
        },
        {
            name: 'Bitmap Copy',
            Id: 49,
            nameId: '652A7BE2-7384-4FE4-9C77-45B72F07993F',
            frame: { width: 173, height: 186, x: 512, y: 275 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1go.rqkyWBuNjy0FpXXassXXa-173-186.png'
        },
        {
            name: 'Bitmap Copy 2',
            Id: 50,
            nameId: 'A46F90F6-023D-4D82-9045-30029FEB873D',
            frame: { width: 173, height: 186, x: 66, y: 275 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1C..rqkyWBuNjy0FpXXassXXa-173-186.png'
        },
        {
            name: 'Group 3',
            Id: 52,
            nameId: '1AD807DB-DC3A-4D7C-9CBD-CD98F8F335DC',
            frame: { width: 729, height: 1473, x: 21, y: 530 },
            layers: [
                {
                    name: 'Rectangle',
                    Id: 53,
                    nameId: 'EA7AD172-C1E5-4A0E-BC42-8A1FC3681B4D',
                    frame: { width: 690, height: 1472.999999999999, x: 30, y: 530 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', cornerRadiusString: '10', borderRadius: 10 },
                    type: 'shape'
                },
                {
                    name: '赞',
                    Id: 54,
                    nameId: '1AF11AC3-2FAE-49FC-94A6-9D4F5780AF60',
                    frame: { width: 30, height: 42, x: 114, y: 1922 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '30',
                        color: '#FF2222',
                        lineHeight: '42',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '赞',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 55,
                    nameId: '9BB9529A-6FDB-463D-A682-F4CFABCAE66C',
                    frame: { width: 46, height: 37, x: 59, y: 1925 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1Oo.rqkyWBuNjy0FpXXassXXa-46-37.png'
                },
                {
                    name: 'Bitmap',
                    Id: 56,
                    nameId: '6A34FF57-2FB8-477D-85E2-4EF20055A3AD',
                    frame: { width: 22, height: 36, x: 194, y: 621 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1VE.rqkyWBuNjy0FpXXassXXa-22-36.png'
                },
                {
                    name: 'Rectangle 2',
                    Id: 57,
                    nameId: '49258A57-EA6E-452A-9810-F5324CC784F1',
                    frame: { width: 630, height: 273, x: 60, y: 722 },
                    styles: { backgroundColor: 'rgba(22,181,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: '罗曼蒂克消亡史',
                    Id: 58,
                    nameId: '34A39E9C-C5D0-440B-B113-830709F54088',
                    frame: { width: 253, height: 50, x: 194, y: 557 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '36',
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '50',
                        fontWeight: 'bold'
                    },
                    value: '罗曼蒂克消亡史',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 59,
                    nameId: '6166EC44-97CE-4690-B729-F281800CBA57',
                    frame: { width: 36, height: 36, x: 457, y: 565 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1t7_3qbGYBuNjy0FoXXciBFXa-36-36.png'
                },
                {
                    name: 'Bitmap',
                    Id: 61,
                    nameId: 'B74B28C9-6EEC-4630-814C-0FBDDD5A368E',
                    frame: { width: 100, height: 100, x: 64, y: 560 },
                    layers: [
                        {
                            name: 'Mask',
                            Id: 62,
                            nameId: '311A2977-7BA4-46A9-AF6C-25646B928D73',
                            frame: { width: 100, height: 100, x: 64, y: 560 },
                            styles: { backgroundColor: 'rgba(216,216,216,1)', fillType: 'color', cornerRadiusString: '6', borderRadius: 6 },
                            type: 'shape'
                        },
                        {
                            name: 'Bitmap',
                            Id: 64,
                            nameId: 'FBCF6D75-D696-489D-9A49-98E6AA00945A',
                            frame: { width: 100, height: 100, x: 64, y: 560 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 65,
                                    nameId: '5BFDE07A-3A1E-4D2E-9D4A-61E5A91DD07C',
                                    frame: { width: 100, height: 100, x: 64, y: 560 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1dXcsqkyWBuNjy0FpXXassXXa-100-100.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'FBCF6D75-D696-489D-9A49-98E6AA00945A'
                        }
                    ],
                    type: 'group',
                    objectID: 'B74B28C9-6EEC-4630-814C-0FBDDD5A368E'
                },
                {
                    name: '来自浙江大学',
                    Id: 66,
                    nameId: 'A8D6050C-CB6F-43D2-A541-30D61F22B751',
                    frame: { width: 192, height: 45, x: 225, y: 617 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '32',
                        color: '#999999',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '来自浙江大学',
                    type: 'text'
                },
                {
                    name: '四十八个字四十八个字四十八个字四十八个字',
                    Id: 67,
                    nameId: 'B0DD3427-666D-45D4-A780-59E7F2169E69',
                    frame: { width: 528, height: 162, x: 132, y: 719 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '36',
                        color: '#FFFFFF',
                        lineHeight: '54',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '四十八个字四十八个字四十八个字四十八个字四十八个字四十八个字四十八个字四十八',
                    type: 'text'
                },
                {
                    name: '——来自学长',
                    Id: 68,
                    nameId: 'A665CF4E-DED8-492E-9316-6B6E10E8BF9B',
                    frame: { width: 217, height: 50, x: 445, y: 921 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '36',
                        color: '#FFFFFF',
                        lineHeight: '50',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '——来自学长',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 69,
                    nameId: 'E0D9CB99-AE0F-45B6-930C-14C7DA3531FD',
                    frame: { width: 33, height: 26, x: 90, y: 730 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1Nk_3qbGYBuNjy0FoXXciBFXa-33-26.png'
                },
                {
                    name: 'Group',
                    Id: 71,
                    nameId: 'F8922EFF-EE50-42EC-8F0E-7BD2C3889577',
                    frame: { width: 197, height: 54, x: 60, y: 1047 },
                    layers: [
                        {
                            name: '￥',
                            Id: 72,
                            nameId: '65442A8B-E376-48BB-B041-DDCA3B1D068C',
                            frame: { width: 37, height: 50, x: 60, y: 1050.696 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '36',
                                color: '#FF2222',
                                lineHeight: '50',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥',
                            type: 'text'
                        },
                        {
                            name: '10',
                            Id: 73,
                            nameId: '521183A9-742B-4185-878A-E0CF63CC18BD',
                            frame: { width: 49, height: 50, x: 95.13599999999997, y: 1047 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '48',
                                color: '#FF2222',
                                lineHeight: '50',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '10',
                            type: 'text'
                        },
                        {
                            name: '￥2222',
                            Id: 74,
                            nameId: '26D721B5-263A-4BC6-A983-D59719C4DFEA',
                            frame: { width: 96, height: 40, x: 161, y: 1059 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#999999',
                                lineHeight: '40',
                                textAlign: 'left',
                                textDecoration: 'line-through',
                                fontWeight: 'normal'
                            },
                            value: '￥2222',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'F8922EFF-EE50-42EC-8F0E-7BD2C3889577'
                },
                {
                    name: '#毕业季#最最经典的iPhone 4便宜',
                    Id: 75,
                    nameId: 'E6BE512C-6AAB-400B-BD98-3406BDBEA719',
                    frame: { width: 630, height: 249, x: 60, y: 1119 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '36',
                        color: '#222222',
                        lineHeight: '54',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '#毕业季#最最经典的iPhone 4便宜卖啦我是学长我说了算，当年靠它找到了我第一个女朋友，里面还留着我们的聊天记录呢',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 77,
                    nameId: '6B5B722D-714E-4FF6-BB43-D1EF09762848',
                    frame: { width: 729, height: 529, x: 21, y: 1361 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 79,
                            nameId: '3DA4AC71-A8BF-40A4-A48B-5655966502F2',
                            frame: { width: 729, height: 529, x: 21, y: 1361 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 80,
                                    nameId: '9C68A3FC-9EB8-4333-B0EF-8DEA303FA6C2',
                                    frame: { width: 729, height: 529, x: 21, y: 1361 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1oRb3qbGYBuNjy0FoXXciBFXa-729-529.png'
                                }
                            ],
                            type: 'group',
                            objectID: '3DA4AC71-A8BF-40A4-A48B-5655966502F2'
                        }
                    ],
                    type: 'group',
                    objectID: '6B5B722D-714E-4FF6-BB43-D1EF09762848'
                },
                {
                    name: 'Group 2',
                    Id: 82,
                    nameId: '9515C69F-C997-4E06-A621-BE74C1864A44',
                    frame: { width: 202, height: 42, x: 488, y: 1922 },
                    layers: [
                        {
                            name: '查看宝贝原照',
                            Id: 83,
                            nameId: '889A945E-45F3-4F21-B833-61302DB72207',
                            frame: { width: 180, height: 42, x: 488, y: 1922 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '30',
                                color: '#228FFF',
                                lineHeight: '42',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '查看宝贝原照',
                            type: 'text'
                        },
                        {
                            name: 'Bitmap',
                            Id: 84,
                            nameId: 'FF3613CF-E0CC-4B9C-BFAA-D8029E320667',
                            frame: { width: 15, height: 25, x: 675, y: 1932 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1D8b3qbGYBuNjy0FoXXciBFXa-15-25.png'
                        }
                    ],
                    type: 'group',
                    objectID: '9515C69F-C997-4E06-A621-BE74C1864A44'
                }
            ],
            type: 'group',
            objectID: '1AD807DB-DC3A-4D7C-9CBD-CD98F8F335DC'
        },
        {
            name: 'Group 4',
            Id: 86,
            nameId: '65002163-A9FE-4661-BE00-CFE620818B68',
            frame: { width: 750, height: 120, x: 0, y: 2076 },
            layers: [
                {
                    name: 'Rectangle 3',
                    Id: 87,
                    nameId: '08139625-9AD0-42C7-B44A-174DA602CCC2',
                    frame: { width: 750, height: 120, x: 0, y: 2076 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Bitmap',
                    Id: 88,
                    nameId: '0780EDCD-3CC8-42BB-A39C-A39151057535',
                    frame: { width: 690, height: 80, x: 30, y: 2096 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1MRb3qbGYBuNjy0FoXXciBFXa-690-80.png'
                },
                {
                    name: '去邀请好友，最低0.01元购',
                    Id: 89,
                    nameId: 'C7D98783-5BA6-4535-B8EB-20A86C18CFBC',
                    frame: { width: 381, height: 45, x: 185, y: 2114 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '32',
                        color: '#FFFFFF',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '去邀请好友，最低0.01元购',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '65002163-A9FE-4661-BE00-CFE620818B68'
        },
        {
            name: 'Bitmap',
            Id: 90,
            nameId: '5A94605C-B0CD-45C5-B69D-42C304631783',
            frame: { width: 631, height: 32, x: 60, y: 690 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1OZU4qhGYBuNjy0FnXXX5lpXa-631-32.png'
        }
    ],
    nameId: 1525757291686,
    Id: 46,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 2196 },
    styles: { backgroundColor: 'rgba(0,158,112,1)' }
};
