"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Group',
            Id: 76,
            nameId: '44B1D253-456F-43FA-8678-614178B7C205',
            frame: { width: 750, height: 1211, x: 0, y: 0 },
            layers: [
                {
                    name: 'Rectangle 4',
                    Id: 77,
                    nameId: '23372915-E7EE-4ED7-82E1-5AA4242FA410',
                    frame: { width: 750, height: 1205, x: 0, y: 2 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Bitmap',
                    Id: 78,
                    nameId: 'EF9E18E3-8709-4FEA-95B3-DFDF721F3BA6',
                    frame: { width: 750, height: 1, x: 0, y: 0 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1FYWtr21TBuNjy0FjXXajyXXa-750-1.png'
                },
                {
                    name: 'Group 3',
                    Id: 80,
                    nameId: 'CC2E4CCB-0504-4A57-BCA0-7293252FDA90',
                    frame: { width: 159, height: 1206, x: 0, y: 5 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 81,
                            nameId: 'A0E52644-FF9D-44BD-AEF4-DBE862D4A03F',
                            frame: { width: 1, height: 1206, x: 158, y: 5 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1IiB2r7CWBuNjy0FaXXXUlXXa-1-1206.png'
                        },
                        {
                            name: '热门转卖',
                            Id: 82,
                            nameId: '981C1C09-0842-48FF-A7E1-B4068C3CBD5E',
                            frame: { width: 112, height: 40, x: 26, y: 39.599998474121094 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 28,
                                color: '#333333',
                                textAlign: 'center',
                                lineHeight: '39.20000076293945',
                                fontWeight: 'bold'
                            },
                            value: '热门转卖',
                            type: 'text'
                        },
                        {
                            name: '男士服装',
                            Id: 83,
                            nameId: '9806EF05-4B8B-4EFB-8946-2F43D6392576',
                            frame: { width: 112, height: 40, x: 26, y: 141.5999984741211 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#999999',
                                textAlign: 'center',
                                lineHeight: '39.20000076293945',
                                fontWeight: 'normal'
                            },
                            value: '男士服装',
                            type: 'text'
                        },
                        {
                            name: '家具/饰品',
                            Id: 84,
                            nameId: 'DB54DCCB-6FF7-462A-9AFB-6EEF70FACAB8',
                            frame: { width: 126, height: 40, x: 19.5, y: 246.5999984741211 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#999999',
                                textAlign: 'center',
                                lineHeight: '39.20000076293945',
                                fontWeight: 'normal'
                            },
                            value: '家具/饰品',
                            type: 'text'
                        },
                        {
                            name: '运动户外',
                            Id: 85,
                            nameId: '120E0985-1D81-4EDA-AAE4-163779DA294D',
                            frame: { width: 112, height: 40, x: 26, y: 349.5999984741211 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#999999',
                                textAlign: 'center',
                                lineHeight: '39.20000076293945',
                                fontWeight: 'normal'
                            },
                            value: '运动户外',
                            type: 'text'
                        },
                        {
                            name: '3C数码',
                            Id: 86,
                            nameId: 'F80CE815-1408-4485-97D2-439520A3235E',
                            frame: { width: 94, height: 40, x: 35, y: 455.5999984741211 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#999999',
                                textAlign: 'center',
                                lineHeight: '39.20000076293945',
                                fontWeight: 'normal'
                            },
                            value: '3C数码',
                            type: 'text'
                        },
                        {
                            name: '个人美妆',
                            Id: 87,
                            nameId: 'C5427F33-DC44-4AE4-9E67-9DAB88D409DE',
                            frame: { width: 112, height: 40, x: 26, y: 559.5999984741211 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#999999',
                                textAlign: 'center',
                                lineHeight: '39.20000076293945',
                                fontWeight: 'normal'
                            },
                            value: '个人美妆',
                            type: 'text'
                        },
                        {
                            name: '箱包',
                            Id: 88,
                            nameId: 'B3298D56-F30A-448F-BD70-4A5A32181DAA',
                            frame: { width: 56, height: 40, x: 54, y: 661.5999984741211 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#999999',
                                textAlign: 'center',
                                lineHeight: '39.20000076293945',
                                fontWeight: 'normal'
                            },
                            value: '箱包',
                            type: 'text'
                        },
                        {
                            name: 'Rectangle 7',
                            Id: 89,
                            nameId: '70CDB4BE-1DEF-4607-B65D-177516986D4E',
                            frame: { width: 8, height: 56, x: 0, y: 32 },
                            styles: { backgroundColor: 'rgba(255,218,68,1)', fillType: 'color' },
                            type: 'shape'
                        }
                    ],
                    type: 'group',
                    objectID: 'CC2E4CCB-0504-4A57-BCA0-7293252FDA90'
                },
                {
                    name: 'Group 4',
                    Id: 91,
                    nameId: 'F899140E-3D3B-431D-A56B-B56E3B7EF7AA',
                    frame: { width: 590, height: 212, x: 160, y: 77 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 92,
                            nameId: '7F84A609-A93E-4F5A-BF07-253D22641186',
                            frame: { width: 571, height: 2, x: 179, y: 287 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1lXlJr1SSBuNjy0FlXXbBpVXa-571-2.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 94,
                            nameId: 'FFA0B5D3-F4A2-44CA-B552-176C7E88AC0C',
                            frame: { width: 148, height: 148, x: 180, y: 109 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 96,
                                    nameId: 'D84BA867-B3E4-41BA-9015-FF7E300781E7',
                                    frame: { width: 148, height: 148, x: 180, y: 109 },
                                    layers: [
                                        {
                                            name: 'Bitmap',
                                            Id: 97,
                                            nameId: '0F9A4D50-4EE2-49B2-B6BF-178D2889506B',
                                            frame: { width: 148, height: 148, x: 180, y: 109 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1IHlar29TBuNjy0FcXXbeiFXa-148-148.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: 'D84BA867-B3E4-41BA-9015-FF7E300781E7'
                                }
                            ],
                            type: 'group',
                            objectID: 'FFA0B5D3-F4A2-44CA-B552-176C7E88AC0C'
                        },
                        {
                            name: '转手卖  ',
                            Id: 98,
                            nameId: 'D1FA149F-0996-4E2A-92A7-B80BE6EC2647',
                            frame: { width: 74, height: 28, x: 344, y: 214 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 20,
                                color: '#333333',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'bold'
                            },
                            value: '转手卖  ',
                            type: 'text'
                        },
                        {
                            name: '￥280.00',
                            Id: 99,
                            nameId: '63DD4BC0-CB22-4F67-9F4A-61716E658A45',
                            frame: { width: 103, height: 28, x: 417.0319999999999, y: 214 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#FF4444',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'bold'
                            },
                            value: '￥280.00',
                            type: 'text'
                        },
                        {
                            name: '聊一聊',
                            Id: 101,
                            nameId: 'AAEDE71A-BBA7-4849-8620-2EC8A687C291',
                            frame: { width: 132, height: 56, x: 598, y: 187 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 102,
                                    nameId: 'F32732D0-8309-45B8-8CAC-DBE6B123B572',
                                    frame: { width: 132, height: 56, x: 598, y: 187 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB15phBrVOWBuNjy0FiXXXFxVXa-132-56.png'
                                },
                                {
                                    name: '卖了换钱',
                                    Id: 103,
                                    nameId: 'A9416853-977A-41F0-9969-AF87682BA97B',
                                    frame: { width: 96.00000000000023, height: 33, x: 616.2941176470588, y: 198 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: 24,
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '33',
                                        fontWeight: 'bold'
                                    },
                                    value: '卖了换钱',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'AAEDE71A-BBA7-4849-8620-2EC8A687C291'
                        },
                        {
                            name: '入手价  ',
                            Id: 104,
                            nameId: '974F3617-4E59-4ED6-8C5E-CB552B6D34BF',
                            frame: { width: 74, height: 28, x: 344, y: 180 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 20,
                                color: '#999999',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '入手价  ',
                            type: 'text'
                        },
                        {
                            name: '￥500.00',
                            Id: 105,
                            nameId: 'C20717C2-5207-403E-9270-2E5B5A520105',
                            frame: { width: 103, height: 28, x: 417.0319999999999, y: 180 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#999999',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '￥500.00',
                            type: 'text'
                        },
                        {
                            name: '全球首款触控Wifi音箱实木打造温...',
                            Id: 106,
                            nameId: '47F1C69D-7E23-4FF4-9500-6A82D1E412BE',
                            frame: { width: 375, height: 33, x: 344, y: 119 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#333333',
                                lineHeight: '33',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '全球首款触控Wifi音箱实木打造温...',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'F899140E-3D3B-431D-A56B-B56E3B7EF7AA'
                },
                {
                    name: 'Group 4',
                    Id: 108,
                    nameId: 'C541D335-4093-41B8-845A-C1F4AD5F5651',
                    frame: { width: 590, height: 212, x: 160, y: 289 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 109,
                            nameId: '70234903-0864-41B3-9652-22E29DD6E6C5',
                            frame: { width: 571, height: 2, x: 179, y: 499 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1eiF2r7CWBuNjy0FaXXXUlXXa-571-2.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 111,
                            nameId: '03FF250C-E0B9-4912-B519-27263F62456E',
                            frame: { width: 148, height: 148, x: 180, y: 321 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 113,
                                    nameId: '30406EAE-5857-479D-B10E-6D88D296D506',
                                    frame: { width: 148, height: 148, x: 180, y: 321 },
                                    layers: [
                                        {
                                            name: 'Bitmap',
                                            Id: 114,
                                            nameId: '72B9A029-1E42-431C-AAD8-8BF8BC6BB9C8',
                                            frame: { width: 148, height: 148, x: 180, y: 321 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1gFlBrVOWBuNjy0FiXXXFxVXa-148-148.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '30406EAE-5857-479D-B10E-6D88D296D506'
                                }
                            ],
                            type: 'group',
                            objectID: '03FF250C-E0B9-4912-B519-27263F62456E'
                        },
                        {
                            name: '转手卖  ',
                            Id: 115,
                            nameId: '5F862302-97D4-4D25-85D2-049892570A26',
                            frame: { width: 74, height: 28, x: 344, y: 426 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 20,
                                color: '#333333',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'bold'
                            },
                            value: '转手卖  ',
                            type: 'text'
                        },
                        {
                            name: '￥280.00',
                            Id: 116,
                            nameId: 'CA9D0239-8660-48F7-8D5F-BF563F5DC414',
                            frame: { width: 103, height: 28, x: 417.0319999999999, y: 426 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#FF4444',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'bold'
                            },
                            value: '￥280.00',
                            type: 'text'
                        },
                        {
                            name: '聊一聊',
                            Id: 118,
                            nameId: 'A6AFB555-1993-412E-9643-A04BAE2CA426',
                            frame: { width: 132, height: 56, x: 598, y: 399 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 119,
                                    nameId: 'BC3AA074-D76C-4229-8DD4-C083E3D1D1E5',
                                    frame: { width: 132, height: 56, x: 598, y: 399 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB17GFcrYSYBuNjSspiXXXNzpXa-132-56.png'
                                },
                                {
                                    name: '卖了换钱',
                                    Id: 120,
                                    nameId: '92B8D4A0-5AEA-46A6-85B6-D914EF1AAEEB',
                                    frame: { width: 96.00000000000023, height: 33, x: 616.2941176470588, y: 410 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: 24,
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '33',
                                        fontWeight: 'bold'
                                    },
                                    value: '卖了换钱',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'A6AFB555-1993-412E-9643-A04BAE2CA426'
                        },
                        {
                            name: '入手价  ',
                            Id: 121,
                            nameId: 'EFE793D8-20CB-4A46-9B55-97866907FCB3',
                            frame: { width: 74, height: 28, x: 344, y: 392 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 20,
                                color: '#999999',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '入手价  ',
                            type: 'text'
                        },
                        {
                            name: '￥500.00',
                            Id: 122,
                            nameId: '3A7831BA-27E7-4203-94AB-4DD1CC741798',
                            frame: { width: 103, height: 28, x: 417.0319999999999, y: 392 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#999999',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '￥500.00',
                            type: 'text'
                        },
                        {
                            name: '全球首款触控Wifi音箱实木打造温...',
                            Id: 123,
                            nameId: '8F21F86A-FF30-42CD-AFCF-EB537F0E91B9',
                            frame: { width: 375, height: 33, x: 344, y: 331 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#333333',
                                lineHeight: '33',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '全球首款触控Wifi音箱实木打造温...',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'C541D335-4093-41B8-845A-C1F4AD5F5651'
                },
                {
                    name: 'Group 4',
                    Id: 125,
                    nameId: '495F2C55-D37B-4E95-9730-C3800B5B25C1',
                    frame: { width: 571, height: 180, x: 179, y: 815 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 126,
                            nameId: 'ACF7200E-C09C-486B-8D19-871544F2CB76',
                            frame: { width: 571, height: 2, x: 179, y: 993 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1PY1tr21TBuNjy0FjXXajyXXa-571-2.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 128,
                            nameId: 'AAB62C1A-727C-49A2-811F-49EE5B7063B7',
                            frame: { width: 148, height: 148, x: 180, y: 815 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 130,
                                    nameId: '10E8C32F-47D8-4FD4-B9AF-B04F4B3F5B9F',
                                    frame: { width: 148, height: 148, x: 180, y: 815 },
                                    layers: [
                                        {
                                            name: 'Bitmap',
                                            Id: 131,
                                            nameId: '2B1426C8-75DC-4946-A9B9-8F73F7DD8D87',
                                            frame: { width: 148, height: 148, x: 180, y: 815 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1HDxlrVGWBuNjy0FbXXb4sXXa-148-148.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '10E8C32F-47D8-4FD4-B9AF-B04F4B3F5B9F'
                                }
                            ],
                            type: 'group',
                            objectID: 'AAB62C1A-727C-49A2-811F-49EE5B7063B7'
                        },
                        {
                            name: '转手卖  ',
                            Id: 132,
                            nameId: '0774873F-592B-4BE0-B6AA-5D93E9CD7481',
                            frame: { width: 74, height: 28, x: 344, y: 920 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 20,
                                color: '#333333',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'bold'
                            },
                            value: '转手卖  ',
                            type: 'text'
                        },
                        {
                            name: '￥280.00',
                            Id: 133,
                            nameId: 'B19332F2-79AB-4CB0-A5D2-B301F19114A1',
                            frame: { width: 103, height: 28, x: 417.0319999999999, y: 920 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#FF4444',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'bold'
                            },
                            value: '￥280.00',
                            type: 'text'
                        },
                        {
                            name: '聊一聊',
                            Id: 135,
                            nameId: 'F6B33B73-FE58-4F97-B360-1F0FCE18604B',
                            frame: { width: 132, height: 56, x: 598, y: 893 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 136,
                                    nameId: 'C72D53AB-D662-4D3D-A497-D664EB5098C2',
                                    frame: { width: 132, height: 56, x: 598, y: 893 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1raJcrYSYBuNjSspiXXXNzpXa-132-56.png'
                                },
                                {
                                    name: '卖了换钱',
                                    Id: 137,
                                    nameId: '6ED89763-48BB-46B3-8B98-4B4D2292684B',
                                    frame: { width: 96.00000000000023, height: 33, x: 616.2941176470588, y: 904 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: 24,
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '33',
                                        fontWeight: 'bold'
                                    },
                                    value: '卖了换钱',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'F6B33B73-FE58-4F97-B360-1F0FCE18604B'
                        },
                        {
                            name: '入手价  ',
                            Id: 138,
                            nameId: '4670724B-D5F2-40F6-B1AA-FA830865BD8F',
                            frame: { width: 74, height: 28, x: 344, y: 886 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 20,
                                color: '#999999',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '入手价  ',
                            type: 'text'
                        },
                        {
                            name: '￥500.00',
                            Id: 139,
                            nameId: '51828324-B4E9-48EF-99D7-18C925D215DC',
                            frame: { width: 103, height: 28, x: 417.0319999999999, y: 886 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#999999',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '￥500.00',
                            type: 'text'
                        },
                        {
                            name: '全球首款触控Wifi音箱实木打造温...',
                            Id: 140,
                            nameId: 'B6888568-9573-4DEE-8849-77A33669AC1E',
                            frame: { width: 375, height: 33, x: 344, y: 825 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#333333',
                                lineHeight: '33',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '全球首款触控Wifi音箱实木打造温...',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '495F2C55-D37B-4E95-9730-C3800B5B25C1'
                },
                {
                    name: 'Group 4',
                    Id: 142,
                    nameId: '01469FB4-BB23-4992-819A-4FB73404FA5D',
                    frame: { width: 590, height: 212, x: 160, y: 995 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 144,
                            nameId: '19F1EC5D-3636-400A-A9D4-5A81239E55C4',
                            frame: { width: 148, height: 148, x: 180, y: 1027 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 146,
                                    nameId: '5BC0E866-6DE1-42FA-8D7F-9E2A81C41A8D',
                                    frame: { width: 148, height: 148, x: 180, y: 1027 },
                                    layers: [
                                        {
                                            name: 'Bitmap',
                                            Id: 147,
                                            nameId: 'D106E8F4-2DEE-44E9-9D7D-9882FF0B999D',
                                            frame: { width: 148, height: 148, x: 180, y: 1027 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1swd4rY9YBuNjy0FgXXcxcXXa-148-148.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '5BC0E866-6DE1-42FA-8D7F-9E2A81C41A8D'
                                }
                            ],
                            type: 'group',
                            objectID: '19F1EC5D-3636-400A-A9D4-5A81239E55C4'
                        },
                        {
                            name: '转手卖  ',
                            Id: 148,
                            nameId: '34DDB9D7-B7A1-43BC-AB68-78F102A99303',
                            frame: { width: 74, height: 28, x: 344, y: 1132 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 20,
                                color: '#333333',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'bold'
                            },
                            value: '转手卖  ',
                            type: 'text'
                        },
                        {
                            name: '￥280.00',
                            Id: 149,
                            nameId: '90390950-4DB7-4899-AFA4-9A777C90BEE7',
                            frame: { width: 103, height: 28, x: 417.0319999999999, y: 1132 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#FF4444',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'bold'
                            },
                            value: '￥280.00',
                            type: 'text'
                        },
                        {
                            name: '聊一聊',
                            Id: 151,
                            nameId: 'D482184D-EDFC-4758-9687-3475BD40113B',
                            frame: { width: 132, height: 56, x: 598, y: 1105 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 152,
                                    nameId: 'B4B5E5A0-05DE-40C3-85B3-A84FBD37142D',
                                    frame: { width: 132, height: 56, x: 598, y: 1105 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1zwd4rY9YBuNjy0FgXXcxcXXa-132-56.png'
                                },
                                {
                                    name: '卖了换钱',
                                    Id: 153,
                                    nameId: '77677F01-7B5B-4047-B416-296EE9AB4CDF',
                                    frame: { width: 96.00000000000023, height: 33, x: 616.2941176470588, y: 1116 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: 24,
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '33',
                                        fontWeight: 'bold'
                                    },
                                    value: '卖了换钱',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'D482184D-EDFC-4758-9687-3475BD40113B'
                        },
                        {
                            name: '入手价  ',
                            Id: 154,
                            nameId: 'FB7B3A59-D4C2-4F10-BBB9-06BF4189DEE9',
                            frame: { width: 74, height: 28, x: 344, y: 1098 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 20,
                                color: '#999999',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '入手价  ',
                            type: 'text'
                        },
                        {
                            name: '￥500.00',
                            Id: 155,
                            nameId: '8C4370B1-B537-4263-AE80-FF6A00DA3E95',
                            frame: { width: 103, height: 28, x: 417.0319999999999, y: 1098 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#999999',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '￥500.00',
                            type: 'text'
                        },
                        {
                            name: '全球首款触控Wifi音箱实木打造温...',
                            Id: 156,
                            nameId: '0F89EB3A-AB82-483F-8EF2-DDE7D90C6F89',
                            frame: { width: 375, height: 33, x: 344, y: 1037 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#333333',
                                lineHeight: '33',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '全球首款触控Wifi音箱实木打造温...',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '01469FB4-BB23-4992-819A-4FB73404FA5D'
                },
                {
                    name: 'Group 4',
                    Id: 158,
                    nameId: '849086F6-DB15-4990-97A0-7B75E30FE5BF',
                    frame: { width: 590, height: 212, x: 160, y: 501 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 159,
                            nameId: '9E0754AF-E930-40E9-8BE5-E6B6514E5E42',
                            frame: { width: 571, height: 2, x: 179, y: 711 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1Fhx9r4SYBuNjSspjXXX73VXa-571-2.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 161,
                            nameId: '2C1409B8-83B6-47A1-84BA-9904F96F0545',
                            frame: { width: 148, height: 148, x: 180, y: 533 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 163,
                                    nameId: '5A1FF80C-A7A6-43BB-B903-045EFA5F4A2B',
                                    frame: { width: 148, height: 148, x: 180, y: 533 },
                                    layers: [
                                        {
                                            name: 'Bitmap',
                                            Id: 164,
                                            nameId: 'CCE72C83-195E-4F5B-B797-873F097D7C78',
                                            frame: { width: 148, height: 148, x: 180, y: 533 },
                                            imageStyles: { resize: 'stretch' },
                                            type: 'image',
                                            value: 'https://gw.alicdn.com/tfs/TB1tXpBrVOWBuNjy0FiXXXFxVXa-148-148.png'
                                        }
                                    ],
                                    type: 'group',
                                    objectID: '5A1FF80C-A7A6-43BB-B903-045EFA5F4A2B'
                                }
                            ],
                            type: 'group',
                            objectID: '2C1409B8-83B6-47A1-84BA-9904F96F0545'
                        },
                        {
                            name: '转手卖  ',
                            Id: 165,
                            nameId: '64A4B644-2420-4151-B368-BFB8BA2D4BDE',
                            frame: { width: 74, height: 28, x: 344, y: 638 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 20,
                                color: '#333333',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'bold'
                            },
                            value: '转手卖  ',
                            type: 'text'
                        },
                        {
                            name: '￥280.00',
                            Id: 166,
                            nameId: '0794988A-C3A4-49A0-A7E3-50A25595B721',
                            frame: { width: 103, height: 28, x: 417.0319999999999, y: 638 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 24,
                                color: '#FF4444',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'bold'
                            },
                            value: '￥280.00',
                            type: 'text'
                        },
                        {
                            name: '聊一聊',
                            Id: 168,
                            nameId: '82F1641A-D441-4BF1-95CD-9BE4062568F7',
                            frame: { width: 132, height: 56, x: 598, y: 611 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 169,
                                    nameId: '6B473A3A-6ADE-494B-AAF3-9ACA066DF922',
                                    frame: { width: 132, height: 56, x: 598, y: 611 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1KiJ2r7CWBuNjy0FaXXXUlXXa-132-56.png'
                                },
                                {
                                    name: '卖了换钱',
                                    Id: 170,
                                    nameId: '5264BFAD-91E3-4264-9C1B-E205FE455B08',
                                    frame: { width: 96.00000000000023, height: 33, x: 616.2941176470588, y: 622 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Medium',
                                        fontSize: 24,
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '33',
                                        fontWeight: 'bold'
                                    },
                                    value: '卖了换钱',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: '82F1641A-D441-4BF1-95CD-9BE4062568F7'
                        },
                        {
                            name: '入手价  ',
                            Id: 171,
                            nameId: 'EAF65F6D-D3C1-4BAC-A969-FD1CDC9CE6AD',
                            frame: { width: 74, height: 28, x: 344, y: 604 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 20,
                                color: '#999999',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '入手价  ',
                            type: 'text'
                        },
                        {
                            name: '￥500.00',
                            Id: 172,
                            nameId: 'F9865FE5-0A1A-46A6-9661-0AA702841648',
                            frame: { width: 103, height: 28, x: 417.0319999999999, y: 604 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#999999',
                                textAlign: 'left',
                                lineHeight: '28',
                                fontWeight: 'normal'
                            },
                            value: '￥500.00',
                            type: 'text'
                        },
                        {
                            name: '全球首款触控Wifi音箱实木打造温...',
                            Id: 173,
                            nameId: 'DA0AB419-B554-455C-AAE5-AB4E19DAC2FC',
                            frame: { width: 375, height: 33, x: 344, y: 543 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 24,
                                color: '#333333',
                                lineHeight: '33',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '全球首款触控Wifi音箱实木打造温...',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '849086F6-DB15-4990-97A0-7B75E30FE5BF'
                },
                {
                    name: '男士服装（12）',
                    Id: 174,
                    nameId: 'CFF48016-907C-468F-B8D7-B64EEDB229A8',
                    frame: { width: 169, height: 40, x: 180, y: 743 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#888888',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '男士服装（12）',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '44B1D253-456F-43FA-8678-614178B7C205'
        },
        {
            name: 'IMG_2704',
            Id: 175,
            nameId: 'BC80883F-48FE-431E-9EDE-404E36F90625',
            frame: { width: 750, height: 1240, x: 0, y: 1210 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1Qeurr49YBuNjy0FfXXXIsVXa-750-1240.png'
        }
    ],
    nameId: 1526536500677,
    Id: 74,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 2450 },
    styles: { backgroundColor: 'rgba(243,245,249,1)' }
};
