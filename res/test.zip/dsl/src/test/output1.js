"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    type: 'GROUP',
    raw: { nameId: 1523617068649, Id: 7, type: 'group' },
    frame: { x: 0, y: 0, width: 228, height: 82 },
    measured: { x: 0, y: 0, width: 228, height: 82 },
    measuredTypes: ['BY_CONFLICT', 'BY_CONFLICT'],
    layout: { flexDirection: 'column', justifyContent: 'flex-end', alignItems: 'center', position: 'relative', width: 228, height: 82 },
    children: [
        {
            name: 'Background',
            type: 'SHAPE',
            raw: { name: 'Background', Id: 8, nameId: '503BB162-5A74-46C0-84BE-DB4DB57460A3', type: 'shape' },
            frame: { width: 228, height: 81.68644067796595, x: 0, y: 0.3135593220338251 },
            measured: { width: 228, height: 81.68644067796595, x: 0, y: 0.3135593220338251 },
            measuredTypes: ['BY_PRIMITIVE', 'BY_PRIMITIVE'],
            layout: { position: 'relative', width: 228, height: 81.68644067796595, margin: [null, 0, 2.2737367544323206e-13, null] },
            styles: { backgroundColor: 'rgba(99,99,99,1)', fillType: 'color', opacity: 1 }
        },
        {
            name: '@AutoGroup',
            id: '@AutoGroupId',
            type: 'GROUP',
            raw: { name: '@AutoGroup', id: '@AutoGroupId', type: 'group' },
            frame: { width: 170, height: 40, x: 30, y: 21 },
            measured: { width: 228, height: 82, x: 0, y: 0 },
            measuredTypes: [],
            layout: {
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'flex-end',
                padding: [21, null, 21, 30],
                position: 'absolute',
                left: 0,
                right: 0,
                top: 0,
                bottom: 0
            },
            children: [
                {
                    name: '精品套装专区',
                    type: 'TEXT',
                    raw: { name: '精品套装专区', Id: 9, nameId: '60862899-F85B-47FC-8328-F42A8A14BAD0', value: '精品套装专区', type: 'text' },
                    frame: { width: 170, height: 40, x: 30, y: 21 },
                    measured: { width: 170, height: 40, x: 30, y: 21 },
                    measuredTypes: ['BY_DEFAULT', 'BY_DEFAULT'],
                    layout: { position: 'relative', margin: [null, 28, null, null] },
                    value: '精品套装专区',
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '28',
                        color: '#FFFFFF',
                        letterSpacing: '0.27',
                        lineHeight: '40',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    }
                }
            ]
        }
    ]
};
