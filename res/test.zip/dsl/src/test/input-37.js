"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: '头像',
            Id: 3,
            nameId: '90E6722B-FBFD-4AB9-8F84-40A3F582FA76',
            frame: { width: 142, height: 171, x: 20, y: 148 },
            layers: [
                {
                    name: 'hui12…',
                    Id: 4,
                    nameId: 'BCDBCEBF-29F4-42E1-AF4F-A6ADB79BBFC1',
                    frame: { width: 88, height: 37, x: 47, y: 271 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                    },
                    value: 'hui12…',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '90E6722B-FBFD-4AB9-8F84-40A3F582FA76'
        },
        {
            name: '头像 copy',
            Id: 6,
            nameId: '8AF8B773-3D44-41A7-9771-5DF6F70E4745',
            frame: { width: 142, height: 171, x: 162, y: 148 },
            layers: [
                {
                    name: '王琴',
                    Id: 7,
                    nameId: '11A9B507-6319-43D2-B8AA-AF638806FA92',
                    frame: { width: 53, height: 37, x: 206.5, y: 271 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                    },
                    value: '王琴',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '8AF8B773-3D44-41A7-9771-5DF6F70E4745'
        },
        {
            name: '头像 copy 2',
            Id: 9,
            nameId: 'BF9F7463-860D-44B0-B32C-78A017E4B2A1',
            frame: { width: 142, height: 171, x: 304, y: 148 },
            layers: [
                {
                    name: 'tb24…',
                    Id: 10,
                    nameId: 'D001F8E4-83BD-4FBB-8FC3-572BEBC931ED',
                    frame: { width: 82, height: 37, x: 334, y: 271 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                    },
                    value: 'tb24…',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: 'BF9F7463-860D-44B0-B32C-78A017E4B2A1'
        },
        {
            name: 'Bitmap',
            Id: 11,
            nameId: '812D4923-D1F0-4BA8-BBE9-294BD328B240',
            frame: { width: 98, height: 98, x: 42, y: 169 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1uZO_u_tYBeNjy1XdXXXXyVXa-98-98.png'
        },
        {
            name: 'Bitmap',
            Id: 12,
            nameId: 'FF2F2E16-BF79-4A53-9560-E049F561428C',
            frame: { width: 98, height: 98, x: 184, y: 169 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1I37dmyOYBuNjSsD4XXbSkFXa-98-98.png'
        },
        {
            name: 'Bitmap',
            Id: 13,
            nameId: 'ECD21496-856D-46D6-926D-FEC16E54FE8E',
            frame: { width: 98, height: 98, x: 326, y: 169 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1RIO_u_tYBeNjy1XdXXXXyVXa-98-98.png'
        },
        {
            name: 'Group',
            Id: 15,
            nameId: '04D0DCD1-DAFB-4954-B41E-60514DCC0497',
            frame: { width: 750, height: 251, x: 0, y: 700 },
            layers: [
                {
                    name: 'list copy',
                    Id: 17,
                    nameId: '03EE08B5-C78B-42BA-B009-307CD4E366ED',
                    frame: { width: 750, height: 251, x: 0, y: 700 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 18,
                            nameId: 'B66D94E7-2524-4ADA-AA65-D74EB66D488F',
                            frame: { width: 720, height: 1, x: 30, y: 950 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1NAEkmDXYBeNkHFrdXXciuVXa-720-1.png'
                        },
                        {
                            name: '塘规',
                            Id: 19,
                            nameId: 'E7A96FC9-D340-422F-9D25-BBB1CF9A4E8F',
                            frame: { width: 64, height: 45, x: 30, y: 732 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 32,
                                color: '#222222',
                                lineHeight: '45',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '塘规',
                            type: 'text'
                        },
                        {
                            name: '这里是西溪悦居业主图书交换群，仅限西溪悦',
                            Id: 20,
                            nameId: '30996721-4706-4A9B-B717-B4A887AB3509',
                            frame: { width: 672, height: 120, x: 29, y: 794 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#888888',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '这里是西溪悦居业主图书交换群，仅限西溪悦居业主加\n入哦~请修改群名片：楼号-房号-姓名。入群请至少分\n享3本书，题材不限！',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '03EE08B5-C78B-42BA-B009-307CD4E366ED'
                },
                {
                    name: 'List_Arrow',
                    Id: 22,
                    nameId: '608E9273-76A1-4722-BEEA-5AE243905BD4',
                    frame: { width: 32, height: 32, x: 696, y: 738 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 23,
                            nameId: '7DDF4523-D1DF-4B3B-891E-0FD3328E1F4A',
                            frame: { width: 14, height: 25, x: 706, y: 742 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1b8lsu1uSBuNjy1XcXXcYjFXa-14-25.png'
                        }
                    ],
                    type: 'group',
                    objectID: '608E9273-76A1-4722-BEEA-5AE243905BD4'
                }
            ],
            type: 'group',
            objectID: '04D0DCD1-DAFB-4954-B41E-60514DCC0497'
        },
        {
            name: 'list copy',
            Id: 25,
            nameId: 'C74FCA98-B48B-4492-97F5-8F61C3C7E67B',
            frame: { width: 750, height: 276, x: 0, y: 951 },
            layers: [
                {
                    name: 'list copy 4',
                    Id: 27,
                    nameId: 'B4511B51-E712-40C6-BC0E-2F31840997AB',
                    frame: { width: 750, height: 96, x: 0, y: 1120 },
                    layers: [
                        {
                            name: '所有人都能加入',
                            Id: 28,
                            nameId: '9BA436F3-88DD-4B65-9E7A-F83572F70FEE',
                            frame: { width: 196, height: 48, x: 487, y: 1144 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#888888',
                                textAlign: 'right',
                                lineHeight: '48',
                                fontWeight: 'normal'
                            },
                            value: '所有人都能加入',
                            type: 'text'
                        },
                        {
                            name: 'List_Arrow',
                            Id: 30,
                            nameId: '6A15484E-3132-47BF-AC52-FFDE617EC81B',
                            frame: { width: 32, height: 32, x: 688, y: 1152 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 31,
                                    nameId: '631FA8B5-1FCF-4F70-BD9C-421D490C4586',
                                    frame: { width: 14, height: 25, x: 698, y: 1156 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB16QEkmDXYBeNkHFrdXXciuVXa-14-25.png'
                                }
                            ],
                            type: 'group',
                            objectID: '6A15484E-3132-47BF-AC52-FFDE617EC81B'
                        },
                        {
                            name: '设置谁能加入鱼塘',
                            Id: 32,
                            nameId: '9F9C245A-FFB5-4F81-A062-7B3DAFC9FC30',
                            frame: { width: 256, height: 45, x: 30, y: 1146 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 32,
                                color: '#222222',
                                lineHeight: '45',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '设置谁能加入鱼塘',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'B4511B51-E712-40C6-BC0E-2F31840997AB'
                },
                {
                    name: 'Rectangle 8 Copy 22',
                    Id: 33,
                    nameId: '210F80E0-B40B-451D-B841-58E6D829FF2D',
                    frame: { width: 750, height: 12, x: 0, y: 1215 },
                    styles: { backgroundColor: 'rgba(243,245,249,1)' },
                    type: 'shape'
                },
                {
                    name: '鱼塘标签',
                    Id: 34,
                    nameId: '63F0E116-2CB7-4D0E-9D89-4EB2A424630F',
                    frame: { width: 128, height: 45, x: 30, y: 977 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 32,
                        color: '#222222',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '鱼塘标签',
                    type: 'text'
                },
                {
                    name: 'Group 3',
                    Id: 36,
                    nameId: 'A7F88FC7-DC4B-4A42-8F48-BDC33F454D7B',
                    frame: { width: 101, height: 40, x: 32, y: 1039 },
                    layers: [
                        {
                            name: '#童话书',
                            Id: 37,
                            nameId: '7F18CBEE-FAC6-48B8-9190-03D7D437C01C',
                            frame: { width: 101, height: 40, x: 32, y: 1039 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#888888',
                                textAlign: 'left',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '#童话书',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'A7F88FC7-DC4B-4A42-8F48-BDC33F454D7B'
                },
                {
                    name: 'Group 3 Copy',
                    Id: 39,
                    nameId: '875C8373-C9C6-46F9-90A5-CB594B4BCF5B',
                    frame: { width: 73, height: 40, x: 166, y: 1039 },
                    layers: [
                        {
                            name: '#幼儿',
                            Id: 40,
                            nameId: '18D9FE98-E46C-4DFD-BC2A-1FAF33EA1878',
                            frame: { width: 73, height: 40, x: 166, y: 1039 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#888888',
                                textAlign: 'left',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '#幼儿',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '875C8373-C9C6-46F9-90A5-CB594B4BCF5B'
                },
                {
                    name: 'Group 3 Copy 3',
                    Id: 42,
                    nameId: '52DC9FA8-B1EE-48B6-9D9B-13AA3713A3C0',
                    frame: { width: 73, height: 40, x: 270, y: 1039 },
                    layers: [
                        {
                            name: '#小区',
                            Id: 43,
                            nameId: 'BCE2D5CB-485F-476A-AF1D-500A91884B04',
                            frame: { width: 73, height: 40, x: 270, y: 1039 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 28,
                                color: '#888888',
                                textAlign: 'left',
                                lineHeight: '40',
                                fontWeight: 'normal'
                            },
                            value: '#小区',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '52DC9FA8-B1EE-48B6-9D9B-13AA3713A3C0'
                }
            ],
            type: 'group',
            objectID: 'C74FCA98-B48B-4492-97F5-8F61C3C7E67B'
        },
        {
            name: 'List_Arrow',
            Id: 45,
            nameId: '25587189-531E-40C3-82F4-2F144055117E',
            frame: { width: 32, height: 32, x: 696, y: 982 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 46,
                    nameId: '546C5802-6C80-450D-A4EE-5B249A3641FB',
                    frame: { width: 14, height: 25, x: 706, y: 986 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1vllsu1uSBuNjy1XcXXcYjFXa-14-25.png'
                }
            ],
            type: 'group',
            objectID: '25587189-531E-40C3-82F4-2F144055117E'
        },
        {
            name: 'list copy 3',
            Id: 48,
            nameId: 'B8464C88-234E-49DF-B116-97FA5893E266',
            frame: { width: 750, height: 96, x: 0, y: 1225 },
            layers: [
                {
                    name: 'Rectangle 68',
                    Id: 49,
                    nameId: 'B30D9660-8B58-4FE1-B092-3709623060E4',
                    frame: { width: 750, height: 88, x: 0, y: 1225 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)' },
                    type: 'shape'
                },
                {
                    name: 'Group 13',
                    Id: 51,
                    nameId: 'D9856817-62E1-41AE-B3E7-76530902093B',
                    frame: { width: 36, height: 37, x: 644, y: 1255 },
                    layers: [
                        {
                            name: 'Group 11',
                            Id: 53,
                            nameId: '451AF52C-40A8-4424-886F-0772B8795BD6',
                            frame: { width: 16, height: 36, x: 644, y: 1255 },
                            layers: [
                                {
                                    name: 'Rectangle 3',
                                    Id: 54,
                                    nameId: '29B82482-5091-4A3C-A5CE-B65EF87E0562',
                                    frame: { width: 15.304347826086996, height: 15.652173913043498, x: 644, y: 1255 },
                                    styles: { borderColor: 'rgba(136,136,136,1)', borderStyle: 'solid', borderWidth: 2, borderRadius: 2 },
                                    type: 'shape'
                                },
                                {
                                    name: 'Rectangle 3',
                                    Id: 55,
                                    nameId: '80D875A0-D72B-4E3F-81D0-B4F10621918D',
                                    frame: { width: 15.304347826086996, height: 15.652173913043498, x: 644, y: 1275.3478260869565 },
                                    styles: { borderColor: 'rgba(136,136,136,1)', borderStyle: 'solid', borderWidth: 2, borderRadius: 2 },
                                    type: 'shape'
                                }
                            ],
                            type: 'group',
                            objectID: '451AF52C-40A8-4424-886F-0772B8795BD6'
                        },
                        {
                            name: 'Rectangle 3',
                            Id: 56,
                            nameId: '37B80D6E-5257-4236-AB6A-9599A8DFD9E0',
                            frame: { width: 15.304347826086996, height: 15.652173913043498, x: 663.8956521739128, y: 1255 },
                            styles: { borderColor: 'rgba(136,136,136,1)', borderStyle: 'solid', borderWidth: 2, borderRadius: 2 },
                            type: 'shape'
                        },
                        {
                            name: 'Bitmap',
                            Id: 57,
                            nameId: '189F2B46-E051-451B-A9C8-B436DFBBF95B',
                            frame: { width: 3, height: 17, x: 677, y: 1275 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1pkIkmDXYBeNkHFrdXXciuVXa-3-17.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 58,
                            nameId: '45ABBE3F-1268-4E2A-B62B-155510847FA1',
                            frame: { width: 3, height: 17, x: 663, y: 1275 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1QBlsu1uSBuNjy1XcXXcYjFXa-3-17.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 59,
                            nameId: '17C0D547-EF0E-4621-AF04-2EB3655E1E38',
                            frame: { width: 3, height: 8, x: 670, y: 1275 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1KHf9mvuSBuNkHFqDXXXfhVXa-3-8.png'
                        },
                        {
                            name: 'Bitmap',
                            Id: 60,
                            nameId: '785B44DC-BD92-43FF-8D4B-CCEB9CA2FDBD',
                            frame: { width: 3, height: 8, x: 670, y: 1284 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1wyMguMmTBuNjy1XbXXaMrVXa-3-8.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'D9856817-62E1-41AE-B3E7-76530902093B'
                },
                {
                    name: 'List_Arrow',
                    Id: 62,
                    nameId: '08B8513F-6F61-4E17-AEAB-8514127D5190',
                    frame: { width: 32, height: 32, x: 688, y: 1257 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 63,
                            nameId: '87E4EC95-EA9A-4510-96A9-3A7EF9A002A8',
                            frame: { width: 14, height: 25, x: 698, y: 1261 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB11Hf9mvuSBuNkHFqDXXXfhVXa-14-25.png'
                        }
                    ],
                    type: 'group',
                    objectID: '08B8513F-6F61-4E17-AEAB-8514127D5190'
                },
                {
                    name: '鱼塘二维码',
                    Id: 64,
                    nameId: '1192CBBD-3077-462A-BBB4-0FBF7E4B65A3',
                    frame: { width: 160, height: 45, x: 30, y: 1251 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 32,
                        color: '#222222',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '鱼塘二维码',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: 'B8464C88-234E-49DF-B116-97FA5893E266'
        },
        {
            name: 'Rectangle 8 Copy 17',
            Id: 65,
            nameId: 'F07EE912-BE35-432E-9196-3962CDD4F8C4',
            frame: { width: 750, height: 10, x: 0, y: 1320 },
            styles: { backgroundColor: 'rgba(243,245,249,1)' },
            type: 'shape'
        },
        {
            name: 'Rectangle 8 Copy 20',
            Id: 66,
            nameId: '52B1B7EE-2167-4EEF-A1A5-6B0FDDEE5F1E',
            frame: { width: 750, height: 10, x: 0, y: 1107 },
            styles: { backgroundColor: 'rgba(243,245,249,1)' },
            type: 'shape'
        },
        {
            name: 'list copy',
            Id: 68,
            nameId: 'A29BF55F-0327-4AC2-ADE2-BCA413AA7629',
            frame: { width: 750, height: 96, x: 0, y: 1332 },
            layers: [
                {
                    name: '消息免打扰',
                    Id: 69,
                    nameId: '286B66AD-2C94-423D-B849-8A6123CA89A6',
                    frame: { width: 160, height: 45, x: 30, y: 1358 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 32,
                        color: '#222222',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '消息免打扰',
                    type: 'text'
                },
                {
                    name: 'Group 2',
                    Id: 71,
                    nameId: '44C98B24-5658-4B3E-992A-628FEA426567',
                    frame: { width: 98, height: 48, x: 622, y: 1357 },
                    layers: [
                        {
                            name: 'Rectangle 17',
                            Id: 72,
                            nameId: '7476F32F-169D-4AA3-9BC6-42216FDE0F88',
                            frame: { width: 98, height: 48, x: 622, y: 1357 },
                            styles: { backgroundColor: 'rgba(229,229,229,1)', borderRadius: 100 },
                            type: 'shape'
                        },
                        {
                            name: 'Oval 4',
                            Id: 73,
                            nameId: '690E810B-5124-4CC7-AEBC-9079FF7D9DAE',
                            frame: { width: 38, height: 38, x: 627, y: 1362 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)', borderRadius: 38 },
                            type: 'shape'
                        }
                    ],
                    type: 'group',
                    objectID: '44C98B24-5658-4B3E-992A-628FEA426567'
                }
            ],
            type: 'group',
            objectID: 'A29BF55F-0327-4AC2-ADE2-BCA413AA7629'
        },
        {
            name: 'list copy 2',
            Id: 75,
            nameId: '6056BE00-6689-4A10-A3C5-88BD7D514D6B',
            frame: { width: 750, height: 96, x: 0, y: 1437 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 76,
                    nameId: '5A7F95AE-E27C-4B16-AF0E-A0CD4CB9B071',
                    frame: { width: 720, height: 1, x: 30, y: 1532 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1ViMguMmTBuNjy1XbXXaMrVXa-720-1.png'
                },
                {
                    name: '卸任塘主',
                    Id: 77,
                    nameId: '22005D34-D3F2-4F62-BCCA-F02FF2B2B8B9',
                    frame: { width: 128, height: 45, x: 30, y: 1463 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 32,
                        color: '#222222',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '卸任塘主',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '6056BE00-6689-4A10-A3C5-88BD7D514D6B'
        },
        {
            name: 'Rectangle 8 Copy 17',
            Id: 78,
            nameId: '8B6B447E-96DB-4F1C-BEFF-26B0D3ADAB94',
            frame: { width: 750, height: 10, x: 0, y: 1427 },
            styles: { backgroundColor: 'rgba(243,245,249,1)' },
            type: 'shape'
        },
        {
            name: 'Rectangle 8 Copy 18',
            Id: 79,
            nameId: 'F9BB5C54-EB8C-40C1-ADFC-0FE64AFD4EB4',
            frame: { width: 750, height: 251, x: 0, y: 1533 },
            styles: { backgroundColor: 'rgba(243,245,249,1)' },
            type: 'shape'
        },
        {
            name: 'Rectangle 9',
            Id: 80,
            nameId: 'B70838C9-42A3-4088-AA44-E0A002061109',
            frame: { width: 750, height: 96, x: 0, y: 1541 },
            styles: { backgroundColor: 'rgba(255,255,255,1)' },
            type: 'shape'
        },
        {
            name: '退出鱼塘',
            Id: 81,
            nameId: 'E6F6A796-3656-4B90-9968-0218F34F6EE2',
            frame: { width: 128, height: 45, x: 311, y: 1567 },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 32,
                color: '#222222',
                lineHeight: '45',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '退出鱼塘',
            type: 'text'
        },
        {
            name: '头像 copy 5',
            Id: 83,
            nameId: '6C494109-CCA4-4058-9488-17AFD2E8E016',
            frame: { width: 142, height: 171, x: 20, y: 319 },
            layers: [
                {
                    name: '3_2003',
                    Id: 84,
                    nameId: '17604B07-516A-425A-BEB6-624CE67E6F2F',
                    frame: { width: 91, height: 37, x: 45.5, y: 442 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                    },
                    value: '3_2003',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '6C494109-CCA4-4058-9488-17AFD2E8E016'
        },
        {
            name: '头像 copy 6',
            Id: 86,
            nameId: '4C97A416-6AB2-48FB-8F7D-48561B4FF85F',
            frame: { width: 142, height: 171, x: 162, y: 319 },
            layers: [
                {
                    name: '鲁2014',
                    Id: 87,
                    nameId: 'AFD2AA38-B7A8-4784-B831-9E51524A128F',
                    frame: { width: 84, height: 37, x: 191, y: 442 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                    },
                    value: '鲁2014',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '4C97A416-6AB2-48FB-8F7D-48561B4FF85F'
        },
        {
            name: '头像 copy 7',
            Id: 89,
            nameId: '429A8C22-6F67-4055-9334-24CD6CD514E4',
            frame: { width: 142, height: 171, x: 304, y: 319 },
            layers: [
                {
                    name: '悟空哈',
                    Id: 90,
                    nameId: 'B92168CF-25E8-450D-8FF1-961600024D74',
                    frame: { width: 79, height: 37, x: 335.5, y: 442 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                    },
                    value: '悟空哈',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '429A8C22-6F67-4055-9334-24CD6CD514E4'
        },
        {
            name: '头像 copy 13',
            Id: 92,
            nameId: '88956E45-BF92-4ED0-A99A-D0BECBA31DDD',
            frame: { width: 142, height: 171, x: 446, y: 319 },
            layers: [
                {
                    name: '邀请',
                    Id: 93,
                    nameId: 'A57BC64C-D681-4234-BFB7-CFF3C372AC26',
                    frame: { width: 53, height: 37, x: 491.5, y: 442 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                    },
                    value: '邀请',
                    type: 'text'
                },
                {
                    name: 'Group 6',
                    Id: 95,
                    nameId: '9CF02549-980E-441F-B350-6B5F9E79F990',
                    frame: { width: 40, height: 41, x: 498, y: 368 },
                    layers: [
                        {
                            name: 'Group 3',
                            Id: 97,
                            nameId: 'FC6A195A-99CC-400B-BFF9-92488A0F78F1',
                            frame: { width: 40, height: 41, x: 498, y: 368 },
                            layers: [
                                {
                                    name: 'Rectangle',
                                    Id: 98,
                                    nameId: '8B392205-7677-4AD4-85A7-95E4F4B90B61',
                                    frame: { width: 40, height: 3, x: 498, y: 387 },
                                    styles: { backgroundColor: 'rgba(204,204,204,1)', borderRadius: 8 },
                                    type: 'shape'
                                },
                                {
                                    name: 'Rectangle',
                                    Id: 99,
                                    nameId: '72EA1341-CBCB-441B-A59C-2CC6B4D78C70',
                                    frame: { width: 3, height: 40, x: 516.5, y: 368.5 },
                                    styles: { backgroundColor: 'rgba(204,204,204,1)', borderRadius: 8 },
                                    type: 'shape'
                                }
                            ],
                            type: 'group',
                            objectID: 'FC6A195A-99CC-400B-BFF9-92488A0F78F1'
                        }
                    ],
                    type: 'group',
                    objectID: '9CF02549-980E-441F-B350-6B5F9E79F990'
                }
            ],
            type: 'group',
            objectID: '88956E45-BF92-4ED0-A99A-D0BECBA31DDD'
        },
        {
            name: '头像 copy 14',
            Id: 101,
            nameId: '7A94FE2B-E769-4160-B400-C932EBE4F277',
            frame: { width: 142, height: 171, x: 588, y: 319 },
            layers: [
                {
                    name: '移出塘民',
                    Id: 102,
                    nameId: '7A167A47-E219-4586-A5A7-E347C4F9BCCB',
                    frame: { width: 105, height: 37, x: 608.5, y: 442 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                    },
                    value: '移出塘民',
                    type: 'text'
                },
                {
                    name: 'Group 7',
                    Id: 104,
                    nameId: '3C6ACAAF-97A1-4F90-A16C-FDB1A3B2D3B1',
                    frame: { width: 40, height: 3, x: 639, y: 387 },
                    layers: [
                        {
                            name: 'Group 3',
                            Id: 106,
                            nameId: 'EF71B9E9-4E2B-4ACC-BC2A-09676D975E9A',
                            frame: { width: 40, height: 3, x: 639, y: 387 },
                            layers: [
                                {
                                    name: 'Rectangle',
                                    Id: 107,
                                    nameId: '4E6E1A96-9E69-4016-BF85-DEDDCA78F75D',
                                    frame: { width: 40, height: 3, x: 639, y: 387 },
                                    styles: { backgroundColor: 'rgba(204,204,204,1)', borderRadius: 8 },
                                    type: 'shape'
                                }
                            ],
                            type: 'group',
                            objectID: 'EF71B9E9-4E2B-4ACC-BC2A-09676D975E9A'
                        }
                    ],
                    type: 'group',
                    objectID: '3C6ACAAF-97A1-4F90-A16C-FDB1A3B2D3B1'
                }
            ],
            type: 'group',
            objectID: '7A94FE2B-E769-4160-B400-C932EBE4F277'
        },
        {
            name: '头像 copy 3',
            Id: 109,
            nameId: '512E27BE-EFD4-41F3-9FF3-AA80A6E63422',
            frame: { width: 142, height: 171, x: 446, y: 148 },
            layers: [
                {
                    name: '沈东奇',
                    Id: 110,
                    nameId: 'B5A84E23-E78C-48E9-90AF-56EF7D761C42',
                    frame: { width: 79, height: 37, x: 477.5, y: 271 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                    },
                    value: '沈东奇',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '512E27BE-EFD4-41F3-9FF3-AA80A6E63422'
        },
        {
            name: '头像 copy 4',
            Id: 112,
            nameId: '4B4D2DA7-52CA-4DD3-AA89-CB4EB586F845',
            frame: { width: 142, height: 171, x: 588, y: 148 },
            layers: [
                {
                    name: '海贼王',
                    Id: 113,
                    nameId: '8248D253-1912-42E5-B88B-D69238CB4C1B',
                    frame: { width: 79, height: 37, x: 619.5, y: 271 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                    },
                    value: '海贼王',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '4B4D2DA7-52CA-4DD3-AA89-CB4EB586F845'
        },
        {
            name: 'Group 4',
            Id: 115,
            nameId: 'D8B8E617-2D8A-47EF-9157-8BC89F22BD66',
            frame: { width: 201, height: 42, x: 282, y: 522 },
            layers: [
                {
                    name: 'Group',
                    Id: 117,
                    nameId: 'F02BF3E0-A31E-43BC-80B0-8D97DE3B8A57',
                    frame: { width: 168, height: 42, x: 282, y: 522 },
                    layers: [
                        {
                            name: '查看更多塘民',
                            Id: 118,
                            nameId: '8BD0A14B-C3F5-4B46-81A4-B6274E43BBE7',
                            frame: { width: 168, height: 42, x: 282, y: 522 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 28,
                                color: '#222222',
                                lineHeight: '42',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '查看更多塘民',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'F02BF3E0-A31E-43BC-80B0-8D97DE3B8A57'
                },
                {
                    name: 'List_Arrow Copy 2',
                    Id: 120,
                    nameId: 'A6C1EDE5-0F3D-4F46-9B2A-B4E2395919C7',
                    frame: { width: 32, height: 32, x: 451, y: 527 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 121,
                            nameId: 'CB46AFE7-01F6-4679-A1AE-7D81EE1DC816',
                            frame: { width: 14, height: 24, x: 461, y: 531 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1tbj9mvuSBuNkHFqDXXXfhVXa-14-24.png'
                        }
                    ],
                    type: 'group',
                    objectID: 'A6C1EDE5-0F3D-4F46-9B2A-B4E2395919C7'
                }
            ],
            type: 'group',
            objectID: 'D8B8E617-2D8A-47EF-9157-8BC89F22BD66'
        },
        {
            name: 'Rectangle 8 Copy 17',
            Id: 122,
            nameId: 'D8BDCCD0-44D8-4035-BEF8-6F3506094059',
            frame: { width: 750, height: 12, x: 0, y: 592 },
            styles: { backgroundColor: 'rgba(243,245,249,1)' },
            type: 'shape'
        },
        {
            name: 'list',
            Id: 124,
            nameId: '41B0E195-2270-4529-8FE1-0A5AFE58EFFC',
            frame: { width: 750, height: 96, x: 0, y: 604 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 125,
                    nameId: '6615E807-D69F-4030-B47F-BB94EF292FDA',
                    frame: { width: 720, height: 1, x: 30, y: 699 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1oiQguMmTBuNjy1XbXXaMrVXa-720-1.png'
                },
                {
                    name: 'List_Arrow',
                    Id: 127,
                    nameId: '45F3E51D-C508-4E55-BA97-25FA51EBA92E',
                    frame: { width: 32, height: 32, x: 688, y: 636 },
                    layers: [
                        {
                            name: 'Bitmap',
                            Id: 128,
                            nameId: 'A94A2254-A098-4BAF-AD27-7EE2B6737A29',
                            frame: { width: 14, height: 25, x: 698, y: 640 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1PrMbmwKTBuNkSne1XXaJoXXa-14-25.png'
                        }
                    ],
                    type: 'group',
                    objectID: '45F3E51D-C508-4E55-BA97-25FA51EBA92E'
                },
                {
                    name: '所属地点',
                    Id: 129,
                    nameId: '94F35A64-216A-429F-9342-049FACF3F906',
                    frame: { width: 128, height: 45, x: 30, y: 630 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 32,
                        color: '#222222',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '所属地点',
                    type: 'text'
                },
                {
                    name: '西溪悦居',
                    Id: 130,
                    nameId: '82A59E30-6F09-48D5-A150-D5FDC22F9596',
                    frame: { width: 112, height: 48, x: 572, y: 628 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#888888',
                        textAlign: 'right',
                        lineHeight: '48',
                        fontWeight: 'normal'
                    },
                    value: '西溪悦居',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '41B0E195-2270-4529-8FE1-0A5AFE58EFFC'
        },
        {
            name: 'Group 5',
            Id: 132,
            nameId: '55EADA7F-3AB8-4499-A5A4-5295CD9EB8F9',
            frame: { width: 6192, height: 226, x: -5447, y: 7 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 133,
                    nameId: '5B8B651D-DBD7-4933-BC65-D89325A1350A',
                    frame: { width: 730, height: 27, x: 15, y: 7 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB13bmfuWmWBuNjy1XaXXXCbXXa-730-27.png'
                },
                {
                    name: '鱼塘信息',
                    Id: 134,
                    nameId: '1B1C3049-8EEF-475C-A30B-985C1EF6F1EF',
                    frame: { width: 136, height: 48, x: 311, y: 59 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 34,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '48',
                        fontWeight: 'normal'
                    },
                    value: '鱼塘信息',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 135,
                    nameId: '55135DA9-6C79-4111-8B38-2C686F6B0F4A',
                    frame: { width: 18, height: 33, x: 41, y: 67 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1XYQbmwKTBuNkSne1XXaJoXXa-18-33.png'
                }
            ],
            type: 'group',
            objectID: '55EADA7F-3AB8-4499-A5A4-5295CD9EB8F9'
        },
        {
            name: 'Bitmap',
            Id: 136,
            nameId: '2C0E2654-6BD7-48E4-8071-916EB854C772',
            frame: { width: 98, height: 98, x: 42, y: 337 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1iYqfuWmWBuNjy1XaXXXCbXXa-98-98.png'
        },
        {
            name: 'Bitmap',
            Id: 137,
            nameId: 'E25674A2-16E4-4535-8208-32C546FE8507',
            frame: { width: 98, height: 98, x: 184, y: 337 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1zbQbmwKTBuNkSne1XXaJoXXa-98-98.png'
        },
        {
            name: 'Bitmap',
            Id: 138,
            nameId: 'F3781D01-8B4F-4390-BE32-267BFC88248F',
            frame: { width: 98, height: 98, x: 326, y: 337 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1DHqfuWmWBuNjy1XaXXXCbXXa-98-98.png'
        },
        {
            name: 'Rectangle 12',
            Id: 139,
            nameId: '5D299B97-5E62-4C06-90F7-7F666B0104D1',
            frame: { width: 98, height: 98, x: 469, y: 337 },
            styles: { borderColor: 'rgba(204,204,204,1)', borderStyle: 'solid', borderWidth: 1, borderRadius: 8 },
            type: 'shape'
        },
        {
            name: 'Rectangle 12 Copy',
            Id: 140,
            nameId: '47BFA0C7-7BE2-4C16-AAEA-023D54F30669',
            frame: { width: 98, height: 98, x: 609, y: 337 },
            styles: { borderColor: 'rgba(204,204,204,1)', borderStyle: 'solid', borderWidth: 1, borderRadius: 8 },
            type: 'shape'
        },
        {
            name: '塘主_28 copy',
            Id: 142,
            nameId: '6B75D2E4-D861-403C-A9FF-A34722CF937A',
            frame: { width: 49, height: 28, x: 67, y: 245 },
            layers: [
                {
                    name: '新浪icon',
                    Id: 144,
                    nameId: '86256569-02EC-4620-AD2A-A6CD4329D19F',
                    frame: { width: 49, height: 28, x: 67, y: 245 },
                    layers: [
                        {
                            name: 'Rectangle 567',
                            Id: 145,
                            nameId: '4B8F126B-DAF1-44C9-A95C-A9AA06A0184F',
                            frame: { width: 49, height: 28, x: 67, y: 245 },
                            styles: { backgroundColor: 'rgba(56,173,255,1)', borderRadius: 4 },
                            type: 'shape'
                        }
                    ],
                    type: 'group',
                    objectID: '86256569-02EC-4620-AD2A-A6CD4329D19F'
                },
                {
                    name: '塘主',
                    Id: 146,
                    nameId: '4976135C-9F10-4D27-BBF2-73C5338C8DAA',
                    frame: { width: 40, height: 20, x: 71.90000000000055, y: 248.27500000000146 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 20,
                        color: '#FFFFFF',
                        lineHeight: '20',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '塘主',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '6B75D2E4-D861-403C-A9FF-A34722CF937A'
        },
        {
            name: 'Bitmap',
            Id: 147,
            nameId: '55D27FD0-7ECA-42A9-A6E3-40D80D6400DB',
            frame: { width: 98, height: 98, x: 468, y: 169 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB15c1_u_tYBeNjy1XdXXXXyVXa-98-98.png'
        },
        {
            name: 'Bitmap',
            Id: 148,
            nameId: '1E3657DE-AA1E-4229-B3F6-CEAF4A3F5051',
            frame: { width: 98, height: 98, x: 609, y: 169 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB18eBau7yWBuNjy0FpXXassXXa-98-98.png'
        }
    ],
    nameId: 1527846994708,
    Id: 1,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 1651 },
    styles: { backgroundColor: 'rgba(255,255,255,1)' }
};
