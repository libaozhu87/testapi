"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Bitmap',
            Id: 2,
            nameId: '85DF5104-4165-4AAA-B9D4-113B68944A5A',
            frame: { width: 750, height: 582, x: 0, y: 0 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1f.z8qkCWBuNjy0FaXXXUlXXa-750-582.png'
        },
        {
            name: 'Bitmap',
            Id: 3,
            nameId: 'C8457CD5-A6AA-471B-A4FB-FA5EEF90403F',
            frame: { width: 173, height: 186, x: 289, y: 275 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1uan7qf5TBuNjSspmXXaDRVXa-173-186.png'
        },
        {
            name: 'Bitmap Copy',
            Id: 4,
            nameId: 'EF04E3FB-EF55-4F44-BD93-5C119F460199',
            frame: { width: 173, height: 186, x: 512, y: 275 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1Noz8qkCWBuNjy0FaXXXUlXXa-173-186.png'
        },
        {
            name: 'Bitmap Copy 2',
            Id: 5,
            nameId: 'FC498E55-7276-46B6-A983-AB37D70D2E62',
            frame: { width: 173, height: 186, x: 66, y: 275 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB12YjRqXuWBuNjSspnXXX1NVXa-173-186.png'
        },
        {
            name: 'Group 3',
            Id: 7,
            nameId: 'D720597C-2091-4F89-A45F-AD96F15603ED',
            frame: { width: 690, height: 1473, x: 30, y: 530 },
            layers: [
                {
                    name: 'Rectangle',
                    Id: 8,
                    nameId: 'FBC79BD0-9D29-4D72-844E-27223750E609',
                    frame: { width: 690, height: 1472.999999999999, x: 30, y: 530 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', cornerRadiusString: '10', borderRadius: 10 },
                    type: 'shape'
                },
                {
                    name: '赞',
                    Id: 9,
                    nameId: 'B4F2B2F3-C030-41DF-9FC9-7948DCF0FA0E',
                    frame: { width: 30, height: 42, x: 114, y: 1922 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '30',
                        color: '#FF2222',
                        lineHeight: '42',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '赞',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 10,
                    nameId: '67675A13-C8C4-458C-89A3-662E0A25874F',
                    frame: { width: 46, height: 37, x: 59, y: 1925 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1PA_qqXGWBuNjy0FbXXb4sXXa-46-37.png'
                },
                {
                    name: 'Bitmap',
                    Id: 11,
                    nameId: 'E9426756-45A0-4B9C-A783-53A5F8601E88',
                    frame: { width: 22, height: 36, x: 194, y: 621 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1nbnRqXuWBuNjSspnXXX1NVXa-22-36.png'
                },
                {
                    name: 'Rectangle 2',
                    Id: 12,
                    nameId: '3FE75BD1-17D3-4FD1-BBF5-C29E56546A67',
                    frame: { width: 630, height: 273, x: 60, y: 722 },
                    styles: { backgroundColor: 'rgba(22,181,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: '罗曼蒂克消亡史',
                    Id: 13,
                    nameId: '4630AC20-F535-4FC6-A9EE-8846C3FD006D',
                    frame: { width: 253, height: 50, x: 194, y: 557 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '36',
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '50',
                        fontWeight: 'bold'
                    },
                    value: '罗曼蒂克消亡史',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 14,
                    nameId: '1D07610E-AA1B-422A-85F7-CEC44F6163A4',
                    frame: { width: 36, height: 36, x: 457, y: 565 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1h_PaqbSYBuNjSspiXXXNzpXa-36-36.png'
                },
                {
                    name: 'Bitmap',
                    Id: 16,
                    nameId: '399D4700-D706-4C92-8450-2206E07A1CCD',
                    frame: { width: 100, height: 100, x: 64, y: 560 },
                    layers: [
                        {
                            name: 'Mask',
                            Id: 17,
                            nameId: '55F88E90-1424-48B5-AF91-5B16E5F1EB07',
                            frame: { width: 100, height: 100, x: 64, y: 560 },
                            styles: { backgroundColor: 'rgba(216,216,216,1)', fillType: 'color', cornerRadiusString: '6', borderRadius: 6 },
                            type: 'shape'
                        },
                        {
                            name: 'Bitmap',
                            Id: 19,
                            nameId: 'DA6D53E0-260D-48DE-A319-2AD2E394A6A8',
                            frame: { width: 100, height: 100, x: 64, y: 560 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 20,
                                    nameId: '52376F7E-BC1F-4C12-98D7-6CA61F5DD81A',
                                    frame: { width: 100, height: 100, x: 64, y: 560 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1zAjpqeuSBuNjSsplXXbe8pXa-100-100.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'DA6D53E0-260D-48DE-A319-2AD2E394A6A8'
                        }
                    ],
                    type: 'group',
                    objectID: '399D4700-D706-4C92-8450-2206E07A1CCD'
                },
                {
                    name: '来自浙江大学',
                    Id: 21,
                    nameId: '509DCE64-4103-40F4-B275-8CDC011D76DE',
                    frame: { width: 192, height: 45, x: 225, y: 617 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '32',
                        color: '#999999',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '来自浙江大学',
                    type: 'text'
                },
                {
                    name: '四十八个字四十八个字四十八个字四十八个字',
                    Id: 22,
                    nameId: 'D127794F-ABE3-4E7D-A4FB-A999469F4C29',
                    frame: { width: 528, height: 162, x: 132, y: 719 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '36',
                        color: '#FFFFFF',
                        lineHeight: '54',
                        maxWidth: 528,
                        maxHeight: 162,
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '四十八个字四十八个字四十八个字四十八个字四十八个字四十八个字四十八个字四十八',
                    type: 'text'
                },
                {
                    name: '——来自学长',
                    Id: 23,
                    nameId: '43B11A69-7598-49F6-B1FF-31C241BBE1A0',
                    frame: { width: 217, height: 50, x: 445, y: 921 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '36',
                        color: '#FFFFFF',
                        lineHeight: '50',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '——来自学长',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 24,
                    nameId: '1BDA02D1-4B5D-4270-A0B1-A16AC6A42592',
                    frame: { width: 33, height: 26, x: 90, y: 730 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1wnPaqbSYBuNjSspiXXXNzpXa-33-26.png'
                },
                {
                    name: 'Group',
                    Id: 26,
                    nameId: 'A8A97B74-3BC0-4B34-8406-57928FB58CC7',
                    frame: { width: 197, height: 67, x: 60, y: 1038 },
                    layers: [
                        {
                            name: '￥',
                            Id: 27,
                            nameId: '09F47CFB-35AF-4857-A083-2678BEE88571',
                            frame: { width: 37, height: 50, x: 60, y: 1038 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '36',
                                color: '#FF2222',
                                lineHeight: '50',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '￥',
                            type: 'text'
                        },
                        {
                            name: '10',
                            Id: 28,
                            nameId: '541A8F5D-549D-4B0F-8D46-8EF7274246CD',
                            frame: { width: 49, height: 50, x: 96, y: 1038 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '48',
                                color: '#FF2222',
                                lineHeight: '50',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '10',
                            type: 'text'
                        },
                        {
                            name: '￥2222',
                            Id: 29,
                            nameId: '04B71B52-0AF1-4293-8654-33FD6B33F5A2',
                            frame: { width: 96, height: 40, x: 161, y: 1059 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#999999',
                                lineHeight: '40',
                                textAlign: 'left',
                                textDecoration: 'line-through',
                                fontWeight: 'normal'
                            },
                            value: '￥2222',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: 'A8A97B74-3BC0-4B34-8406-57928FB58CC7'
                },
                {
                    name: '#毕业季#最最经典的iPhone 4便宜',
                    Id: 30,
                    nameId: '455B5B2B-3855-4B2F-9426-B313AD3BD201',
                    frame: { width: 630, height: 249, x: 60, y: 1119 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '36',
                        color: '#222222',
                        lineHeight: '54',
                        maxWidth: 630,
                        maxHeight: 249,
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '#毕业季#最最经典的iPhone 4便宜卖啦我是学长我说了算，当年靠它找到了我第一个女朋友，里面还留着我们的聊天记录呢',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 32,
                    nameId: '07EEAA34-BCA7-4262-9C1F-2F1E9F238E25',
                    frame: { width: 630, height: 500, x: 60, y: 1375 },
                    layers: [
                        {
                            name: 'Mask',
                            Id: 33,
                            nameId: '152A8583-D154-4E8D-9C23-97A20A3275EF',
                            frame: { width: 630, height: 500, x: 60, y: 1375 },
                            styles: { backgroundColor: 'rgba(216,216,216,1)', fillType: 'color', cornerRadiusString: '10', borderRadius: 10 },
                            type: 'shape'
                        },
                        {
                            name: 'Bitmap',
                            Id: 35,
                            nameId: 'D6088D79-0985-4CAB-832E-2605AD977300',
                            frame: { width: 630, height: 500, x: 60, y: 1375 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 36,
                                    nameId: 'EC9C7A1A-D520-4A0F-990A-BC834876A074',
                                    frame: { width: 630, height: 500, x: 60, y: 1375 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB17MHKqkOWBuNjSsppXXXPgpXa-630-500.png'
                                }
                            ],
                            type: 'group',
                            objectID: 'D6088D79-0985-4CAB-832E-2605AD977300'
                        }
                    ],
                    type: 'group',
                    objectID: '07EEAA34-BCA7-4262-9C1F-2F1E9F238E25'
                },
                {
                    name: 'Group 2',
                    Id: 38,
                    nameId: '906A7942-6015-4DDD-B92A-E5B2D01B3BDB',
                    frame: { width: 202, height: 42, x: 488, y: 1922 },
                    layers: [
                        {
                            name: '查看宝贝原照',
                            Id: 39,
                            nameId: '20E6B1C8-96E8-445C-A291-FACAF354397E',
                            frame: { width: 180, height: 42, x: 488, y: 1922 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '30',
                                color: '#228FFF',
                                lineHeight: '42',
                                textAlign: 'left',
                                fontWeight: 'normal'
                            },
                            value: '查看宝贝原照',
                            type: 'text'
                        },
                        {
                            name: 'Bitmap',
                            Id: 40,
                            nameId: '596AE6FA-7B21-4417-94A0-C6FB757C4032',
                            frame: { width: 15, height: 25, x: 675, y: 1932 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1UoT8qkCWBuNjy0FaXXXUlXXa-15-25.png'
                        }
                    ],
                    type: 'group',
                    objectID: '906A7942-6015-4DDD-B92A-E5B2D01B3BDB'
                }
            ],
            type: 'group',
            objectID: 'D720597C-2091-4F89-A45F-AD96F15603ED'
        },
        {
            name: 'Group 4',
            Id: 42,
            nameId: '06D043FC-ED53-47FA-977E-64F5503C6D55',
            frame: { width: 750, height: 120, x: 0, y: 2076 },
            layers: [
                {
                    name: 'Rectangle 3',
                    Id: 43,
                    nameId: 'A8692D84-CB1A-47BF-9097-F2A0035302DA',
                    frame: { width: 750, height: 120, x: 0, y: 2076 },
                    styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                    type: 'shape'
                },
                {
                    name: 'Bitmap',
                    Id: 44,
                    nameId: '5FA64CB2-DF75-4E17-8E66-72B2B3CFED9B',
                    frame: { width: 690, height: 80, x: 30, y: 2096 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1nMLKqkOWBuNjSsppXXXPgpXa-690-80.png'
                },
                {
                    name: '去邀请好友，最低0.01元购',
                    Id: 45,
                    nameId: '8E60F2C6-90A0-4F06-82BA-744697F8AD47',
                    frame: { width: 381, height: 45, x: 185, y: 2114 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '32',
                        color: '#FFFFFF',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '去邀请好友，最低0.01元购',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '06D043FC-ED53-47FA-977E-64F5503C6D55'
        },
        {
            name: 'Bitmap',
            Id: 46,
            nameId: 'FF8CE894-30A7-4540-BAFE-B9B01361F8D5',
            frame: { width: 631, height: 32, x: 60, y: 690 },
            imageStyles: { resize: 'stretch' },
            type: 'image',
            value: 'https://gw.alicdn.com/tfs/TB1ULZXqhSYBuNjSspjXXX73VXa-631-32.png'
        }
    ],
    nameId: 1525745975398,
    Id: 1,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 2196 },
    styles: { backgroundColor: 'rgba(0,158,112,1)' }
};
