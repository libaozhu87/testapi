"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: '首页',
            Id: 2,
            nameId: 'C545F6CF-D1B6-47EE-B0E9-EFD6F9CD1380',
            frame: { width: 70, height: 30, x: 30, y: 0 },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '22',
                color: '#8A5BFF',
                letterSpacing: '0.26',
                textAlign: 'center',
                lineHeight: '30',
                maxWidth: 68,
                maxHeight: 30,
                fontWeight: 'normal'
            },
            value: '首页',
            type: 'text'
        },
        {
            name: '全部',
            Id: 3,
            nameId: 'AA9FB9E9-076A-42EE-B87A-1ADA27E51F06',
            frame: { width: 90, height: 30, x: 160, y: 0 },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '22',
                color: '#9092A5',
                letterSpacing: '0.12',
                textAlign: 'center',
                lineHeight: '30',
                maxWidth: 88,
                maxHeight: 30,
                fontWeight: 'bold'
            },
            value: '全部',
            type: 'text'
        },
        {
            name: '店主精选',
            Id: 4,
            nameId: 'B5D6756A-5D0F-44E0-8E14-F0D8573994DA',
            frame: { width: 120, height: 30, x: 285, y: 0 },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '22',
                color: '#9092A5',
                letterSpacing: '0.26',
                textAlign: 'center',
                lineHeight: '30',
                maxWidth: 120,
                maxHeight: 30,
                fontWeight: 'bold'
            },
            value: '店主精选',
            type: 'text'
        },
        {
            name: '购物袋',
            Id: 5,
            nameId: '65065078-0C99-4426-BB01-EBE27B14EE93',
            frame: { width: 110, height: 30, x: 430, y: 0 },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '22',
                color: '#9092A5',
                letterSpacing: '0.12',
                textAlign: 'center',
                lineHeight: '30',
                maxWidth: 106,
                maxHeight: 30,
                fontWeight: 'bold'
            },
            value: '购物袋',
            type: 'text'
        },
        {
            name: '我的',
            Id: 6,
            nameId: '7CD2A363-8C59-4B7E-842E-237F3E525D24',
            frame: { width: 60, height: 30, x: 595, y: 0 },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '22',
                color: '#9092A5',
                letterSpacing: '0.12',
                textAlign: 'center',
                lineHeight: '30',
                maxWidth: 60,
                maxHeight: 30,
                fontWeight: 'bold'
            },
            value: '我的',
            type: 'text'
        }
    ],
    nameId: 1523618259727,
    Id: 1,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 30 }
};
