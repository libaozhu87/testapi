"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Rectangle 224 Copy 4',
            id: 1,
            nameId: 'F3728C82-893A-4FE8-A022-29C45E6862B7',
            frame: { width: 750, height: 16, x: 0, y: 0 },
            styles: { backgroundColor: 'rgba(243,245,249,1)', fillType: 'color', opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle 224 Copy 7',
            id: 2,
            nameId: 'ED3F542E-A2AB-4A75-BD6F-D2C8EC04E057',
            frame: { width: 750, height: 16, x: 0, y: 465 },
            styles: { backgroundColor: 'rgba(243,245,249,1)', fillType: 'color', opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Mask',
            id: 3,
            nameId: '27944DD6-5C75-41EF-890F-23AE66F795BE',
            frame: { width: 750, height: 89, x: 0, y: 16 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
            type: 'shape'
        },
        {
            name: '宝妈们喜欢的鱼塘',
            id: 4,
            nameId: '2163FE24-67E8-486B-BC3D-7E4BDE33EB87',
            frame: { width: 256, height: 36, x: 32, y: 43 },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '32',
                color: '#222222',
                lineHeight: '36',
                textAlign: 'left',
                fontWeight: 'bold'
            },
            value: '宝妈们喜欢的鱼塘',
            type: 'text'
        },
        {
            name: 'Rectangle 24',
            id: 5,
            nameId: 'FD3DEB2C-92BF-4F38-B7E3-D6712B6D0987',
            frame: { width: 750, height: 128, x: 0, y: 105 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle 24 Copy',
            id: 6,
            nameId: '0E0D8C27-F453-443E-B3C4-0E46156C244A',
            frame: { width: 598, height: 128, x: 152, y: 105 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle',
            id: 7,
            nameId: '73CD0699-8550-423C-9D01-A1739A68D554',
            frame: { width: 118, height: 64, x: 594, y: 133 },
            styles: { fillType: 'gradient', cornerRadiusString: '6', borderRadius: 6, opacity: 1 },
            type: 'shape'
        },
        {
            name: '加入',
            id: 8,
            nameId: '16C7E925-D653-4CEE-A9D6-F472CD468C0B',
            frame: { width: 56, height: 40, x: 626, y: 145 },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'bold'
            },
            value: '加入',
            type: 'text'
        },
        {
            name: '新锐宝妈团(337人)',
            id: 9,
            nameId: '904CBFD2-6093-4A62-A5CA-F3737C462494',
            frame: { width: 253, height: 44, x: 152, y: 123 },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '30',
                color: '#222222',
                lineHeight: '44',
                textAlign: 'left',
                fontWeight: 'bold'
            },
            value: '新锐宝妈团(337人)',
            type: 'text'
        },
        {
            name: 'Oval Copy 2',
            id: 10,
            nameId: 'F13BB74A-1406-4A15-8242-1A21D9E23632',
            frame: { width: 20, height: 23.75, x: 153, y: 181 },
            styles: { backgroundColor: 'rgba(34,34,34,0.2)', fillType: 'color', borderRadius: 20, opacity: 0.2 },
            type: 'shape'
        },
        {
            name: 'Oval 10 Copy',
            id: 11,
            nameId: '5676138A-7D9E-4A08-9B10-58E2381201C5',
            frame: { width: 7.5, height: 7.5, x: 159.25, y: 186.625 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', borderRadius: 7.5, opacity: 1 },
            type: 'shape'
        },
        {
            name: '杭州 473件宝贝',
            id: 12,
            nameId: 'A11FF902-72FB-499E-8BF2-4EB3AE4FBED7',
            frame: { width: 193, height: 44, x: 181, y: 171 },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '26',
                color: '#999999',
                lineHeight: '44',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '杭州  473件宝贝',
            type: 'text'
        },
        {
            name: 'Oval',
            id: 13,
            nameId: '141B1549-909F-4C18-B1D2-E5ED99306A80',
            frame: { width: 4, height: 4, x: 239, y: 190 },
            styles: { backgroundColor: 'rgba(153,153,153,1)', fillType: 'color', borderRadius: 4, opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle 24',
            id: 14,
            nameId: 'D2C73807-65ED-44EA-8A9F-77A12E70AF01',
            frame: { width: 96, height: 96, x: 32, y: 121 },
            styles: { backgroundColor: 'rgba(0,0,0,0.12)', fillType: 'color', cornerRadiusString: '6', borderRadius: 6, opacity: 0.12 },
            type: 'shape'
        },
        {
            name: 'Rectangle',
            id: 15,
            nameId: '1F610456-FC62-4BAE-8208-79A8B7225809',
            frame: { width: 42, height: 42, x: 36, y: 125 },
            styles: { cornerRadiusString: '3', borderRadius: 3, opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle Copy 2',
            id: 16,
            nameId: 'BA33CC82-5D98-4008-A9BB-8C88EDA9F4CA',
            frame: { width: 42, height: 42, x: 36, y: 171 },
            styles: { cornerRadiusString: '3', borderRadius: 3, opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle Copy',
            id: 17,
            nameId: '1E2C3072-E32B-48C5-B60E-653D62C901C0',
            frame: { width: 42, height: 42, x: 82, y: 125 },
            styles: { cornerRadiusString: '3', borderRadius: 3, opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle Copy 3',
            id: 18,
            nameId: '41E41ACC-AF7C-418A-9A63-B58B42FE8052',
            frame: { width: 42, height: 42, x: 82, y: 171 },
            styles: { cornerRadiusString: '3', borderRadius: 3, opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle 24',
            id: 19,
            nameId: '6B894AA5-4DF7-4BB5-A412-A0BD81E1B693',
            frame: { width: 750, height: 128, x: 0, y: 233 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle 24 Copy',
            id: 20,
            nameId: 'DD259553-C841-43F6-BDBE-FE5321681EEB',
            frame: { width: 598, height: 128, x: 152, y: 233 },
            styles: { opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle',
            id: 21,
            nameId: 'F5CACA79-4E3D-437B-A1FE-D9D70F85F44B',
            frame: { width: 118, height: 64, x: 594, y: 261 },
            styles: { fillType: 'gradient', cornerRadiusString: '6', borderRadius: 6, opacity: 1 },
            type: 'shape'
        },
        {
            name: '加入',
            id: 22,
            nameId: 'B93E60C9-567A-4C3B-AF8B-FE7761525AC8',
            frame: { width: 56, height: 40, x: 626, y: 273 },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'bold'
            },
            value: '加入',
            type: 'text'
        },
        {
            name: '新锐宝妈团(337人)',
            id: 23,
            nameId: '87481A05-B591-46B8-82DA-EBCE84BBE096',
            frame: { width: 253, height: 44, x: 152, y: 251 },
            textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '30',
                color: '#222222',
                lineHeight: '44',
                textAlign: 'left',
                fontWeight: 'bold'
            },
            value: '新锐宝妈团(337人)',
            type: 'text'
        },
        {
            name: 'Oval Copy 2',
            id: 24,
            nameId: '9BA9B3D5-0884-497F-B6C2-4A61A632E7F2',
            frame: { width: 20, height: 23.75, x: 153, y: 309 },
            styles: { backgroundColor: 'rgba(34,34,34,0.2)', fillType: 'color', borderRadius: 20, opacity: 0.2 },
            type: 'shape'
        },
        {
            name: 'Oval 10 Copy',
            id: 25,
            nameId: 'FF05669E-13F0-4801-B1D0-3CCD6FADA08D',
            frame: { width: 7.5, height: 7.5, x: 159.25, y: 314.625 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', borderRadius: 7.5, opacity: 1 },
            type: 'shape'
        },
        {
            name: '杭州 473件宝贝',
            id: 26,
            nameId: '7A3032B9-3226-4E12-8BA5-EFAB947E7BF8',
            frame: { width: 193, height: 44, x: 181, y: 299 },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '26',
                color: '#999999',
                lineHeight: '44',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '杭州  473件宝贝',
            type: 'text'
        },
        {
            name: 'Oval',
            id: 27,
            nameId: '89E64AA6-DDC9-4FCF-B6EC-E0AB9981AFA2',
            frame: { width: 4, height: 4, x: 239, y: 318 },
            styles: { backgroundColor: 'rgba(153,153,153,1)', fillType: 'color', borderRadius: 4, opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle 24',
            id: 28,
            nameId: '0BFB9525-E66D-433F-8952-E0E7D3189BE1',
            frame: { width: 96, height: 96, x: 32, y: 249 },
            styles: { backgroundColor: 'rgba(0,0,0,0.12)', fillType: 'color', cornerRadiusString: '6', borderRadius: 6, opacity: 0.12 },
            type: 'shape'
        },
        {
            name: 'Rectangle',
            id: 29,
            nameId: '3A8C663F-83DF-4195-A8E3-D7863CE1506A',
            frame: { width: 42, height: 42, x: 36, y: 253 },
            styles: { cornerRadiusString: '3', borderRadius: 3, opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle Copy 2',
            id: 30,
            nameId: 'AA78FEDF-6060-422D-BFDD-1876894471EB',
            frame: { width: 42, height: 42, x: 36, y: 299 },
            styles: { cornerRadiusString: '3', borderRadius: 3, opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle Copy',
            id: 31,
            nameId: 'CE97806B-AC7A-4DCF-8FA0-50206FE3391F',
            frame: { width: 42, height: 42, x: 82, y: 253 },
            styles: { cornerRadiusString: '3', borderRadius: 3, opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle Copy 3',
            id: 32,
            nameId: '357C4790-BC62-454E-AF63-864ED7F741DD',
            frame: { width: 42, height: 42, x: 82, y: 299 },
            styles: { cornerRadiusString: '3', borderRadius: 3, opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle 13',
            id: 33,
            nameId: 'A77E0E7A-F22A-4555-8B22-13ABA9A58E8F',
            frame: { width: 750, height: 16, x: 0, y: 361 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle 13 Copy',
            id: 34,
            nameId: '333E5DFD-FDAF-44C9-992B-6E9E270BED61',
            frame: { width: 718, height: 16, x: 32, y: 361 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle 18',
            id: 35,
            nameId: '29B135D3-1657-4727-9627-DC5A95644C42',
            frame: { width: 750, height: 88, x: 0, y: 377 },
            styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Rectangle 4',
            id: 36,
            nameId: '4FBB4F17-51B0-4B6C-9201-669D6163A7BD',
            frame: { width: 32, height: 32, x: 443, y: 405 },
            styles: { opacity: 1 },
            type: 'shape'
        },
        {
            name: 'Combined Shape',
            id: 37,
            nameId: '5A17D62D-122E-4623-A586-122E0B354A8A',
            frame: { width: 14, height: 24, x: 453, y: 409 },
            styles: { backgroundColor: 'rgba(34,34,34,0.16)', fillType: 'color', opacity: 0.16 },
            type: 'shape'
        },
        {
            name: '查看更多鱼塘',
            id: 38,
            nameId: '37602219-6344-4478-AAF1-B4E5F67AFF32',
            frame: { width: 168, height: 40, x: 275, y: 401 },
            textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#888888',
                lineHeight: '40',
                textAlign: 'left',
                fontWeight: 'normal'
            },
            value: '查看更多鱼塘',
            type: 'text'
        }
    ],
    nameId: 1524019163414,
    id: 0,
    type: 'group',
    frame: { x: 0, y: 0, width: 750, height: 481 }
};
