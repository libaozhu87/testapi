"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    layers: [
        {
            name: 'Navigation Bar',
            Id: 3,
            nameId: '9CE57362-0EEA-4A91-B885-69BCF684D75D',
            frame: { width: 750, height: 128, x: 1, y: 0 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 4,
                    nameId: 'F101CA37-8E20-418E-9A82-469F3B32B95A',
                    frame: { width: 750, height: 128, x: 1, y: 0 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1OQyxuL1TBuNjy0FjXXajyXXa-750-128.png'
                },
                {
                    name: 'Status Bar black',
                    Id: 6,
                    nameId: '974337CF-6640-4793-9CD3-B6D625680B20',
                    frame: { width: 731, height: 33, x: 14, y: 3 },
                    layers: [
                        {
                            name: 'Signal',
                            Id: 8,
                            nameId: '043BA0E7-39BD-4000-B749-F1A9FFA8DBB8',
                            frame: { width: 190, height: 28, x: 14, y: 8 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 9,
                                    nameId: '4583D51D-7F87-4215-83BD-4D0325B9AE81',
                                    frame: { width: 68, height: 11, x: 14, y: 15 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1U.fDuTtYBeNjy1XdXXXXyVXa-68-11.png'
                                },
                                {
                                    name: 'VIRGI',
                                    Id: 10,
                                    nameId: 'F75B5059-5EE1-4529-826A-7DC40C6418D0',
                                    frame: { width: 62, height: 27, x: 90.40533333333337, y: 8 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 22,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '27',
                                        fontWeight: 'normal'
                                    },
                                    value: 'VIRGI',
                                    type: 'text'
                                },
                                {
                                    name: 'N',
                                    Id: 11,
                                    nameId: '0B51875A-11C7-48DA-89B4-4CC8811F7412',
                                    frame: { width: 17, height: 27, x: 152.01133303333336, y: 8 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 22,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '27',
                                        fontWeight: 'normal'
                                    },
                                    value: 'N',
                                    type: 'text'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 12,
                                    nameId: '27969E55-99EB-46AF-ABE2-DDB4311A564C',
                                    frame: { width: 25, height: 19, x: 179, y: 11 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB1JvgMuwmTBuNjy1XbXXaMrVXa-25-19.png'
                                }
                            ],
                            type: 'group',
                            objectID: '043BA0E7-39BD-4000-B749-F1A9FFA8DBB8'
                        },
                        {
                            name: 'Bitmap',
                            Id: 13,
                            nameId: '8DBDCB28-A6D6-401B-B56B-B337BD32D068',
                            frame: { width: 17, height: 27, x: 607, y: 7 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB11Ol0uKuSBuNjy1XcXXcYjFXa-17-27.png'
                        },
                        {
                            name: 'Battery',
                            Id: 15,
                            nameId: 'F52E6CE9-3EB8-4F71-9D74-6B39C40655FD',
                            frame: { width: 416, height: 33, x: 328.66933333333327, y: 3 },
                            layers: [
                                {
                                    name: 'Bitmap',
                                    Id: 16,
                                    nameId: 'FF462123-FDC5-41FD-8333-3E5FA162C9D0',
                                    frame: { width: 4, height: 7, x: 740, y: 17 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB17euJuGmWBuNjy1XaXXXCbXXa-4-7.png'
                                },
                                {
                                    name: 'Shape',
                                    Id: 17,
                                    nameId: '43B485C0-6884-4409-A289-CAFA3FFCA3FC',
                                    frame: { width: 14.074666666666644, height: 15, x: 696.6213333333333, y: 13 },
                                    styles: {
                                        backgroundColor: 'rgba(0,0,0,1)',
                                        borderBottomLeftRadius: '1',
                                        borderBottomRightRadius: '0',
                                        borderTopLeftRadius: '1',
                                        borderTopRightRadius: '0'
                                    },
                                    type: 'shape'
                                },
                                {
                                    name: 'Bitmap',
                                    Id: 18,
                                    nameId: '28EEE23B-26EE-4E54-A6A0-9D8C6CFEFF93',
                                    frame: { width: 46, height: 19, x: 694, y: 11 },
                                    imageStyles: { resize: 'stretch' },
                                    type: 'image',
                                    value: 'https://gw.alicdn.com/tfs/TB15LgMuwmTBuNjy1XbXXaMrVXa-46-19.png'
                                },
                                {
                                    name: '22',
                                    Id: 19,
                                    nameId: '0F8FFC1A-FAEA-42DC-B4DC-BEEBB13BA41B',
                                    frame: { width: 28, height: 28, x: 637.3066666666664, y: 7 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue-Light',
                                        fontSize: 23,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '28',
                                        fontWeight: 'normal'
                                    },
                                    value: '22',
                                    type: 'text'
                                },
                                {
                                    name: '%',
                                    Id: 20,
                                    nameId: 'D2799CF3-F0EA-4FC5-9B65-3AF69D2BA3E8',
                                    frame: { width: 22, height: 28, x: 664.8826666666664, y: 7 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue-Light',
                                        fontSize: 23,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '28',
                                        fontWeight: 'normal'
                                    },
                                    value: '%',
                                    type: 'text'
                                },
                                {
                                    name: '4 21 PM',
                                    Id: 21,
                                    nameId: 'F9B2D26E-09CD-493C-9399-953E273D1433',
                                    frame: { width: 97, height: 30, x: 328.66933333333327, y: 6 },
                                    textStyles: {
                                        fontFamily: 'HelveticaNeue',
                                        fontSize: 24,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '29',
                                        fontWeight: 'normal'
                                    },
                                    value: '4 21 PM',
                                    type: 'text'
                                },
                                {
                                    name: ':',
                                    Id: 22,
                                    nameId: 'F3647C83-7C9B-4149-9B22-FFB3EAD3C030',
                                    frame: { width: 9, height: 33, x: 342.2413333333334, y: 3 },
                                    textStyles: {
                                        fontFamily: 'AvenirNext-Regular',
                                        fontSize: 24,
                                        color: '#000000',
                                        textAlign: 'left',
                                        lineHeight: '33',
                                        fontWeight: 'normal'
                                    },
                                    value: ':',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'F52E6CE9-3EB8-4F71-9D74-6B39C40655FD'
                        }
                    ],
                    type: 'group',
                    objectID: '974337CF-6640-4793-9CD3-B6D625680B20'
                },
                {
                    name: 'Louie 2',
                    Id: 23,
                    nameId: '3894F8E0-AF9F-445F-9012-D80738E7B2AA',
                    frame: { width: 204, height: 48, x: 276.5, y: 61 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 34,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '48',
                        fontWeight: 'normal'
                    },
                    value: '申请房东身份',
                    type: 'text'
                },
                {
                    name: 'Louie 2',
                    Id: 24,
                    nameId: 'C51AAC32-4AE8-40D1-A43B-9D4CAE8F66BE',
                    frame: { width: 112, height: 40, x: 608, y: 67 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#222222',
                        textAlign: 'right',
                        lineHeight: '40',
                        fontWeight: 'normal'
                    },
                    value: '申请规则',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 25,
                    nameId: '23949875-6415-4204-ABEB-612677EBA98F',
                    frame: { width: 21, height: 40, x: 33, y: 64 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB14GXVuH9YBuNjy0FgXXcxcXXa-21-40.png'
                }
            ],
            type: 'group',
            objectID: '9CE57362-0EEA-4A91-B885-69BCF684D75D'
        },
        {
            name: 'title',
            Id: 27,
            nameId: '4B75C53A-A9C1-4334-8541-1FD70F418087',
            frame: { width: 1212, height: 65, x: -585, y: 143 },
            layers: [
                {
                    name: '申请成功后房源可获得更多曝光',
                    Id: 28,
                    nameId: 'F5D28BB9-DE84-4B90-9E4B-E1678C86A1BA',
                    frame: { width: 365, height: 40, x: 262, y: 168 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#999999',
                        textAlign: 'left',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'normal'
                    },
                    value: '申请成功后房源可获得更多曝光',
                    type: 'text'
                },
                {
                    name: '请选择你的身份',
                    Id: 29,
                    nameId: 'CF726EA2-D618-4343-A879-281D1D51FF36',
                    frame: { width: 224, height: 45, x: 32, y: 162 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#222222',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'bold'
                    },
                    value: '请选择你的身份',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '4B75C53A-A9C1-4334-8541-1FD70F418087'
        },
        {
            name: '主按钮',
            Id: 31,
            nameId: '5AA27130-95DF-4B8D-8528-DF8A64AFB995',
            frame: { width: 1316, height: 1171, x: -585, y: 143 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 32,
                    nameId: '16339592-AB3F-47E9-A37F-68B24BA6BD1F',
                    frame: { width: 710, height: 80, x: 21, y: 1234 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1vuyJuGmWBuNjy1XaXXXCbXXa-710-80.png'
                },
                {
                    name: '提交申请',
                    Id: 33,
                    nameId: '30722AE1-7B0B-4AF2-952B-8DD24969C28D',
                    frame: { width: 128, height: 45, x: 313, y: 1250 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '45',
                        fontWeight: 'bold'
                    },
                    value: '提交申请',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '5AA27130-95DF-4B8D-8528-DF8A64AFB995'
        },
        {
            name: 'Group',
            Id: 35,
            nameId: '5A83BFF4-019F-48E7-993B-65B0516A2C58',
            frame: { width: 750, height: 192, x: 1, y: 240 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 36,
                    nameId: 'F03E8E75-38D3-4DCC-8F23-316008608A64',
                    frame: { width: 718, height: 1, x: 33, y: 431 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1IQqIuSBYBeNjy0FeXXbnmFXa-718-1.png'
                },
                {
                    name: '保证不收租客中介费，最多可发布3条在线房',
                    Id: 37,
                    nameId: '25206BCA-8B41-473E-817E-9DA50CCEC7F6',
                    frame: { width: 601, height: 74, x: 102, y: 324 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        lineHeight: '39',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '保证不收租客中介费，最多可发布3条在线房源。你的所有房源将会获得             标签',
                    type: 'text'
                },
                {
                    name: '个人房东',
                    Id: 38,
                    nameId: '3FF4DD3B-21DF-4857-82F2-0DBE17AAED57',
                    frame: { width: 128, height: 40, x: 102, y: 273 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#222222',
                        textAlign: 'left',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'bold'
                    },
                    value: '个人房东',
                    type: 'text'
                },
                {
                    name: 'Oval 4',
                    Id: 39,
                    nameId: '4355A04A-4C57-4783-A206-A284B6CF2106',
                    frame: { width: 44, height: 44, x: 33, y: 271 },
                    styles: { borderColor: 'rgba(51,51,51,0.12)', borderStyle: 'solid', borderWidth: 2.2, borderRadius: 44 },
                    type: 'shape'
                },
                {
                    name: '(房屋所有者、转租客)',
                    Id: 40,
                    nameId: '57E90430-FACC-4508-A25E-EF5832A24395',
                    frame: { width: 252, height: 37, x: 239, y: 276 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        lineHeight: '37',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '(房屋所有者、转租客)',
                    type: 'text'
                },
                {
                    name: '个人房东tag',
                    Id: 42,
                    nameId: '7C51F688-B3D3-41CE-B681-DB99C7A92095',
                    frame: { width: 93, height: 29, x: 346, y: 369 },
                    layers: [
                        {
                            name: 'Rectangle 5',
                            Id: 43,
                            nameId: '48A22440-0037-4AF6-877A-09246411D72C',
                            frame: { width: 93, height: 28, x: 346, y: 369 },
                            styles: { backgroundColor: 'rgba(255,143,19,0.12)', borderRadius: 4 },
                            type: 'shape'
                        },
                        {
                            name: '个人房东',
                            Id: 44,
                            nameId: '3E2B8C93-8EE5-41F9-B34E-F12EF60E4BD9',
                            frame: { width: 80, height: 28, x: 353, y: 369.5 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 20,
                                color: '#FF8E12',
                                lineHeight: '28',
                                textAlign: 'left',
                                fontWeight: 'bold'
                            },
                            value: '个人房东',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '7C51F688-B3D3-41CE-B681-DB99C7A92095'
                }
            ],
            type: 'group',
            objectID: '5A83BFF4-019F-48E7-993B-65B0516A2C58'
        },
        {
            name: 'Group',
            Id: 46,
            nameId: '2573374D-0E35-49C6-9E50-706021AF3C79',
            frame: { width: 750, height: 192, x: 1, y: 432 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 47,
                    nameId: 'FA35B83E-B615-4DE3-97A9-ABB332CF53F3',
                    frame: { width: 718, height: 1, x: 33, y: 623 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1BJXGuQyWBuNjy0FpXXassXXa-718-1.png'
                },
                {
                    name: 'Oval 4',
                    Id: 48,
                    nameId: '93E02A01-A53D-41A1-B61F-BD8E9736CCDB',
                    frame: { width: 44, height: 44, x: 34, y: 464 },
                    styles: { borderColor: 'rgba(51,51,51,0.12)', borderStyle: 'solid', borderWidth: 2.2, borderRadius: 44 },
                    type: 'shape'
                },
                {
                    name: '保证不收租客中介费，在线房源发布不限制。',
                    Id: 49,
                    nameId: 'B47DD8F7-500E-40B5-9518-B43F3973BEAE',
                    frame: { width: 619, height: 74, x: 102, y: 516 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        lineHeight: '39',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '保证不收租客中介费，在线房源发布不限制。你的所有房源将会获得             标签',
                    type: 'text'
                },
                {
                    name: '公寓直租',
                    Id: 50,
                    nameId: '533F2763-5916-41EA-BD47-9C3B1D8182BD',
                    frame: { width: 128, height: 40, x: 102, y: 465 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#222222',
                        textAlign: 'left',
                        lineHeight: '39.20000076293945',
                        fontWeight: 'bold'
                    },
                    value: '公寓直租',
                    type: 'text'
                },
                {
                    name: '(公寓管家、职业二房东)',
                    Id: 51,
                    nameId: 'F142F912-781F-4804-AE3B-187FF0502CFE',
                    frame: { width: 278, height: 37, x: 239, y: 468 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        lineHeight: '37',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '(公寓管家、职业二房东)',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '2573374D-0E35-49C6-9E50-706021AF3C79'
        },
        {
            name: 'Group',
            Id: 53,
            nameId: '65C92224-92DF-4A45-82BF-1F2848D91CAC',
            frame: { width: 750, height: 192, x: 1, y: 624 },
            layers: [
                {
                    name: 'Bitmap',
                    Id: 54,
                    nameId: 'B96E10F8-2936-4971-861A-2F858D7BEAA4',
                    frame: { width: 718, height: 1, x: 33, y: 815 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1pGeXuNGYBuNjy0FnXXX5lpXa-718-1.png'
                },
                {
                    name: '保证不收租客中介费，在线房源发布不限制。',
                    Id: 55,
                    nameId: '7D5F0223-F863-4F7A-84AE-129639AADA5D',
                    frame: { width: 619, height: 74, x: 101, y: 710 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#888888',
                        lineHeight: '39',
                        textAlign: 'left',
                        fontWeight: 'normal'
                    },
                    value: '保证不收租客中介费，在线房源发布不限制。你的所有房源将会获得             标签',
                    type: 'text'
                },
                {
                    name: 'Bitmap',
                    Id: 56,
                    nameId: '52CEDFD3-D4A3-46B1-94F2-B72DDF9A4CD3',
                    frame: { width: 44, height: 44, x: 34, y: 657 },
                    imageStyles: { resize: 'stretch' },
                    type: 'image',
                    value: 'https://gw.alicdn.com/tfs/TB1sr8ouHGYBuNjy0FoXXciBFXa-44-44.png'
                }
            ],
            type: 'group',
            objectID: '65C92224-92DF-4A45-82BF-1F2848D91CAC'
        },
        {
            name: 'Group 9',
            Id: 58,
            nameId: 'C0300639-3C0B-40C4-A270-C5B6D144B795',
            frame: { width: 750, height: 1346, x: 1, y: 0 },
            layers: [
                {
                    name: 'Rectangle',
                    Id: 59,
                    nameId: '161AFE1F-BE49-4B11-946F-3A09B01F6E1E',
                    frame: { width: 750, height: 1346.000000000002, x: 1, y: 0 },
                    styles: { backgroundColor: 'rgba(0,0,0,0.6)' },
                    type: 'shape'
                }
            ],
            type: 'group',
            objectID: 'C0300639-3C0B-40C4-A270-C5B6D144B795'
        },
        {
            name: 'Group 2',
            Id: 61,
            nameId: '9EA19E72-93DD-4902-A0E6-714673D4C311',
            frame: { width: 638, height: 326, x: 57, y: 497 },
            layers: [
                {
                    name: 'Group',
                    Id: 63,
                    nameId: '0EB2F654-B043-4227-9B97-E1384433B99C',
                    frame: { width: 638, height: 326, x: 57, y: 497 },
                    layers: [
                        {
                            name: 'Rectangle',
                            Id: 64,
                            nameId: 'A02760EF-3414-44C7-BD18-5F3E6A00FE4C',
                            frame: { width: 637.5, height: 325.8333333333326, x: 57, y: 497 },
                            styles: { backgroundColor: 'rgba(255,255,255,1)', borderRadius: 8 },
                            type: 'shape'
                        },
                        {
                            name: 'Bitmap',
                            Id: 65,
                            nameId: 'E490F032-47BE-4A21-AD06-0258B579006A',
                            frame: { width: 638, height: 2, x: 57, y: 722 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB10kGxuL1TBuNjy0FjXXajyXXa-638-2.png'
                        },
                        {
                            name: 'Rectangle',
                            Id: 66,
                            nameId: '5D920609-68DA-4B50-AB3C-3D0EEABF9D4C',
                            frame: { width: 1.0416666666667425, height: 100, x: 376, y: 722.8333333333321 },
                            styles: { backgroundColor: 'rgba(229,229,229,1)' },
                            type: 'shape'
                        },
                        {
                            name: '次按钮',
                            Id: 68,
                            nameId: 'A545AEBB-17F6-4642-80D6-62FE79645F3A',
                            frame: { width: 64, height: 46, x: 190.66666666666788, y: 750.9166666666679 },
                            layers: [
                                {
                                    name: '取消',
                                    Id: 69,
                                    nameId: 'E8334F40-240B-4F44-9C74-73FC9D74A333',
                                    frame: { width: 64, height: 45, x: 190.66666666666788, y: 751.1166674296073 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: 32,
                                        color: '#222222',
                                        textAlign: 'center',
                                        lineHeight: '44.79999923706055',
                                        fontWeight: 'normal'
                                    },
                                    value: '取消',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'A545AEBB-17F6-4642-80D6-62FE79645F3A'
                        },
                        {
                            name: 'Bitmap',
                            Id: 70,
                            nameId: '94ACD41B-EE81-4619-9C68-B25C34762EE0',
                            frame: { width: 319, height: 101, x: 376, y: 722 },
                            imageStyles: { resize: 'stretch' },
                            type: 'image',
                            value: 'https://gw.alicdn.com/tfs/TB1.qeXuNGYBuNjy0FnXXX5lpXa-319-101.png'
                        },
                        {
                            name: '主按钮',
                            Id: 72,
                            nameId: 'E20AB9D8-CE4E-4FAF-9438-6DE7B7BF4F75',
                            frame: { width: 64, height: 46, x: 508.4166666666679, y: 750.9166666666679 },
                            layers: [
                                {
                                    name: '确定',
                                    Id: 73,
                                    nameId: '07724B72-EC48-4E9F-80C9-05D3B2406825',
                                    frame: { width: 64, height: 45, x: 508.4166666666679, y: 751.1166674296073 },
                                    textStyles: {
                                        fontFamily: 'PingFangSC-Regular',
                                        fontSize: 32,
                                        color: '#333333',
                                        textAlign: 'center',
                                        lineHeight: '44.79999923706055',
                                        fontWeight: 'normal'
                                    },
                                    value: '确定',
                                    type: 'text'
                                }
                            ],
                            type: 'group',
                            objectID: 'E20AB9D8-CE4E-4FAF-9438-6DE7B7BF4F75'
                        },
                        {
                            name: '确定要申请”免费中介”？',
                            Id: 74,
                            nameId: '450558E3-ADDF-4B84-9DEB-152199794008',
                            frame: { width: 359, height: 48, x: 197, y: 564 },
                            textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 32,
                                color: '#333333',
                                textAlign: 'center',
                                lineHeight: '48',
                                fontWeight: 'bold'
                            },
                            value: '确定要申请”免费中介”？',
                            type: 'text'
                        }
                    ],
                    type: 'group',
                    objectID: '0EB2F654-B043-4227-9B97-E1384433B99C'
                },
                {
                    name: '该身分申请成功后，6个月内不能修改身份',
                    Id: 75,
                    nameId: '3F54AE8A-A79D-4C9A-B3BF-C32B891AC4BD',
                    frame: { width: 521, height: 40, x: 118, y: 624 },
                    textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#888888',
                        textAlign: 'center',
                        lineHeight: '40',
                        fontWeight: 'normal'
                    },
                    value: '该身分申请成功后，6个月内不能修改身份',
                    type: 'text'
                }
            ],
            type: 'group',
            objectID: '9EA19E72-93DD-4902-A0E6-714673D4C311'
        }
    ],
    nameId: 1527761467445,
    Id: 1,
    type: 'group',
    frame: { x: 0, y: 0, width: 752, height: 1346 },
    styles: { backgroundColor: 'rgba(255,255,255,1)' }
};
