"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
function size(collect) {
    var type = typof_1.default(collect);
    if (type === 'array' || type === 'string') {
        return collect.length;
    }
    else if (type === 'object') {
        var count_1 = 0;
        Object.keys(collect).forEach(function (k) {
            if (collect.hasOwnProperty(k)) {
                count_1++;
            }
        });
        return count_1;
    }
    return 0;
}
exports.default = size;
