"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var equals_1 = require("./equals");
function folded(arr, equalsFunc) {
    equalsFunc = equalsFunc || equals_1.default;
    return arr.reduce(function (pre, cur, index) {
        var tail = pre[pre.length - 1];
        if (tail && equals_1.default(tail.value, cur)) {
            tail.count++;
        }
        else {
            pre.push({ value: cur, index: index, count: 1 });
        }
        return pre;
    }, []);
}
exports.folded = folded;
function hasRepeat(head, remains, equalsFunc) {
    if (head.length <= remains.length) {
        return head.every(function (item, i) { return equalsFunc(item, remains[i]); });
    }
    return false;
}
function folded2(arr, equalsFunc) {
    if (arr === undefined || arr.length === 0) {
        return [];
    }
    else if (arr.length <= 3) {
        return [{ arr: arr.slice(), count: 1 }];
    }
    equalsFunc = equalsFunc || equals_1.default;
    var head = arr[0];
    var i = 1;
    for (; i <= arr.length / 2; i++) {
        if (!equalsFunc(head, arr[i])) {
            i++;
            break;
        }
    }
    for (; i <= arr.length / 2; i++) {
        var frag = arr.slice(0, i);
        var remains = arr.slice(i);
        var result_1 = { arr: frag.slice(), count: 1 };
        while (hasRepeat(frag, remains, equalsFunc)) {
            result_1.count++;
            remains = remains.slice(i);
        }
        if (result_1.count > 1) {
            return [result_1].concat(folded2(remains, equalsFunc));
        }
    }
    var result = folded2(arr.slice(1), equalsFunc);
    if (result[0].count === 1) {
        result[0].arr.unshift(head);
    }
    else {
        result.unshift({ arr: [head], count: 1 });
    }
    return result;
}
exports.folded2 = folded2;
