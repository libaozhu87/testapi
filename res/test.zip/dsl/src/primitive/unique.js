"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function unique(arr) {
    return arr && arr.filter(function (v, index) { return arr.indexOf(v) === index; });
}
exports.default = unique;
