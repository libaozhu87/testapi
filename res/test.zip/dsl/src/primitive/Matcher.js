"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Match_1 = require("./Match");
var pred_1 = require("./pred");
var toString_1 = require("./toString");
var Matcher = (function () {
    function Matcher() {
        this._match = new Match_1.Match();
        this._cache = undefined;
        this._defaultReturn = this;
    }
    Matcher.prototype.preprocess = function (map) {
        this._match.preprocess(map);
        return this;
    };
    Matcher.prototype.postprocess = function (map) {
        this._match.postprocess(map);
        return this;
    };
    Matcher.prototype.cacheEnabled = function () {
        this._cache = {};
        return this;
    };
    Matcher.prototype.strict = function (strict) {
        this._match.strict(strict);
        return this;
    };
    Matcher.prototype.case = function (cond, tap) {
        this._match.case.apply(this._match, arguments);
        return this;
    };
    Matcher.prototype.default = function (tap) {
        this.case(pred_1.default.T, tap);
        return this._defaultReturn;
    };
    Matcher.prototype.setDefaultReturn = function (defaultReturn) {
        return (this._defaultReturn = defaultReturn);
    };
    Matcher.prototype.invoke = function () {
        var params = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            params[_i] = arguments[_i];
        }
        var _a, _b;
        if (this._cache) {
            var key = toString_1.default(params);
            var cache = this._cache[key];
            if (!cache) {
                cache = [(_a = this._match).invoke.apply(_a, params)];
                this._cache[key] = cache;
            }
            return cache[0];
        }
        else {
            return (_b = this._match).invoke.apply(_b, params);
        }
    };
    Matcher.prototype.append = function (otherMatcher) {
        this._match.append(otherMatcher._match);
        return this;
    };
    return Matcher;
}());
exports.Matcher = Matcher;
function matcher() {
    return new Matcher();
}
exports.matcher = matcher;
