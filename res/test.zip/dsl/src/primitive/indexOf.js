"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function indexOf(arr, pred) {
    if (arr) {
        if (typeof pred === 'function') {
            var length_1 = arr.length;
            for (var i = 0; i < length_1; i++) {
                if (pred(arr[i], i, arr)) {
                    return i;
                }
            }
        }
        else {
            return arr.indexOf(pred);
        }
    }
    return -1;
}
exports.default = indexOf;
