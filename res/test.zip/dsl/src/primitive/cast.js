"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
var isMatch_1 = require("./isMatch");
function toFunction(v) {
    return typof_1.default(v) === 'function' ? v : v && v.invoke ? function (nv) { return v.invoke(nv); } : function () { return v; };
}
function toValue(v) {
    var args = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        args[_i - 1] = arguments[_i];
    }
    return typof_1.default(v) === 'function'
        ? v.apply(void 0, args) :
        v;
}
function toValue2(v) {
    var args = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        args[_i - 1] = arguments[_i];
    }
    return typof_1.default(v) === 'function' ? v.apply(void 0, args) : v && v.invoke ? v.invoke.apply(v, args) : v;
}
function toArray(v) {
    return Array.isArray(v) ? v : [v];
}
function toPred(cond, strict) {
    var type = typof_1.default(cond);
    return type === 'function'
        ? function () {
            return cond.apply(this, arguments);
        }
        :
            function (target) { return isMatch_1.default(target, cond, strict); };
}
exports.default = {
    toArray: toArray,
    toFunction: toFunction,
    toValue: toValue,
    toValue2: toValue2,
    toPred: toPred
};
