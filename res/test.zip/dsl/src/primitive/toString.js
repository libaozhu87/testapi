"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
function toString(v) {
    var type = typof_1.default(v);
    if (type === 'object' || type === 'array') {
        return JSON.stringify(v);
    }
    else {
        return String(v);
    }
}
exports.default = toString;
