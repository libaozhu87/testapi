"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_js_1 = require("./typof.js");
function isType(type, v) {
    return typof_js_1.default(v) === type;
}
exports.default = isType;
