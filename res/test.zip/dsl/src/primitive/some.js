"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
function some(collect, predicate) {
    var type = typof_1.default(collect);
    if (type === 'array') {
        return collect.some(predicate);
    }
    else if (type === 'object') {
        Object.keys(collect).forEach(function (k) {
            if (collect.hasOwnProperty(k)) {
                if (predicate(collect[k], k, collect)) {
                    return true;
                }
            }
        });
        return false;
    }
    else {
        return false;
    }
}
exports.default = some;
