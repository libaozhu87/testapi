"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var identical_js_1 = require("./identical.js");
function equalsIgnoreCase(a, b) {
    return typeof a === 'string' && typeof b === 'string' ? a.toLowerCase() === b.toLowerCase() : identical_js_1.default(a, b);
}
exports.default = equalsIgnoreCase;
