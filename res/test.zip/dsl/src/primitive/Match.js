"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var cast_1 = require("./cast");
var Exception_1 = require("./Exception");
var pred_1 = require("./pred");
var isMatch_1 = require("./isMatch");
var Match = (function () {
    function Match() {
        this._cases = [];
        this._strict = true;
    }
    Match.prototype.preprocess = function (map) {
        this._preprocess = map;
        return this;
    };
    Match.prototype.postprocess = function (map) {
        this._postprocess = map;
        return this;
    };
    Match.prototype.strict = function (strict) {
        this._strict = strict;
        return this;
    };
    Match.prototype.case = function (condition, action) {
        this._cases.push(arguments.length <= 1 ? [condition] : [condition, action]);
        return this;
    };
    Match.prototype.append = function (otherMatch) {
        this._cases.concat(otherMatch._cases);
        return this;
    };
    Match.prototype.default = function (action) {
        return this.case(pred_1.default.T, action);
    };
    Match.prototype.invoke = function () {
        var params = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            params[_i] = arguments[_i];
        }
        var input = this.handlePreprocess.apply(this, params);
        var matched = false;
        for (var _a = 0, _b = this._cases; _a < _b.length; _a++) {
            var aCase = _b[_a];
            if (matched || isMatch_1.default(input, aCase[0], this._strict)) {
                matched = true;
                if (aCase.length > 1) {
                    var output = cast_1.default.toValue2(aCase[1], input);
                    return this.handlePostprocess(output, input);
                }
            }
        }
        throw new Exception_1.Exception('NoMatchError');
    };
    Match.prototype.handlePreprocess = function () {
        var params = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            params[_i] = arguments[_i];
        }
        return this._preprocess ? this._preprocess.apply(this, params) : params[0];
    };
    Match.prototype.handlePostprocess = function (output, input) {
        return this._postprocess ? this._postprocess(output, input) : output;
    };
    return Match;
}());
exports.Match = Match;
function match() {
    return new Match();
}
exports.match = match;
