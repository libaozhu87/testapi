"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function range(start, stop, step) {
    if (stop === undefined) {
        stop = start || 0;
        start = 0;
    }
    step = step || 1;
    var length = Math.max(Math.ceil((stop - start) / step), 0);
    var arr = Array(length);
    for (var idx = 0; idx < length; idx++, start += step) {
        arr[idx] = start;
    }
    return arr;
}
exports.default = range;
