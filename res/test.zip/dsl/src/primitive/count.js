"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var isEmpty_1 = require("./isEmpty");
function count(arr, value) {
    if (isEmpty_1.default(arr)) {
        return 0;
    }
    else {
        return arr.reduce(function (pre, cur) { return pre + (cur === value ? 1 : 0); }, 0);
    }
}
exports.default = count;
