"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Exception = (function () {
    function Exception(code, msg, data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }
    return Exception;
}());
exports.Exception = Exception;
function exception(code, msg, data) {
    return new Exception(code, msg, data);
}
exports.exception = exception;
