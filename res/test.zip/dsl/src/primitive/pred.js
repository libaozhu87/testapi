"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var cmp_1 = require("./cmp");
var curry_1 = require("./curry");
var equalsIgnoreCase_1 = require("./equalsIgnoreCase");
var isEmpty_1 = require("./isEmpty");
var isType_1 = require("./isType");
var logic_1 = require("./logic");
var prop_1 = require("./prop");
function functor2(func) {
    return function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return args.length === 0 ? func : args.length === 1 ? function (target) { return func(target, args[0]); } : func(args[0], args[1]);
    };
}
function functorRest(func) {
    return function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return function (target) { return func(target, [].slice.call(args, 0)); };
    };
}
exports.default = {
    eq: functor2(cmp_1.default.equals),
    gte: functor2(cmp_1.default.gte),
    gt: functor2(cmp_1.default.gt),
    lte: functor2(cmp_1.default.lte),
    lt: functor2(cmp_1.default.lt),
    feq: functor2(cmp_1.default.fequals),
    fgte: functor2(cmp_1.default.fgte),
    fgt: functor2(cmp_1.default.fgt),
    flte: functor2(cmp_1.default.flte),
    flt: functor2(cmp_1.default.flt),
    and: functorRest(logic_1.default.and),
    or: functorRest(logic_1.default.or),
    not: functor2(logic_1.default.not),
    equalsIgnoreCase: functor2(equalsIgnoreCase_1.default),
    T: logic_1.default.T,
    F: logic_1.default.F,
    isEmpty: isEmpty_1.default,
    isType: curry_1.default.curry(isType_1.default),
    prop: curry_1.default.curry(prop_1.default)
};
