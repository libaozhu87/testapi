"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function flatten(arr, deep) {
    if (deep === void 0) { deep = false; }
    return arr.reduce(function (flat, toFlatten) {
        return flat.concat(deep && Array.isArray(toFlatten) ? flatten(toFlatten, true) : toFlatten);
    }, []);
}
exports.default = flatten;
