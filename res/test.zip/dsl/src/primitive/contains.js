"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function contains(collect, value) {
    return collect && collect.indexOf(value) !== -1;
}
exports.default = contains;
