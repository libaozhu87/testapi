"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var logger_1 = require("./logger");
function assert(cond) {
    var msg = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        msg[_i - 1] = arguments[_i];
    }
    if (!cond) {
        if (msg) {
            logger_1.default.log.apply(logger_1.default, msg);
        }
        throw new Error("");
    }
}
exports.default = assert;
