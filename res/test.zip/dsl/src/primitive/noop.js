"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function noop() { }
exports.default = noop;
