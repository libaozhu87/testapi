"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
var toString_1 = require("./toString");
function stringify(rootObj) {
    var type = typof_1.default(rootObj);
    if (type === null || type !== 'object') {
        return toString_1.default(rootObj);
    }
    else {
        var kvParis = [];
        for (var key in rootObj) {
            if (rootObj.hasOwnProperty(key)) {
                var value = toString_1.default(rootObj[key]);
                var enValue = encodeURIComponent(value);
                kvParis.push(key + "=" + enValue);
            }
        }
        return kvParis.join('&');
    }
}
function parse(url) {
    if (url) {
        var index = url.indexOf('?');
        var str = index === -1 ? url : url.substr(index + 1);
        var pairs = str.split('&');
        var target = {};
        for (var i = 0; pairs && i < pairs.length; i++) {
            var kv = pairs[i].split('=');
            var k = kv[0];
            var v = decodeURIComponent(kv[1]);
            var rawV = void 0;
            try {
                rawV = JSON.parse(v);
            }
            catch (e) {
                rawV = v;
            }
            target[k] = rawV;
        }
        return target;
    }
    return url;
}
function join() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    return args
        .filter(function (v) { return v; })
        .map(stringify)
        .join('&')
        .replace(/[?|&]+/g, '&')
        .replace('&', '?');
}
exports.default = {
    stringify: stringify,
    parse: parse,
    join: join
};
