"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var equals_1 = require("./equals");
var THRESHOLD = 0.0000001;
exports.default = {
    equals: equals_1.default,
    gt: function (a, b) { return a > b; },
    gte: function (a, b) { return a >= b; },
    lt: function (a, b) { return a < b; },
    lte: function (a, b) { return a <= b; },
    fequals: function (a, b) { return Math.abs(a - b) <= THRESHOLD; },
    fgt: function (a, b) { return a - b > THRESHOLD; },
    fgte: function (a, b) { return a - b >= -THRESHOLD; },
    flt: function (a, b) { return a - b < -THRESHOLD; },
    flte: function (a, b) { return a - b <= THRESHOLD; }
};
