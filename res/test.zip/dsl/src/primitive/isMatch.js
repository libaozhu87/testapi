"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var equalsLoose_1 = require("./equalsLoose");
var identical_1 = require("./identical");
var prop_1 = require("./prop");
var typof_1 = require("./typof");
function matchObject(target, cond) {
    var typeTarget = typof_1.default(target);
    if (typeTarget === 'array') {
        var keys = Object.keys(cond);
        return keys.length === 1 && keys[0] === 'length' ? isMatch(target.length, cond.length, undefined) : false;
    }
    else if (typeTarget === 'object') {
        for (var k in cond) {
            if (!isMatch(prop_1.default(k, target), prop_1.default(k, cond), undefined)) {
                return false;
            }
        }
        return true;
    }
    else {
        return false;
    }
}
function matchArray(target, cond) {
    if (typof_1.default(target) === 'array') {
        for (var i in cond) {
            if (!isMatch(target[i], cond[i], undefined)) {
                return false;
            }
        }
        return true;
    }
    return false;
}
function matchRegexp(target, cond) {
    return cond.test(target);
}
function matchBoolean(target, cond) {
    return !!target === cond;
}
function matchPrimitive(target, cond, strict) {
    return strict ? identical_1.default(target, cond) : equalsLoose_1.default(target, cond);
}
function isMatch(target, cond, strict) {
    var type = typof_1.default(cond);
    return type === 'function'
        ? cond(target)
        : type === 'object'
            ? matchObject(target, cond)
            : type === 'array'
                ? matchArray(target, cond)
                : type === 'regexp' ? matchRegexp(target, cond) : type === 'boolean' ? matchBoolean(target, cond) : matchPrimitive(target, cond, strict);
}
exports.default = isMatch;
