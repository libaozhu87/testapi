"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function remove(arr, value) {
    if (arr === undefined) {
        return -1;
    }
    var index = arr.indexOf(value);
    if (index !== -1) {
        arr.splice(index, 1);
    }
    return index;
}
exports.default = remove;
