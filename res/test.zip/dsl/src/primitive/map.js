"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
function map(collect, iteratee) {
    var type = typof_1.default(collect);
    if (type === 'array') {
        return collect.map(iteratee);
    }
    else if (type === 'object') {
        var result_1 = {};
        Object.keys(collect).forEach(function (k) {
            if (collect.hasOwnProperty(k)) {
                result_1[k] = iteratee(collect[k], k, collect);
            }
        });
        return result_1;
    }
}
exports.default = map;
