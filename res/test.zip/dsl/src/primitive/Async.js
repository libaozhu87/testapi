"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var cast_1 = require("./cast");
var logger_1 = require("./logger");
var Matcher_1 = require("./Matcher");
var Moment_1 = require("./Moment");
var prop_1 = require("./prop");
var toString_1 = require("./toString");
function noop() {
    return undefined;
}
function identity(e, v, ctx, cb) {
    return cb(e, v, ctx);
}
function trust() {
    return true;
}
function assert(cond, msg) {
    if (!cond) {
        throw new Error(msg);
    }
}
var SysError = (function () {
    function SysError(type, message, data) {
        this.type = type;
        this.message = message;
        this.data = data;
    }
    return SysError;
}());
var BreakError = (function (_super) {
    __extends(BreakError, _super);
    function BreakError(data) {
        return _super.call(this, 'break', 'break-error', data) || this;
    }
    return BreakError;
}(SysError));
var ContinueError = (function (_super) {
    __extends(ContinueError, _super);
    function ContinueError(data) {
        return _super.call(this, 'continue', 'continue-error', data) || this;
    }
    return ContinueError;
}(SysError));
var CancelError = (function (_super) {
    __extends(CancelError, _super);
    function CancelError() {
        return _super.call(this, 'cancel', 'cancel-error', undefined) || this;
    }
    return CancelError;
}(SysError));
var DONE_LEVEL;
(function (DONE_LEVEL) {
    DONE_LEVEL[DONE_LEVEL["CANCELED"] = 1] = "CANCELED";
    DONE_LEVEL[DONE_LEVEL["CATCHED"] = 2] = "CATCHED";
    DONE_LEVEL[DONE_LEVEL["COMPLETED"] = 3] = "COMPLETED";
})(DONE_LEVEL = exports.DONE_LEVEL || (exports.DONE_LEVEL = {}));
var SWALLOW_ERROR_LEVEL;
(function (SWALLOW_ERROR_LEVEL) {
    SWALLOW_ERROR_LEVEL[SWALLOW_ERROR_LEVEL["NEVER"] = 0] = "NEVER";
    SWALLOW_ERROR_LEVEL[SWALLOW_ERROR_LEVEL["CANCELED"] = 1] = "CANCELED";
    SWALLOW_ERROR_LEVEL[SWALLOW_ERROR_LEVEL["CATCHED"] = 2] = "CATCHED";
    SWALLOW_ERROR_LEVEL[SWALLOW_ERROR_LEVEL["ALL"] = 3] = "ALL";
})(SWALLOW_ERROR_LEVEL = exports.SWALLOW_ERROR_LEVEL || (exports.SWALLOW_ERROR_LEVEL = {}));
function isUncatchable(e) {
    return e instanceof SysError;
}
function series(a1, a2) {
    return function (e, v, ctx, cb) { return a1(e, v, ctx, function (ne, nv, nctx) { return a2(ne, nv, nctx, cb); }); };
}
function synthetise(executer, catcher) {
    return function (e, v, ctx, cb) {
        if (ctx.isDone()) {
            return ctx;
        }
        else if (isUncatchable(e)) {
            return cb(e, undefined, ctx);
        }
        else {
            if (e) {
                if (catcher) {
                    var catched = false;
                    try {
                        catcher(e, new AdvancedContext(ctx, cb));
                        catched = true;
                    }
                    catch (ne) {
                        cb(ne, undefined, ctx);
                    }
                    if (catched) {
                        ctx.complete(e, undefined, DONE_LEVEL.CATCHED);
                    }
                }
                else {
                    return cb(e, undefined, ctx);
                }
            }
            else {
                if (executer) {
                    try {
                        executer(v, new AdvancedContext(ctx, cb));
                    }
                    catch (ne) {
                        cb(ne, undefined, ctx);
                    }
                }
                else {
                    cb(undefined, v, ctx);
                }
            }
        }
        return ctx;
    };
}
var Branches = (function () {
    function Branches() {
        this._cases = [];
        this._closed = false;
    }
    Branches.prototype.case = function (cond, closed) {
        assert(this._closed === false, 'Unexpected "else/elseif" follows behind "else"');
        this._closed = closed;
        var tuple = { condition: cast_1.default.toPred(cond), method: identity };
        this._cases.push(tuple);
    };
    Branches.prototype.append = function (asyncable) {
        var top = this._cases[this._cases.length - 1];
        top.method = series(top.method, asyncable);
        return this;
    };
    Branches.prototype.toAsyncable = function () {
        var _this_1 = this;
        return function (e, v, ctx, cb) {
            if (ctx.isDone()) {
                return ctx;
            }
            if (e) {
                return cb(e, undefined, ctx);
            }
            for (var _i = 0, _a = _this_1._cases; _i < _a.length; _i++) {
                var tuple = _a[_i];
                var condition = tuple.condition;
                var method = tuple.method;
                if (condition(v, ctx)) {
                    return method(undefined, v, ctx, cb);
                }
            }
            return cb(undefined, v, ctx);
        };
    };
    return Branches;
}());
var ErrorScope = (function () {
    function ErrorScope() {
        this._method = identity;
    }
    ErrorScope.prototype.append = function (asyncable) {
        this._method = series(this._method, asyncable);
        return this;
    };
    ErrorScope.prototype.toAsyncable = function () {
        var _this_1 = this;
        return function (e, v, ctx, cb) {
            if (ctx.isDone()) {
                return ctx;
            }
            if (!e) {
                return cb(undefined, v, ctx);
            }
            else if (isUncatchable(e)) {
                return cb(e, undefined, ctx);
            }
            return _this_1._method(undefined, e, ctx, cb);
        };
    };
    return ErrorScope;
}());
var Looper = (function () {
    function Looper(iterator) {
        this._iterator = iterator;
        this._method = identity;
    }
    Looper.prototype.append = function (asyncable) {
        this._method = series(this._method, asyncable);
        return this;
    };
    Looper.prototype.toAsyncable = function () {
        var _this_1 = this;
        var method = this._method;
        return function (e, v, ctx, cb) {
            if (ctx.isDone()) {
                return ctx;
            }
            var iter = _this_1._iterator(v, ctx);
            var flatMethod = function (fe, fv, fctx) {
                if (fe instanceof BreakError) {
                    return cb(undefined, fe.data, fctx);
                }
                else if (fe instanceof ContinueError) {
                    return flatMethod(undefined, fe.data, ctx);
                }
                else if (fe) {
                    return cb(fe, undefined, fctx);
                }
                else {
                    var result = iter(fv, fctx);
                    if (!result.isDone) {
                        return method(undefined, result.value, fctx, flatMethod);
                    }
                    else {
                        return cb(undefined, fv, fctx);
                    }
                }
            };
            return flatMethod(e, v, ctx);
        };
    };
    return Looper;
}());
var Main = (function () {
    function Main() {
        this._method = identity;
    }
    Main.prototype.append = function (asyncable) {
        this._method = series(this._method, asyncable);
        return this;
    };
    Main.prototype.toAsyncable = function () {
        return this._method;
    };
    return Main;
}());
var Context = (function () {
    function Context(global, outterCanceller, swallowErrorLevel, callback) {
        this.global = global;
        this.locals = {};
        this._isDone = false;
        this._outterCanceller = outterCanceller;
        this._callback = callback;
        this._swallowErrorLevel = swallowErrorLevel;
    }
    Context.prototype.isDone = function () {
        if (!this._isDone) {
            if (cast_1.default.toValue(this._outterCanceller)) {
                logger_1.default.log('outter-cancel');
                this.cancel();
            }
        }
        return this._isDone;
    };
    Context.prototype.cancel = function () {
        logger_1.default.log('cancel');
        return this.complete(new CancelError(), undefined, DONE_LEVEL.CANCELED);
    };
    Context.prototype.complete = function (e, v, level) {
        if (!this._isDone) {
            logger_1.default.log('done', e, v);
            this._isDone = true;
            this._outterCanceller = undefined;
            var callback = this._callback;
            this._callback = undefined;
            if (!(e && this._swallowErrorLevel >= level)) {
                return callback(e, v, this);
            }
        }
        else {
            logger_1.default.log('Unexpected done called again.');
        }
        return this;
    };
    return Context;
}());
var AdvancedContext = (function () {
    function AdvancedContext(ctx, cb) {
        this.locals = ctx.locals;
        this._ctx = ctx;
        this._callback = cb;
    }
    AdvancedContext.prototype.break = function (v) {
        return this._callback(new BreakError(v), undefined, this._ctx);
    };
    AdvancedContext.prototype.continue = function (v) {
        return this._callback(new ContinueError(v), undefined, this._ctx);
    };
    AdvancedContext.prototype.next = function (v) {
        return this._callback(undefined, v, this._ctx);
    };
    AdvancedContext.prototype.error = function (e) {
        return this._callback(e, undefined, this._ctx);
    };
    AdvancedContext.prototype.accept = function (e, v) {
        return this._callback(e, v, this._ctx);
    };
    AdvancedContext.prototype.isDone = function () {
        return this._ctx.isDone();
    };
    AdvancedContext.prototype.cancel = function () {
        return this._ctx.cancel();
    };
    AdvancedContext.prototype.complete = function (e, v, level) {
        if (level === void 0) { level = DONE_LEVEL.COMPLETED; }
        return this._ctx.complete(e, v, level);
    };
    return AdvancedContext;
}());
exports.AdvancedContext = AdvancedContext;
var Async = (function () {
    function Async() {
        this._swallowErrorLevel = SWALLOW_ERROR_LEVEL.CATCHED;
        this._stageStack = [new Main()];
        this._global = {};
    }
    Async.prototype.append = function (asyncable) {
        var topStage = this._stageStack[this._stageStack.length - 1];
        topStage.append(asyncable);
        return this;
    };
    Async.prototype.toAsyncable = function () {
        assert(this._stageStack.length === 1, 'Expected "end".');
        return this._stageStack[0].toAsyncable();
    };
    Async.prototype.then = function (executer, catcher) {
        return this.append(synthetise(executer, catcher));
    };
    Async.prototype.maxConcurrency = function (max) {
        max = cast_1.default.toValue(max);
        if (max <= 0) {
            return this;
        }
        var conManager = { array: [] };
        return this.action(function (v, ctx) {
            conManager.array = conManager.array.filter(function (con) { return !con.isDone(); });
            if (conManager.array.indexOf(ctx) === -1) {
                conManager.array.push(ctx);
                while (conManager.array.length > max) {
                    var con = conManager.array.shift();
                    logger_1.default.log('Canceled by max concurrency.');
                    con.cancel();
                }
            }
        });
    };
    Async.prototype.setSwallowErrorLevel = function (swallowErrorLevel) {
        this._swallowErrorLevel = swallowErrorLevel;
        return this;
    };
    Async.prototype.invoke = function (v, cb) {
        return this.accept(undefined, v, undefined, cb);
    };
    Async.prototype.accept = function (e, v, ctx, cb) {
        cb = typeof cb === 'function' ? cb : noop;
        ctx = ctx === undefined ? this.newCtx(cb) : ctx;
        var asyncable = this.toAsyncable();
        asyncable.call(this, e, v, ctx, function (ne, nv) { return ctx.complete(ne, nv, DONE_LEVEL.COMPLETED); });
        return ctx;
    };
    Async.prototype.apply = function (_this, args) {
        return this.invoke(args[0]);
    };
    Async.prototype.call = function (_this, arg) {
        return this.invoke(arg);
    };
    Async.prototype.if = function (cond) {
        var stage = new Branches();
        stage.case(cond, false);
        this._stageStack.push(stage);
        return this;
    };
    Async.prototype.elseif = function (cond) {
        var stage = this._stageStack[this._stageStack.length - 1];
        assert(stage instanceof Branches, '"elseif/else" must follows behind "if".');
        stage.case(cond, false);
        return this;
    };
    Async.prototype.else = function () {
        var stage = this._stageStack[this._stageStack.length - 1];
        assert(stage instanceof Branches, '"elseif/else" must follows behind "if".');
        stage.case(trust, true);
        return this;
    };
    Async.prototype.whenError = function () {
        var stage = new ErrorScope();
        this._stageStack.push(stage);
        return this;
    };
    Async.prototype.end = function () {
        var stage0 = this._stageStack.pop();
        var stage1 = this._stageStack.pop();
        assert(stage0 && stage1, '"end" is expected in a loop/branches scope');
        this._stageStack.push(stage1.append(stage0.toAsyncable()));
        return this;
    };
    Async.prototype.break = function () {
        assert(this.isInLooper(), "break is expected in a loop scope.");
        return this.then(function (v, ctx) { return ctx.break(v); });
    };
    Async.prototype.continue = function () {
        assert(this.isInLooper(), "continue is expected in a loop scope.");
        return this.then(function (v, ctx) { return ctx.continue(v); });
    };
    Async.prototype.repeat = function (value) {
        var stage = new Looper(function (v, ctx) {
            var n = Number(cast_1.default.toValue(value, v, ctx));
            return function (iv) { return ({ isDone: !(--n >= 0), value: iv }); };
        });
        this._stageStack.push(stage);
        return this;
    };
    Async.prototype.forEach = function () {
        var stage = new Looper(function (v, ctx) {
            var index = -1;
            return function () { return (++index < v.length ? { value: v[index], isDone: false } : { isDone: true }); };
        });
        this._stageStack.push(stage);
        return this;
    };
    Async.prototype.for = function (begin, end, step) {
        step = step ? 1 : step;
        var stage = new Looper(function () {
            var index = begin;
            return function () {
                var ret = (step > 0 && index >= end) || (step < 0 && index <= end) ? { isDone: true } : { value: index, isDone: false };
                index = index + step;
                return ret;
            };
        });
        this._stageStack.push(stage);
        return this;
    };
    Async.prototype.while = function (cond) {
        var stage = new Looper(function (v, ctv) {
            var pred = cast_1.default.toPred(cond, v);
            return function (iv, ictx) { return ({ isDone: !pred(iv, ictx), value: iv }); };
        });
        this._stageStack.push(stage);
        return this;
    };
    Async.prototype.throttle = function (mills) {
        var isInLoop = this.isInLooper();
        var mark = 0;
        return this.then(function (v, ctx) {
            var now = new Date().getTime();
            if (mark + mills <= now) {
                mark = now;
                return ctx.next(v);
            }
            else {
                logger_1.default.log('swallow throttle.');
                if (isInLoop) {
                    return ctx.continue(v);
                }
                else {
                    return ctx.cancel();
                }
            }
        });
    };
    Async.prototype.debounce = function (mills) {
        var isInLoop = this.isInLooper();
        var newestMap;
        return this.action(function (v, ctx) {
            newestMap = ctx.locals;
        })
            .wait(mills)
            .then(function (v, ctx) {
            if (newestMap === ctx.locals) {
                newestMap = undefined;
                return ctx.next(v);
            }
            else {
                logger_1.default.log('swallow debounce.');
                if (isInLoop) {
                    return ctx.continue(v);
                }
                else {
                    ctx.cancel();
                }
            }
        });
    };
    Async.prototype.switch = function () {
        var aMatcher = new Matcher_1.Matcher();
        var next = this.then(function (v, ctx) { return ctx.next(aMatcher.invoke(v)); });
        aMatcher.setDefaultReturn(next);
        return aMatcher;
    };
    Async.prototype.all = function () {
        var workers = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            workers[_i] = arguments[_i];
        }
        var executeable = this.merge(function (context, index, v, ctx) {
            context.arrived++;
            context.values[index] = v;
            if (context.arrived === workers.length) {
                context.triggered = true;
                ctx.next(context.values);
            }
        }, workers);
        return this.append(executeable);
    };
    Async.prototype.race = function () {
        var workers = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            workers[_i] = arguments[_i];
        }
        var executeable = this.merge(function (context, index, v, ctx) {
            context.triggered = true;
            ctx.next({ index: index, v: v });
        }, workers);
        return this.append(executeable);
    };
    Async.prototype.sequence = function () {
        var workers = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            workers[_i] = arguments[_i];
        }
        var asyncable = workers.map(function (async) { return async.toAsyncable(); }).reduce(series, identity);
        return this.append(asyncable);
    };
    Async.prototype.callWorker = function (worker) {
        return this.append(function (e, v, ctx, cb) {
            var realWorker = typeof worker === 'function' ? worker(v, ctx) : worker;
            return realWorker.accept(e, v, ctx, cb);
        });
    };
    Async.prototype.recurse = function () {
        var _this_1 = this;
        return this.then(function (v, ctx) { return _this_1.invoke(v, function (ne, nv) { return ctx.accept(ne, nv); }); });
    };
    Async.prototype.catch = function (catcher) {
        return this.then(undefined, catcher);
    };
    Async.prototype.map = function (value) {
        return this.then(function (v, ctx) { return ctx.next(cast_1.default.toValue(value, v, ctx)); });
    };
    Async.prototype.throw = function (e) {
        return this.then(function (v, ctx) { return ctx.error(e === undefined ? v : cast_1.default.toValue(e, v, ctx)); });
    };
    Async.prototype.return = function (rv) {
        var self = this;
        var cur = self;
        if (arguments.length > 0) {
            cur = this.map(rv);
        }
        return cur.then(function (v, ctx) { return ctx.complete(undefined, v, DONE_LEVEL.COMPLETED); });
    };
    Async.prototype.ifThenReturn = function (cond, rv) {
        if (arguments.length <= 1) {
            return this.if(cond)
                .return()
                .end();
        }
        else {
            return this.if(cond)
                .return(rv)
                .end();
        }
    };
    Async.prototype.ifThenThrow = function (cond, e) {
        return this.if(cond)
            .throw(e)
            .end();
    };
    Async.prototype.action = function (action) {
        return this.then(function (v, ctx) {
            if (action) {
                action(v, ctx);
            }
            return ctx.next(v);
        });
    };
    Async.prototype.validate = function (action) {
        return this.action(action);
    };
    Async.prototype.whatever = function (action) {
        return this.then(function (v, ctx) {
            if (action) {
                action(undefined, v, ctx);
            }
            return ctx.next(v);
        }, function (e, ctx) {
            if (action) {
                action(e, undefined, ctx);
            }
            return ctx.error(e);
        });
    };
    Async.prototype.wait = function (mills) {
        return this.then(function (v, ctx) { return setTimeout(function () { return ctx.next(v); }, Math.round(cast_1.default.toValue(mills, v, ctx))); });
    };
    Async.prototype.countDown = function (mills, fn) {
        var moment;
        return this.action(function () {
            moment = moment || new Moment_1.Moment();
        })
            .wait(mills)
            .map(function (v, ctx) { return fn(moment.mark(), v, ctx); });
    };
    Async.prototype.stringify = function () {
        return this.map(toString_1.default);
    };
    Async.prototype.log = function (label, ctxlog) {
        if (label === void 0) { label = ''; }
        if (ctxlog === void 0) { ctxlog = false; }
        return this.whatever(function (e, v, ctx) {
            if (e) {
                logger_1.default.log(label + ' error:', e, ctxlog ? toString_1.default(ctx) : '');
            }
            else {
                logger_1.default.log(label, toString_1.default(v), ctxlog ? toString_1.default(ctx) : '');
            }
        });
    };
    Async.prototype.prop = function (k) {
        return this.then(function (v, ctx) { return ctx.next(prop_1.default(k, v)); });
    };
    Async.prototype.currentLimiting = function (limit, time) {
        if (time === void 0) { time = 1000; }
        var manager = {
            consumedTsArray: [],
            waitingArray: [],
            isBatching: false,
            onRecv: function (v, ctx) {
                this.waitingArray.push({ v: v, ctx: ctx });
                this.consume();
            },
            consume: function () {
                var _this_1 = this;
                var now = new Date().getTime();
                this.consumedTsArray = this.consumedTsArray.filter(function (consumed) { return consumed + time > now; });
                var consumedLength = this.consumedTsArray.length;
                for (var i = 0; i < limit - consumedLength && this.waitingArray.length > 0; i++) {
                    var _a = this.waitingArray.shift(), v = _a.v, ctx = _a.ctx;
                    ctx.next(v);
                    this.consumedTsArray.push(now);
                }
                if (!this.isBatching && this.waitingArray.length > 0) {
                    var headConsumed = this.consumedTsArray[0];
                    var delay = headConsumed + time - now;
                    this.isBatching = true;
                    setTimeout(function () {
                        _this_1.isBatching = false;
                        _this_1.consume();
                    }, delay);
                }
            }
        };
        return this.then(function (v, ctx) { return manager.onRecv(v, ctx); });
    };
    Async.prototype.forward = function (worker, asyncFlag) {
        return this.then(function (v, ctx) {
            var realWorker = typeof worker === 'function' ? worker(v, ctx) : worker;
            if (!asyncFlag) {
                realWorker.invoke(v, noop);
                return ctx.next(v);
            }
            else {
                return realWorker.invoke(v, function (ne, nv) { return ctx.accept(ne, nv); });
            }
        });
    };
    Async.prototype.bindOutterCanceller = function (outterCanceller) {
        this._outterCanceller = outterCanceller;
        return this;
    };
    Async.prototype.bindLifeCircle = function (lifeCircle) {
        var _this_1 = this;
        lifeCircle.on('created', function () { return (_this_1._lifeState = 'created'); });
        lifeCircle.on('destroyed', function () { return (_this_1._lifeState = 'destroyed'); });
        lifeCircle.on('paused', function () { return (_this_1._lifeState = 'paused'); });
        lifeCircle.on('resumed', function () { return (_this_1._lifeState = 'resumed'); });
    };
    Async.prototype.newCtx = function (cb) {
        return new Context(this._global, this._outterCanceller, this._swallowErrorLevel, cb);
    };
    Async.prototype.isInLooper = function () {
        return this._stageStack.some(function (v) { return v instanceof Looper; });
    };
    Async.prototype.merge = function (recevie, triggers) {
        if (!triggers || !triggers.length) {
            return identity;
        }
        return function (e, v, ctx, cb) {
            var record = { arrived: 0, triggered: false, values: [] };
            triggers.forEach(function (trigger, index) {
                trigger.invoke(v, function (ne, nv) {
                    if (!record.triggered) {
                        if (ne) {
                            record.triggered = true;
                            cb(ne, nv, ctx);
                        }
                        else {
                            recevie(record, index, nv, new AdvancedContext(ctx, cb));
                        }
                    }
                    return ctx;
                });
            });
            return ctx;
        };
    };
    return Async;
}());
exports.Async = Async;
