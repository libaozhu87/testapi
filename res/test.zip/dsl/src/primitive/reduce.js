"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
function reduce(collect, iteratee, memo) {
    var type = typof_1.default(collect);
    if (type === 'array') {
        return collect.reduce(iteratee, memo);
    }
    else if (type === 'object') {
        Object.keys(collect).forEach(function (k) {
            if (collect.hasOwnProperty(k)) {
                memo = iteratee(memo, collect[k], k, collect);
            }
        });
        return memo;
    }
    else {
    }
}
exports.default = reduce;
