"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
function plain(obj) {
    var type = typof_1.default(obj);
    if (type === 'array' || type === 'object') {
        var newObj = type === 'array' ? [] : {};
        for (var key in obj) {
            var value = obj[key];
            var wrapValue = plain(value);
            if (typof_1.default(value) !== typof_1.default(wrapValue)) {
                Object.defineProperty(newObj, key, wrapValue);
            }
            else {
                newObj[key] = wrapValue;
            }
        }
        return newObj;
    }
    else if (type === 'function') {
        var _v_1 = obj;
        return {
            enumerable: false,
            configurable: false,
            get: function () { return _v_1; },
            set: function (newVal) { return (_v_1 = newVal); }
        };
    }
    else {
        return obj;
    }
}
exports.default = plain;
