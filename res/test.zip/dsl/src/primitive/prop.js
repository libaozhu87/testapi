"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function prop(key, target) {
    key = String(key);
    return key === '_' || key === undefined ? target : key.split('.').reduce(function (pre, cur) { return pre && pre[cur]; }, target);
}
exports.default = prop;
