"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function zipMatrix(arr0, arr1) {
    var merge = [];
    for (var _i = 0, arr0_1 = arr0; _i < arr0_1.length; _i++) {
        var t = arr0_1[_i];
        for (var _a = 0, arr1_1 = arr1; _a < arr1_1.length; _a++) {
            var k = arr1_1[_a];
            merge.push([t, k]);
        }
    }
    return merge;
}
exports.zipMatrix = zipMatrix;
function zipDiagonal(arr0, arr1) {
    arr1 = arr1 || arr0;
    var merge = [];
    for (var i = 0; i < arr0.length; i++) {
        for (var j = i + 1; j < arr1.length; j++) {
            merge.push([arr0[i], arr1[j]]);
        }
    }
    return merge;
}
exports.zipDiagonal = zipDiagonal;
function zipLong(arr0, arr1) {
    var arrs = [arr0, arr1];
    var long = arrs.reduce(function (pre, arr) { return Math.max(pre, arr.length); }, 0);
    var result = [];
    var _loop_1 = function (i) {
        result[i] = arrs.map(function (arr) { return arr[i]; });
    };
    for (var i = 0; i < long; i++) {
        _loop_1(i);
    }
    return result;
}
exports.zipLong = zipLong;
function zipShort(arr0, arr1) {
    var arrs = [arr0, arr1];
    var short = arrs.reduce(function (pre, arr) { return Math.min(pre, arr.length); }, 4096);
    var result = [];
    var _loop_2 = function (i) {
        result[i] = arrs.map(function (arr) { return arr[i]; });
    };
    for (var i = 0; i < short; i++) {
        _loop_2(i);
    }
    return result;
}
exports.zipShort = zipShort;
function zipBetween(arr) {
    var result = [];
    for (var i = 0; i < arr.length - 1; i++) {
        result[i] = [arr[i], arr[i + 1]];
    }
    return result;
}
exports.zipBetween = zipBetween;
