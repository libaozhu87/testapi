"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var isEmpty_1 = require("./isEmpty");
function isNotEmpty(v) {
    return !isEmpty_1.default(v);
}
exports.default = isNotEmpty;
