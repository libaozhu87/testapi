"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
var isNull_1 = require("./isNull");
function isEmpty(v) {
    if (isNull_1.default(v)) {
        return true;
    }
    else {
        var type = typof_1.default(v);
        if (type === 'object') {
            return Object.keys(v).length === 0;
        }
        else if (type === 'array' || type === 'string') {
            return v.length === 0;
        }
        return false;
    }
}
exports.default = isEmpty;
