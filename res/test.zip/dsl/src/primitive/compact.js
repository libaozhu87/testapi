"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var isEmpty_1 = require("./isEmpty");
var filter_1 = require("./filter");
var typof_1 = require("./typof");
function isCompactable(v) {
    var type = typof_1.default(v);
    if (type === 'object') {
        return Object.keys(v).length === 0;
    }
    else if (type === 'array' || type === 'string') {
        return v.length === 0;
    }
    else if (v === undefined || v === null) {
        return true;
    }
    return false;
}
function compact(collect) {
    var type = typof_1.default(collect);
    if (type !== 'array' && type !== 'object') {
        return isEmpty_1.default(collect) ? undefined : collect;
    }
    else {
        return filter_1.default(collect, function (item) { return !isCompactable(item); });
    }
}
exports.default = compact;
