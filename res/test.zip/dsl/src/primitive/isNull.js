"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function isNull(v) {
    if (v === 'null' || v === 'undefined') {
        return true;
    }
    return !v;
}
exports.default = isNull;
