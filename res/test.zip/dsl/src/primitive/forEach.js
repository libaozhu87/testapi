"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
function forEach(collect, iteratee) {
    var type = typof_1.default(collect);
    if (type === 'array') {
        return collect.forEach(iteratee);
    }
    else if (type === 'object') {
        Object.keys(collect).forEach(function (k) {
            if (collect.hasOwnProperty(k)) {
                iteratee(collect[k], k, collect);
            }
        });
        return collect;
    }
}
exports.default = forEach;
