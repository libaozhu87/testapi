"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var identical_1 = require("./identical");
var typof_1 = require("./typof");
function equals(a, b) {
    if (identical_1.default(a, b)) {
        return true;
    }
    var typeA = typof_1.default(a);
    var typeB = typof_1.default(b);
    if (typeA !== typeB) {
        return false;
    }
    if (a === null || b === null || a === undefined || b === undefined) {
        return false;
    }
    switch (typeA) {
        case 'object':
            var aKeys = Object.keys(a);
            var bKeys = Object.keys(b);
            if (aKeys.length !== bKeys.length) {
                return false;
            }
            for (var k in a) {
                if (!equals(a[k], b[k])) {
                    return false;
                }
            }
            return true;
        case 'array':
            if (a.length !== b.length) {
                return false;
            }
            for (var i in a) {
                if (!equals(a[i], b[i])) {
                    return false;
                }
            }
            return true;
        default:
            return false;
    }
}
exports.default = equals;
