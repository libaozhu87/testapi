"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
function filter(collect, pred) {
    var type = typof_1.default(collect);
    if (type === 'array') {
        return collect.filter(pred);
    }
    else if (type === 'object') {
        var obj_1 = {};
        Object.keys(collect).forEach(function (k) {
            if (collect.hasOwnProperty(k)) {
                if (pred(collect[k], k, collect)) {
                    obj_1[k] = collect[k];
                }
            }
        });
        return obj_1;
    }
}
exports.default = filter;
