"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var isNull_1 = require("./isNull");
var typof_1 = require("./typof");
function isFalse(v) {
    if (isNull_1.default(v)) {
        return true;
    }
    else {
        var type = typof_1.default(v);
        if (type === 'string') {
            var lowerCase = v.toLowerCase();
            return lowerCase === '0' || lowerCase === 'false' || lowerCase === 'no';
        }
        else {
            return false;
        }
    }
}
exports.default = isFalse;
