"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function endsWith(str, suffix) {
    return str !== undefined && suffix !== undefined && str.indexOf(suffix, str.length - suffix.length) !== -1;
}
exports.default = endsWith;
