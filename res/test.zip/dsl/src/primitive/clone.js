"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_js_1 = require("./typof.js");
function clone(v) {
    if (Array.isArray(v)) {
        return v.map(clone);
    }
    else if (typof_js_1.default(v) === 'object') {
        var newV = {};
        for (var key in v) {
            if (v.hasOwnProperty(key)) {
                newV[key] = clone(v[key]);
            }
        }
        return newV;
    }
    else {
        return v;
    }
}
exports.default = clone;
