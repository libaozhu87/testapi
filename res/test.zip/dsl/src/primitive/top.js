"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var isEmpty_1 = require("./isEmpty");
function compareNumber(t0, t1) {
    return t0 - t1;
}
function top(arr, compare) {
    if (isEmpty_1.default(arr)) {
        return undefined;
    }
    else {
        compare = compare || compareNumber;
        return arr.reduce(function (pre, cur) {
            if (pre !== undefined && compare(pre, cur) <= 0) {
                return pre;
            }
            return cur;
        }, undefined);
    }
}
exports.default = top;
