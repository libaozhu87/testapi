"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function identity(n) {
    return n;
}
exports.default = identity;
