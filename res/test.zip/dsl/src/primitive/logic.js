"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var cast_1 = require("./cast");
function andOr(isAnd, preds, target) {
    for (var i in preds) {
        if (!!preds[i](target) !== isAnd) {
            return !isAnd;
        }
    }
    return isAnd;
}
function and(target, preds) {
    preds = preds ? preds.map(cast_1.default.toPred) : [];
    return andOr(true, preds, target);
}
function or(target, preds) {
    preds = preds ? preds.map(cast_1.default.toPred) : [];
    return andOr(false, preds, target);
}
function not(target, cond) {
    var pred = cast_1.default.toPred(cond, undefined);
    return !pred(target);
}
function T() {
    return true;
}
function F() {
    return false;
}
exports.default = {
    and: and,
    or: or,
    not: not,
    T: T,
    F: F
};
