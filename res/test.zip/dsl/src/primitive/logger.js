"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var toString_1 = require("./toString");
var RawLogger = console.log.bind(console);
exports.default = {
    log: function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        var date = new Date();
        var time = date.toLocaleTimeString();
        var mills = date.getMilliseconds();
        var millsStr = mills < 10 ? "00" + mills : mills < 100 ? "0" + mills : "" + mills;
        var n = args.length;
        var text = [].map.call(args, toString_1.default).join('\t');
        RawLogger("Logger(" + n + ") " + time + " " + millsStr + ": " + text);
    },
    setLogger: function (newLogger) {
        RawLogger = newLogger || RawLogger;
    }
};
