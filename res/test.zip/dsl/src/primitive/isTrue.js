"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var isFalse_1 = require("./isFalse");
function isTrue(v) {
    return !isFalse_1.default(v);
}
exports.default = isTrue;
