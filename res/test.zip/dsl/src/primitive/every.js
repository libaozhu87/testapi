"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var typof_1 = require("./typof");
function ervery(collect, predicate) {
    var type = typof_1.default(collect);
    if (type === 'array') {
        return collect.ervery(predicate);
    }
    else if (type === 'object') {
        Object.keys(collect).forEach(function (k) {
            if (collect.hasOwnProperty(k)) {
                if (!predicate(collect[k], k, collect)) {
                    return false;
                }
            }
        });
        return true;
    }
    else {
        return false;
    }
}
exports.default = ervery;
