"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function startsWith(str, prefix) {
    return str !== undefined && prefix !== undefined && str.slice(0, prefix.length) === prefix;
}
exports.default = startsWith;
