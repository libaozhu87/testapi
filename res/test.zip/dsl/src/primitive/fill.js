"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function fill(capity, value) {
    var arr = Array.apply(undefined, Array(capity));
    return value === undefined ? arr : arr.map(function () { return value; });
}
exports.default = fill;
