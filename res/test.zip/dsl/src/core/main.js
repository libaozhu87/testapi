"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var build_1 = require("./build");
var regroup_new_1 = require("./regroup-new");
var property_1 = require("./property");
var clean_1 = require("./clean");
var weex_1 = require("./../template/weex");
var measure_direction_1 = require("./measure-direction");
var debug_1 = require("./debug");
var measure_size_1 = require("./measure-size");
var measure_position_type_1 = require("./measure-position-type");
var measure_justify_content_1 = require("./measure-justify-content");
var measure_padding_1 = require("./measure-padding");
var measure_position_1 = require("./measure-position");
var measure_cross_align_1 = require("./measure-cross-align");
var measure_special_layout_1 = require("./measure-special-layout");
var measure_position_type_polyfill_1 = require("./measure-position-type-polyfill");
var simplify_1 = require("./simplify");
var input_polyfil_1 = require("./input-polyfil");
var cfg_1 = require("./cfg");
var writer_1 = require("./writer");
var format_1 = require("./../primitive/format");
var compact_1 = require("./../primitive/compact");
var applanate_1 = require("./applanate");
var clone_1 = require("./../primitive/clone");
var render_1 = require("./../screenshot/render");
var Async_1 = require("./../primitive/Async");
function genLabel(cfg) {
    return compact_1.default([format_1.default('{_:d,yyyy-MM-dd}/{_:d,hh-mm-ss}', new Date()), cfg.fileName, cfg.artBoard]).join('_');
}
function flexbox(input, cfg, needLog) {
    if (cfg === void 0) { cfg = cfg_1.DefaultCfg; }
    if (needLog === void 0) { needLog = true; }
    var _a;
    var property = new property_1.Property(cfg);
    property.setLogicalWidth(input.frame.width);
    var label = genLabel(cfg);
    var cloned = clone_1.default(input);
    var polyfilled = input_polyfil_1.default(cloned);
    var elements = applanate_1.default(polyfilled);
    var regrouped = regroup_new_1.regroup(elements, polyfilled);
    var root = build_1.build(regrouped, property);
    root = measure_direction_1.measureDirection(root, property);
    root = measure_position_type_1.measurePositionType(root, property);
    root = measure_size_1.measureSize(root, property);
    root = measure_special_layout_1.measureSpecialLayout(root, property);
    root = measure_position_type_polyfill_1.measurePositionTypePolyfill(root, property);
    root = measure_justify_content_1.fixMainAxis(root, property);
    root = measure_padding_1.fixCrossAxis(root, property);
    root = measure_justify_content_1.measureJustifyContent(root, property);
    root = measure_cross_align_1.measureCrossAlign(root, property);
    root = measure_position_1.measurePosition(root, property);
    root = measure_padding_1.measurePadding(root, property);
    root = simplify_1.simplify(root, property);
    debug_1.debug(root, property);
    var weexContext = weex_1.weex(root, undefined);
    clean_1.clean(root, property);
    var ssl = render_1.toSkeletonScreenLoadingDSL(root);
    if (needLog) {
        (_a = new Async_1.Async()).sequence.apply(_a, [writer_1.WriteUtil.async({ type: 'object', path: "public/logs/" + label + "/input.js", context: input }),
            writer_1.WriteUtil.async({ type: 'object', path: "public/logs/" + label + "/elements.js", context: elements }),
            writer_1.WriteUtil.async({ type: 'object', path: "public/logs/" + label + "/regrouped.js", context: regrouped }),
            writer_1.WriteUtil.async({ type: 'object', path: "public/logs/" + label + "/dsl.js", context: root }),
            writer_1.WriteUtil.async({ type: 'object', path: "public/logs/" + label + "/ssl.js", context: ssl }),
            writer_1.WriteUtil.async({ type: 'string', path: "public/logs/" + label + "/index.vue", context: weexContext }),
            render_1.renderInput(polyfilled, elements, "public/logs/" + label + "/input-screenshot.png"),
            render_1.renderDSL(root, "public/logs/" + label + "/screenshot.png"),
            render_1.renderDSL(ssl, "public/logs/" + label + "/skeleton-screen-loading.png"),
            writer_1.WriteUtil.ensureDir("public/logs/" + label + "/nodes")].concat(render_1.renderElements(root, "public/logs/" + label + "/nodes"), [writer_1.WriteUtil.ensureDir("public/logs/" + label + "/cards")], root.children.map(function (child, i) { return render_1.renderDSL(child, "public/logs/" + label + "/cards/card" + i + "-" + child.id + ".png"); }))).invoke(true);
    }
    return {
        dsl: root,
        skeletonScreenLoadingDSL: ssl,
        weex: weexContext
    };
}
exports.flexbox = flexbox;
var weex_2 = require("./../template/weex");
exports.weex = weex_2.weex;
