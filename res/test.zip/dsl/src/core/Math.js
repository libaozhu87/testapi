"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var flex_type_1 = require("./../define/flex-type");
var frame_util_1 = require("./frame-util");
function compare(a, b) {
    if (a < b) {
        return -1;
    }
    else if (a > b) {
        return 1;
    }
    else {
        return 0;
    }
}
exports.compare = compare;
function area(frame) {
    return frame.width * frame.height;
}
exports.area = area;
function isInRange(v, range) {
    return v >= range[0] && v < range[1];
}
exports.isInRange = isInRange;
function isInBox(p, frame) {
    return p.x >= frame.x && p.x < frame.x + frame.width && p.y >= frame.y && p.y < frame.y + frame.height;
}
exports.isInBox = isInBox;
function isOverlap(f0, f1) {
    return [flex_type_1.FlexDirection.ROW, flex_type_1.FlexDirection.COLUMN].every(function (dir) { return isOverlapOnDirection(f0, f1, dir); });
}
exports.isOverlap = isOverlap;
function isOverlapOnDirection(f0, f1, dir) {
    if (dir === flex_type_1.FlexDirection.ROW) {
        return (isInRange(f0.x, [f1.x, f1.x + f1.width]) ||
            isInRange(f0.x + f0.width - 1, [f1.x, f1.x + f1.width]) ||
            isInRange(f1.x, [f0.x, f0.x + f0.width]) ||
            isInRange(f1.x + f1.width - 1, [f0.x, f0.x + f0.width]));
    }
    else {
        return (isInRange(f0.y, [f1.y, f1.y + f1.height]) ||
            isInRange(f0.y + f0.height - 1, [f1.y, f1.y + f1.height]) ||
            isInRange(f1.y, [f0.y, f0.y + f0.height]) ||
            isInRange(f1.y + f1.height - 1, [f0.y, f0.y + f0.height]));
    }
}
exports.isOverlapOnDirection = isOverlapOnDirection;
function isOverlapOnDirByShelling(f0, f1, dir) {
    return isOverlapOnDirection(frame_util_1.FrameUtil.shelling(f0), frame_util_1.FrameUtil.shelling(f1), dir);
}
exports.isOverlapOnDirByShelling = isOverlapOnDirByShelling;
function measureOverlapOnDir(f0, f1, dir) {
    var intersect = intersectionOnDirection(f0, f1, dir);
    var l0 = frame_util_1.FrameUtil.getLength(f0, dir);
    var l1 = frame_util_1.FrameUtil.getLength(f1, dir);
    return [intersect / l0, intersect / l1, intersect];
}
exports.measureOverlapOnDir = measureOverlapOnDir;
function isFullOverlap(small, large) {
    return (isInBox({ x: small.x, y: small.y }, large) &&
        isInBox({ x: small.x + small.width - 1, y: small.y }, large) &&
        isInBox({ x: small.x + small.width - 1, y: small.y + small.height - 1 }, large) &&
        isInBox({ x: small.x, y: small.y + small.height - 1 }, large));
}
exports.isFullOverlap = isFullOverlap;
function isFullOverlapOnDirection(small, large, dir) {
    if (dir === flex_type_1.FlexDirection.ROW) {
        return isInRange(small.x, [large.x, large.x + large.width]) && isInRange(small.x + small.width - 1, [large.x, large.x + large.width]);
    }
    else {
        return isInRange(small.y, [large.y, large.y + large.height]) && isInRange(small.y + small.height - 1, [large.y, large.y + large.height]);
    }
}
exports.isFullOverlapOnDirection = isFullOverlapOnDirection;
function isFullOverlapOnDirectionByScale(small, large, scale, dir) {
    if (dir === flex_type_1.FlexDirection.ROW) {
        var sl = small.x + small.width * (1 - scale) / 2;
        var sr = small.x + small.width * (scale + 1) / 2;
        var ll = large.x + large.width * (1 - scale) / 2;
        var lr = large.x + large.width * (scale + 1) / 2;
        return isInRange(sl, [ll, lr]) && isInRange(sr - scale, [ll, lr]);
    }
    else {
        var st = small.y + small.height * (1 - scale) / 2;
        var sb = small.y + small.height * (scale + 1) / 2;
        var lt = large.y + large.height * (1 - scale) / 2;
        var lb = large.y + large.height * (scale + 1) / 2;
        return isInRange(st, [lt, lb]) && isInRange(sb - scale, [lt, lb]);
    }
}
exports.isFullOverlapOnDirectionByScale = isFullOverlapOnDirectionByScale;
function intersection(f0, f1) {
    if (isOverlap(f0, f1)) {
        var left = Math.max(f0.x, f1.x);
        var top_1 = Math.max(f0.y, f1.y);
        var righ = Math.min(f0.x + f0.width, f1.x + f1.width);
        var bottom = Math.min(f0.y + f0.height, f1.y + f1.height);
        return {
            x: left,
            y: top_1,
            width: righ - left,
            height: bottom - top_1
        };
    }
    return undefined;
}
exports.intersection = intersection;
function intersectionOnDirection(f0, f1, dir) {
    return intersectionOnDirectionByScale(f0, f1, 1, dir);
}
exports.intersectionOnDirection = intersectionOnDirection;
function intersectionOnDirectionByScale(f0, f1, scale, dir) {
    var center0 = frame_util_1.FrameUtil.getCenter(f0, dir);
    var center1 = frame_util_1.FrameUtil.getCenter(f1, dir);
    var len0 = frame_util_1.FrameUtil.getLength(f0, dir);
    var len1 = frame_util_1.FrameUtil.getLength(f1, dir);
    var intersect = (len0 + len1) * scale / 2 - Math.abs(center1 - center0);
    return Math.max(intersect, 0);
}
exports.intersectionOnDirectionByScale = intersectionOnDirectionByScale;
function marginOnDirectionByScale(start, end, scale, dir) {
    var center0 = frame_util_1.FrameUtil.getCenter(start, dir);
    var center1 = frame_util_1.FrameUtil.getCenter(end, dir);
    var len0 = frame_util_1.FrameUtil.getLength(start, dir);
    var len1 = frame_util_1.FrameUtil.getLength(end, dir);
    var intersect = center1 - center0 - (len0 + len1) * scale / 2;
    return Math.max(intersect, -1);
}
exports.marginOnDirectionByScale = marginOnDirectionByScale;
function frameEquals(f0, f1) {
    return f0 === f1 || (f0 && f1 && f0.x === f1.x && f0.y === f1.y && f0.width === f1.width && f0.height === f1.height);
}
exports.frameEquals = frameEquals;
