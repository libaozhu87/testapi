"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var flex_type_1 = require("./../define/flex-type");
var zip_1 = require("./../primitive/zip");
var math_1 = require("./math");
var top_1 = require("./../primitive/top");
var flatten_1 = require("./../primitive/flatten");
var unique_1 = require("./../primitive/unique");
var assert_1 = require("./../primitive/assert");
var magic_1 = require("./magic");
function filterConflicts(fc) {
    var max = Math.max(fc.conflictRate, fc.maxEffect);
    return max >= magic_1.CONFLICT_ERROR && (fc.conflictValue > 4 || max >= 1);
}
function findConflict(frameCarrys, conflictFunc) {
    var pairs = zip_1.zipDiagonal(frameCarrys, frameCarrys);
    return pairs.filter(function (pair) { return conflictFunc(pair[0].carry.exactFrame, pair[1].carry.exactFrame).some(function (v) { return v > 0; }); });
}
function solveConflict(conflicts, conflictFunc, preferInTwo) {
    if (preferInTwo === void 0) { preferInTwo = false; }
    var conflictPairs = conflicts;
    var solvedMode;
    function getLayerZIndexMode(carry) {
        var mode;
        for (var _i = 0, conflictPairs_1 = conflictPairs; _i < conflictPairs_1.length; _i++) {
            var pair = conflictPairs_1[_i];
            var other = void 0;
            if (pair[0] === carry) {
                other = pair[1];
            }
            else if (pair[1] === carry) {
                other = pair[0];
            }
            if (other !== undefined) {
                var newMode = other.carry.zIndex > carry.carry.zIndex ? -1 : 1;
                if (mode === undefined) {
                    mode = newMode;
                }
                else if (mode !== newMode) {
                    return 0;
                }
            }
        }
        assert_1.default(mode !== undefined);
        return mode;
    }
    function recount() {
        conflictPairs.forEach(function (pair) {
            pair.forEach(function (fc) {
                fc.count = 0;
                fc.conflictRate = 0;
                fc.maxEffect = 0;
                fc.conflictValue = 0;
            });
        });
        conflictPairs.forEach(function (pair) {
            var v2 = conflictFunc(pair[0].carry.exactFrame, pair[1].carry.exactFrame);
            pair.forEach(function (fc, i) {
                fc.count++;
                fc.conflictValue += v2[2];
                fc.conflictRate += v2[i];
                fc.maxEffect += v2[1 - i];
            });
        });
    }
    function findMostOverlap() {
        recount();
        var frameCarrys = unique_1.default(flatten_1.default(conflictPairs));
        frameCarrys.sort(function (f0, f1) {
            if (f0.count === f1.count) {
                if (f0.maxEffect === f1.maxEffect) {
                    return math_1.area(f0.carry.exactFrame) - math_1.area(f1.carry.exactFrame);
                }
                return f1.maxEffect - f0.maxEffect;
            }
            return f1.count - f0.count;
        });
        for (var _i = 0, frameCarrys_1 = frameCarrys; _i < frameCarrys_1.length; _i++) {
            var one = frameCarrys_1[_i];
            var mode = getLayerZIndexMode(one);
            if (mode !== 0) {
                if (solvedMode === undefined || solvedMode === mode) {
                    solvedMode = mode;
                    return one;
                }
            }
        }
        return frameCarrys[0];
    }
    function removeOverlap(f) {
        conflictPairs = conflictPairs.filter(function (pair) { return pair[0] !== f && pair[1] !== f; });
    }
    var overlaps = [];
    while (conflictPairs.length > 0) {
        var frameCarry = findMostOverlap();
        assert_1.default(frameCarry !== undefined);
        overlaps.push(__assign({}, frameCarry));
        removeOverlap(frameCarry);
    }
    if (preferInTwo && conflicts.length === 1) {
        var first = top_1.default(conflicts[0], function (pre, cur) {
            if (pre.carry.type !== cur.carry.type) {
                if (pre.carry.type === node_1.NodeType.IMAGE) {
                    return -1;
                }
                else if (cur.carry.type === node_1.NodeType.IMAGE) {
                    return 1;
                }
                else if (pre.carry.type === node_1.NodeType.GROUP) {
                    return 1;
                }
                else if (cur.carry.type === node_1.NodeType.GROUP) {
                    return -1;
                }
            }
            return math_1.area(pre.carry.exactFrame) - math_1.area(cur.carry.exactFrame);
        });
        return [__assign({}, first)];
    }
    return overlaps;
}
function tFindOverlaps(frameCarrys, conflictFunc) {
    return tRawFindOverlaps(frameCarrys, conflictFunc).map(function (frameCarry) { return frameCarry.carry; });
}
exports.tFindOverlaps = tFindOverlaps;
function strictFindOverlaps(frameCarrys, conflictFunc) {
    var conflicts = findConflict(frameCarrys, conflictFunc);
    var solvedConflicts = solveConflict(conflicts, conflictFunc);
    return solvedConflicts.map(function (frameCarry) { return frameCarry.carry; });
}
exports.strictFindOverlaps = strictFindOverlaps;
function tRawStrictFindOverlaps(frameCarrys, conflictFunc) {
    var conflicts = findConflict(frameCarrys, conflictFunc);
    var solvedConflicts = solveConflict(conflicts, conflictFunc);
    return solvedConflicts;
}
exports.tRawStrictFindOverlaps = tRawStrictFindOverlaps;
function tRawFindOverlaps(frameCarrys, conflictFunc, preferImageInTwo) {
    if (preferImageInTwo === void 0) { preferImageInTwo = false; }
    var conflicts = findConflict(frameCarrys, conflictFunc);
    var solvedConflicts = solveConflict(conflicts, conflictFunc, preferImageInTwo);
    return solvedConflicts.filter(filterConflicts);
}
exports.tRawFindOverlaps = tRawFindOverlaps;
function findOverlapsOnDirection(group, property, dir) {
    var conflictFunc = function (f0, f1) { return math_1.measureOverlapOnDir(f0, f1, dir); };
    var frameCarrys = property
        .getChildren(group)
        .filter(function (child) { return child.layout.position !== flex_type_1.PositionType.ABSOLUTE; })
        .map(function (node) { return ({ carry: node }); });
    var result = tRawFindOverlaps(frameCarrys, conflictFunc, true);
    return result.map(function (fc) { return fc.carry; });
}
exports.findOverlapsOnDirection = findOverlapsOnDirection;
function calcDir(rowOverlaps, columnOverlaps) {
    if (rowOverlaps.length === columnOverlaps.length) {
        var dif = rowOverlaps.reduce(function (pre, cur) { return pre + cur.maxEffect; }, 0) - columnOverlaps.reduce(function (pre, cur) { return pre + cur.maxEffect; }, 0);
        return dif < 0 ? flex_type_1.FlexDirection.ROW : flex_type_1.FlexDirection.COLUMN;
    }
    return rowOverlaps.length < columnOverlaps.length ? flex_type_1.FlexDirection.ROW : flex_type_1.FlexDirection.COLUMN;
}
function getDirection(group, property) {
    var nodes = property.getChildren(group);
    var frameCarrys = nodes.map(function (node) { return ({ carry: node }); });
    var rowOverlaps = tRawStrictFindOverlaps(frameCarrys, function (l1, l2) { return math_1.measureOverlapOnDir(l1, l2, flex_type_1.FlexDirection.ROW); });
    var columOverlaps = tRawStrictFindOverlaps(frameCarrys, function (l1, l2) { return math_1.measureOverlapOnDir(l1, l2, flex_type_1.FlexDirection.COLUMN); });
    return calcDir(rowOverlaps, columOverlaps);
}
exports.getDirection = getDirection;
function getDirectionByBaseNodes(nodes) {
    var frameCarrys = nodes.map(function (node) { return ({ carry: node }); });
    var rowOverlaps = tRawStrictFindOverlaps(frameCarrys, function (l1, l2) { return math_1.measureOverlapOnDir(l1, l2, flex_type_1.FlexDirection.ROW); });
    var columOverlaps = tRawStrictFindOverlaps(frameCarrys, function (l1, l2) { return math_1.measureOverlapOnDir(l1, l2, flex_type_1.FlexDirection.COLUMN); });
    return calcDir(rowOverlaps, columOverlaps);
}
exports.getDirectionByBaseNodes = getDirectionByBaseNodes;
function getDirection2(group) {
    if (group.type === node_1.NodeType.GROUP) {
        var nodes = group.layers;
        return getDirectionByBaseNodes(nodes);
    }
    return undefined;
}
exports.getDirection2 = getDirection2;
function isConflictedByNodes(nodes) {
    var frameCarrys = nodes.map(function (node) { return ({ carry: node }); });
    return [flex_type_1.FlexDirection.COLUMN, flex_type_1.FlexDirection.ROW].every(function (dir) { return tRawFindOverlaps(frameCarrys, function (l1, l2) { return math_1.measureOverlapOnDir(l1, l2, dir); }).length > 0; });
}
function isConflicted(group, filterBG) {
    var nodes = group.children.filter(function (child) {
        if (filterBG) {
            return !((child.type === node_1.NodeType.SHAPE || child.type === node_1.NodeType.IMAGE) &&
                group.measured.width === child.measured.width &&
                group.measured.height === child.measured.height &&
                child.measured.x === 0 &&
                child.measured.y === 0);
        }
        else {
            return true;
        }
    });
    return isConflictedByNodes(nodes);
}
exports.isConflicted = isConflicted;
function isConflicted2(group) {
    if (group.type === node_1.NodeType.GROUP) {
        var nodes = group.layers;
        return isConflictedByNodes(nodes);
    }
    return false;
}
exports.isConflicted2 = isConflicted2;
function isConflictedOnDirection(nodes, dir) {
    var frameCarrys = nodes.map(function (node) { return ({ carry: node }); });
    return tRawFindOverlaps(frameCarrys, function (l1, l2) { return math_1.measureOverlapOnDir(l1, l2, dir); }).length > 0;
}
exports.isConflictedOnDirection = isConflictedOnDirection;
