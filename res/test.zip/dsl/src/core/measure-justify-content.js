"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var node_util_1 = require("./node-util");
var layout_util_1 = require("./layout-util");
var flex_type_1 = require("./../define/flex-type");
var magic_1 = require("./magic");
var frame_util_1 = require("./frame-util");
function justifyContent(node, property) {
    if (node.layout.justifyContent === undefined) {
        node.layout.justifyContent = forecastJustifyContent(node, property);
    }
}
function fixNodeMainAxis(node, property) {
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        var group = node;
        if (group.layout.justifyContent === flex_type_1.JustifyContent.SPACE_BETWEEN || group.specialLayout !== undefined) {
            var dir = node.layout.flexDirection;
            if (!layout_util_1.LayoutUtil.isFixed(node.layout, dir)) {
                layout_util_1.LayoutUtil.setLength(node.layout, dir, frame_util_1.FrameUtil.getLength(node.measured, dir));
            }
        }
    }
}
function measureJustifyContent(node, property) {
    return node_util_1.NodeUtil.visitNodeTreeReverse(node, property, justifyContent);
}
exports.measureJustifyContent = measureJustifyContent;
function fixMainAxis(node, property) {
    return node_util_1.NodeUtil.visitNodeTreeReverse(node, property, fixNodeMainAxis);
}
exports.fixMainAxis = fixMainAxis;
function isCenter(start, end, length) {
    var min = Math.min(start, end);
    var max = Math.max(start, end);
    var offset = max - min;
    if (min === 0) {
        return false;
    }
    var centerRate = 1 - offset / min;
    return centerRate >= 0.9 && offset <= magic_1.CENTER_ERROR * 2;
}
function handleCommon(group, property) {
    var contentChildren = property.getLinearChildren(group);
    var length = contentChildren.length;
    if (length >= 1) {
        var dir = group.layout.flexDirection;
        var spaces = node_util_1.NodeUtil.getChildrenArounds(group, contentChildren, property);
        var start = spaces[0];
        var end = spaces[spaces.length - 1];
        var length_1 = frame_util_1.FrameUtil.getLength(group.measured, dir);
        if (isCenter(start, end, length_1)) {
            return flex_type_1.JustifyContent.CENTER;
        }
        else if (start - end >= magic_1.MAGIC_MARGIN && dir === flex_type_1.FlexDirection.ROW) {
            return flex_type_1.JustifyContent.FLEX_END;
        }
        else {
            return flex_type_1.JustifyContent.FLEX_START;
        }
    }
    else {
        return flex_type_1.JustifyContent.FLEX_START;
    }
}
function forecastJustifyContent(node, property) {
    if (node.layout.justifyContent) {
        return node.layout.justifyContent;
    }
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        var group = node;
        if (group.specialLayout !== undefined) {
            return flex_type_1.JustifyContent.SPACE_BETWEEN;
        }
        return handleCommon(group, property);
    }
}
