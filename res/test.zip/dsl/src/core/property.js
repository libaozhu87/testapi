"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var flex_type_1 = require("./../define/flex-type");
var platform_1 = require("./../define/platform");
var isEmpty_1 = require("./../primitive/isEmpty");
var min_1 = require("./../primitive/min");
var endsWith_1 = require("./../primitive/endsWith");
var Property = (function () {
    function Property(cfg) {
        this._logicalWidth = 750;
        this._platform = platform_1.Platform.WEEX;
        this._debug = false;
        this._platform = cfg.platform;
        this._debug = cfg.debug;
        this._page = cfg.page;
    }
    Property.prototype.minZIndex = function (node) {
        var _this = this;
        var type = node.type;
        if (type === node_1.NodeType.GROUP) {
            var group = node;
            return min_1.default(group.children.map(function (child) { return _this.minZIndex(child); }));
        }
        else {
            return node.zIndex;
        }
    };
    Property.prototype.getChildren = function (node) {
        if (node.type === node_1.NodeType.GROUP) {
            return node.children;
        }
        return [];
    };
    Property.prototype.getMarkedChildren = function (node) {
        var _this = this;
        return this.getChildren(node).filter(function (child) { return _this.isMarkedNode(child); });
    };
    Property.prototype.getBackgroundChildren = function (node) {
        var _this = this;
        return this.getChildren(node).filter(function (child) { return _this.isMatchParentSize(child); });
    };
    Property.prototype.getLinearChildren = function (node) {
        return this.getChildren(node).filter(function (child) { return child.layout.position !== flex_type_1.PositionType.ABSOLUTE; });
    };
    Property.prototype.isDivider = function (node, dir) {
        var type = node.type;
        if (type === node_1.NodeType.SHAPE || type === node_1.NodeType.IMAGE) {
            if (dir === flex_type_1.FlexDirection.COLUMN) {
                return node.measured.width / node.measured.height >= 32 && node.measured.width >= 200;
            }
            else if (dir === flex_type_1.FlexDirection.ROW) {
                return node.measured.height / node.measured.width >= 32 && node.measured.height >= 200;
            }
        }
        return false;
    };
    Property.prototype.isFixedTextWidth = function (node) {
        if (node.type === node_1.NodeType.TEXT) {
            var text = node;
            if (text.textStyles.lineHeight > 0 && text.frame.height > text.textStyles.lineHeight * 1.5) {
                return true;
            }
            else if (endsWith_1.default(text.value, '…') || endsWith_1.default(text.value, '...')) {
                return true;
            }
        }
        return false;
    };
    Property.prototype.isMultiLinesText = function (node) {
        if (node.type === node_1.NodeType.TEXT) {
            var text = node;
            if (text.textStyles.lines > 0) {
                return true;
            }
            else if (text.textStyles.lineHeight > 0 && text.frame.height > text.textStyles.lineHeight * 1.5) {
                return true;
            }
        }
        return false;
    };
    Property.prototype.isSingleLinesText = function (node) {
        if (node.type === node_1.NodeType.TEXT) {
            return !this.isMultiLinesText(node);
        }
        return false;
    };
    Property.prototype.getLogicalWidth = function () {
        return this._logicalWidth;
    };
    Property.prototype.setLogicalWidth = function (value) {
        this._logicalWidth = value;
    };
    Property.prototype.getPlatform = function () {
        return this._platform;
    };
    Property.prototype.isDebug = function () {
        return this._debug;
    };
    Property.prototype.getPage = function () {
        return this._page;
    };
    Property.prototype.hasValidBackground = function (node) {
        var type = node.type;
        if (type === node_1.NodeType.GROUP) {
            var group = node;
            var styles = group.styles;
            if (styles) {
                if (!isEmpty_1.default(styles)) {
                    return true;
                }
            }
        }
        return false;
    };
    Property.prototype.isMatchParentSize = function (node) {
        var parent = node.parent;
        if (parent !== undefined) {
            return (parent.measured.width === node.measured.width &&
                parent.measured.height === node.measured.height &&
                node.measured.x === 0 &&
                node.measured.y === 0);
        }
        return false;
    };
    Property.prototype.isMarkedNode = function (node) {
        return false;
    };
    return Property;
}());
exports.Property = Property;
