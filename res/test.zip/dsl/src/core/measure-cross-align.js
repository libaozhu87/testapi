"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var flex_type_1 = require("./../define/flex-type");
var node_util_1 = require("./node-util");
var direction_util_1 = require("./direction-util");
var frame_util_1 = require("./frame-util");
var platform_1 = require("./../define/platform");
var layout_util_1 = require("./layout-util");
var isEmpty_1 = require("./../primitive/isEmpty");
var magic_1 = require("./magic");
var special_1 = require("./../define/special");
function alignSelf(node, property) {
    var parent = node.parent;
    if (!parent) {
        return;
    }
    if (node.layout.position !== flex_type_1.PositionType.ABSOLUTE) {
        if (node.specialAlign === special_1.SpecialAlign.START) {
            node.layout.alignSelf = flex_type_1.AlignItems.FLEX_START;
        }
        else if (node.specialAlign === special_1.SpecialAlign.CENTER) {
            node.layout.alignSelf = flex_type_1.AlignItems.CENTER;
        }
        else if (node.specialAlign === special_1.SpecialAlign.END) {
            node.layout.alignSelf = flex_type_1.AlignItems.FLEX_END;
        }
        else {
            var dir = direction_util_1.DirectionUtil.cross(parent.layout.flexDirection);
            var length_1 = frame_util_1.FrameUtil.getLength(parent.measured, dir);
            var start = frame_util_1.FrameUtil.getStart(node.measured, dir);
            var end = length_1 - frame_util_1.FrameUtil.getEnd(node.measured, dir);
            if (Math.abs(start) <= magic_1.CENTER_ERROR && Math.abs(end) <= magic_1.CENTER_ERROR) {
                node.layout.alignSelf = undefined;
            }
            else if (frame_util_1.FrameUtil.isCenter(node.measured, parent.measured, dir)) {
                node.layout.alignSelf = flex_type_1.AlignItems.CENTER;
            }
            else if (frame_util_1.FrameUtil.isNearStart(node.measured, parent.measured, dir)) {
                node.layout.alignSelf = flex_type_1.AlignItems.FLEX_START;
            }
            else if (frame_util_1.FrameUtil.isNearEnd(node.measured, parent.measured, dir)) {
                node.layout.alignSelf = flex_type_1.AlignItems.FLEX_END;
            }
        }
    }
}
function alignItems(node, property) {
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        var group_1 = node;
        var children_1 = property.getLinearChildren(group_1);
        if (!isEmpty_1.default(children_1)) {
            var cross = direction_util_1.DirectionUtil.cross(group_1.layout.flexDirection);
            var isFixed = layout_util_1.LayoutUtil.isFixed(group_1.layout, cross);
            if (isFixed) {
                var aligns = [flex_type_1.AlignItems.FLEX_START, flex_type_1.AlignItems.CENTER, flex_type_1.AlignItems.FLEX_END];
                var max_1 = 0;
                var maxAlign_1;
                aligns.forEach(function (align) {
                    var sum = children_1.reduce(function (count, child) { return (child.layout.alignSelf === align ? count + 1 : count); }, 0);
                    if (sum > 0 && (max_1 < sum || (sum === max_1 && align === flex_type_1.AlignItems.CENTER))) {
                        max_1 = sum;
                        maxAlign_1 = align;
                    }
                });
                group_1.layout.alignItems = maxAlign_1 === undefined ? flex_type_1.AlignItems.FLEX_START : maxAlign_1;
            }
            else {
                var isAllStart = children_1.every(function (child) { return child.layout.alignSelf === flex_type_1.AlignItems.FLEX_START || child.layout.alignSelf === undefined; });
                var isAllCenter = !isAllStart && children_1.every(function (child) { return child.layout.alignSelf === flex_type_1.AlignItems.CENTER || child.layout.alignSelf === undefined; });
                if (isAllStart) {
                    group_1.layout.alignItems = flex_type_1.AlignItems.FLEX_START;
                }
                else if (isAllCenter) {
                    group_1.layout.alignItems = flex_type_1.AlignItems.CENTER;
                }
                else {
                    var sumStart = children_1.reduce(function (count, child) { return (child.layout.alignSelf === flex_type_1.AlignItems.FLEX_START ? count + 1 : count); }, 0);
                    var sumEnd = children_1.reduce(function (count, child) { return (child.layout.alignSelf === flex_type_1.AlignItems.FLEX_END ? count + 1 : count); }, 0);
                    var align = sumStart >= sumEnd ? flex_type_1.AlignItems.FLEX_START : flex_type_1.AlignItems.FLEX_END;
                    group_1.layout.alignItems = align;
                }
            }
            children_1.forEach(function (child) {
                if (child.layout.alignSelf === undefined) {
                    child.layout.alignSelf = group_1.layout.alignItems;
                }
            });
            children_1.forEach(function (child) {
                if (property.getPlatform() === platform_1.Platform.FLUTTER) {
                    child.layout.alignSelf = undefined;
                }
            });
        }
    }
}
function measureCrossAlign(node, property) {
    var r0 = node_util_1.NodeUtil.visitNodeTree(node, property, alignSelf);
    return node_util_1.NodeUtil.visitNodeTree(r0, property, alignItems);
}
exports.measureCrossAlign = measureCrossAlign;
