"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var flex_type_1 = require("./../define/flex-type");
exports.TOP_INDEX = 0;
exports.RIGHT_INDEX = 1;
exports.BOTTOM_INDEX = 2;
exports.LEFT_INDEX = 3;
var LayoutUtil = (function () {
    function LayoutUtil() {
    }
    LayoutUtil.setLength = function (layout, dir, value) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            layout.width = value;
        }
        else {
            layout.height = value;
        }
    };
    LayoutUtil.getLength = function (layout, dir) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            return layout.width;
        }
        else {
            return layout.height;
        }
    };
    LayoutUtil.isFixed = function (layout, dir) {
        return LayoutUtil.getLength(layout, dir) !== undefined;
    };
    LayoutUtil.setPositionStart = function (layout, dir, value) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            layout.left = value;
        }
        else {
            layout.top = value;
        }
    };
    LayoutUtil.setPositionEnd = function (layout, dir, value) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            layout.right = value;
        }
        else {
            layout.bottom = value;
        }
    };
    LayoutUtil.setMarginStart = function (layout, dir, value) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            layout.margin[exports.LEFT_INDEX] = value;
        }
        else {
            layout.margin[exports.TOP_INDEX] = value;
        }
    };
    LayoutUtil.setMarginEnd = function (layout, dir, value) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            layout.margin[exports.RIGHT_INDEX] = value;
        }
        else {
            layout.margin[exports.BOTTOM_INDEX] = value;
        }
    };
    LayoutUtil.setPaddingStart = function (layout, dir, value) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            layout.padding[exports.LEFT_INDEX] = value;
        }
        else {
            layout.padding[exports.TOP_INDEX] = value;
        }
    };
    LayoutUtil.setPaddingEnd = function (layout, dir, value) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            layout.padding[exports.RIGHT_INDEX] = value;
        }
        else {
            layout.padding[exports.BOTTOM_INDEX] = value;
        }
    };
    LayoutUtil.getFrameBoxWithMargin = function (node) {
        var box = __assign({}, node.measured);
        var left = box.x;
        var right = box.x + box.width;
        var top = box.y;
        var bottom = box.y + box.height;
        if (node.layout.margin) {
            node.layout.margin.forEach(function (v, index) {
                if (v !== undefined) {
                    switch (index) {
                        case exports.TOP_INDEX:
                            top -= v;
                            break;
                        case exports.RIGHT_INDEX:
                            right += v;
                            break;
                        case exports.BOTTOM_INDEX:
                            bottom += v;
                            break;
                        case exports.LEFT_INDEX:
                            left -= v;
                    }
                }
            });
        }
        return { x: left, y: top, width: right - left, height: bottom - top };
    };
    LayoutUtil.setTransformForCenter = function (layout, dir) {
        var add = dir === flex_type_1.FlexDirection.ROW ? flex_type_1.Transform.X_50 : flex_type_1.Transform.Y_50;
        if (layout.transform === undefined || layout.transform === add) {
            layout.transform = add;
        }
        else if (layout.transform !== add) {
            layout.transform = flex_type_1.Transform.XY_50;
        }
    };
    LayoutUtil.getPadding = function (layout, index) {
        if (layout && layout.padding) {
            return layout.padding[index];
        }
    };
    return LayoutUtil;
}());
exports.LayoutUtil = LayoutUtil;
