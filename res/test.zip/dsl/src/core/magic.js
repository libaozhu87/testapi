"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MAGIC_MARGIN = 40;
exports.MAGIC_PADDING = 48;
exports.CENTER_ERROR = 3;
exports.CONFLICT_ERROR = 0.1;
exports.SIMILAR_THRESHOLD = 0.725;
exports.SIMILAR_BOX = 0.825;
exports.MIN_SPACE = 8;
exports.MIN_GRID_ITEMS = 3;
function isMagicMargin(margin) {
    return margin >= exports.MAGIC_MARGIN;
}
exports.isMagicMargin = isMagicMargin;
function isMargicPadding(padding) {
    return padding >= exports.MAGIC_PADDING;
}
exports.isMargicPadding = isMargicPadding;
