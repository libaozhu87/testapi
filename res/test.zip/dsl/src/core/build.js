"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var node_factory_1 = require("./node-factory");
var node_util_1 = require("./node-util");
var compact_1 = require("./../primitive/compact");
var sort_children_1 = require("./sort-children");
function buildNodeTree(input, parent, property) {
    var node = node_factory_1.buildNode(input, parent);
    if (node.type === node_1.NodeType.GROUP) {
        var group_1 = node;
        group_1.children = compact_1.default(input.layers.map(function (layer) { return buildNodeTree(layer, group_1, property); }));
    }
    return node;
}
function absolute2relative(node, property) {
    var parent = node.parent;
    node.measured.x = node.measured.x - (parent ? parent.frame.x : 0);
    node.measured.y = node.measured.y - (parent ? parent.frame.y : 0);
}
function build(input, property) {
    var root = buildNodeTree(input, undefined, property);
    node_util_1.NodeUtil.visitNodeTreeReverse(root, property, absolute2relative);
    sort_children_1.sortChildren(root, property);
    return root;
}
exports.build = build;
