"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var flex_type_1 = require("./../define/flex-type");
var node_util_1 = require("./node-util");
var conflict_1 = require("./conflict");
var frame_util_1 = require("./frame-util");
var indexOf_1 = require("./../primitive/indexOf");
var magic_1 = require("./magic");
var layout_util_1 = require("./layout-util");
function positionTypePolyfill(node, property) {
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        var group_1 = node;
        var dir_1 = conflict_1.getDirection(group_1, property);
        if (dir_1 === flex_type_1.FlexDirection.ROW && !conflict_1.isConflicted(group_1, true) && group_1.specialLayout === undefined) {
            var linears = property.getLinearChildren(group_1);
            var bewteens = node_util_1.NodeUtil.getChildrenBetweens(group_1, linears, property);
            if (bewteens.some(magic_1.isMagicMargin) && linears.length <= 3) {
                var centerIndex = indexOf_1.default(linears, function (child) { return frame_util_1.FrameUtil.isCenter(child.measured, group_1.measured, dir_1); });
                if (centerIndex >= 0) {
                    linears.forEach(function (child) { return (child.layout.position = flex_type_1.PositionType.ABSOLUTE); });
                    linears[centerIndex].layout.position = flex_type_1.PositionType.RELATIVE;
                    layout_util_1.LayoutUtil.setLength(group_1.layout, dir_1, frame_util_1.FrameUtil.getLength(group_1.measured, dir_1));
                }
            }
        }
    }
}
function measurePositionTypePolyfill(node, property) {
    return node_util_1.NodeUtil.visitNodeTree(node, property, positionTypePolyfill);
}
exports.measurePositionTypePolyfill = measurePositionTypePolyfill;
