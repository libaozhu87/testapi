"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var platform_1 = require("./../define/platform");
exports.DefaultCfg = { debug: false, platform: platform_1.Platform.WEEX, page: undefined, fileName: '', artBoard: '' };
