"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var flex_type_1 = require("./../define/flex-type");
var node_util_1 = require("./node-util");
var conflict_1 = require("./conflict");
function positionType(node, property) {
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        var group = node;
        var dir = conflict_1.getDirection(group, property);
        if (conflict_1.isConflicted(group, false)) {
            var conflicts = conflict_1.findOverlapsOnDirection(group, property, dir);
            conflicts.forEach(function (child) {
                child.layout.position = flex_type_1.PositionType.ABSOLUTE;
            });
        }
        property.getChildren(node).forEach(function (child) {
            if (child.layout.position !== flex_type_1.PositionType.ABSOLUTE) {
                child.layout.position = flex_type_1.PositionType.RELATIVE;
            }
        });
    }
}
function measurePositionType(node, property) {
    return node_util_1.NodeUtil.visitNodeTree(node, property, positionType);
}
exports.measurePositionType = measurePositionType;
