"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var node_util_1 = require("./node-util");
var measure_size_type_1 = require("./../define/measure-size-type");
var frame_util_1 = require("./frame-util");
var layout_util_1 = require("./layout-util");
var flex_type_1 = require("./../define/flex-type");
var conflict_1 = require("./conflict");
var magic_1 = require("./magic");
var ResizeByInput = (function () {
    function ResizeByInput() {
    }
    ResizeByInput.prototype.isMatch = function (node, dir, property) {
        return !node.parent;
    };
    ResizeByInput.prototype.apply = function (node, dir, property) {
        return {
            length: frame_util_1.FrameUtil.getLength(node.measured, dir),
            offset: 0,
            fixed: dir === flex_type_1.FlexDirection.ROW,
            type: measure_size_type_1.MeasuredSizeType.BY_INPUT
        };
    };
    return ResizeByInput;
}());
var ResizeByLargePadding = (function () {
    function ResizeByLargePadding() {
    }
    ResizeByLargePadding.prototype.isMatch = function (node, dir, property) {
        var type = node.type;
        if (type === node_1.NodeType.GROUP) {
            var group = node;
            var linears = property.getLinearChildren(group);
            var frame = linears.map(function (child) { return child.measured; }).reduce(frame_util_1.FrameUtil.expand, undefined);
            if (frame !== undefined) {
                var start = frame_util_1.FrameUtil.getStart(frame, dir);
                var end = frame_util_1.FrameUtil.getLength(group.measured, dir) - frame_util_1.FrameUtil.getEnd(frame, dir);
                return magic_1.isMargicPadding(start) || magic_1.isMargicPadding(end);
            }
        }
        return false;
    };
    ResizeByLargePadding.prototype.apply = function (node, dir, property) {
        return {
            length: frame_util_1.FrameUtil.getLength(node.measured, dir),
            offset: 0,
            fixed: true,
            type: 'ResizeByLargePadding'
        };
    };
    return ResizeByLargePadding;
}());
var ResizeByStretchWidth = (function () {
    function ResizeByStretchWidth() {
    }
    ResizeByStretchWidth.prototype.isMatch = function (node, dir, property) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            var type = node.type, parent_1 = node.parent;
            if (type === node_1.NodeType.GROUP &&
                !property.hasValidBackground(node) &&
                parent_1 &&
                parent_1.layout.flexDirection === flex_type_1.FlexDirection.COLUMN &&
                parent_1.measured.width === property.getLogicalWidth()) {
                return true;
            }
        }
        return false;
    };
    ResizeByStretchWidth.prototype.apply = function (node, dir, property) {
        return {
            length: property.getLogicalWidth(),
            offset: -frame_util_1.FrameUtil.getStart(node.measured, dir),
            fixed: true,
            type: measure_size_type_1.MeasuredSizeType.BY_SKETCH_WIDTH
        };
    };
    return ResizeByStretchWidth;
}());
var ResizeByMark = (function () {
    function ResizeByMark() {
    }
    ResizeByMark.prototype.isMatch = function (node, dir, property) {
        return false;
    };
    ResizeByMark.prototype.apply = function (node, dir, property) {
        return {
            length: frame_util_1.FrameUtil.getLength(node.measured, dir),
            offset: 0,
            fixed: true,
            type: measure_size_type_1.MeasuredSizeType.BY_MARK
        };
    };
    return ResizeByMark;
}());
var ResizeByConflict = (function () {
    function ResizeByConflict() {
    }
    ResizeByConflict.prototype.isMatch = function (node, dir, property) {
        var type = node.type;
        if (type === node_1.NodeType.GROUP) {
            var group = node;
            return conflict_1.isConflicted(group, true);
        }
        return false;
    };
    ResizeByConflict.prototype.apply = function (node, dir, property) {
        return {
            length: frame_util_1.FrameUtil.getLength(node.measured, dir),
            offset: 0,
            fixed: true,
            type: measure_size_type_1.MeasuredSizeType.BY_CONFLICT
        };
    };
    return ResizeByConflict;
}());
var ResizeByImageAsBackground = (function () {
    function ResizeByImageAsBackground() {
    }
    ResizeByImageAsBackground.prototype.isMatch = function (node, dir, property) {
        return property.getBackgroundChildren(node).some(function (child) { return child.type === node_1.NodeType.IMAGE; });
    };
    ResizeByImageAsBackground.prototype.apply = function (node, dir, property) {
        return {
            length: frame_util_1.FrameUtil.getLength(node.measured, dir),
            offset: 0,
            fixed: true,
            type: measure_size_type_1.MeasuredSizeType.BY_IMAGE_AS_BACKGROUND
        };
    };
    return ResizeByImageAsBackground;
}());
var ResizeByShapeAsBackground = (function () {
    function ResizeByShapeAsBackground() {
    }
    ResizeByShapeAsBackground.prototype.isMatch = function (node, dir, property) {
        return (property.getBackgroundChildren(node).some(function (child) { return child.type === node_1.NodeType.SHAPE; }) && property.getBackgroundChildren(node).length === 1);
    };
    ResizeByShapeAsBackground.prototype.apply = function (node, dir, property) {
        return {
            length: frame_util_1.FrameUtil.getLength(node.measured, dir),
            offset: 0,
            fixed: false,
            type: measure_size_type_1.MeasuredSizeType.BY_SHAPE_AS_BACKGROUND
        };
    };
    return ResizeByShapeAsBackground;
}());
var ResizeByPritimive = (function () {
    function ResizeByPritimive() {
    }
    ResizeByPritimive.prototype.isMatch = function (node, dir, property) {
        if (node.type === node_1.NodeType.IMAGE) {
            return true;
        }
        else if (node.type === node_1.NodeType.SHAPE) {
            return !property.isMatchParentSize(node);
        }
        return false;
    };
    ResizeByPritimive.prototype.apply = function (node, dir, property) {
        return {
            length: frame_util_1.FrameUtil.getLength(node.measured, dir),
            offset: 0,
            fixed: true,
            type: measure_size_type_1.MeasuredSizeType.BY_PRIMITIVE
        };
    };
    return ResizeByPritimive;
}());
var ResizeByText = (function () {
    function ResizeByText() {
    }
    ResizeByText.prototype.isMatch = function (node, dir, property) {
        if (node.type === node_1.NodeType.TEXT) {
            if (dir === flex_type_1.FlexDirection.ROW) {
                return property.isFixedTextWidth(node);
            }
        }
        return false;
    };
    ResizeByText.prototype.apply = function (node, dir, property) {
        return {
            length: frame_util_1.FrameUtil.getLength(node.measured, dir),
            offset: 0,
            fixed: true,
            type: measure_size_type_1.MeasuredSizeType.BY_TEXT
        };
    };
    return ResizeByText;
}());
var ResizeByDefault = (function () {
    function ResizeByDefault() {
    }
    ResizeByDefault.prototype.isMatch = function (node, dir, property) {
        return true;
    };
    ResizeByDefault.prototype.apply = function (node, dir, property) {
        return {
            length: frame_util_1.FrameUtil.getLength(node.measured, dir),
            offset: 0,
            fixed: false,
            type: measure_size_type_1.MeasuredSizeType.BY_DEFAULT
        };
    };
    return ResizeByDefault;
}());
var FlexboxResizer = (function () {
    function FlexboxResizer(resizers) {
        this._resizers = resizers;
    }
    FlexboxResizer.prototype.apply = function (node, dir, property) {
        for (var _i = 0, _a = this._resizers; _i < _a.length; _i++) {
            var resizer = _a[_i];
            if (resizer.isMatch(node, dir, property)) {
                return resizer.apply(node, dir, property);
            }
        }
    };
    return FlexboxResizer;
}());
var RESIZER = new FlexboxResizer([
    new ResizeByPritimive(),
    new ResizeByMark(),
    new ResizeByConflict(),
    new ResizeByImageAsBackground(),
    new ResizeByShapeAsBackground(),
    new ResizeByInput(),
    new ResizeByStretchWidth(),
    new ResizeByText(),
    new ResizeByLargePadding(),
    new ResizeByDefault()
]);
function firstRound(node, property) {
    var dirs = [flex_type_1.FlexDirection.ROW, flex_type_1.FlexDirection.COLUMN];
    dirs.forEach(function (dir) {
        var struct = RESIZER.apply(node, dir, property);
        frame_util_1.FrameUtil.setLength(node.measured, dir, struct.length);
        frame_util_1.FrameUtil.setStartOffset(node.measured, dir, struct.offset);
        if (struct.fixed) {
            layout_util_1.LayoutUtil.setLength(node.layout, dir, struct.length);
        }
        node.reasons.push(struct.type);
        property.getChildren(node).forEach(function (child) {
            frame_util_1.FrameUtil.setStartOffset(child.measured, dir, -struct.offset);
        });
    });
}
exports.firstRound = firstRound;
function measureSize(node, property) {
    return node_util_1.NodeUtil.visitNodeTree(node, property, firstRound);
}
exports.measureSize = measureSize;
