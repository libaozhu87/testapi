"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var node_factory_1 = require("./node-factory");
var isEmpty_1 = require("./../primitive/isEmpty");
var frame_util_1 = require("./frame-util");
var remove_1 = require("./../primitive/remove");
var id_generate_1 = require("./id-generate");
var NodeUtil = (function () {
    function NodeUtil() {
    }
    NodeUtil.visitNodeTree = function (node, property, visiter) {
        var container = { root: node };
        NodeUtil._visitNodeTree(node, property, visiter, container);
        return container.root;
    };
    NodeUtil._visitNodeTree = function (node, property, visiter, rootContainer) {
        visiter(node, property, rootContainer);
        if (node.type === node_1.NodeType.GROUP) {
            property.getChildren(node).forEach(function (child) { return NodeUtil._visitNodeTree(child, property, visiter, rootContainer); });
        }
    };
    NodeUtil.visitNodeTreeReverse = function (node, property, visiter, rootContainer) {
        var container = { root: node };
        NodeUtil._visitNodeTreeReverse(node, property, visiter, container);
        return container.root;
    };
    NodeUtil._visitNodeTreeReverse = function (node, property, visiter, rootContainer) {
        if (node.type === node_1.NodeType.GROUP) {
            property.getChildren(node).forEach(function (child) { return NodeUtil._visitNodeTreeReverse(child, property, visiter, rootContainer); });
        }
        visiter(node, property, rootContainer);
    };
    NodeUtil.prevSlibing = function (child, property) {
        var parent = child.parent;
        var contentChildren = property.getLinearChildren(parent);
        var index = contentChildren.indexOf(child);
        if (index === -1) {
            throw new Error("");
        }
        return contentChildren[index - 1];
    };
    NodeUtil.nextSlibing = function (child, property) {
        var parent = child.parent;
        var contentChildren = property.getLinearChildren(parent);
        var index = contentChildren.indexOf(child);
        if (index === -1) {
            throw new Error("");
        }
        return contentChildren[index + 1];
    };
    NodeUtil.newGroup = function (nodes, parent) {
        if (nodes.length === 0) {
            throw new Error("");
        }
        var frame = nodes.map(function (node) { return node.frame; }).reduce(frame_util_1.FrameUtil.expand, undefined);
        var exactFrame = nodes.map(function (node) { return node.exactFrame; }).reduce(frame_util_1.FrameUtil.expand, undefined);
        var input = {
            name: '@GeneratedGroup',
            id: 'a' + id_generate_1.newId(),
            type: node_1.NodeType.GROUP,
            frame: frame,
            exactFrame: exactFrame,
            layers: undefined,
            value: undefined,
            styles: undefined,
            textStyles: undefined,
            imageStyles: undefined,
            zIndex: 0
        };
        var newGroup = node_factory_1.buildNode(input, parent);
        newGroup.measured = nodes.map(function (node) { return node.measured; }).reduce(frame_util_1.FrameUtil.expand, undefined);
        newGroup.children = nodes;
        nodes.forEach(function (child) {
            child.parent = newGroup;
            child.measured.x = child.measured.x - newGroup.measured.x;
            child.measured.y = child.measured.y - newGroup.measured.y;
        });
        var index = parent.children.indexOf(nodes[0]);
        if (index < 0) {
            throw new Error("");
        }
        nodes.forEach(function (node) {
            remove_1.default(parent.children, node);
        });
        parent.children.splice(index, 0, newGroup);
        return newGroup;
    };
    NodeUtil.getChildrenBetweens = function (group, children, property) {
        if (isEmpty_1.default(children)) {
            return [];
        }
        var dir = group.layout.flexDirection;
        return children
            .map(function (child) {
            var prevChild = NodeUtil.prevSlibing(child, property);
            var end = prevChild ? frame_util_1.FrameUtil.getEnd(prevChild.measured, dir) : 0;
            var start = frame_util_1.FrameUtil.getStart(child.measured, dir);
            return start - end;
        })
            .slice(1);
    };
    NodeUtil.getChildrenArounds = function (group, children, property) {
        if (isEmpty_1.default(children)) {
            return [];
        }
        var head = children[0];
        var tail = children[children.length - 1];
        var dir = group.layout.flexDirection;
        var first = frame_util_1.FrameUtil.getStart(head.measured, dir);
        return [first]
            .concat(NodeUtil.getChildrenBetweens(group, children, property))
            .concat(frame_util_1.FrameUtil.getLength(group.measured, dir) - frame_util_1.FrameUtil.getEnd(tail.measured, dir));
    };
    return NodeUtil;
}());
exports.NodeUtil = NodeUtil;
