"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var conflict_1 = require("./conflict");
var zip_1 = require("./../primitive/zip");
var magic_1 = require("./magic");
var logger_1 = require("./../primitive/logger");
var assert_1 = require("./../primitive/assert");
var frame_util_1 = require("./frame-util");
var flex_type_1 = require("./../define/flex-type");
var min_1 = require("./../primitive/min");
var max_1 = require("./../primitive/max");
var AREA_RATE = 0.3;
function similarBox(n0, n1) {
    var widthDif = Math.min(n0.width, n1.width) / Math.max(n0.width, n1.width);
    var heightDif = Math.min(n0.height, n1.height) / Math.max(n0.height, n1.height);
    var result = widthDif * heightDif;
    assert_1.default(result >= 0 && result <= 1, result);
    return result;
}
exports.similarBox = similarBox;
function textSimilar(s0, s1) {
    var weights = [0.3, 0.4, 0.1, 0.1, 0.1];
    var bits = [
        s0.color === s1.color,
        s0.fontSize === s1.fontSize,
        s0.fontStyle === s1.fontStyle,
        s0.textDecoration === s1.textDecoration,
        s0.fontFamily === s1.fontFamily
    ];
    var result = weights.reduce(function (pre, cur, i) { return pre + (bits[i] ? cur : 0); }, 0);
    assert_1.default(result >= 0 && result <= 1, result);
    return result;
}
function imageSimilar(f0, f1) {
    var result = similarBox(f0, f1);
    assert_1.default(result >= 0 && result <= 1, result);
    return result;
}
function shapeSimilar(s0, s1) {
    var weights = [0.3, 0.3, 0.3, 0.1, 0.0];
    var bits = [
        s0.backgroundColor === s1.backgroundColor,
        s0.borderColor === s1.borderColor,
        s0.borderRadius === s1.borderRadius,
        s0.borderWidth === s1.borderWidth,
        s0.borderStyle === s1.borderStyle
    ];
    var weight = weights.reduce(function (pre, cur, i) { return pre + (bits[i] ? cur : 0); }, 0);
    var STRUCT_RATE = 0.3;
    var result = STRUCT_RATE + (1 - STRUCT_RATE) * weight;
    assert_1.default(result >= 0 && result <= 1, result);
    return result;
}
function arraySimilarRaw(layers0, layers1, cachePair, cacheArray) {
    if (layers0.length === 0 || layers1.length === 0) {
        return 0;
    }
    var kArray = layers0[0].id + '-' + layers1[0].id;
    var vArray = cacheArray[kArray];
    if (vArray === undefined) {
        var max_2 = -1;
        var m = layers0[0];
        var remains = layers0.slice(1);
        for (var i = 0; i < layers1.length; i++) {
            var kPair = m.id + '-' + layers1[i].id;
            var vPair = cachePair[kPair];
            assert_1.default(typeof vPair === 'number');
            max_2 = Math.max(vPair + arraySimilarRaw(remains, layers1.slice(i + 1), cachePair, cacheArray), max_2);
        }
        cacheArray[kArray] = max_2;
        assert_1.default(max_2 <= Math.min(layers0.length, layers1.length), max_2);
        return max_2;
    }
    return vArray;
}
function groupSimilar(layers0, layers1, calc) {
    if (layers0.length === 0 || layers1.length === 0) {
        return layers0.length === layers1.length ? 1 : 0;
    }
    var d0 = conflict_1.getDirectionByBaseNodes(layers0);
    var d1 = conflict_1.getDirectionByBaseNodes(layers1);
    if (d0 === d1) {
        var pairs = zip_1.zipMatrix(layers0, layers1);
        var cachePair_1 = {};
        pairs.forEach(function (pair) {
            var kPair = pair[0].id + '-' + pair[1].id;
            var vPair = calc(pair[0], pair[1]);
            cachePair_1[kPair] = vPair;
            assert_1.default(vPair >= 0 && vPair <= 1, vPair);
        });
        var sum = arraySimilarRaw(layers0, layers1, cachePair_1, {});
        var result = sum * 2 / (layers0.length + layers1.length);
        assert_1.default(result >= 0 && result <= 1, result, sum, layers0.length, layers1.length);
        return result;
    }
    return 0;
}
function similarTree(n0, n1) {
    var areaSimilar = similarBox(n0.exactFrame, n1.exactFrame);
    var t0 = n0.type;
    var t1 = n1.type;
    if (t0 === t1) {
        if (t0 === node_1.NodeType.GROUP) {
            return areaSimilar * AREA_RATE + (1 - AREA_RATE) * groupSimilar(n0.layers || n0.children, n1.layers || n1.children, similarTree);
        }
        else if (n0.type === node_1.NodeType.TEXT) {
            return textSimilar(n0.textStyles, n1.textStyles);
        }
        else if (n0.type === node_1.NodeType.IMAGE) {
            var boxR = imageSimilar(n0.exactFrame, n1.exactFrame);
            return 1 - (1 - boxR) * (1 - boxR);
        }
        else if (n0.type === node_1.NodeType.SHAPE) {
            return areaSimilar * AREA_RATE + (1 - AREA_RATE) * shapeSimilar(n0.styles, n1.styles);
        }
    }
    return areaSimilar * AREA_RATE;
}
exports.similarTree = similarTree;
function isSimilarTree(n0, n1, threshold) {
    if (threshold === void 0) { threshold = magic_1.SIMILAR_THRESHOLD; }
    return similarTree(n0, n1) >= threshold;
}
exports.isSimilarTree = isSimilarTree;
function isSimilarBox(n0, n1, threshold) {
    if (threshold === void 0) { threshold = magic_1.SIMILAR_BOX; }
    return similarBox(n0.exactFrame, n1.exactFrame) >= threshold;
}
function isSimilarAsGridLine(nodes, threshold) {
    if (threshold === void 0) { threshold = magic_1.SIMILAR_THRESHOLD; }
    if (nodes && nodes.length >= magic_1.MIN_GRID_ITEMS) {
        if (nodes.every(function (child) { return isSimilarTree(child, nodes[0], magic_1.SIMILAR_THRESHOLD); })) {
            logger_1.default.log('isSimilarGridLine', true, nodes.map(function (node) { return node.id; }));
            logger_1.default.log(nodes.map(function (child) { return similarTree(child, nodes[0]); }));
            return true;
        }
        else if (nodes.every(function (child) { return isSimilarBox(child, nodes[0], magic_1.SIMILAR_BOX); })) {
            logger_1.default.log('isSimilarGridLine', true, nodes.map(function (node) { return node.id; }));
            logger_1.default.log(nodes.map(function (child) { return isSimilarBox(child, nodes[0]); }));
            return true;
        }
        else {
            logger_1.default.log('isSimilarGridLine', false, nodes.map(function (node) { return node.id; }));
            logger_1.default.log(nodes.map(function (child) { return isSimilarBox(child, nodes[0]); }));
            logger_1.default.log(nodes.map(function (child) { return similarTree(child, nodes[0]); }));
        }
    }
    return false;
}
exports.isSimilarAsGridLine = isSimilarAsGridLine;
function isSimilarAsGrid(nodes, parent, threshold) {
    if (threshold === void 0) { threshold = magic_1.SIMILAR_THRESHOLD; }
    if (nodes && nodes.length >= magic_1.MIN_GRID_ITEMS && parent !== undefined && parent.layout.flexDirection === flex_type_1.FlexDirection.ROW) {
        if (nodes.every(function (child) { return isSimilarBox(child, nodes[0], magic_1.SIMILAR_BOX); })) {
            logger_1.default.log('isSimilarGridLine', true, parent.id);
            logger_1.default.log(nodes.map(function (child) { return isSimilarBox(child, nodes[0]); }));
            var f = frame_util_1.FrameUtil.expandFrames.apply(frame_util_1.FrameUtil, nodes.map(function (node) { return node.measured; }));
            var pf = parent.measured;
            var left = frame_util_1.FrameUtil.getStart(f, flex_type_1.FlexDirection.ROW);
            var right = frame_util_1.FrameUtil.getLength(pf, flex_type_1.FlexDirection.ROW) - frame_util_1.FrameUtil.getEnd(f, flex_type_1.FlexDirection.ROW);
            if (Math.abs(left - right) < 4) {
                var centers = nodes.map(function (child) { return frame_util_1.FrameUtil.getCenter(child.measured, flex_type_1.FlexDirection.ROW); });
                var betweens = centers
                    .map(function (v, i, arr) {
                    return i > 0 ? v - arr[i - 1] : 0;
                })
                    .slice(1);
                var minValue = min_1.default(betweens);
                var maxValue = max_1.default(betweens);
                if (maxValue - minValue < 4 || (maxValue - minValue) / minValue < 0.1) {
                    return true;
                }
                else {
                    logger_1.default.log('isSimilarGridLine(MIN,MAX)', false, parent.id, minValue, maxValue);
                }
            }
            else {
                logger_1.default.log('isSimilarGridLine(L,R)', false, parent.id, left, right);
            }
        }
        else {
            logger_1.default.log('isSimilarGridLine', false, parent.id);
            logger_1.default.log(nodes.map(function (child) { return isSimilarBox(child, nodes[0]); }));
            logger_1.default.log(nodes.map(function (child) { return similarTree(child, nodes[0]); }));
        }
    }
    return false;
}
exports.isSimilarAsGrid = isSimilarAsGrid;
