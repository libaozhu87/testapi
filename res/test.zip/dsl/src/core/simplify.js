"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var flex_type_1 = require("./../define/flex-type");
var node_util_1 = require("./node-util");
var layout_util_1 = require("./layout-util");
var frame_util_1 = require("./frame-util");
var clone_1 = require("./../primitive/clone");
var magic_1 = require("./magic");
function simplifyText(node, property, rootContainer) {
    var type = node.type;
    if (type === node_1.NodeType.TEXT) {
        var text_1 = node;
        var group_1 = text_1.parent;
        if (group_1 !== undefined && property.getChildren(group_1).length === 1) {
            var isCenter = [flex_type_1.FlexDirection.ROW, flex_type_1.FlexDirection.COLUMN].every(function (dir) { return frame_util_1.FrameUtil.isCenter(text_1.measured, group_1.measured, dir, 4); });
            var row = flex_type_1.FlexDirection.ROW;
            var col = flex_type_1.FlexDirection.COLUMN;
            var paddings = [
                frame_util_1.FrameUtil.getStart(text_1.measured, row),
                frame_util_1.FrameUtil.getLength(group_1.measured, row) - frame_util_1.FrameUtil.getEnd(text_1.measured, row),
                frame_util_1.FrameUtil.getStart(text_1.measured, col),
                frame_util_1.FrameUtil.getLength(group_1.measured, col) - frame_util_1.FrameUtil.getEnd(text_1.measured, col)
            ];
            if (isCenter && paddings.every(function (padding) { return padding <= magic_1.MAGIC_MARGIN; })) {
                var grandparent = group_1.parent;
                if (grandparent !== undefined && frame_util_1.FrameUtil.getLength(grandparent.measured, row) === frame_util_1.FrameUtil.getLength(group_1.measured, row)) {
                    return;
                }
                ;
                [flex_type_1.FlexDirection.ROW, flex_type_1.FlexDirection.COLUMN].forEach(function (dir) {
                    layout_util_1.LayoutUtil.setPaddingStart(group_1.layout, dir, frame_util_1.FrameUtil.getStart(text_1.measured, dir));
                    layout_util_1.LayoutUtil.setPaddingEnd(group_1.layout, dir, frame_util_1.FrameUtil.getLength(group_1.measured, dir) - frame_util_1.FrameUtil.getEnd(text_1.measured, dir));
                });
                if (text_1.textStyles.maxHeight > 0) {
                    text_1.textStyles.maxHeight +=
                        frame_util_1.FrameUtil.getStart(text_1.measured, col) + frame_util_1.FrameUtil.getLength(group_1.measured, col) - frame_util_1.FrameUtil.getEnd(text_1.measured, col);
                }
                var parent_1 = group_1.parent;
                if (parent_1 !== undefined) {
                    var index = parent_1.children.indexOf(group_1);
                    parent_1.children.splice(index, 1, text_1);
                }
                else {
                    rootContainer.root = text_1;
                }
                text_1.parent = parent_1;
                group_1.parent = undefined;
                group_1.children = [];
                text_1.layout = clone_1.default(group_1.layout);
                text_1.layout.flexDirection = undefined;
                text_1.layout.justifyContent = undefined;
                text_1.layout.alignItems = undefined;
                text_1.frame = __assign({}, group_1.frame);
                text_1.measured = __assign({}, group_1.measured);
                text_1.reasons = text_1.reasons.concat(group_1.reasons);
                text_1.styles = group_1.styles;
                if (text_1.textStyles.lineHeight !== undefined) {
                    text_1.textStyles.lineHeight = Math.min(text_1.textStyles.lineHeight, group_1.exactFrame.height);
                }
                console.log('simplifyText', text_1.name);
            }
        }
    }
}
function simplify(node, property) {
    return node_util_1.NodeUtil.visitNodeTreeReverse(node, property, simplifyText);
}
exports.simplify = simplify;
