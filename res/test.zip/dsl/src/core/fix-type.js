"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
function fixType(node) {
    if (node.type === node_1.NodeType.GROUP) {
        var group = node;
        group.children.forEach(fixType);
    }
    ;
    Object.assign(node, { type: node.type.toUpperCase() });
}
exports.default = fixType;
