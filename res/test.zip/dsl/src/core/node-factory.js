"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var flex_type_1 = require("./../define/flex-type");
var node_1 = require("./../define/node");
var CNode = (function () {
    function CNode(input, parent) {
        this.name = input.name;
        this.id = input.id;
        this.zIndex = input.zIndex;
        this.type = this.nodeType(input.type);
        this.parent = parent;
        this.specialAlign = input.specailAlign;
        this.raw = __assign({}, input);
        this.raw.frame = undefined;
        this.raw.exactFrame = undefined;
        this.raw.layers = undefined;
        this.raw.styles = undefined;
        this.raw.textStyles = undefined;
        this.raw.imageStyles = undefined;
        this.frame = __assign({}, input.frame);
        this.exactFrame = __assign({}, input.exactFrame);
        this.measured = __assign({}, this.frame);
        this.reasons = [];
        this.layout = {
            flexDirection: undefined,
            justifyContent: undefined,
            alignItems: undefined,
            padding: [undefined, undefined, undefined, undefined],
            position: flex_type_1.PositionType.RELATIVE,
            width: undefined,
            height: undefined,
            left: undefined,
            right: undefined,
            top: undefined,
            bottom: undefined,
            margin: [undefined, undefined, undefined, undefined],
            flex: undefined,
            alignSelf: undefined
        };
    }
    CNode.prototype.nodeType = function (type) {
        if (type === node_1.NodeType.TEXT) {
            return node_1.NodeType.TEXT;
        }
        else if (type === node_1.NodeType.IMAGE) {
            return node_1.NodeType.IMAGE;
        }
        else if (type === node_1.NodeType.SHAPE) {
            return node_1.NodeType.SHAPE;
        }
        else if (type === node_1.NodeType.GROUP) {
            return node_1.NodeType.GROUP;
        }
        else if (type === 'component') {
            return node_1.NodeType.COMPONENT;
        }
        throw new Error("Unknow type " + type);
    };
    return CNode;
}());
var CText = (function (_super) {
    __extends(CText, _super);
    function CText(input, parent) {
        var _this = _super.call(this, input, parent) || this;
        _this.value = input.value;
        _this.textStyles = input.textStyles;
        if (!(_this.textStyles.lineHeight > 0 && _this.frame.height >= _this.textStyles.lineHeight * 2)) {
            _this.textStyles.maxWidth = undefined;
            _this.textStyles.maxHeight = undefined;
        }
        return _this;
    }
    return CText;
}(CNode));
var CImage = (function (_super) {
    __extends(CImage, _super);
    function CImage(input, parent) {
        var _this = _super.call(this, input, parent) || this;
        _this.value = input.value;
        _this.imageStyles = input.imageStyles;
        return _this;
    }
    return CImage;
}(CNode));
var CShape = (function (_super) {
    __extends(CShape, _super);
    function CShape(input, parent) {
        var _this = _super.call(this, input, parent) || this;
        _this.styles = input.styles;
        _this.styles.opacity = undefined;
        return _this;
    }
    return CShape;
}(CNode));
var CGroup = (function (_super) {
    __extends(CGroup, _super);
    function CGroup(input, parent) {
        var _this = _super.call(this, input, parent) || this;
        _this.styles = input.styles;
        _this.specialLayout = undefined;
        return _this;
    }
    return CGroup;
}(CNode));
function buildNode(input, parent) {
    var type = input.type;
    if (type === node_1.NodeType.TEXT) {
        return new CText(input, parent);
    }
    else if (type === node_1.NodeType.IMAGE) {
        return new CImage(input, parent);
    }
    else if (type === node_1.NodeType.SHAPE) {
        return new CShape(input, parent);
    }
    else if (type === node_1.NodeType.GROUP) {
        return new CGroup(input, parent);
    }
    else {
        throw new Error("Unknow type " + type);
    }
}
exports.buildNode = buildNode;
