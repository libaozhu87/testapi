"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var flex_type_1 = require("./../define/flex-type");
var DirectionUtil = (function () {
    function DirectionUtil() {
    }
    DirectionUtil.cross = function (dir) {
        if (dir === flex_type_1.FlexDirection.COLUMN) {
            return flex_type_1.FlexDirection.ROW;
        }
        else if (dir === flex_type_1.FlexDirection.ROW) {
            return flex_type_1.FlexDirection.COLUMN;
        }
    };
    return DirectionUtil;
}());
exports.DirectionUtil = DirectionUtil;
