"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var flex_type_1 = require("./../define/flex-type");
var frame_util_1 = require("./frame-util");
var layout_util_1 = require("./layout-util");
var direction_util_1 = require("./direction-util");
var node_util_1 = require("./node-util");
var conflict_1 = require("./conflict");
function isFirstLinearChild(child, property) {
    return property.getLinearChildren(child.parent).indexOf(child) === 0;
}
function isLastLinearChild(child, property) {
    var linears = property.getLinearChildren(child.parent);
    return linears.indexOf(child) === linears.length - 1;
}
function setPositionForAbsolute(child, parent, dir, isChildUseCenter) {
    if (isChildUseCenter) {
        if (layout_util_1.LayoutUtil.isFixed(child.layout, dir)) {
            layout_util_1.LayoutUtil.setPositionStart(child.layout, dir, frame_util_1.FrameUtil.getStart(child.measured, dir));
        }
        else {
            var center = frame_util_1.FrameUtil.getCenter(child.measured, dir);
            layout_util_1.LayoutUtil.setPositionStart(child.layout, dir, center);
            layout_util_1.LayoutUtil.setTransformForCenter(child.layout, dir);
        }
    }
    else if (frame_util_1.FrameUtil.getLength(child.measured, dir) === frame_util_1.FrameUtil.getLength(parent.measured, dir) &&
        frame_util_1.FrameUtil.getStart(child.measured, dir) === 0) {
        layout_util_1.LayoutUtil.setPositionStart(child.layout, dir, 0);
        layout_util_1.LayoutUtil.setPositionEnd(child.layout, dir, 0);
    }
    else if (frame_util_1.FrameUtil.isNearEnd(child.measured, parent.measured, dir)) {
        layout_util_1.LayoutUtil.setPositionEnd(child.layout, dir, frame_util_1.FrameUtil.getLength(parent.measured, dir) - frame_util_1.FrameUtil.getEnd(child.measured, dir));
    }
    else {
        layout_util_1.LayoutUtil.setPositionStart(child.layout, dir, frame_util_1.FrameUtil.getStart(child.measured, dir));
    }
}
function newGroupForAbsolute(child, parent, property) {
    var oldChildMeasured = __assign({}, child.measured);
    var newGroup = node_util_1.NodeUtil.newGroup([child], parent);
    child.measured.x = oldChildMeasured.x;
    child.measured.y = oldChildMeasured.y;
    newGroup.measured.x = 0;
    newGroup.measured.y = 0;
    newGroup.measured.width = parent.measured.width;
    newGroup.measured.height = parent.measured.height;
    newGroup.layout.flexDirection = flex_type_1.FlexDirection.COLUMN;
    newGroup.layout.justifyContent = frame_util_1.FrameUtil.isCenter(child.measured, newGroup.measured, flex_type_1.FlexDirection.COLUMN)
        ? flex_type_1.JustifyContent.CENTER
        : frame_util_1.FrameUtil.isNearEnd(child.measured, newGroup.measured, flex_type_1.FlexDirection.COLUMN)
            ? flex_type_1.JustifyContent.FLEX_END
            : flex_type_1.JustifyContent.FLEX_START;
    newGroup.layout.alignItems = frame_util_1.FrameUtil.isCenter(child.measured, newGroup.measured, flex_type_1.FlexDirection.ROW)
        ? flex_type_1.AlignItems.CENTER
        : frame_util_1.FrameUtil.isNearEnd(child.measured, newGroup.measured, flex_type_1.FlexDirection.ROW)
            ? flex_type_1.AlignItems.FLEX_END
            : flex_type_1.AlignItems.FLEX_START;
    newGroup.layout.position = flex_type_1.PositionType.ABSOLUTE;
    newGroup.layout.left = 0;
    newGroup.layout.top = 0;
    newGroup.layout.right = 0;
    newGroup.layout.bottom = 0;
    measurePosition(child, property);
    return newGroup;
}
function needPolyfillForTextAbsoluteCenter(child, property) {
    var type = child.type, parent = child.parent;
    return (type === node_1.NodeType.TEXT &&
        (frame_util_1.FrameUtil.isCenter(child.measured, parent.measured, flex_type_1.FlexDirection.ROW) && !layout_util_1.LayoutUtil.isFixed(child.layout, flex_type_1.FlexDirection.ROW)) &&
        (!frame_util_1.FrameUtil.isCenter(child.measured, parent.measured, flex_type_1.FlexDirection.COLUMN) || property.isSingleLinesText(child)) &&
        false);
}
function needPolyfillForAbsoluteCenter(child) {
    var parent = child.parent;
    var dirs = [flex_type_1.FlexDirection.ROW, flex_type_1.FlexDirection.COLUMN];
    return dirs.some(function (dir) {
        return !layout_util_1.LayoutUtil.isFixed(child.layout, dir) && frame_util_1.FrameUtil.isCenter(child.measured, parent.measured, dir);
    });
}
function isCrossStrictInCenter(child, property, dir) {
    var type = child.type;
    if (type === node_1.NodeType.GROUP) {
        var group = child;
        var mainDir = group.layout.flexDirection;
        if (direction_util_1.DirectionUtil.cross(mainDir) === dir) {
            if (!conflict_1.isConflicted(group, true)) {
                var linears = property.getLinearChildren(group);
                if (linears.length >= 2) {
                    if (group.layout.alignItems === flex_type_1.AlignItems.CENTER) {
                        return linears.every(function (linear) { return linear.layout.alignSelf === flex_type_1.AlignItems.CENTER || linear.layout.alignSelf === undefined; });
                    }
                }
            }
        }
    }
    return false;
}
function needCenterForAbsolute(child, property, dir) {
    var parent = child.parent;
    var isCenter = frame_util_1.FrameUtil.isCenter(child.measured, parent.measured, dir);
    return isCenter || isCrossStrictInCenter(child, property, dir);
}
function calcAbsolute(child, property) {
    var parent = child.parent;
    var dirs = [flex_type_1.FlexDirection.ROW, flex_type_1.FlexDirection.COLUMN];
    var needWrap = dirs.some(function (dir) { return needCenterForAbsolute(child, property, dir) && (parent === undefined || !layout_util_1.LayoutUtil.isFixed(parent.layout, dir)); });
    if (needWrap) {
        if (needPolyfillForTextAbsoluteCenter(child, property)) {
            var text = child;
            layout_util_1.LayoutUtil.setPositionStart(text.layout, flex_type_1.FlexDirection.ROW, 0);
            layout_util_1.LayoutUtil.setPositionEnd(text.layout, flex_type_1.FlexDirection.ROW, 0);
            text.textStyles.textAlign = 'center';
            setPositionForAbsolute(child, parent, flex_type_1.FlexDirection.COLUMN, false);
        }
        else if (needPolyfillForAbsoluteCenter(child)) {
            newGroupForAbsolute(child, parent, property);
            child.layout.position = flex_type_1.PositionType.RELATIVE;
            calcMainAxis(child, property);
            calcCrossAxis(child, property);
        }
        else {
            dirs.forEach(function (dir) {
                setPositionForAbsolute(child, parent, dir, needCenterForAbsolute(child, property, dir));
            });
        }
    }
    else {
        dirs.forEach(function (dir) {
            setPositionForAbsolute(child, parent, dir, needCenterForAbsolute(child, property, dir));
        });
    }
}
function calcMainAxis(child, property) {
    var parent = child.parent;
    var dir = parent.layout.flexDirection;
    var justifyContent = parent.layout.justifyContent;
    var isFixed = layout_util_1.LayoutUtil.isFixed(parent.layout, dir);
    if (justifyContent === flex_type_1.JustifyContent.SPACE_BETWEEN) {
        var children = property.getLinearChildren(parent);
        if (children[0] === child) {
            layout_util_1.LayoutUtil.setMarginStart(child.layout, dir, frame_util_1.FrameUtil.getStart(child.measured, dir));
        }
        else if (children[children.length - 1] === child) {
            layout_util_1.LayoutUtil.setMarginEnd(child.layout, dir, frame_util_1.FrameUtil.getLength(parent.measured, dir) - frame_util_1.FrameUtil.getEnd(child.measured, dir));
        }
        else {
        }
    }
    else if (justifyContent === flex_type_1.JustifyContent.FLEX_START) {
        var prev = node_util_1.NodeUtil.prevSlibing(child, property);
        var prevEnd = prev ? frame_util_1.FrameUtil.getEnd(prev.measured, dir) : 0;
        var offset = frame_util_1.FrameUtil.getStart(child.measured, dir) - prevEnd;
        if (property.isDivider(child, dir) && prev) {
            layout_util_1.LayoutUtil.setMarginEnd(prev.layout, dir, offset);
        }
        else {
            layout_util_1.LayoutUtil.setMarginStart(child.layout, dir, offset);
        }
        var offset2 = frame_util_1.FrameUtil.getLength(parent.measured, dir) - frame_util_1.FrameUtil.getEnd(child.measured, dir);
        if (!isFixed && isLastLinearChild(child, property)) {
            layout_util_1.LayoutUtil.setMarginEnd(child.layout, dir, offset2);
        }
    }
    else if (justifyContent === flex_type_1.JustifyContent.CENTER) {
        var prev = node_util_1.NodeUtil.prevSlibing(child, property);
        if (prev) {
            var prevEnd = frame_util_1.FrameUtil.getEnd(prev.measured, dir);
            var offset = frame_util_1.FrameUtil.getStart(child.measured, dir) - prevEnd;
            layout_util_1.LayoutUtil.setMarginStart(child.layout, dir, offset);
        }
    }
    else if (justifyContent === flex_type_1.JustifyContent.FLEX_END) {
        var next = node_util_1.NodeUtil.nextSlibing(child, property);
        var nextStart = next ? frame_util_1.FrameUtil.getStart(next.measured, dir) : frame_util_1.FrameUtil.getLength(parent.measured, dir);
        var offset = nextStart - frame_util_1.FrameUtil.getEnd(child.measured, dir);
        if (property.isDivider(child, dir) && next) {
            layout_util_1.LayoutUtil.setMarginStart(next.layout, dir, offset);
        }
        else {
            layout_util_1.LayoutUtil.setMarginEnd(child.layout, dir, offset);
        }
        var offset2 = frame_util_1.FrameUtil.getStart(child.measured, dir);
        if (!isFixed && isFirstLinearChild(child, property)) {
            layout_util_1.LayoutUtil.setMarginStart(child.layout, dir, offset2);
        }
    }
    else {
        throw new Error(parent.name + " " + child.name + " " + justifyContent);
    }
}
function calcCrossAxis(child, property) {
    var parent = child.parent;
    var dir = direction_util_1.DirectionUtil.cross(parent.layout.flexDirection);
    var align = child.layout.alignSelf || parent.layout.alignItems;
    var isFixed = parent && layout_util_1.LayoutUtil.isFixed(parent.layout, dir);
    if (align === flex_type_1.AlignItems.FLEX_START) {
        layout_util_1.LayoutUtil.setMarginStart(child.layout, dir, frame_util_1.FrameUtil.getStart(child.measured, dir));
        if (!isFixed) {
            var offset = frame_util_1.FrameUtil.getLength(parent.measured, dir) - frame_util_1.FrameUtil.getEnd(child.measured, dir);
            layout_util_1.LayoutUtil.setMarginEnd(child.layout, dir, offset);
        }
    }
    else if (align === flex_type_1.AlignItems.CENTER) {
        var offset = frame_util_1.FrameUtil.getCenter(child.measured, dir) - frame_util_1.FrameUtil.getLength(parent.measured, dir) / 2;
        if (offset > 0) {
            layout_util_1.LayoutUtil.setMarginStart(child.layout, dir, offset);
        }
        else {
            layout_util_1.LayoutUtil.setMarginEnd(child.layout, dir, -offset);
        }
    }
    else if (align === flex_type_1.AlignItems.FLEX_END) {
        var offset = frame_util_1.FrameUtil.getLength(parent.measured, dir) - frame_util_1.FrameUtil.getEnd(child.measured, dir);
        layout_util_1.LayoutUtil.setMarginEnd(child.layout, dir, offset);
        if (!isFixed) {
            layout_util_1.LayoutUtil.setMarginStart(child.layout, dir, frame_util_1.FrameUtil.getStart(child.measured, dir));
        }
    }
    else if (align === flex_type_1.AlignItems.STRETCH) {
        layout_util_1.LayoutUtil.setMarginStart(child.layout, dir, 0);
        layout_util_1.LayoutUtil.setMarginEnd(child.layout, dir, 0);
    }
}
function position(node, property) {
    property.getChildren(node).forEach(function (child) {
        if (child.layout.position === flex_type_1.PositionType.ABSOLUTE) {
            calcAbsolute(child, property);
        }
        else {
            calcMainAxis(child, property);
            calcCrossAxis(child, property);
        }
    });
}
function measurePosition(node, property) {
    return node_util_1.NodeUtil.visitNodeTree(node, property, position);
}
exports.measurePosition = measurePosition;
