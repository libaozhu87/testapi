"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var frame_util_1 = require("./frame-util");
var math_1 = require("./math");
var flex_type_1 = require("./../define/flex-type");
var fill_1 = require("./../primitive/fill");
var flatten_1 = require("./../primitive/flatten");
var min_1 = require("./../primitive/min");
var top_1 = require("./../primitive/top");
var unique_1 = require("./../primitive/unique");
var logger_1 = require("./../primitive/logger");
var assert_1 = require("./../primitive/assert");
var isEmpty_1 = require("./../primitive/isEmpty");
var compact_1 = require("./../primitive/compact");
var conflict_1 = require("./conflict");
var similar_1 = require("./similar");
var magic_1 = require("./magic");
var node_1 = require("./../define/node");
var id_generate_1 = require("./id-generate");
var special_1 = require("./../define/special");
function layerComparator(c0, c1, dir) {
    if (math_1.isOverlap(c0.exactFrame, c1.exactFrame)) {
        return c0.zIndex - c1.zIndex;
    }
    else {
        return frame_util_1.FrameUtil.getStart(c0.exactFrame, dir) - frame_util_1.FrameUtil.getStart(c1.exactFrame, dir);
    }
}
function decompose(layer) {
    if (layer.type === node_1.NodeType.GROUP) {
        return layer.layers.slice();
    }
    return [layer];
}
function compose(nodes, dir) {
    var children = compact_1.default(nodes);
    if (children.length === 0) {
        return undefined;
    }
    else if (children.length === 1) {
        return children[0];
    }
    var zIndex = min_1.default(children.map(function (child) { return child.zIndex; }));
    var frames = children.map(function (node) { return node.frame; });
    var exactFrames = children.map(function (node) { return node.exactFrame; });
    var newFrame = frames.reduce(frame_util_1.FrameUtil.expand, undefined);
    var newExactFrame = exactFrames.reduce(frame_util_1.FrameUtil.expand, undefined);
    var group = {
        name: 'auto-merge',
        id: 'g' + id_generate_1.newId(),
        type: node_1.NodeType.GROUP,
        frame: newFrame,
        exactFrame: newExactFrame,
        layers: children,
        value: undefined,
        styles: undefined,
        textStyles: undefined,
        imageStyles: undefined,
        zIndex: zIndex,
        dir: dir
    };
    return group;
}
var SliceResultType;
(function (SliceResultType) {
    SliceResultType["OVERLAPS_BACKGROUND"] = "OVERLAPS_BACKGROUND";
    SliceResultType["OVERLAPS_MIDGROUND"] = "OVERLAPS_MIDGROUND";
    SliceResultType["OVERLAPS_FOREGROUND"] = "OVERLAPS_FOREGROUND";
    SliceResultType["PROJECTION"] = "PROJECTION";
    SliceResultType["PROJECTION_SCALED"] = "PROJECTION_SCALED";
    SliceResultType["CONFILCT_BACKGROUND"] = "CONFILCT_BACKGROUND";
    SliceResultType["CONFILCT_FOREGROUND"] = "CONFILCT_FOREGROUND";
})(SliceResultType || (SliceResultType = {}));
function sliceResultTypeOrder(type) {
    switch (type) {
        case SliceResultType.OVERLAPS_BACKGROUND:
        case SliceResultType.OVERLAPS_MIDGROUND:
        case SliceResultType.OVERLAPS_FOREGROUND:
            return 1;
        case SliceResultType.PROJECTION:
            return 2;
        case SliceResultType.PROJECTION_SCALED:
            return 3;
        case SliceResultType.CONFILCT_BACKGROUND:
        case SliceResultType.CONFILCT_FOREGROUND:
            return 4;
        default:
            return 5;
    }
}
function sliceByOverlaps(nodes) {
    var dirs = [flex_type_1.FlexDirection.ROW, flex_type_1.FlexDirection.COLUMN];
    nodes = nodes.slice().sort(function (n0, n1) { return n0.zIndex - n1.zIndex; });
    var isCoincidence = function (small, large) {
        return dirs.every(function (dir) {
            var intersection = math_1.intersectionOnDirection(small.exactFrame, large.exactFrame, dir);
            return intersection / frame_util_1.FrameUtil.getLength(small.exactFrame, dir) >= 0.5;
        });
    };
    var index = 0;
    var _loop_1 = function () {
        var bg = nodes[index];
        if (index === nodes.length - 1 || !nodes.every(function (small) { return small === bg || isCoincidence(small, bg); })) {
            if (index > 0) {
                return { value: {
                        start: nodes.slice(0, index),
                        end: nodes.slice(index),
                        dir: undefined,
                        margin: -1,
                        conflictRate: 1,
                        type: SliceResultType.OVERLAPS_BACKGROUND
                    } };
            }
            return "break";
        }
    };
    for (index = 0; index < nodes.length; index++) {
        var state_1 = _loop_1();
        if (typeof state_1 === "object")
            return state_1.value;
        if (state_1 === "break")
            break;
    }
    var _loop_2 = function () {
        var fg = nodes[index];
        if (index === 0 || !nodes.every(function (small) { return small === fg || isCoincidence(small, fg); })) {
            if (index < nodes.length - 1) {
                return { value: {
                        start: nodes.slice(0, index + 1),
                        end: nodes.slice(index + 1),
                        dir: undefined,
                        margin: -1,
                        conflictRate: 1,
                        type: SliceResultType.OVERLAPS_FOREGROUND
                    } };
            }
            return "break";
        }
    };
    for (index = nodes.length - 1; index >= 0; index--) {
        var state_2 = _loop_2();
        if (typeof state_2 === "object")
            return state_2.value;
        if (state_2 === "break")
            break;
    }
    var _loop_3 = function () {
        var mg = nodes[index];
        if (nodes.every(function (small) { return small === mg || isCoincidence(small, mg); })) {
            return { value: {
                    start: nodes.slice(0, index),
                    end: nodes.slice(index),
                    dir: undefined,
                    margin: -1,
                    conflictRate: 1,
                    type: SliceResultType.OVERLAPS_MIDGROUND
                } };
        }
    };
    for (index = 1; index < nodes.length; index++) {
        var state_3 = _loop_3();
        if (typeof state_3 === "object")
            return state_3.value;
    }
    return undefined;
}
function calcConflictRateOnDir(start, end, scale, dir) {
    var sf = frame_util_1.FrameUtil.expandFrames.apply(frame_util_1.FrameUtil, start.map(function (n) { return n.exactFrame; }));
    var ef = frame_util_1.FrameUtil.expandFrames.apply(frame_util_1.FrameUtil, end.map(function (n) { return n.exactFrame; }));
    var intersection = math_1.intersectionOnDirectionByScale(sf, ef, scale, dir);
    return intersection / (Math.min(frame_util_1.FrameUtil.getLength(sf, dir), frame_util_1.FrameUtil.getLength(ef, dir)) * scale);
}
function calcMarginOnDir(start, end, scale, dir) {
    var sf = frame_util_1.FrameUtil.expandFrames.apply(frame_util_1.FrameUtil, start.map(function (n) { return n.exactFrame; }));
    var ef = frame_util_1.FrameUtil.expandFrames.apply(frame_util_1.FrameUtil, end.map(function (n) { return n.exactFrame; }));
    return math_1.marginOnDirectionByScale(sf, ef, scale, dir);
}
function selectSliceResult(a, b) {
    if (a === undefined || b === undefined) {
        return a || b;
    }
    var orderA = sliceResultTypeOrder(a.type);
    var orderB = sliceResultTypeOrder(b.type);
    if (orderA !== orderB) {
        return orderA < orderB ? a : b;
    }
    assert_1.default(a !== undefined && b !== undefined);
    if (orderA === sliceResultTypeOrder(SliceResultType.OVERLAPS_BACKGROUND)) {
        return a;
    }
    if (orderA === sliceResultTypeOrder(SliceResultType.PROJECTION)) {
        if (a.margin >= 0 && a.dir === flex_type_1.FlexDirection.COLUMN && a.dir !== b.dir) {
            return a;
        }
        if (b.margin >= 0 && b.dir === flex_type_1.FlexDirection.COLUMN && a.dir !== b.dir) {
            return b;
        }
        return a.margin >= b.margin ? a : b;
    }
    if (orderA === sliceResultTypeOrder(SliceResultType.PROJECTION_SCALED)) {
        return a.margin >= b.margin ? a : b;
    }
    if (orderA === sliceResultTypeOrder(SliceResultType.CONFILCT_BACKGROUND)) {
        return a.conflictRate >= b.conflictRate ? a : b;
    }
    throw new Error("");
}
var NodeGraph = (function () {
    function NodeGraph(nodes, isBelongTo, sort) {
        this._vectors = [];
        this._majorsCache = {};
        this._nodes = nodes;
        this._sort = sort;
        for (var i = 0; i < nodes.length; i++) {
            for (var j = i + 1; j < nodes.length; j++) {
                var ni = nodes[i];
                var nj = nodes[j];
                var isJToI = isBelongTo(nj, ni);
                var isIToJ = isBelongTo(ni, nj);
                if (isJToI && isIToJ) {
                    if (nj.zIndex < ni.zIndex) {
                        this._vectors.push([ni, nj]);
                    }
                    else {
                        this._vectors.push([nj, ni]);
                    }
                }
                else if (isJToI) {
                    this._vectors.push([nj, ni]);
                }
                else if (isIToJ) {
                    this._vectors.push([ni, nj]);
                }
            }
        }
    }
    NodeGraph.prototype.majors = function () {
        var _this = this;
        return this._nodes.filter(function (node) { return _this.isMajor(node); });
    };
    NodeGraph.prototype.getMajor = function (node) {
        var major = top_1.default(this.getMajors(node), this._sort);
        return major;
    };
    NodeGraph.prototype.getBlock = function (major) {
        var _this = this;
        var result = this._nodes.filter(function (node) { return _this.getMajor(node) === major; });
        return result;
    };
    NodeGraph.prototype.isMajor = function (node) {
        for (var _i = 0, _a = this._vectors; _i < _a.length; _i++) {
            var vector = _a[_i];
            if (vector[0] === node) {
                return false;
            }
        }
        return true;
    };
    NodeGraph.prototype.getParents = function (node) {
        var parents = [];
        for (var _i = 0, _a = this._vectors; _i < _a.length; _i++) {
            var vector = _a[_i];
            if (vector[0] === node) {
                parents.push(vector[1]);
            }
        }
        parents = unique_1.default(parents);
        return parents;
    };
    NodeGraph.prototype.getMajors = function (node) {
        var _this = this;
        var majors = this._majorsCache[node.id];
        if (majors !== undefined) {
            return majors;
        }
        var parents = this.getParents(node);
        if (!isEmpty_1.default(parents)) {
            majors = unique_1.default(flatten_1.default(parents.map(function (parent) {
                if (_this.isMajor(parent)) {
                    return parent;
                }
                else {
                    return _this.getMajors(parent);
                }
            }), true));
            this._majorsCache[node.id] = majors;
            return majors;
        }
        majors = [node];
        this._majorsCache[node.id] = majors;
        return majors;
    };
    return NodeGraph;
}());
function sliceByProjectionOnDir(nodes, dir, scale) {
    var nodeGraph = new NodeGraph(nodes, function (n0, n1) { return math_1.isFullOverlapOnDirectionByScale(n0.exactFrame, n1.exactFrame, scale, dir); }, function (n0, n1) { return -frame_util_1.FrameUtil.getCenter(n0.exactFrame, dir) + frame_util_1.FrameUtil.getCenter(n1.exactFrame, dir); });
    var majors = nodeGraph.majors();
    if (majors.length <= 1) {
        return undefined;
    }
    else {
        var type = scale >= 0.999999 ? SliceResultType.PROJECTION : SliceResultType.PROJECTION_SCALED;
        majors.sort(function (a, b) { return frame_util_1.FrameUtil.getCenter(a.exactFrame, dir) - frame_util_1.FrameUtil.getCenter(b.exactFrame, dir); });
        var pairs = [];
        var _loop_4 = function (i) {
            var start = majors.slice(0, i);
            var end = majors.slice(i);
            var block0 = flatten_1.default(start.map(function (major) { return nodeGraph.getBlock(major); }), false);
            var block1 = flatten_1.default(end.map(function (major) { return nodeGraph.getBlock(major); }), false);
            var isEndAsBackground = !block1.every(function (b1) { return block0.every(function (b0) { return !math_1.isOverlap(b0.exactFrame, b1.exactFrame) || b1.zIndex > b0.zIndex; }); });
            pairs.push({
                start: block0,
                end: block1,
                dir: dir,
                margin: calcMarginOnDir(start, end, scale, dir),
                conflictRate: calcConflictRateOnDir(start, end, scale, dir),
                type: type,
                isEndAsBackground: isEndAsBackground
            });
        };
        for (var i = 1; i < majors.length; i++) {
            _loop_4(i);
        }
        var result = top_1.default(pairs, function (a, b) { return (selectSliceResult(a, b) === a ? -1 : 1); });
        if (type === SliceResultType.PROJECTION) {
            if (result && result.conflictRate >= 0.2) {
                return undefined;
            }
        }
        return result;
    }
}
function sliceByProjection(nodes) {
    var rowResult = sliceByProjectionOnDir(nodes, flex_type_1.FlexDirection.ROW, 1);
    var colResult = sliceByProjectionOnDir(nodes, flex_type_1.FlexDirection.COLUMN, 1);
    return selectSliceResult(rowResult, colResult);
}
function sliceBySolveConflict(nodes) {
    var nodeGraph = new NodeGraph(nodes, function (n0, n1) { return math_1.isFullOverlap(n0.exactFrame, n1.exactFrame) && n0.zIndex > n1.zIndex; }, function (n0, n1) { return -n0.zIndex + n1.zIndex; });
    var majors = nodeGraph.majors();
    var dir = conflict_1.getDirectionByBaseNodes(majors);
    var majorConflicts = conflict_1.tRawFindOverlaps(majors.map(function (node) { return ({ carry: node }); }), function (l1, l2) {
        return math_1.measureOverlapOnDir(l1, l2, dir);
    }).map(function (frameCarry) { return frameCarry.carry; });
    if (isEmpty_1.default(majorConflicts)) {
        majorConflicts = conflict_1.strictFindOverlaps(majors.map(function (node) { return ({ carry: node }); }), function (l1, l2) { return math_1.measureOverlapOnDir(l1, l2, dir); });
    }
    assert_1.default(!isEmpty_1.default(majorConflicts));
    var majorRemains = majors.filter(function (node) { return majorConflicts.indexOf(node) === -1; });
    var confilctIsBackground = majorConflicts.some(function (conflict) {
        return majorRemains.some(function (remain) { return math_1.isOverlap(remain.exactFrame, conflict.exactFrame) && remain.zIndex > conflict.zIndex; });
    });
    var conflicts = unique_1.default(flatten_1.default(majorConflicts.map(function (mc) { return nodeGraph.getBlock(mc); }))).sort(function (n0, n1) { return n0.zIndex - n1.zIndex; });
    var remains = unique_1.default(flatten_1.default(majorRemains.map(function (mc) { return nodeGraph.getBlock(mc); }))).sort(function (n0, n1) { return n0.zIndex - n1.zIndex; });
    if (confilctIsBackground) {
        return {
            start: conflicts,
            end: remains,
            margin: -1,
            conflictRate: 1,
            dir: dir,
            type: SliceResultType.CONFILCT_BACKGROUND
        };
    }
    else {
        return {
            start: remains,
            end: conflicts,
            margin: -1,
            conflictRate: 1,
            dir: dir,
            type: SliceResultType.CONFILCT_FOREGROUND
        };
    }
}
function sliceByProjectionScaled(nodes) {
    for (var scale = 0.95; scale > 0.5; scale -= 0.05) {
        var rowResult = sliceByProjectionOnDir(nodes, flex_type_1.FlexDirection.ROW, scale);
        var colResult = sliceByProjectionOnDir(nodes, flex_type_1.FlexDirection.COLUMN, scale);
        var result = selectSliceResult(rowResult, colResult);
        if (result) {
            return result;
        }
    }
}
function slice(nodes) {
    var result = sliceByOverlaps(nodes);
    if (result !== undefined) {
        return result;
    }
    result = sliceByProjection(nodes);
    if (result !== undefined) {
        return result;
    }
    result = sliceByProjectionScaled(nodes);
    if (result !== undefined) {
        return result;
    }
    return sliceBySolveConflict(nodes);
}
function unite(nodes) {
    if (isEmpty_1.default(nodes)) {
        return undefined;
    }
    else if (nodes.length === 1) {
        return nodes[0];
    }
    logger_1.default.log('----unite----');
    logger_1.default.log('all', nodes.map(function (n) { return n.id; }));
    var result = slice(nodes);
    assert_1.default(result !== undefined);
    logger_1.default.log('start', result.start.map(function (n) { return n.id; }));
    logger_1.default.log('end', result.end.map(function (n) { return n.id; }));
    logger_1.default.log('dir', result.dir);
    logger_1.default.log('margin', result.margin);
    logger_1.default.log('conflictRate', result.conflictRate);
    logger_1.default.log('type', result.type);
    var type = result.type;
    switch (type) {
        case SliceResultType.OVERLAPS_BACKGROUND:
            return compose(result.start.concat([unite(result.end)]), result.dir);
        case SliceResultType.OVERLAPS_FOREGROUND:
            return compose([unite(result.start)].concat(result.end), result.dir);
        case SliceResultType.OVERLAPS_MIDGROUND:
            return compose([unite(result.start), unite(result.end)], result.dir);
        case SliceResultType.PROJECTION:
        case SliceResultType.PROJECTION_SCALED:
            return compose([unite(result.start), unite(result.end)], result.dir);
        case SliceResultType.CONFILCT_BACKGROUND:
            return compose([unite(result.start), unite(result.end)], result.dir);
        case SliceResultType.CONFILCT_FOREGROUND:
            return compose([unite(result.start), unite(result.end)], result.dir);
        default:
            throw new Error("" + type);
    }
}
function flattenNodeOnDirection(node, parentDir) {
    if (node.type === node_1.NodeType.GROUP) {
        var dir_1 = node.dir;
        if (dir_1 === undefined) {
            var g = flattenGroup(node);
            return [g];
        }
        else {
            if (dir_1 === parentDir) {
                return flatten_1.default(node.layers.map(function (l) { return flattenNodeOnDirection(l, dir_1); }), true);
            }
            else {
                var g = flattenGroup(node);
                return [g];
            }
        }
    }
    else {
        return [node];
    }
}
function flattenGroup(node) {
    if (node.type === node_1.NodeType.GROUP) {
        var dir_2 = node.dir;
        node.layers = flatten_1.default(node.layers.map(function (l) { return flattenNodeOnDirection(l, dir_2); }), true);
    }
    return node;
}
function sortOneGroup(group) {
    var dir = conflict_1.getDirection2(group);
    group.layers.sort(function (c0, c1) { return layerComparator(c0, c1, dir); });
}
function sortChildren(node) {
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        sortOneGroup(node);
        node.layers.forEach(sortChildren);
    }
    return node;
}
function seperate(pre, cur, nxt) {
    pre = pre === undefined ? cur : pre;
    nxt = nxt === undefined ? cur : nxt;
    if (pre * 2 <= cur && cur >= magic_1.MAGIC_MARGIN) {
        return true;
    }
    if (nxt * 2 <= cur && cur >= magic_1.MAGIC_MARGIN) {
        return true;
    }
    return false;
}
function scanBySeperate(group) {
    var type = group.type;
    if (type === node_1.NodeType.GROUP) {
        var contents_1 = group.layers;
        var dir_3 = group.dir;
        if (dir_3 === flex_type_1.FlexDirection.ROW && contents_1.length > 2 && !conflict_1.isConflicted2(group)) {
            var bewteens = contents_1.map(function (child, index) {
                var cur = child;
                var nxt = contents_1[index + 1];
                var start = nxt ? frame_util_1.FrameUtil.getStart(nxt.exactFrame, dir_3) : 9999999;
                var end = frame_util_1.FrameUtil.getEnd(cur.exactFrame, dir_3);
                return start - end;
            });
            var sliceIndexs = [];
            for (var i = 0; i < bewteens.length; i++) {
                var pre = bewteens[i - 1];
                var cur = bewteens[i];
                var nxt = bewteens[i + 1];
                if (seperate(pre, cur, nxt)) {
                    sliceIndexs.push(i);
                }
            }
            if (sliceIndexs.length < contents_1.length && sliceIndexs.length > 1) {
                var newLayers = [];
                var _loop_5 = function (i) {
                    var start = i === 0 ? -1 : sliceIndexs[i - 1];
                    var end = sliceIndexs[i];
                    var newgroup = compose(Array.apply(undefined, Array(end - start)).map(function (v, index) {
                        return contents_1[start + index + 1];
                    }), flex_type_1.FlexDirection.ROW);
                    newLayers.push(newgroup);
                };
                for (var i = 0; i < sliceIndexs.length; i++) {
                    _loop_5(i);
                }
                group.layers = newLayers;
                sortOneGroup(group);
            }
        }
        group.layers.forEach(scanBySeperate);
    }
    return group;
}
function isGridLineLike(g) {
    var row = flex_type_1.FlexDirection.ROW;
    var isRow = conflict_1.getDirection2(g) === flex_type_1.FlexDirection.ROW;
    var notConfilcted = !conflict_1.isConflicted2(g);
    var isGridNum = g.type === node_1.NodeType.GROUP && g.layers.length >= magic_1.MIN_GRID_ITEMS;
    if (isRow && notConfilcted && isGridNum) {
        var spaces_1 = g.layers
            .map(function (l) { return l.exactFrame; })
            .map(function (f, i, arr) {
            if (i >= 1) {
                var p = arr[i - 1];
                return frame_util_1.FrameUtil.getStart(f, row) - frame_util_1.FrameUtil.getEnd(p, row);
            }
            return 0;
        })
            .slice(1);
        var isPositive = spaces_1.every(function (s) { return s > 0; });
        var isMarginSimilar = spaces_1.every(function (s) { return Math.abs(s - spaces_1[0]) / spaces_1[0] <= 0.2; });
        var centers_1 = g.layers
            .map(function (l) { return l.exactFrame; })
            .map(function (f) { return frame_util_1.FrameUtil.getCenter(f, row); })
            .map(function (v, i, arr) {
            if (i >= 1) {
                var p = arr[i - 1];
                return v - p;
            }
            return 0;
        })
            .slice(1);
        var isCenterSimilar = centers_1.every(function (s) { return Math.abs(s - centers_1[0]) / centers_1[0] <= 0.2; });
        return isPositive && (isMarginSimilar || isCenterSimilar) && similar_1.isSimilarAsGridLine(g.layers);
    }
    return false;
}
function isSimilarGridLine(preLayers, nextLayer) {
    var gs = preLayers.concat([nextLayer]);
    var isAllGridLine = gs.every(isGridLineLike);
    if (isAllGridLine) {
        var gridNum_1 = gs[0].layers.length;
        var seperator = frame_util_1.FrameUtil.getStart(nextLayer.exactFrame, flex_type_1.FlexDirection.COLUMN) -
            frame_util_1.FrameUtil.getEnd(preLayers[preLayers.length - 1].exactFrame, flex_type_1.FlexDirection.COLUMN);
        var isSameGridNum = gs.every(function (g) { return g.type === node_1.NodeType.GROUP; }) && gs.every(function (g) { return g.layers.length === gridNum_1; });
        var isNotLargeMargin = seperator <= magic_1.MAGIC_MARGIN;
        if (isSameGridNum && isNotLargeMargin) {
            var dir_4 = flex_type_1.FlexDirection.ROW;
            var isNotRepeated = !gs[0].layers.every(function (l, i) { return similar_1.isSimilarTree(l, nextLayer.layers[i]); });
            var frames_1 = fill_1.default(gridNum_1).map(function (_, i) { return frame_util_1.FrameUtil.expandFrames.apply(frame_util_1.FrameUtil, gs.map(function (g) { return g.layers[i].exactFrame; })); });
            var bewteens = frames_1
                .map(function (f, i) {
                var pre = frames_1[i - 1];
                var cur = f;
                if (pre !== undefined) {
                    return frame_util_1.FrameUtil.getStart(cur, dir_4) - frame_util_1.FrameUtil.getEnd(pre, dir_4);
                }
            })
                .slice(1);
            var isBewteens = bewteens.every(function (b) { return b >= 0; });
            return isNotRepeated && isBewteens;
        }
    }
    return false;
}
function mergeLines(gs) {
    var colums = gs[0].layers.length;
    return compose(fill_1.default(colums).map(function (_, i) {
        return compose(gs.map(function (g) { return g.layers[i]; }), flex_type_1.FlexDirection.COLUMN);
    }), flex_type_1.FlexDirection.ROW);
}
function scanByGridlayout(group) {
    var type = group.type;
    if (type === node_1.NodeType.GROUP) {
        var dir = conflict_1.getDirection2(group);
        if (dir === flex_type_1.FlexDirection.COLUMN && group.layers.length >= 2) {
            var layers = group.layers.slice();
            var preGridLayers = void 0;
            for (var i = 1; i < layers.length; i++) {
                var layer = layers[i];
                var flush = true;
                var prev = layers[i - 1];
                preGridLayers = preGridLayers || [prev];
                if (isSimilarGridLine(preGridLayers, layer)) {
                    flush = false;
                    preGridLayers.push(layer);
                }
                if (!flush && i === layers.length - 1) {
                    i = layers.length;
                    flush = true;
                }
                if (flush) {
                    if (preGridLayers !== undefined && preGridLayers.length > 1) {
                        layers.splice(i - preGridLayers.length, preGridLayers.length, mergeLines(preGridLayers));
                        i = i - (preGridLayers.length - 1);
                    }
                    preGridLayers = undefined;
                }
            }
            group.layers = layers;
        }
        group.layers.forEach(scanByGridlayout);
    }
    return group;
}
function isLeftRightLine(line) {
    var type = line.type;
    if (type === node_1.NodeType.GROUP) {
        var row = flex_type_1.FlexDirection.ROW;
        var isRow = conflict_1.getDirection2(line) === flex_type_1.FlexDirection.ROW;
        var notConfilcted = !conflict_1.isConflicted2(line);
        var is2Num = line.layers.length === 2;
        var left = line.layers[0];
        var right = line.layers[1];
        var space = frame_util_1.FrameUtil.getEnd(right.exactFrame, row) - frame_util_1.FrameUtil.getStart(left.exactFrame, row);
        return (isRow &&
            notConfilcted &&
            is2Num &&
            space >= magic_1.MAGIC_MARGIN &&
            frame_util_1.FrameUtil.getStart(left.exactFrame, flex_type_1.FlexDirection.COLUMN) !== frame_util_1.FrameUtil.getStart(right.exactFrame, flex_type_1.FlexDirection.COLUMN) &&
            frame_util_1.FrameUtil.getEnd(left.exactFrame, flex_type_1.FlexDirection.COLUMN) !== frame_util_1.FrameUtil.getEnd(right.exactFrame, flex_type_1.FlexDirection.COLUMN) &&
            frame_util_1.FrameUtil.getCenter(left.exactFrame, flex_type_1.FlexDirection.COLUMN) !== frame_util_1.FrameUtil.getCenter(right.exactFrame, flex_type_1.FlexDirection.COLUMN));
    }
    return false;
}
function isLeftLine(line) {
    var children = decompose(line);
    if (children.length >= 2) {
        var notConfilcted = !conflict_1.isConflicted2(line);
        var isRow = conflict_1.getDirection2(line) === flex_type_1.FlexDirection.ROW;
        if (isRow && notConfilcted) {
            var spaces = children
                .map(function (l) { return l.exactFrame; })
                .map(function (f, i, arr) {
                if (i >= 1) {
                    var p = arr[i - 1];
                    return frame_util_1.FrameUtil.getStart(f, flex_type_1.FlexDirection.ROW) - frame_util_1.FrameUtil.getEnd(p, flex_type_1.FlexDirection.ROW);
                }
                return 0;
            })
                .slice(1);
            return spaces.every(function (space) { return space < magic_1.MAGIC_MARGIN; });
        }
        else {
            return false;
        }
    }
    return true;
}
function tryMergeLeftRightLine(line0, line1) {
    if (line0 === undefined || line1 === undefined) {
        return;
    }
    var left0;
    var left1;
    var right;
    var offset;
    if (isLeftLine(line0) && isLeftRightLine(line1)) {
        left0 = line0;
        left1 = line1.layers[0];
        right = line1.layers[1];
        offset = frame_util_1.FrameUtil.getCenter(left1.exactFrame, flex_type_1.FlexDirection.COLUMN) - frame_util_1.FrameUtil.getCenter(right.exactFrame, flex_type_1.FlexDirection.COLUMN);
    }
    else if (isLeftRightLine(line0) && isLeftLine(line1)) {
        left0 = line0.layers[0];
        right = line0.layers[1];
        left1 = line1;
        offset = frame_util_1.FrameUtil.getCenter(left0.exactFrame, flex_type_1.FlexDirection.COLUMN) - frame_util_1.FrameUtil.getCenter(right.exactFrame, flex_type_1.FlexDirection.COLUMN);
    }
    if (left0 && left1 && right) {
        var leftFrame = frame_util_1.FrameUtil.expandFrames(left0.exactFrame, left1.exactFrame);
        var rightFrame = right.exactFrame;
        var hasMargin = magic_1.isMagicMargin(frame_util_1.FrameUtil.getEnd(rightFrame, flex_type_1.FlexDirection.ROW) - frame_util_1.FrameUtil.getStart(leftFrame, flex_type_1.FlexDirection.ROW));
        var newOffset = frame_util_1.FrameUtil.getCenter(leftFrame, flex_type_1.FlexDirection.COLUMN) - frame_util_1.FrameUtil.getCenter(rightFrame, flex_type_1.FlexDirection.COLUMN);
        if (hasMargin && Math.abs(newOffset) <= Math.abs(offset) + 2) {
            return compose([
                compose([left0, left1], flex_type_1.FlexDirection.COLUMN),
                right
            ], flex_type_1.FlexDirection.ROW);
        }
    }
}
function scanByRightCenter(group) {
    var type = group.type;
    if (type === node_1.NodeType.GROUP) {
        var dir = conflict_1.getDirection2(group);
        if (dir === flex_type_1.FlexDirection.COLUMN && group.layers.length >= 2) {
            var layers = group.layers.slice();
            for (var i = 0; i < layers.length; i++) {
                var merge = tryMergeLeftRightLine(layers[i - 1], layers[i]);
                if (merge !== undefined) {
                    layers.splice(i - 1, 2, merge);
                    i--;
                }
            }
            group.layers = layers;
        }
        group.layers.forEach(scanByRightCenter);
    }
    return group;
}
function log(input, tabs) {
    if (tabs === void 0) { tabs = 0; }
    var prefix = fill_1.default(tabs + 1, '').join('\t');
    logger_1.default.log(prefix + input.id);
    if (input.type === node_1.NodeType.GROUP) {
        input.layers.forEach(function (l) { return log(l, tabs + 1); });
    }
}
function isAuxiliaryLineLike(layer, auxiliaryLine, align) {
    if (layer !== undefined && !conflict_1.isConflicted2(layer)) {
        var arr = decompose(layer);
        var child = arr[0];
        if (align === special_1.SpecialAlign.START) {
            if (frame_util_1.FrameUtil.getStart(child.exactFrame, flex_type_1.FlexDirection.ROW) === auxiliaryLine) {
                return true;
            }
        }
        else if (align === special_1.SpecialAlign.CENTER) {
            if (frame_util_1.FrameUtil.getCenter(child.exactFrame, flex_type_1.FlexDirection.ROW) === auxiliaryLine) {
                return true;
            }
        }
        else if (align === special_1.SpecialAlign.END) {
            if (frame_util_1.FrameUtil.getEnd(child.exactFrame, flex_type_1.FlexDirection.ROW) === auxiliaryLine) {
                return true;
            }
        }
    }
    return false;
}
function extendAuxiliaryLine(layers, auxiliaryLine, align) {
    var arr = [];
    for (var _i = 0, layers_1 = layers; _i < layers_1.length; _i++) {
        var layer = layers_1[_i];
        if (isAuxiliaryLineLike(layer, auxiliaryLine, align)) {
            arr.push(layer);
        }
        else {
            break;
        }
    }
    return arr;
}
function scanByAuxiliaryLine(group) {
    groupByAuxiliaryLineRaw(group, special_1.SpecialAlign.START, true);
    return group;
}
function groupByAuxiliaryLineRaw(group, align, isTopToBottom) {
    var type = group.type;
    if (type === node_1.NodeType.GROUP) {
        var dir = conflict_1.getDirection2(group);
        if (dir === flex_type_1.FlexDirection.COLUMN) {
            var layers = isTopToBottom ? decompose(group) : decompose(group).reverse();
            for (var i = 0; i < layers.length - 1; i++) {
                var curLayer = layers[i];
                if (!conflict_1.isConflicted2(curLayer)) {
                    var arr = align !== special_1.SpecialAlign.END ? decompose(curLayer) : decompose(curLayer).reverse();
                    for (var j = 1; j < arr.length; j++) {
                        var child = arr[j];
                        var auxiliaryLine = void 0;
                        if (align === special_1.SpecialAlign.START) {
                            auxiliaryLine = frame_util_1.FrameUtil.getStart(child.exactFrame, flex_type_1.FlexDirection.ROW);
                        }
                        else if (align === special_1.SpecialAlign.END) {
                            auxiliaryLine = frame_util_1.FrameUtil.getEnd(child.exactFrame, flex_type_1.FlexDirection.ROW);
                        }
                        else if (align === special_1.SpecialAlign.CENTER) {
                            auxiliaryLine = frame_util_1.FrameUtil.getCenter(child.exactFrame, flex_type_1.FlexDirection.ROW);
                        }
                        var lines = extendAuxiliaryLine(layers.slice(i + 1), auxiliaryLine, align);
                        if (lines.length >= 1) {
                            lines.forEach(function (line) {
                                line.specailAlign = special_1.SpecialAlign.START;
                                logger_1.default.log('specailAlign', line.id);
                            });
                            break;
                        }
                    }
                }
            }
            group.layers = isTopToBottom ? layers : layers.reverse();
        }
        group.layers.forEach(function (layer) { return groupByAuxiliaryLineRaw(layer, align, isTopToBottom); });
    }
    return group;
}
function mergeBackground(group) {
    var type = group.type;
    if (type === node_1.NodeType.GROUP) {
        var backgrounds = group.layers.filter(function (child) { return child.type === node_1.NodeType.SHAPE && frame_util_1.FrameUtil.equals(group.exactFrame, child.exactFrame); });
        var bg0_1 = backgrounds[0];
        if (backgrounds.length >= 1 && isEmpty_1.default(group.styles) && (group.layers[0] === bg0_1 || bg0_1.styles.backgroundColor === undefined)) {
            if (bg0_1.styles === undefined || bg0_1.styles.opacity === undefined || bg0_1.styles.opacity === 1) {
                group.styles = __assign({}, bg0_1.styles);
                group.layers = group.layers.filter(function (child) { return child !== bg0_1; });
                logger_1.default.log('mergeBackground', bg0_1.id, group.id);
            }
        }
        group.layers.forEach(mergeBackground);
    }
    return group;
}
function mergeOneChild(group, parent) {
    var type = group.type;
    if (type === node_1.NodeType.GROUP) {
        if (parent !== undefined) {
            if (group.layers.length === 1) {
                var child = group.layers[0];
                var couldGroupIgnored = isEmpty_1.default(group.styles);
                var couldChildIgnored = child.type === node_1.NodeType.GROUP && isEmpty_1.default(child.styles);
                if (couldGroupIgnored) {
                    var index = parent.layers.indexOf(group);
                    parent.layers.splice(index, 1, child);
                    logger_1.default.log('mergeOneChild-group', child.id, group.id);
                }
                else if (couldChildIgnored) {
                    group.layers = child.layers;
                    logger_1.default.log('mergeOneChild-child', child.id, group.id);
                }
            }
        }
        group.layers.forEach(function (child) { return mergeOneChild(child, group); });
    }
    return group;
}
function regroup(elements, polyfilled) {
    var root = unite(elements);
    root = flattenGroup(root);
    root = sortChildren(root);
    root = scanByAuxiliaryLine(root);
    root = scanBySeperate(root);
    root = scanByGridlayout(root);
    root = scanByRightCenter(root);
    root = mergeBackground(root);
    root = mergeOneChild(root);
    root.frame = __assign({}, polyfilled.frame);
    root.exactFrame = __assign({}, polyfilled.exactFrame);
    root.styles = __assign({}, polyfilled.styles);
    log(root);
    return root;
}
exports.regroup = regroup;
