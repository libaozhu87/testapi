"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var unique_1 = require("./../../primitive/unique");
var flatten_1 = require("./../../primitive/flatten");
var compact_1 = require("./../../primitive/compact");
var clone_1 = require("./../../primitive/clone");
var input_polyfil_1 = require("./../input-polyfil");
var color_util_1 = require("./../../template/color-util");
var node_1 = require("./../../define/node");
var id_generate_1 = require("./../id-generate");
function isValidNode(node) {
    if (!node.type) {
        throw new Error(JSON.stringify(node));
    }
    return node.type !== node_1.NodeType.GROUP && node.frame.width > 0 && node.frame.height > 0;
}
function applanate(node, result) {
    if (result === void 0) { result = []; }
    if (node.type === node_1.NodeType.GROUP) {
        node.layers.forEach(function (layer) { return applanate(layer, result); });
    }
    else if (isValidNode(node)) {
        node.zIndex = id_generate_1.newId();
        node.id = node.type[0] + node.zIndex;
        result.push(node);
    }
    return result;
}
var FastCanvas = (function () {
    function FastCanvas(width, height) {
        this.width = width;
        this.canvas = Array.apply(undefined, Array(width * height));
    }
    FastCanvas.prototype.draw = function (drawable) {
        var x = drawable.x, y = drawable.y, width = drawable.width, height = drawable.height, fill = drawable.fill, ref = drawable.ref;
        var r = x + width;
        var b = y + height;
        if (fill === -1) {
            for (var i = x; i < r; i++) {
                for (var j = y; j < b; j++) {
                    var index = i + j * this.width;
                    var pix = this.canvas[index] || (this.canvas[index] = { fill: undefined, refs: [] });
                    pix.fill = fill;
                    pix.refs.push(ref);
                }
            }
        }
        else {
            for (var i = x; i < r; i++) {
                for (var j = y; j < b; j++) {
                    var index = i + j * this.width;
                    var pix = this.canvas[index] || (this.canvas[index] = { fill: undefined, refs: [] });
                    if (pix.fill !== fill) {
                        pix.fill = fill;
                        pix.refs = [ref];
                    }
                }
            }
        }
    };
    FastCanvas.prototype.getUsedRefs = function () {
        var compacted = compact_1.default(this.canvas);
        return unique_1.default(flatten_1.default(compacted.map(function (p) { return p.refs; })));
    };
    return FastCanvas;
}());
function node2drawables(input, width, height) {
    var type = input.type, styles = input.styles;
    var ref = '' + input.id;
    if (type === node_1.NodeType.SHAPE && styles.backgroundImage === undefined) {
        if (styles.borderColor || styles.backgroundColor) {
            var backgroundColor = color_util_1.color2int(styles.backgroundColor);
            if (backgroundColor !== undefined && color_util_1.alpha(backgroundColor) !== 255) {
                return [__assign({}, input.exactFrame, { fill: -1, ref: ref })];
            }
            var box = input.exactFrame;
            var ds = [];
            var borderColor = color_util_1.color2int(styles.borderColor);
            var offset = (styles.borderRadius || 0) + (styles.borderWidth || 0);
            if (borderColor !== undefined) {
                ds.push({ x: box.x, y: box.y, width: box.width, height: offset, fill: -1, ref: ref });
                ds.push({ x: box.x, y: box.y + box.height - offset, width: box.width, height: offset, fill: -1, ref: ref });
                ds.push({ x: box.x, y: offset, width: offset, height: box.height - offset * 2, fill: -1, ref: ref });
                ds.push({
                    x: box.x + box.width - offset,
                    y: box.y + offset,
                    width: offset,
                    height: box.height - offset * 2,
                    fill: -1,
                    ref: ref
                });
            }
            if (backgroundColor !== undefined) {
                ds.push({
                    x: box.x + offset,
                    y: box.y + offset,
                    width: box.width - offset * 2,
                    height: box.height - offset * 2,
                    fill: backgroundColor,
                    ref: ref
                });
            }
            return ds;
        }
        else {
            return [];
        }
    }
    else {
        return [__assign({}, input.exactFrame, { fill: -1, ref: ref })];
    }
}
function clean(input) {
    var cloned = clone_1.default(input);
    var polyfilled = input_polyfil_1.default(cloned);
    var _a = polyfilled.exactFrame, width = _a.width, height = _a.height;
    var canvas = new FastCanvas(width, height);
    var elements = applanate(polyfilled);
    flatten_1.default(elements.map(function (ele) { return node2drawables(ele, width, height); })).forEach(function (drawable) {
        canvas.draw(drawable);
    });
    var refs = canvas.getUsedRefs();
    elements.filter(function (ele) { return refs.indexOf(ele.id) !== -1; });
    return undefined;
}
exports.default = clean;
