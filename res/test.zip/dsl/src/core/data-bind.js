"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    tabs: [{ name: '区域', selected: true }, { name: '最新发布', selected: true }, { name: '租金' }, { name: '筛选' }],
    items: [{ name: '综合排序' }, { name: '离我最近' }, { name: '最新发布' }, { name: '价格从低到高' }]
};
