"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var node_util_1 = require("./node-util");
var conflict_1 = require("./conflict");
function calcNode(node, property) {
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        var group = node;
        group.layout.flexDirection = conflict_1.getDirection(group, property);
    }
}
function measureDirection(node, property) {
    return node_util_1.NodeUtil.visitNodeTree(node, property, calcNode);
}
exports.measureDirection = measureDirection;
