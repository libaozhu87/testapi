"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var id_generate_1 = require("./id-generate");
function isValidNode(node) {
    if (!node.type) {
        throw new Error(JSON.stringify(node));
    }
    if (node.type !== node_1.NodeType.GROUP && node.frame.width > 0 && node.frame.height > 0) {
        if (node.type === node_1.NodeType.SHAPE) {
            return (node.styles !== undefined &&
                (node.styles.borderColor !== undefined || node.styles.backgroundColor !== undefined || node.styles.backgroundImage !== undefined));
        }
        return true;
    }
}
function _applanate(node, result) {
    if (node.type === node_1.NodeType.GROUP) {
        node.layers.forEach(function (layer) { return _applanate(layer, result); });
    }
    else if (isValidNode(node)) {
        node.zIndex = id_generate_1.newId();
        node.id = node.type[0] + node.zIndex;
        result.push(node);
    }
    return result;
}
function applanate(node) {
    id_generate_1.resetIdGenerator();
    return _applanate(node, []);
}
exports.default = applanate;
