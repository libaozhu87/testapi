"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var G_ID = 0;
function newId() {
    return ++G_ID;
}
exports.newId = newId;
function resetIdGenerator() {
    G_ID = 0;
}
exports.resetIdGenerator = resetIdGenerator;
