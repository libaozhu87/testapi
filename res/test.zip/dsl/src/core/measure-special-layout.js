"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var node_util_1 = require("./node-util");
var special_1 = require("./../define/special");
var indexOf_1 = require("./../primitive/indexOf");
var similar_1 = require("./similar");
var flex_type_1 = require("./../define/flex-type");
var magic_1 = require("./magic");
var frame_util_1 = require("./frame-util");
var logger_1 = require("./../primitive/logger");
function measureGridLayout(node, property) {
    var type = node.type;
    var dir = node.layout.flexDirection;
    if (type === node_1.NodeType.GROUP) {
        var group = node;
        if (dir === flex_type_1.FlexDirection.ROW) {
            var linears = property.getLinearChildren(group);
            var margins = node_util_1.NodeUtil.getChildrenBetweens(group, linears, property);
            if (group.specialLayout === undefined && linears.length >= magic_1.MIN_GRID_ITEMS && margins.every(function (margin) { return margin >= 0; })) {
                var isSimailar = similar_1.isSimilarAsGrid(linears, group);
                if (isSimailar) {
                    group.specialLayout = special_1.SpecialLayout.GRID;
                    logger_1.default.log('SpecialLayout.GRID', group.id, group.specialLayout === special_1.SpecialLayout.GRID);
                }
            }
        }
        group.children.forEach(function (child) { return measureGridLayout(child, property); });
    }
    return false;
}
function measureSpaceBetween(node, property) {
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        var group_1 = node;
        var dir_1 = group_1.layout.flexDirection;
        if (dir_1 === flex_type_1.FlexDirection.ROW && group_1.specialLayout === undefined) {
            var linears = property.getLinearChildren(group_1);
            var bewteens = node_util_1.NodeUtil.getChildrenBetweens(group_1, linears, property);
            var centerIndex = indexOf_1.default(linears, function (child) { return frame_util_1.FrameUtil.isCenter(child.measured, group_1.measured, dir_1); });
            if (linears.length === 2 && bewteens.some(magic_1.isMagicMargin) && centerIndex < 0) {
                var isParentSpaceBetween = void 0;
                var parent_1 = group_1.parent;
                while (parent_1 !== undefined && parent_1.layout.flexDirection === flex_type_1.FlexDirection.ROW) {
                    if (parent_1.specialLayout === special_1.SpecialLayout.SPACE_BETWEEN) {
                        isParentSpaceBetween = true;
                        break;
                    }
                    parent_1 = parent_1.parent;
                }
                if (isParentSpaceBetween) {
                    var linearsInParent = property.getLinearChildren(parent_1);
                    var bewteensInParent = node_util_1.NodeUtil.getChildrenBetweens(parent_1, linearsInParent, property);
                    if (bewteensInParent[0] < bewteens[0]) {
                        parent_1.specialLayout = undefined;
                        group_1.specialLayout = special_1.SpecialLayout.SPACE_BETWEEN;
                    }
                    else {
                        parent_1.specialLayout = special_1.SpecialLayout.SPACE_BETWEEN;
                        group_1.specialLayout = undefined;
                    }
                }
                else {
                    group_1.specialLayout = special_1.SpecialLayout.SPACE_BETWEEN;
                }
            }
        }
        group_1.children.forEach(function (child) { return measureSpaceBetween(child, property); });
    }
}
function measureSpecialLayout(node, property) {
    measureSpaceBetween(node, property);
    measureGridLayout(node, property);
    return node;
}
exports.measureSpecialLayout = measureSpecialLayout;
