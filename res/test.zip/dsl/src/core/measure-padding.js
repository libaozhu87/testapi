"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var node_util_1 = require("./node-util");
var flex_type_1 = require("./../define/flex-type");
var layout_util_1 = require("./layout-util");
var isEmpty_1 = require("./../primitive/isEmpty");
var frame_util_1 = require("./frame-util");
var direction_util_1 = require("./direction-util");
var math_1 = require("./math");
var magic_1 = require("./magic");
function fixOnCrossDir(node, property) {
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        var group = node;
        var children = property.getChildren(group);
        var crossDir_1 = direction_util_1.DirectionUtil.cross(group.layout.flexDirection);
        if (!isEmpty_1.default(children)) {
            if (!layout_util_1.LayoutUtil.isFixed(group.layout, crossDir_1)) {
                var shouldFixed = false;
                var frames_1 = children.map(function (child) { return layout_util_1.LayoutUtil.getFrameBoxWithMargin(child); });
                if (frames_1.length >= 2) {
                    shouldFixed = true;
                    var _loop_1 = function (i) {
                        var testFrame = __assign({}, frames_1[i]);
                        frame_util_1.FrameUtil.setStartOffset(testFrame, crossDir_1, -magic_1.MAGIC_MARGIN / 2);
                        frame_util_1.FrameUtil.setLength(testFrame, crossDir_1, frame_util_1.FrameUtil.getLength(testFrame, crossDir_1) + magic_1.MAGIC_MARGIN);
                        shouldFixed = !frames_1.every(function (f) { return math_1.isFullOverlapOnDirection(f, testFrame, crossDir_1); });
                    };
                    for (var i = 0; i < frames_1.length && shouldFixed; i++) {
                        _loop_1(i);
                    }
                }
                if (shouldFixed) {
                    layout_util_1.LayoutUtil.setLength(group.layout, crossDir_1, frame_util_1.FrameUtil.getLength(group.measured, crossDir_1));
                }
            }
        }
    }
}
function paddingOnNotFixed(node, property) {
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        var group_1 = node;
        var children_1 = property.getChildren(group_1).filter(function (child) { return !(property.isMatchParentSize(child) && child.type === node_1.NodeType.SHAPE); });
        if (!isEmpty_1.default(children_1)) {
            var dirs = [flex_type_1.FlexDirection.ROW, flex_type_1.FlexDirection.COLUMN];
            dirs.forEach(function (dir) {
                if (!layout_util_1.LayoutUtil.isFixed(group_1.layout, dir)) {
                    var frame = children_1.map(function (child) { return layout_util_1.LayoutUtil.getFrameBoxWithMargin(child); }).reduce(frame_util_1.FrameUtil.expand, undefined);
                    var paddingStart = frame_util_1.FrameUtil.getStart(frame, dir);
                    var paddingEnd = frame_util_1.FrameUtil.getLength(group_1.measured, dir) - frame_util_1.FrameUtil.getEnd(frame, dir);
                    layout_util_1.LayoutUtil.setPaddingStart(group_1.layout, dir, paddingStart);
                    layout_util_1.LayoutUtil.setPaddingEnd(group_1.layout, dir, paddingEnd);
                }
            });
        }
    }
}
function measurePadding(node, property) {
    return node_util_1.NodeUtil.visitNodeTree(node, property, paddingOnNotFixed);
}
exports.measurePadding = measurePadding;
function fixCrossAxis(node, property) {
    return node_util_1.NodeUtil.visitNodeTree(node, property, fixOnCrossDir);
}
exports.fixCrossAxis = fixCrossAxis;
