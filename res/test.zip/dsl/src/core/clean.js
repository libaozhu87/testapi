"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_util_1 = require("./node-util");
function clean(root, property) {
    node_util_1.NodeUtil.visitNodeTree(root, property, function (child) {
        child.parent = undefined;
        if (child.layout.padding.every(function (padding) { return padding === undefined; })) {
            child.layout.padding = undefined;
        }
        if (child.layout.margin.every(function (margin) { return margin === undefined; })) {
            child.layout.margin = undefined;
        }
    });
    return root;
}
exports.clean = clean;
