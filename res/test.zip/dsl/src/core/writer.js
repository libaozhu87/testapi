"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require("fs");
var path = require("path");
var Async_1 = require("./../primitive/Async");
var WriteUtil = (function () {
    function WriteUtil() {
    }
    WriteUtil.write = function (rPath, context, cb) {
        var full = path.resolve(rPath);
        console.log(full);
        console.log('-------------');
        console.log(WriteUtil.ensureDir(path.dirname(full)));
        var worker = new Async_1.Async()
            .sequence(WriteUtil.ensureDir(path.dirname(full)))
            .then(function (v, ctx) {
            fs.writeFile(full, context, function (err) {
                ctx.accept(err, "write " + full + " success!");
            });
        })
            .log();
        worker.invoke(true, function (e, v, ctx) {
            if (cb) {
                cb(e, v);
            }
        });
    };
    WriteUtil.writeObject = function (rPath, obj, cb) {
        var str = 'export default ' + JSON.stringify(obj, undefined, 2);
        WriteUtil.write(rPath, str, cb);
    };
    WriteUtil.async = function (writeable) {
        return new Async_1.Async().then(function (v, ctx) {
            if (writeable.type === 'object') {
                WriteUtil.writeObject(writeable.path, writeable.context, function (err) { return ctx.accept(err, true); });
            }
            else if (writeable.type === 'string') {
                WriteUtil.write(writeable.path, writeable.context, function (err) { return ctx.accept(err, true); });
            }
            else {
                throw new Error("" + writeable.type);
            }
        });
    };
    WriteUtil.ensureDir = function (dirname) {
        return new Async_1.Async().then(function (v, ctx) {
            fs.exists(dirname, function (exists) {
                if (exists) {
                    ctx.next(true);
                }
                else {
                    WriteUtil.ensureDir(path.dirname(dirname)).invoke(true, function (err) {
                        if (err) {
                            ctx.error(err);
                        }
                        else {
                            fs.mkdir(dirname, undefined, function (err) {
                                if (!err) {
                                    console.log("mkdir " + dirname + " success!");
                                }
                                ctx.accept(err, true);
                            });
                        }
                    });
                }
            });
        });
    };
    return WriteUtil;
}());
exports.WriteUtil = WriteUtil;
