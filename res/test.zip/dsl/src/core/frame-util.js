"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var flex_type_1 = require("./../define/flex-type");
var magic_1 = require("./magic");
var FrameUtil = (function () {
    function FrameUtil() {
    }
    FrameUtil.round = function (f) {
        return {
            x: Math.round(f.x),
            y: Math.round(f.y),
            width: Math.round(f.width),
            height: Math.round(f.height)
        };
    };
    FrameUtil.equals = function (f0, f1) {
        return f0.x === f1.x && f0.y === f1.y && f0.width === f1.width && f0.height === f1.height;
    };
    FrameUtil.expandFrames = function () {
        var fs = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            fs[_i] = arguments[_i];
        }
        return fs.reduce(FrameUtil.expand, undefined);
    };
    FrameUtil.expandPoint = function (f, p) {
        var l = Math.min(f.x, p.x);
        var t = Math.min(f.y, p.y);
        var r = Math.max(l + f.width, p.x);
        var b = Math.max(t + f.height, p.y);
        return { x: l, y: t, width: r - l, height: b - t };
    };
    FrameUtil.expand = function (f0, f1) {
        if (f0 === undefined && f1 === undefined) {
            return undefined;
        }
        else if (f0 === undefined) {
            return __assign({}, f1);
        }
        else if (f1 === undefined) {
            return __assign({}, f0);
        }
        var l = Math.min(f0.x, f1.x);
        var t = Math.min(f0.y, f1.y);
        var r = Math.max(f0.x + f0.width, f1.x + f1.width);
        var b = Math.max(f0.y + f0.height, f1.y + f1.height);
        return { x: l, y: t, width: r - l, height: b - t };
    };
    FrameUtil.getLength = function (f, dir) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            return f.width;
        }
        else {
            return f.height;
        }
    };
    FrameUtil.setLength = function (f, dir, value) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            f.width = value;
        }
        else {
            f.height = value;
        }
    };
    FrameUtil.getStart = function (f, dir) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            return f.x;
        }
        else {
            return f.y;
        }
    };
    FrameUtil.setStart = function (f, dir, value) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            f.x = value;
        }
        else {
            f.y = value;
        }
    };
    FrameUtil.setStartOffset = function (f, dir, offset) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            f.x += offset;
        }
        else {
            f.y += offset;
        }
    };
    FrameUtil.getEnd = function (f, dir) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            return f.x + f.width;
        }
        else {
            return f.y + f.height;
        }
    };
    FrameUtil.getCenter = function (f, dir) {
        if (dir === flex_type_1.FlexDirection.ROW) {
            return f.x + f.width / 2;
        }
        else {
            return f.y + f.height / 2;
        }
    };
    FrameUtil.isCenter = function (child, parent, dir, thred) {
        if (thred === void 0) { thred = magic_1.CENTER_ERROR; }
        var pLen = FrameUtil.getLength(parent, dir);
        var center = FrameUtil.getCenter(child, dir);
        if (Math.abs(center - pLen / 2) < magic_1.CENTER_ERROR) {
            return true;
        }
        else {
            return false;
        }
    };
    FrameUtil.isNearStart = function (child, parent, dir, thred) {
        if (thred === void 0) { thred = magic_1.CENTER_ERROR; }
        if (FrameUtil.isCenter(child, parent, dir)) {
            return false;
        }
        else if (dir === flex_type_1.FlexDirection.ROW) {
            return child.x + child.width / 2 - parent.width / 2 <= -thred;
        }
        else {
            return child.y + child.height / 2 - parent.height / 2 <= -thred;
        }
    };
    FrameUtil.isNearEnd = function (child, parent, dir) {
        return !FrameUtil.isCenter(child, parent, dir) && !FrameUtil.isNearStart(child, parent, dir);
    };
    FrameUtil.toLeft = function (frame) {
        return frame.x;
    };
    FrameUtil.toRight = function (frame) {
        return frame.x + frame.width;
    };
    FrameUtil.toTop = function (frame) {
        return frame.y;
    };
    FrameUtil.toBottom = function (frame) {
        return frame.x + frame.height;
    };
    FrameUtil.shelling = function (frame) {
        return {
            x: frame.width >= 4 ? frame.x - 1 : frame.x,
            y: frame.height >= 4 ? frame.y - 1 : frame.y,
            width: frame.width >= 4 ? frame.width - 2 : frame.width,
            height: frame.height >= 4 ? frame.height - 2 : frame.height
        };
    };
    FrameUtil.scale = function (frame, rate) {
        var f = __assign({}, frame);
        var offsetX = Math.round((rate - 1) * frame.width * 0.5);
        var offsetY = Math.round((rate - 1) * frame.height * 0.5);
        f.x -= offsetX;
        f.y -= offsetY;
        f.width += offsetX * 2;
        f.height += offsetY * 2;
        return f;
    };
    FrameUtil.scaleOnType = function (frame, rate, scaleType) {
        var f = __assign({}, frame);
        var offsetX = Math.round((rate - 1) * frame.width);
        var offsetY = Math.round((rate - 1) * frame.height);
        if (scaleType === FrameUtil.SCALE_ROW_START) {
            f.x -= offsetX;
        }
        else if (scaleType === FrameUtil.SCALE_ROW_END) {
            f.width += offsetX;
        }
        else if (scaleType === FrameUtil.SCALE_COL_START) {
            f.y -= offsetY;
        }
        else if (scaleType === FrameUtil.SCALE_COL_END) {
            f.height += offsetY;
        }
        return f;
    };
    FrameUtil.translate = function (frame, _a) {
        var x = _a.x, y = _a.y;
        return { x: frame.x + x, y: frame.y + y, width: frame.width, height: frame.height };
    };
    FrameUtil.SCALE_ROW_START = 'row-start';
    FrameUtil.SCALE_ROW_END = 'row-end';
    FrameUtil.SCALE_COL_START = 'col-start';
    FrameUtil.SCALE_COL_END = 'col-end';
    return FrameUtil;
}());
exports.FrameUtil = FrameUtil;
