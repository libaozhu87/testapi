"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var node_util_1 = require("./node-util");
var flex_type_1 = require("./../define/flex-type");
function randomColor() {
    var r = ('0' + Math.floor(Math.random() * 256).toString(16)).slice(-2);
    var g = ('0' + Math.floor(Math.random() * 256).toString(16)).slice(-2);
    var b = ('0' + Math.floor(Math.random() * 256).toString(16)).slice(-2);
    return '#' + r + g + b;
}
function randomBackground(node, property) {
    var def = {
        opacity: undefined,
        borderStyle: undefined,
        borderWidth: undefined,
        borderRadius: undefined,
        borderColor: undefined,
        backgroundColor: undefined,
        backgroundImage: undefined
    };
    var type = node.type;
    if (type === node_1.NodeType.GROUP) {
        var group = node;
        group.styles = group.styles || def;
        group.styles.backgroundColor = randomColor();
    }
    else if (type === node_1.NodeType.TEXT) {
        var text = node;
        text.styles = text.styles || def;
        text.styles.backgroundColor = randomColor();
    }
    else if (type === node_1.NodeType.SHAPE) {
        var shape = node;
        shape.styles = shape.styles || def;
        shape.styles.backgroundColor = randomColor();
    }
}
exports.randomBackground = randomBackground;
function debug(node, property) {
    if (property.isDebug()) {
        node_util_1.NodeUtil.visitNodeTree(node, property, function (n, p) {
            if (n.layout.position === flex_type_1.PositionType.ABSOLUTE) {
                randomBackground(n, p);
            }
        });
    }
}
exports.debug = debug;
