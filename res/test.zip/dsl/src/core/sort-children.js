"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var node_1 = require("./../define/node");
var node_util_1 = require("./node-util");
var conflict_1 = require("./conflict");
var math_1 = require("./math");
var frame_util_1 = require("./frame-util");
function sort(node, property) {
    if (node.type === node_1.NodeType.GROUP) {
        var group = node;
        var dir_1 = conflict_1.getDirection(group, property);
        group.children.sort(function (c0, c1) {
            if (math_1.isOverlap(c0.exactFrame, c1.exactFrame)) {
                return property.minZIndex(c0) - property.minZIndex(c1);
            }
            else {
                return frame_util_1.FrameUtil.getStart(c0.measured, dir_1) - frame_util_1.FrameUtil.getStart(c1.measured, dir_1);
            }
        });
    }
}
function sortChildren(node, property) {
    node_util_1.NodeUtil.visitNodeTreeReverse(node, property, sort);
}
exports.sortChildren = sortChildren;
