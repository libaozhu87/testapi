"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a;
var path = require("path");
var fs = require("fs");
var canvas_1 = require("canvas");
var Request = require("pixl-request");
var node_1 = require("./../define/node");
var Async_1 = require("./../primitive/Async");
var flatten_1 = require("./../primitive/flatten");
var compact_1 = require("./../primitive/compact");
var layout_util_1 = require("./../core/layout-util");
var frame_util_1 = require("./../core/frame-util");
var request = new Request();
canvas_1.registerFont(path.resolve(__dirname, './../../PingFang-SC.ttf'), { family: 'PingFangSC' });
function drawShape(ctx, styles, frame) {
    var raw = function () {
        if (!styles) {
            return;
        }
        var x = frame.x, y = frame.y, width = frame.width, height = frame.height;
        var radius = Math.min(styles.borderRadius || 0, Math.min(width, height) / 2);
        var fillColor = styles.backgroundColor;
        var strokeColor = styles.borderColor;
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + width - radius, y);
        ctx.arcTo(x + width, y, x + width, y + radius, radius);
        ctx.lineTo(x + width, y + height - radius);
        ctx.arcTo(x + width, y + height, x + width - radius, y + height, radius);
        ctx.lineTo(x + radius, y + height);
        ctx.arcTo(x, y + height, x, y + height - radius, radius);
        ctx.lineTo(x, y + radius);
        ctx.arcTo(x, y, x + radius, y, radius);
        ctx.closePath();
        ctx.lineWidth = styles.borderWidth || 1;
        if (strokeColor !== undefined) {
            ctx.strokeStyle = strokeColor;
            ctx.stroke();
        }
        if (fillColor !== undefined) {
            ctx.fillStyle = fillColor;
            ctx.fill();
        }
    };
    return new Async_1.Async().action(raw);
}
function breakline(ctx, line, width) {
    if (ctx.measureText(line).width <= width) {
        return [line];
    }
    else {
        var lines = [];
        var lastIndex = 0;
        for (var i = 1; i < line.length; i++) {
            var prev = line.substring(lastIndex, i);
            var next = line.substring(lastIndex, i + 1);
            if (ctx.measureText(prev).width <= width && ctx.measureText(next).width > width) {
                lines.push(prev);
                lastIndex = i;
            }
        }
        lines.push(line.substring(lastIndex));
        return lines;
    }
}
function drawText(ctx, text, textStyles, frame) {
    var raw = function () {
        var isMultiLines = frame.height > textStyles.lineHeight * 1.5;
        var x = frame.x, y = frame.y, width = frame.width, height = frame.height;
        ctx.fillStyle = textStyles.color;
        ctx.font = textStyles.fontStyle + " " + textStyles.fontSize + "px PingFangSC";
        ctx.textBaseline = 'middle';
        if (isMultiLines) {
            var ls = text.split('\n').map(function (line) { return breakline(ctx, line, width); });
            var lines = compact_1.default(flatten_1.default(ls));
            var offset = (height - (lines.length - 1) * textStyles.lineHeight) / 2;
            for (var _i = 0, lines_1 = lines; _i < lines_1.length; _i++) {
                var line = lines_1[_i];
                ctx.fillText(line, x, y + offset);
                offset += textStyles.lineHeight;
            }
        }
        else {
            ctx.fillText(text, x, y + height / 2);
        }
    };
    return new Async_1.Async().action(raw);
}
function drawImage(ctx, url, frame) {
    return new Async_1.Async().then(function (v, next) {
        request.get(url, function (err, resp, data) {
            if (err) {
                next.error(err);
            }
            var img = new canvas_1.Image();
            img.src = data;
            var x = frame.x, y = frame.y, width = frame.width, height = frame.height;
            ctx.drawImage(img, x, y, width, height);
            next.next(true);
        });
    });
}
function applanate(node) {
    if (node.type === node_1.NodeType.GROUP) {
        var group = node;
        return [node].concat(group.children.reduce(function (pre, cur) { return pre.concat(applanate(cur)); }, []));
    }
    else {
        return [node];
    }
}
function renderDSL(node, path) {
    var _a;
    var _b = node.measured, width = _b.width, height = _b.height;
    var canvas = canvas_1.createCanvas(width, height);
    var ctx = canvas.getContext('2d');
    var _c = node.frame, x = _c.x, y = _c.y;
    var offset = { x: -x, y: -y };
    var nodes = applanate(node);
    var workers = compact_1.default(flatten_1.default(nodes.map(function (child) {
        var type = child.type;
        if (type === node_1.NodeType.GROUP) {
            var group = child;
            return [drawShape(ctx, group.styles, frame_util_1.FrameUtil.translate(group.frame, offset))];
        }
        else if (type === node_1.NodeType.SHAPE) {
            var shape = child;
            return [drawShape(ctx, shape.styles, frame_util_1.FrameUtil.translate(shape.frame, offset))];
        }
        else if (type === node_1.NodeType.TEXT) {
            var text = child;
            var pl = layout_util_1.LayoutUtil.getPadding(text.layout, layout_util_1.LEFT_INDEX) || 0;
            var pr = layout_util_1.LayoutUtil.getPadding(text.layout, layout_util_1.RIGHT_INDEX) || 0;
            var pt = layout_util_1.LayoutUtil.getPadding(text.layout, layout_util_1.TOP_INDEX) || 0;
            var pb = layout_util_1.LayoutUtil.getPadding(text.layout, layout_util_1.BOTTOM_INDEX) || 0;
            var _a = text.frame, x_1 = _a.x, y_1 = _a.y, width_1 = _a.width, height_1 = _a.height;
            return [
                drawShape(ctx, text.styles, frame_util_1.FrameUtil.translate(text.frame, offset)),
                drawText(ctx, text.value, text.textStyles, frame_util_1.FrameUtil.translate({ x: x_1 + pl, y: y_1 + pt, width: width_1 - pl - pr, height: height_1 - pt - pb }, offset))
            ];
        }
        else if (type === node_1.NodeType.IMAGE) {
            var image = child;
            return [drawImage(ctx, image.value, frame_util_1.FrameUtil.translate(image.frame, offset))];
        }
        else {
            throw new Error("" + type);
        }
    })));
    return (_a = new Async_1.Async()).sequence.apply(_a, workers).action(function () { return flush(canvas, path); });
}
exports.renderDSL = renderDSL;
function renderInput(root, nodes, path) {
    var _a;
    var _b = root.frame, x = _b.x, y = _b.y, width = _b.width, height = _b.height;
    var canvas = canvas_1.createCanvas(width, height);
    var ctx = canvas.getContext('2d');
    var offset = { x: -x, y: -y };
    var workers = compact_1.default(flatten_1.default([root].concat(nodes).map(function (child) {
        var type = child.type;
        if (type === node_1.NodeType.GROUP) {
            return [drawShape(ctx, child.styles, frame_util_1.FrameUtil.translate(child.frame, offset))];
        }
        else if (type === node_1.NodeType.SHAPE) {
            return [drawShape(ctx, child.styles, frame_util_1.FrameUtil.translate(child.frame, offset))];
        }
        else if (type === node_1.NodeType.TEXT) {
            return [drawText(ctx, child.value, child.textStyles, frame_util_1.FrameUtil.translate(child.frame, offset))];
        }
        else if (type === node_1.NodeType.IMAGE) {
            return [drawImage(ctx, child.value, frame_util_1.FrameUtil.translate(child.frame, offset))];
        }
        else {
            throw new Error("" + type);
        }
    })));
    return (_a = new Async_1.Async()).sequence.apply(_a, workers).action(function () { return flush(canvas, path); });
}
exports.renderInput = renderInput;
function renderElements(root, dir) {
    var stack = [root];
    var array = [];
    while (stack.length > 0) {
        var top_1 = stack.pop();
        if (top_1.type === node_1.NodeType.GROUP) {
            stack.push.apply(stack, top_1.children);
        }
        array.push(top_1);
    }
    return array.map(function (node) { return renderDSL(node, dir + "/" + node.id + ".png"); });
}
exports.renderElements = renderElements;
var COLORS = (_a = {},
    _a[node_1.NodeType.GROUP] = '#f8f8f8',
    _a[node_1.NodeType.TEXT] = '#f0f0f0',
    _a[node_1.NodeType.IMAGE] = '#e8e8e8',
    _a[node_1.NodeType.SHAPE] = '#f0f0f0',
    _a);
function sslStle(type) {
    return {
        opacity: undefined,
        borderRadius: undefined,
        borderStyle: undefined,
        borderWidth: undefined,
        borderColor: undefined,
        backgroundImage: undefined,
        backgroundColor: COLORS[type]
    };
}
function toSkeletonScreenLoadingDSL(node) {
    var type = node.type;
    var result;
    if (type === node_1.NodeType.GROUP) {
        var group = __assign({}, node);
        group.children = group.children.map(toSkeletonScreenLoadingDSL);
        group.styles = sslStle(type);
        result = group;
    }
    else {
        result = __assign({}, node, { styles: sslStle(type), type: node_1.NodeType.SHAPE });
    }
    result.layout = __assign({}, result.layout, { width: result.measured.width, height: result.measured.height });
    return result;
}
exports.toSkeletonScreenLoadingDSL = toSkeletonScreenLoadingDSL;
function renderSkeletonScreenLoading(node, path) {
    var sslDSL = toSkeletonScreenLoadingDSL(node);
    return renderDSL(sslDSL, path);
}
exports.renderSkeletonScreenLoading = renderSkeletonScreenLoading;
function flush(canvas, fileName) {
    var out = fs.createWriteStream(path.resolve(fileName));
    var stream = canvas.pngStream();
    stream.pipe(out);
    out.on('finish', function () {
        console.log("The PNG file " + fileName + " was created.");
    });
}
