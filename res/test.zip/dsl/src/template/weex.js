"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a;
var node_1 = require("./../define/node");
var json2html_1 = require("./json2html");
var isEmpty_1 = require("./../primitive/isEmpty");
var Matcher_1 = require("./../primitive/Matcher");
var reduce_1 = require("./../primitive/reduce");
var compact_1 = require("./../primitive/compact");
var layout_util_1 = require("./../core/layout-util");
var class_name_1 = require("./class-name");
var flex_type_1 = require("./../define/flex-type");
var INDEX_MAP = (_a = {},
    _a[layout_util_1.TOP_INDEX] = 'top',
    _a[layout_util_1.RIGHT_INDEX] = 'right',
    _a[layout_util_1.BOTTOM_INDEX] = 'bottom',
    _a[layout_util_1.LEFT_INDEX] = 'left',
    _a);
var TAG_MATCHER = Matcher_1.matcher()
    .case(node_1.NodeType.TEXT, node_1.NodeType.TEXT)
    .case(node_1.NodeType.IMAGE, node_1.NodeType.IMAGE)
    .case(node_1.NodeType.SHAPE)
    .case(node_1.NodeType.GROUP, 'div')
    .default(function () {
    throw new Error("");
});
function attrs(input) {
    var type = input.type;
    if (type === node_1.NodeType.IMAGE) {
        return { src: input.value };
    }
}
function camelCase2kebabCase(value) {
    if (!isEmpty_1.default(value)) {
        var name_1 = String(value);
        if (name_1.toUpperCase() === name_1) {
            return name_1.toLowerCase().replace('_', '-');
        }
        else {
            var arr = [];
            for (var i = 0; i < name_1.length; i++) {
                var char = name_1.charAt(i);
                if (char.toUpperCase() === char) {
                    arr.push('-');
                }
                arr.push(char.toLowerCase());
            }
            return arr.join('');
        }
    }
    return value;
}
function paddingOrMargin(k, arr) {
    if (arr) {
        return compact_1.default(arr.reduce(function (pre, value, index) {
            var indexStr = INDEX_MAP[index];
            if (value !== undefined) {
                pre[k + '-' + indexStr] = value + 'px';
            }
            return pre;
        }, {}));
    }
}
function styles(input) {
    var map = __assign({}, input.layout, input.styles, input.textStyles, input.imageStyles);
    var result = reduce_1.default(map, function (pre, v, k) {
        var kk = camelCase2kebabCase(k);
        pre[kk] = v;
        return pre;
    }, {});
    result.width = map.width === undefined ? undefined : result.width + 'px';
    result.height = map.height === undefined ? undefined : result.height + 'px';
    result.src = map.src;
    result['font-family'] = map.fontFamily;
    result['background-color'] = map.backgroundColor;
    result.padding = undefined;
    Object.assign(result, paddingOrMargin('padding', map.padding));
    result.margin = undefined;
    Object.assign(result, paddingOrMargin('margin', map.margin));
    result['line-height'] = map.lineHeight !== undefined ? parseInt(map.lineHeight, 10) + 'px' : undefined;
    return compact_1.default(result);
}
function buildHtmlNode(input, parent, pageName) {
    var subfix;
    if (parent !== undefined) {
        var brothers = parent.children.filter(function (child) { return child.layout.position !== flex_type_1.PositionType.ABSOLUTE; });
        if (brothers.length === 2) {
            var index = brothers.indexOf(input);
            if (index === 0) {
                subfix = parent.layout.flexDirection === flex_type_1.FlexDirection.ROW ? 'left' : 'up';
            }
            else if (index === brothers.length - 1) {
                subfix = parent.layout.flexDirection === flex_type_1.FlexDirection.ROW ? 'right' : 'down';
            }
        }
    }
    var type = input.type;
    var css = styles(input);
    var result = {
        id: '',
        clazz: {
            name: class_name_1.generate(input, parent, css, pageName, subfix),
            styles: css
        },
        tag: TAG_MATCHER.invoke(type),
        attrs: attrs(input),
        value: type === node_1.NodeType.TEXT ? input.value : undefined,
        children: undefined
    };
    input.clazz = result.clazz;
    return result;
}
function buildHtmlNodeTree(input, parent, pageName) {
    var node = buildHtmlNode(input, parent, pageName);
    if (input.type === node_1.NodeType.GROUP) {
        var group_1 = input;
        node.children = group_1.children.map(function (layer) { return buildHtmlNodeTree(layer, group_1, pageName); });
    }
    return node;
}
function weex(node, pageName) {
    var html = buildHtmlNodeTree(node, undefined, camelCase2kebabCase(pageName));
    var lines = [
        "<template>",
        "\t<scroller style=\"width: 750px;\">",
        json2html_1.htmlStringify(html, false, 2),
        "\t</scroller>",
        "</template>",
        "\n",
        "<style scoped>",
        json2html_1.styleStringify(html),
        "</style>",
        "\n",
        "<script>",
        "</script>"
    ];
    return lines.join('\n');
}
exports.weex = weex;
function weexTemplate(node, pageName) {
    var html = buildHtmlNodeTree(node, undefined, camelCase2kebabCase(pageName));
    return json2html_1.htmlStringify(html, true, 2);
}
exports.weexTemplate = weexTemplate;
function localHtml(node, pageName) {
    var html = buildHtmlNodeTree(node, undefined, camelCase2kebabCase(pageName));
    var xml = '`' + json2html_1.htmlStringify(html, true, 2) + '`';
    return "\n<html>\n<head>\n  <script src=\"https://cdn.jsdelivr.net/npm/vue\"></script>\n</head>\n<body>\n  <div id=\"app\">\n  </div>\n  <script>\n    let Profile = Vue.extend({\n      template: " + xml + "\n    })\n    new Profile().$mount('#app')\n  </script>\n</body>\n</html>\n";
}
exports.localHtml = localHtml;
