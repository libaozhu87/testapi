"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Orientation;
(function (Orientation) {
    Orientation["HORIZONTAL"] = "horizontal";
    Orientation["VERTICAL"] = "vertical";
})(Orientation = exports.Orientation || (exports.Orientation = {}));
var SizeType = (function () {
    function SizeType() {
    }
    SizeType.MATCH_PARENT = 'match_parent';
    SizeType.WRAP_CONTENT = 'wrap_content';
    SizeType.FIXED = 'fixed';
    return SizeType;
}());
exports.SizeType = SizeType;
var Gravity;
(function (Gravity) {
    Gravity["LEFT"] = "left";
    Gravity["CENTER_HORIZONTAL"] = "center_horizontal";
    Gravity["RIGHT"] = "right";
    Gravity["FILL_HORIZONTAL"] = "fill_horizontal";
    Gravity["TOP"] = "top";
    Gravity["CENTER_VERTICAL"] = "center_vertical";
    Gravity["BOTTOM"] = "bottom";
    Gravity["FILL_VERTICAL"] = "fill_vertical";
})(Gravity = exports.Gravity || (exports.Gravity = {}));
var Unit;
(function (Unit) {
    Unit["DP"] = "dp";
    Unit["PX"] = "px";
})(Unit = exports.Unit || (exports.Unit = {}));
var View = (function () {
    function View() {
    }
    return View;
}());
exports.View = View;
var Image = (function (_super) {
    __extends(Image, _super);
    function Image() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Image;
}(View));
exports.Image = Image;
var Text = (function (_super) {
    __extends(Text, _super);
    function Text() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Text;
}(View));
exports.Text = Text;
var ViewGroup = (function (_super) {
    __extends(ViewGroup, _super);
    function ViewGroup() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ViewGroup;
}(View));
exports.ViewGroup = ViewGroup;
var LinearLayout = (function (_super) {
    __extends(LinearLayout, _super);
    function LinearLayout() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return LinearLayout;
}(ViewGroup));
exports.LinearLayout = LinearLayout;
var RelativeLayout = (function (_super) {
    __extends(RelativeLayout, _super);
    function RelativeLayout() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return RelativeLayout;
}(ViewGroup));
exports.RelativeLayout = RelativeLayout;
var FrameLayout = (function (_super) {
    __extends(FrameLayout, _super);
    function FrameLayout() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return FrameLayout;
}(ViewGroup));
exports.FrameLayout = FrameLayout;
