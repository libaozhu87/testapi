"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var View = (function () {
    function View() {
    }
    return View;
}());
exports.View = View;
