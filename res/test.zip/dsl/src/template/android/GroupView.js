"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var BaseLayout = (function () {
    function BaseLayout() {
    }
    return BaseLayout;
}());
exports.BaseLayout = BaseLayout;
