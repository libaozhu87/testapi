"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FrameLayout = (function () {
    function FrameLayout() {
    }
    return FrameLayout;
}());
exports.FrameLayout = FrameLayout;
