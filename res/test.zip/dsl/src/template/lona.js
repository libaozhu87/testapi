"use strict";
var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a;
var node_1 = require("./../define/node");
var Matcher_1 = require("./../primitive/Matcher");
var compact_1 = require("./../primitive/compact");
var layout_util_1 = require("./../core/layout-util");
var id = 0;
function generateId() {
    return ++id;
}
var INDEX_MAP = (_a = {},
    _a[layout_util_1.TOP_INDEX] = 'Top',
    _a[layout_util_1.RIGHT_INDEX] = 'Right',
    _a[layout_util_1.BOTTOM_INDEX] = 'Bottom',
    _a[layout_util_1.LEFT_INDEX] = 'Left',
    _a);
var TAG_MATCHER = Matcher_1.matcher()
    .case(node_1.NodeType.TEXT, 'Lona:Text')
    .case(node_1.NodeType.IMAGE, 'Lona:Image')
    .case(node_1.NodeType.SHAPE)
    .case(node_1.NodeType.GROUP, 'Lona:View')
    .default(function () {
    throw new Error("");
});
function paddingOrMargin(k, arr) {
    if (arr) {
        return compact_1.default(arr.reduce(function (pre, value, index) {
            var indexStr = INDEX_MAP[index];
            if (value !== undefined) {
                pre[k + indexStr] = value;
            }
            return pre;
        }, {}));
    }
}
function styles(input) {
    var map = __assign({}, input.layout, input.styles, input.textStyles, input.imageStyles);
    Object.assign(map, paddingOrMargin('padding', map.padding));
    map.padding = undefined;
    Object.assign(map, paddingOrMargin('margin', map.margin));
    map.margin = undefined;
    return compact_1.default(map);
}
function buildNode(input, property) {
    var result = {
        id: '' + generateId(),
        name: TAG_MATCHER.invoke(input.type) + generateId(),
        type: TAG_MATCHER.invoke(input.type),
        params: styles(input),
        children: undefined
    };
    if (input.type === node_1.NodeType.IMAGE) {
        result.params = Object.assign(result.params, { image: input.value });
    }
    else if (input.type === node_1.NodeType.TEXT) {
        result.params = Object.assign(result.params, { text: input.value });
    }
    return result;
}
function buildNodeTree(input, property) {
    var node = buildNode(input, property);
    if (input.type === node_1.NodeType.GROUP) {
        var group = input;
        node.children = group.children.map(function (layer) { return buildNodeTree(layer, property); });
    }
    return node;
}
function lona(node, property) {
    var lonaRoot = buildNodeTree(node, property);
    return JSON.stringify(lonaRoot);
}
exports.lona = lona;
