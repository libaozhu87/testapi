"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var reduce_1 = require("./../primitive/reduce");
var compact_1 = require("./../primitive/compact");
function classStringify(clazzes) {
    var names = {};
    return compact_1.default(clazzes.map(function (clazz) {
        var name = clazz.name, styles = clazz.styles;
        if (names[name]) {
            return undefined;
        }
        names[name] = true;
        var stylesStr = styles &&
            reduce_1.default(compact_1.default(styles), function (pre, v, k) {
                return pre.concat("\t" + k + ": " + v + ";");
            }, []).join('\n');
        return stylesStr ? "." + name + " {" + '\n' + stylesStr + '\n' + "}" : "." + name + " {}";
    })).join('\n');
}
exports.classStringify = classStringify;
