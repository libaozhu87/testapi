"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var isEmpty_1 = require("./../primitive/isEmpty");
var range_1 = require("./../primitive/range");
var reduce_1 = require("./../primitive/reduce");
var compact_1 = require("./../primitive/compact");
var flatten_1 = require("./../primitive/flatten");
var json2class_1 = require("./json2class");
function htmlStringify(html, useStyle, tabs) {
    if (tabs === void 0) { tabs = 0; }
    var value = html.value, clazz = html.clazz, attrs = html.attrs, tag = html.tag, children = html.children;
    var tabsStr = range_1.default(0, tabs + 1, 1)
        .map(function () { return ''; })
        .join('\t');
    var attrsStr = attrs &&
        compact_1.default(reduce_1.default(compact_1.default(attrs), function (memo, v, k) {
            return memo.concat(k + "=\"" + v + "\"");
        }, [])).join(' ');
    attrsStr = attrsStr || '';
    var stylesStr = useStyle &&
        compact_1.default(reduce_1.default(compact_1.default(clazz.styles), function (memo, v, k) {
            return memo.concat(k + ":" + v);
        }, [])).join('; ');
    stylesStr = stylesStr ? "style=\"" + stylesStr + "\"" : '';
    var classStr = !useStyle ? "class=\"" + clazz.name + "\"" : '';
    var desc = compact_1.default([stylesStr, classStr, attrsStr]).join(' ');
    if (!isEmpty_1.default(children)) {
        var childrenStr = children.map(function (child) { return htmlStringify(child, useStyle, tabs + 1); }).join('\n');
        return tabsStr + "<" + tag + " " + desc + ">" + '\n' + childrenStr + '\n' + (tabsStr + "</" + tag + ">");
    }
    else {
        return tabsStr + "<" + tag + " " + desc + ">" + (value ? value : '') + "</" + tag + ">";
    }
}
exports.htmlStringify = htmlStringify;
function styleList(html) {
    var list = [html.clazz];
    if (!isEmpty_1.default(html.children)) {
        return list.concat(flatten_1.default(html.children.map(styleList)));
    }
    return list;
}
function styleStringify(html, tabs) {
    if (tabs === void 0) { tabs = 0; }
    var list = styleList(html);
    return json2class_1.classStringify(list);
}
exports.styleStringify = styleStringify;
