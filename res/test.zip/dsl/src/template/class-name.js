"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var compact_1 = require("./../primitive/compact");
var flex_type_1 = require("../define/flex-type");
var color_util_1 = require("./color-util");
var isEmpty_1 = require("./../primitive/isEmpty");
function isMatchParentSize(node) {
    var parent = node.parent;
    if (parent !== undefined) {
        return (parent.measured.width === node.measured.width &&
            parent.measured.height === node.measured.height &&
            node.measured.x === 0 &&
            node.measured.y === 0);
    }
    return false;
}
function generate_(node, parent, css, prefix, subfix) {
    var styles = node.styles;
    var textStyles = node.textStyles;
    var dir = node.layout.flexDirection;
    var justifyContent = node.layout.justifyContent;
    var des;
    if (node.layout.position === flex_type_1.PositionType.ABSOLUTE) {
        des = 'absolute';
        var backgrounds = parent.children.filter(isMatchParentSize);
        if (backgrounds.indexOf(node) !== -1) {
            des = 'background';
        }
    }
    var fontSize;
    if (textStyles && textStyles.fontSize !== undefined) {
        fontSize = 'size' + textStyles.fontSize;
    }
    var shapeWidth = node.layout.width !== undefined ? 'w' + node.layout.width : undefined;
    var shapeHeight = node.layout.height !== undefined ? 'h' + node.layout.height : undefined;
    var color = color_util_1.colorName((textStyles && textStyles.color) || (styles && styles.backgroundColor) || (styles && styles.borderColor));
    var basic = compact_1.default([prefix, color, dir, justifyContent, fontSize, shapeWidth, shapeHeight, des, subfix]).join('-');
    var name = isEmpty_1.default(basic) ? node.id : basic + '-' + node.id;
    return name;
}
function generate(node, parent, css, prefix, subfix) {
    if (!css) {
        return undefined;
    }
    var name = generate_(node, parent, css, prefix, subfix);
    return name;
}
exports.generate = generate;
