"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var top_1 = require("./../primitive/top");
var COMMON_COLORS = [
    ['black', 0x000000ff],
    ['blue', 0x0000ffff],
    ['cyan', 0x00ffffff],
    ['ltgray', 0xd3d3d3ff],
    ['gray', 0x808080ff],
    ['dkgray', 0xa9a9a9ff],
    ['green', 0x00ff00ff],
    ['magenta', 0xff00ffff],
    ['red', 0xff0000ff],
    ['white', 0xffffffff],
    ['yellow', 0xffff00ff]
];
function distance(v1, v2) {
    var r1 = (v1 & 0xff000000) >> 24;
    var g1 = (v1 & 0x00ff0000) >> 16;
    var b1 = (v1 & 0x0000ff00) >> 8;
    var a1 = (v1 & 0x000000ff) >> 0;
    var r2 = (v2 & 0xff000000) >> 24;
    var g2 = (v2 & 0x00ff0000) >> 16;
    var b2 = (v2 & 0x0000ff00) >> 8;
    var a2 = (v1 & 0x000000ff) >> 0;
    return Math.sqrt((r1 - r2) * (r1 - r2) + (g1 - g2) * (g1 - g2) + (b1 - b2) * (b1 - b2) + (a1 - a2) * (a1 - a2));
}
function color2int(color) {
    var colorStr = color && color.trim();
    if (colorStr !== undefined) {
        if (colorStr[0] === '#') {
            var valueStr = colorStr.slice(1);
            if (valueStr.length === 8) {
                return parseInt(valueStr, 16);
            }
            else if (valueStr.length === 6) {
                return parseInt(valueStr + 'FF', 16);
            }
            else {
                throw new Error(color + " is not a valid color.");
            }
        }
        else if (colorStr[0] === 'r') {
            var index0 = colorStr.indexOf('(');
            var index1 = colorStr.indexOf(')');
            if (index0 >= 0 && index1 >= 0 && index0 < index1) {
                var values = colorStr.slice(index0 + 1, index1).split(',');
                if (values.length >= 3 && values.length <= 4) {
                    if (values.length === 3) {
                        values.push('255');
                    }
                    return values.map(function (v) { return parseInt(v, 10); }).reduce(function (pre, cur) { return pre * 256 + cur; }, 0);
                }
            }
        }
        throw new Error(color + " is not a valid color.");
    }
    return undefined;
}
exports.color2int = color2int;
function red(color) {
    if (red !== undefined) {
        return (color & 0xff000000) >> 24;
    }
}
exports.red = red;
function green(color) {
    if (red !== undefined) {
        return (color & 0x00ff0000) >> 16;
    }
}
exports.green = green;
function blue(color) {
    if (red !== undefined) {
        return (color & 0x0000ff00) >> 8;
    }
}
exports.blue = blue;
function alpha(color) {
    if (red !== undefined) {
        return (color & 0x000000ff) >> 0;
    }
}
exports.alpha = alpha;
function colorName(input) {
    var value = color2int(input);
    if (value !== undefined) {
        var result = top_1.default(COMMON_COLORS, function (pre, cur) { return distance(pre[1], value) - distance(cur[1], value); });
        return result[0];
    }
}
exports.colorName = colorName;
