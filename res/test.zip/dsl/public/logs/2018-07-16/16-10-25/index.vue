<template>
	<scroller style="width: 750px;">
		<div class="white-column-flex-start-w304-g32">
			<div class="ltgray-column-flex-start-w304-h304-g29">
				<image class="w304-h304-background-i2" src="https://gw.alicdn.com/tfs/TB1YIsjDkyWBuNjy0FpXXassXXa-304-304.png"></image>
				<div class="column-flex-start-w304-g28">
					<div class="column-flex-start-w304-h100-up-g34">
						<div class="row-flex-start-w304-h100-g33">
							<image class="w304-h100-background-i3" src="https://gw.alicdn.com/tfs/TB1f9MmDbGYBuNjy0FoXXciBFXa-304-100.png"></image>
							<div class="white-column-flex-start-g20">
								<div class="white-column-center-up-g18">
									<text class="black-size20-t8">票数 3330</text>
								</div>
								<text class="white-size20-down-t9">排名 287</text>
							</div>
						</div>
						<image class="w60-h74-absolute-i4" src="https://gw.alicdn.com/tfs/TB1NeAtDXOWBuNjy0FiXXXFxVXa-60-74.png"></image>
					</div>
					<div class="row-flex-start-w304-h100-down-g27">
						<image class="w304-h100-background-i5" src="https://gw.alicdn.com/tfs/TB1mLZVDh9YBuNjy0FfXXXIsVXa-304-100.png"></image>
						<div class="row-flex-start-g26">
							<image class="w56-h56-left-i13" src="https://gw.alicdn.com/tfs/TB1FfZVDh9YBuNjy0FfXXXIsVXa-56-56.png"></image>
							<div class="column-flex-start-right-g25">
								<div class="row-flex-start-up-g24">
									<text class="white-size24-left-t14">淘大王池</text>
									<text class="white-size20-right-t17">我参赛的</text>
								</div>
								<text class="yellow-size20-down-t15">漫威复仇者集中营</text>
							</div>
						</div>
					</div>
				</div>
			</div>
			<text class="black-size28-w264-t10">钢铁侠全球限量款手办全球限量款40台…</text>
			<div class="column-center-w264-h54-g31">
				<image class="w264-h54-background-i11" src="https://gw.alicdn.com/tfs/TB1rCquDqmWBuNjy1XaXXXCbXXa-264-54.png"></image>
				<text class="gray-size28-t12">投票分2亿</text>
			</div>
		</div>
	</scroller>
</template>


<style scoped>
.white-column-flex-start-w304-g32 {
	flex-direction: column;
	justify-content: flex-start;
	align-items: center;
	position: relative;
	width: 304px;
	background-color: rgba(255,255,255,1);
	padding-top: 0px;
	padding-bottom: 0px;
}
.ltgray-column-flex-start-w304-h304-g29 {
	flex-direction: column;
	justify-content: flex-start;
	align-items: flex-start;
	position: relative;
	width: 304px;
	height: 304px;
	align-self: center;
	background-color: rgba(216,216,216,1);
	border-bottom-left-radius: 0;
	border-bottom-right-radius: 0;
	border-top-left-radius: 10;
	border-top-right-radius: 10;
	margin-top: 0px;
	margin-right: 0px;
}
.w304-h304-background-i2 {
	position: absolute;
	width: 304px;
	height: 304px;
	left: 0;
	top: 0;
	resize: stretch;
}
.column-flex-start-w304-g28 {
	flex-direction: column;
	justify-content: flex-start;
	align-items: flex-start;
	position: relative;
	width: 304px;
	align-self: flex-start;
	padding-top: 0px;
	padding-bottom: 0px;
	margin-top: 0px;
	margin-left: 0px;
}
.column-flex-start-w304-h100-up-g34 {
	flex-direction: column;
	justify-content: flex-start;
	align-items: flex-start;
	position: relative;
	width: 304px;
	height: 100px;
	align-self: flex-start;
	margin-top: 0px;
	margin-left: 0px;
}
.row-flex-start-w304-h100-g33 {
	flex-direction: row;
	justify-content: flex-start;
	align-items: center;
	position: relative;
	width: 304px;
	height: 100px;
	align-self: flex-start;
	margin-top: 0px;
	margin-left: 0px;
}
.w304-h100-background-i3 {
	position: absolute;
	width: 304px;
	height: 100px;
	left: 0;
	top: 0;
	resize: stretch;
}
.white-column-flex-start-g20 {
	flex-direction: column;
	justify-content: flex-start;
	align-items: center;
	position: relative;
	align-self: center;
	border-color: rgba(255,255,255,1);
	border-style: solid;
	border-width: 1;
	border-radius: 6;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
	margin-bottom: 2px;
	margin-left: 20px;
}
.white-column-center-up-g18 {
	flex-direction: column;
	justify-content: center;
	align-items: center;
	position: relative;
	align-self: center;
	background-color: rgba(255,255,255,1);
	border-bottom-left-radius: 0;
	border-bottom-right-radius: 0;
	border-top-left-radius: 6;
	border-top-right-radius: 6;
	padding-top: 1px;
	padding-right: 8.5px;
	padding-bottom: 1px;
	padding-left: 8px;
	margin-top: 0px;
	margin-right: 0px;
}
.black-size20-t8 {
	position: relative;
	align-self: center;
	font-family: PingFangSC-Regular;
	font-size: 20;
	color: #222222;
	line-height: 28px;
	font-weight: normal;
	margin-right: 0.5px;
}
.white-size20-down-t9 {
	position: relative;
	align-self: center;
	font-family: PingFangSC-Regular;
	font-size: 20;
	color: #FFFFFF;
	line-height: 28px;
	font-weight: normal;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 2px;
}
.w60-h74-absolute-i4 {
	position: absolute;
	width: 60px;
	height: 74px;
	right: 20;
	top: 1;
	resize: stretch;
}
.row-flex-start-w304-h100-down-g27 {
	flex-direction: row;
	justify-content: flex-start;
	align-items: center;
	position: relative;
	width: 304px;
	height: 100px;
	align-self: flex-start;
	margin-top: 104px;
	margin-bottom: 0px;
	margin-left: 0px;
}
.w304-h100-background-i5 {
	position: absolute;
	width: 304px;
	height: 100px;
	left: 0;
	top: 0;
	resize: stretch;
}
.row-flex-start-g26 {
	flex-direction: row;
	justify-content: flex-start;
	align-items: center;
	position: relative;
	align-self: center;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
	margin-top: 2.5px;
	margin-left: 20px;
}
.w56-h56-left-i13 {
	position: relative;
	width: 56px;
	height: 56px;
	align-self: center;
	resize: stretch;
	margin-bottom: 0.5px;
	margin-left: 0px;
}
.column-flex-start-right-g25 {
	flex-direction: column;
	justify-content: flex-start;
	align-items: flex-start;
	position: relative;
	align-self: center;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	margin-left: 10px;
}
.row-flex-start-up-g24 {
	flex-direction: row;
	justify-content: flex-start;
	align-items: center;
	position: relative;
	align-self: flex-start;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-left: 0px;
}
.white-size24-left-t14 {
	position: relative;
	align-self: center;
	font-family: PingFangSC-Medium;
	font-size: 24;
	color: #FFFFFF;
	line-height: 33px;
	font-weight: bold;
	margin-bottom: 0px;
	margin-left: 0px;
}
.white-size20-right-t17 {
	position: relative;
	align-self: center;
	background-color: rgba(255,34,34,1);
	border-radius: 4;
	font-family: PingFangSC-Regular;
	font-size: 20;
	color: #FFFFFF;
	line-height: 24px;
	font-weight: normal;
	padding-top: 0px;
	padding-right: 5px;
	padding-bottom: 0px;
	padding-left: 5px;
	margin-right: 0px;
	margin-bottom: 1.5px;
	margin-left: 9px;
}
.yellow-size20-down-t15 {
	position: relative;
	align-self: flex-start;
	font-family: PingFangSC-Regular;
	font-size: 20;
	color: #FFDA44;
	line-height: 28px;
	font-weight: normal;
	margin-top: 2px;
	margin-right: 33px;
	margin-bottom: 0px;
	margin-left: 2px;
}
.black-size28-w264-t10 {
	position: relative;
	width: 264px;
	align-self: center;
	font-family: PingFangSC-Medium;
	font-size: 28;
	color: #222222;
	line-height: 40px;
	text-align: left;
	font-weight: bold;
	margin-top: 13px;
	margin-right: 0px;
}
.column-center-w264-h54-g31 {
	flex-direction: column;
	justify-content: center;
	align-items: center;
	position: relative;
	width: 264px;
	height: 54px;
	align-self: center;
	margin-top: 17px;
	margin-right: 0px;
	margin-bottom: 20px;
}
.w264-h54-background-i11 {
	position: absolute;
	width: 264px;
	height: 54px;
	left: 0;
	top: 0;
	resize: stretch;
}
.gray-size28-t12 {
	position: relative;
	align-self: center;
	font-family: PingFangSC-Medium;
	font-size: 28;
	color: #925715;
	line-height: 40px;
	font-weight: bold;
	margin-left: 2.5px;
}
</style>


<script>
</script>