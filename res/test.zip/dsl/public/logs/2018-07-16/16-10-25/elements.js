export default [
  {
    "name": "Mask",
    "Id": 6,
    "nameId": "B6959C1D-E7FC-4797-9C74-FE8C0EB1D0C8",
    "frame": {
      "x": 0,
      "y": 0,
      "width": 304,
      "height": 304
    },
    "styles": {
      "backgroundColor": "rgba(216,216,216,1)",
      "borderBottomLeftRadius": "0",
      "borderBottomRightRadius": "0",
      "borderTopLeftRadius": "10",
      "borderTopRightRadius": "10"
    },
    "type": "shape",
    "exactFrame": {
      "x": 0,
      "y": 0,
      "width": 304,
      "height": 304
    },
    "zIndex": 1,
    "id": "s1"
  },
  {
    "name": "Bitmap",
    "Id": 9,
    "nameId": "1168DE09-DD3E-4C6A-BB4F-FBC3272A7E38",
    "frame": {
      "x": 0,
      "y": 0,
      "width": 304,
      "height": 304
    },
    "imageStyles": {
      "resize": "stretch"
    },
    "type": "image",
    "value": "https://gw.alicdn.com/tfs/TB1YIsjDkyWBuNjy0FpXXassXXa-304-304.png",
    "exactFrame": {
      "x": 0,
      "y": 0,
      "width": 304,
      "height": 304
    },
    "zIndex": 2,
    "id": "i2"
  },
  {
    "name": "Bitmap",
    "Id": 10,
    "nameId": "D5FC39D1-727B-4E25-A593-C56915FA5BC0",
    "frame": {
      "x": 0,
      "y": 0,
      "width": 304,
      "height": 100
    },
    "imageStyles": {
      "resize": "stretch"
    },
    "type": "image",
    "value": "https://gw.alicdn.com/tfs/TB1f9MmDbGYBuNjy0FoXXciBFXa-304-100.png",
    "exactFrame": {
      "x": 0,
      "y": 0,
      "width": 304,
      "height": 100
    },
    "zIndex": 3,
    "id": "i3"
  },
  {
    "name": "Bitmap Copy",
    "Id": 11,
    "nameId": "68980BF4-2C48-43E0-96DF-4F52C92549E1",
    "frame": {
      "x": 224,
      "y": 1,
      "width": 60,
      "height": 74
    },
    "imageStyles": {
      "resize": "stretch"
    },
    "type": "image",
    "value": "https://gw.alicdn.com/tfs/TB1NeAtDXOWBuNjy0FiXXXFxVXa-60-74.png",
    "exactFrame": {
      "x": 224,
      "y": 1,
      "width": 60,
      "height": 74
    },
    "zIndex": 4,
    "id": "i4"
  },
  {
    "name": "Bitmap",
    "Id": 12,
    "nameId": "BA6025F1-EED4-4119-85C7-F8C4FFD44BFA",
    "frame": {
      "x": 0,
      "y": 204,
      "width": 304,
      "height": 100
    },
    "imageStyles": {
      "resize": "stretch"
    },
    "type": "image",
    "value": "https://gw.alicdn.com/tfs/TB1mLZVDh9YBuNjy0FfXXXIsVXa-304-100.png",
    "exactFrame": {
      "x": 0,
      "y": 204,
      "width": 304,
      "height": 100
    },
    "zIndex": 5,
    "id": "i5"
  },
  {
    "name": "Rectangle 5",
    "Id": 15,
    "nameId": "642AB3BF-68E6-4B8A-B902-BD00FA1305F8",
    "frame": {
      "x": 20,
      "y": 18,
      "width": 112,
      "height": 60
    },
    "styles": {
      "borderColor": "rgba(255,255,255,1)",
      "borderStyle": "solid",
      "borderWidth": 1,
      "borderRadius": 6
    },
    "type": "shape",
    "exactFrame": {
      "x": 20,
      "y": 18,
      "width": 112,
      "height": 60
    },
    "zIndex": 6,
    "id": "s6"
  },
  {
    "name": "Rectangle 6",
    "Id": 16,
    "nameId": "85269465-912C-4053-A775-38C2731FD388",
    "frame": {
      "x": 20,
      "y": 18,
      "width": 112,
      "height": 30
    },
    "styles": {
      "backgroundColor": "rgba(255,255,255,1)",
      "borderBottomLeftRadius": "0",
      "borderBottomRightRadius": "0",
      "borderTopLeftRadius": "6",
      "borderTopRightRadius": "6"
    },
    "type": "shape",
    "exactFrame": {
      "x": 20,
      "y": 18,
      "width": 112,
      "height": 30
    },
    "zIndex": 7,
    "id": "s7"
  },
  {
    "name": "票数 3330",
    "Id": 17,
    "nameId": "56693B4C-B7A2-432A-9365-A0DA9650AF62",
    "frame": {
      "x": 28,
      "y": 19,
      "width": 95,
      "height": 28
    },
    "textStyles": {
      "fontFamily": "PingFangSC-Regular",
      "fontSize": 20,
      "color": "#222222",
      "lineHeight": 28,
      "fontWeight": "normal"
    },
    "value": "票数 3330",
    "type": "text",
    "exactFrame": {
      "x": 28,
      "y": 23,
      "width": 95,
      "height": 20
    },
    "zIndex": 8,
    "id": "t8"
  },
  {
    "name": "排名 287",
    "Id": 18,
    "nameId": "131863EF-6DC0-45AB-9F4D-A44ED77AAC4F",
    "frame": {
      "x": 35,
      "y": 48,
      "width": 82,
      "height": 28
    },
    "textStyles": {
      "fontFamily": "PingFangSC-Regular",
      "fontSize": 20,
      "color": "#FFFFFF",
      "lineHeight": 28,
      "fontWeight": "normal"
    },
    "value": "排名 287",
    "type": "text",
    "exactFrame": {
      "x": 35,
      "y": 52,
      "width": 82,
      "height": 20
    },
    "zIndex": 9,
    "id": "t9"
  },
  {
    "name": "钢铁侠全球限量款手办全球限量款40台…",
    "Id": 19,
    "nameId": "1C7E3033-AD8B-404F-8EBA-725BE410F1F8",
    "frame": {
      "x": 20,
      "y": 317,
      "width": 264,
      "height": 80
    },
    "textStyles": {
      "fontFamily": "PingFangSC-Medium",
      "fontSize": 28,
      "color": "#222222",
      "lineHeight": 40,
      "textAlign": "left",
      "fontWeight": "bold"
    },
    "value": "钢铁侠全球限量款手办全球限量款40台…",
    "type": "text",
    "exactFrame": {
      "x": 20,
      "y": 323,
      "width": 264,
      "height": 68
    },
    "zIndex": 10,
    "id": "t10"
  },
  {
    "name": "Bitmap",
    "Id": 20,
    "nameId": "EDF359F5-9CD2-4E0B-9F53-8F006D0F5FC1",
    "frame": {
      "x": 20,
      "y": 414,
      "width": 264,
      "height": 54
    },
    "imageStyles": {
      "resize": "stretch"
    },
    "type": "image",
    "value": "https://gw.alicdn.com/tfs/TB1rCquDqmWBuNjy1XaXXXCbXXa-264-54.png",
    "exactFrame": {
      "x": 20,
      "y": 414,
      "width": 264,
      "height": 54
    },
    "zIndex": 11,
    "id": "i11"
  },
  {
    "name": "投票分2亿",
    "Id": 21,
    "nameId": "7B659904-1836-48B7-B38A-2B864AF11EBF",
    "frame": {
      "x": 90,
      "y": 421,
      "width": 129,
      "height": 40
    },
    "textStyles": {
      "fontFamily": "PingFangSC-Medium",
      "fontSize": 28,
      "color": "#925715",
      "lineHeight": 40,
      "fontWeight": "bold"
    },
    "value": "投票分2亿",
    "type": "text",
    "exactFrame": {
      "x": 90,
      "y": 427,
      "width": 129,
      "height": 28
    },
    "zIndex": 12,
    "id": "t12"
  },
  {
    "name": "Bitmap",
    "Id": 22,
    "nameId": "88751A7C-D6E6-42AA-9E8A-1C724F5E8F56",
    "frame": {
      "x": 20,
      "y": 228,
      "width": 56,
      "height": 56
    },
    "imageStyles": {
      "resize": "stretch"
    },
    "type": "image",
    "value": "https://gw.alicdn.com/tfs/TB1FfZVDh9YBuNjy0FfXXXIsVXa-56-56.png",
    "exactFrame": {
      "x": 20,
      "y": 228,
      "width": 56,
      "height": 56
    },
    "zIndex": 13,
    "id": "i13"
  },
  {
    "name": "淘大王池",
    "Id": 23,
    "nameId": "CF9C2145-AEA5-406B-95DE-476D5549C0F2",
    "frame": {
      "x": 86,
      "y": 225,
      "width": 96,
      "height": 33
    },
    "textStyles": {
      "fontFamily": "PingFangSC-Medium",
      "fontSize": 24,
      "color": "#FFFFFF",
      "lineHeight": 33,
      "fontWeight": "bold"
    },
    "value": "淘大王池",
    "type": "text",
    "exactFrame": {
      "x": 86,
      "y": 230,
      "width": 96,
      "height": 24
    },
    "zIndex": 14,
    "id": "t14"
  },
  {
    "name": "漫威复仇者集中营",
    "Id": 24,
    "nameId": "5CE45B23-65E7-4C22-A971-3C94F75C59BF",
    "frame": {
      "x": 88,
      "y": 260,
      "width": 160,
      "height": 28
    },
    "textStyles": {
      "fontFamily": "PingFangSC-Regular",
      "fontSize": 20,
      "color": "#FFDA44",
      "lineHeight": 28,
      "fontWeight": "normal"
    },
    "value": "漫威复仇者集中营",
    "type": "text",
    "exactFrame": {
      "x": 88,
      "y": 264,
      "width": 160,
      "height": 20
    },
    "zIndex": 15,
    "id": "t15"
  },
  {
    "name": "Rectangle 4",
    "Id": 25,
    "nameId": "614FFDA6-6CFB-4683-A814-D9E2767C8453",
    "frame": {
      "x": 191,
      "y": 229,
      "width": 90,
      "height": 24
    },
    "styles": {
      "backgroundColor": "rgba(255,34,34,1)",
      "borderRadius": 4
    },
    "type": "shape",
    "exactFrame": {
      "x": 191,
      "y": 229,
      "width": 90,
      "height": 24
    },
    "zIndex": 16,
    "id": "s16"
  },
  {
    "name": "我参赛的",
    "Id": 26,
    "nameId": "CE214AF0-ED16-4EE8-B0B0-A3967A264509",
    "frame": {
      "x": 196,
      "y": 226,
      "width": 80,
      "height": 28
    },
    "textStyles": {
      "fontFamily": "PingFangSC-Regular",
      "fontSize": 20,
      "color": "#FFFFFF",
      "lineHeight": 24,
      "fontWeight": "normal"
    },
    "value": "我参赛的",
    "type": "text",
    "exactFrame": {
      "x": 196,
      "y": 230,
      "width": 80,
      "height": 20
    },
    "zIndex": 17,
    "id": "t17"
  }
]