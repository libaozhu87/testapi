export default {
  "name": "auto-merge",
  "id": "g32",
  "zIndex": 1,
  "type": "group",
  "raw": {
    "name": "auto-merge",
    "id": "g32",
    "type": "group",
    "zIndex": 1,
    "dir": "column"
  },
  "frame": {
    "x": 0,
    "y": 0,
    "width": 304,
    "height": 488
  },
  "exactFrame": {
    "x": 0,
    "y": 0,
    "width": 304,
    "height": 468
  },
  "measured": {
    "x": 0,
    "y": 0,
    "width": 304,
    "height": 488
  },
  "reasons": [
    "BY_INPUT",
    "BY_INPUT"
  ],
  "layout": {
    "flexDirection": "column",
    "justifyContent": "flex-start",
    "alignItems": "center",
    "padding": [
      0,
      null,
      0,
      null
    ],
    "position": "relative",
    "width": 304
  },
  "styles": {
    "backgroundColor": "rgba(255,255,255,1)"
  },
  "children": [
    {
      "name": "auto-merge",
      "id": "g29",
      "zIndex": 1,
      "type": "group",
      "raw": {
        "name": "auto-merge",
        "id": "g29",
        "type": "group",
        "zIndex": 1
      },
      "frame": {
        "x": 0,
        "y": 0,
        "width": 304,
        "height": 304
      },
      "exactFrame": {
        "x": 0,
        "y": 0,
        "width": 304,
        "height": 304
      },
      "measured": {
        "x": 0,
        "y": 0,
        "width": 304,
        "height": 304
      },
      "reasons": [
        "BY_IMAGE_AS_BACKGROUND",
        "BY_IMAGE_AS_BACKGROUND"
      ],
      "layout": {
        "flexDirection": "column",
        "justifyContent": "flex-start",
        "alignItems": "flex-start",
        "position": "relative",
        "width": 304,
        "height": 304,
        "margin": [
          0,
          0,
          null,
          null
        ],
        "alignSelf": "center"
      },
      "styles": {
        "backgroundColor": "rgba(216,216,216,1)",
        "borderBottomLeftRadius": "0",
        "borderBottomRightRadius": "0",
        "borderTopLeftRadius": "10",
        "borderTopRightRadius": "10"
      },
      "children": [
        {
          "name": "Bitmap",
          "id": "i2",
          "zIndex": 2,
          "type": "image",
          "raw": {
            "name": "Bitmap",
            "Id": 9,
            "nameId": "1168DE09-DD3E-4C6A-BB4F-FBC3272A7E38",
            "type": "image",
            "value": "https://gw.alicdn.com/tfs/TB1YIsjDkyWBuNjy0FpXXassXXa-304-304.png",
            "zIndex": 2,
            "id": "i2"
          },
          "frame": {
            "x": 0,
            "y": 0,
            "width": 304,
            "height": 304
          },
          "exactFrame": {
            "x": 0,
            "y": 0,
            "width": 304,
            "height": 304
          },
          "measured": {
            "x": 0,
            "y": 0,
            "width": 304,
            "height": 304
          },
          "reasons": [
            "BY_PRIMITIVE",
            "BY_PRIMITIVE"
          ],
          "layout": {
            "position": "absolute",
            "width": 304,
            "height": 304,
            "left": 0,
            "top": 0
          },
          "value": "https://gw.alicdn.com/tfs/TB1YIsjDkyWBuNjy0FpXXassXXa-304-304.png",
          "imageStyles": {
            "resize": "stretch"
          },
          "clazz": {
            "name": "w304-h304-background-i2",
            "styles": {
              "position": "absolute",
              "width": "304px",
              "height": "304px",
              "left": 0,
              "top": 0,
              "resize": "stretch"
            }
          }
        },
        {
          "name": "auto-merge",
          "id": "g28",
          "zIndex": 3,
          "type": "group",
          "raw": {
            "name": "auto-merge",
            "id": "g28",
            "type": "group",
            "zIndex": 3,
            "dir": "column"
          },
          "frame": {
            "x": 0,
            "y": 0,
            "width": 304,
            "height": 304
          },
          "exactFrame": {
            "x": 0,
            "y": 0,
            "width": 304,
            "height": 304
          },
          "measured": {
            "x": 0,
            "y": 0,
            "width": 304,
            "height": 304
          },
          "reasons": [
            "BY_STRETCH_WIDTH",
            "BY_DEFAULT"
          ],
          "layout": {
            "flexDirection": "column",
            "justifyContent": "flex-start",
            "alignItems": "flex-start",
            "padding": [
              0,
              null,
              0,
              null
            ],
            "position": "relative",
            "width": 304,
            "margin": [
              0,
              null,
              null,
              0
            ],
            "alignSelf": "flex-start"
          },
          "children": [
            {
              "name": "auto-merge",
              "id": "g34",
              "zIndex": 3,
              "type": "group",
              "raw": {
                "name": "auto-merge",
                "id": "g34",
                "type": "group",
                "zIndex": 3,
                "dir": "row"
              },
              "frame": {
                "x": 0,
                "y": 0,
                "width": 304,
                "height": 100
              },
              "exactFrame": {
                "x": 0,
                "y": 0,
                "width": 304,
                "height": 100
              },
              "measured": {
                "x": 0,
                "y": 0,
                "width": 304,
                "height": 100
              },
              "reasons": [
                "BY_CONFLICT",
                "BY_CONFLICT"
              ],
              "layout": {
                "flexDirection": "column",
                "justifyContent": "flex-start",
                "alignItems": "flex-start",
                "position": "relative",
                "width": 304,
                "height": 100,
                "margin": [
                  0,
                  null,
                  null,
                  0
                ],
                "alignSelf": "flex-start"
              },
              "children": [
                {
                  "name": "auto-merge",
                  "id": "g33",
                  "zIndex": 3,
                  "type": "group",
                  "raw": {
                    "name": "auto-merge",
                    "id": "g33",
                    "type": "group",
                    "zIndex": 3,
                    "dir": "column"
                  },
                  "frame": {
                    "x": 0,
                    "y": 0,
                    "width": 304,
                    "height": 100
                  },
                  "exactFrame": {
                    "x": 0,
                    "y": 0,
                    "width": 304,
                    "height": 100
                  },
                  "measured": {
                    "x": 0,
                    "y": 0,
                    "width": 304,
                    "height": 100
                  },
                  "reasons": [
                    "BY_IMAGE_AS_BACKGROUND",
                    "BY_IMAGE_AS_BACKGROUND"
                  ],
                  "layout": {
                    "flexDirection": "row",
                    "justifyContent": "flex-start",
                    "alignItems": "center",
                    "position": "relative",
                    "width": 304,
                    "height": 100,
                    "margin": [
                      0,
                      null,
                      null,
                      0
                    ],
                    "alignSelf": "flex-start"
                  },
                  "children": [
                    {
                      "name": "Bitmap",
                      "id": "i3",
                      "zIndex": 3,
                      "type": "image",
                      "raw": {
                        "name": "Bitmap",
                        "Id": 10,
                        "nameId": "D5FC39D1-727B-4E25-A593-C56915FA5BC0",
                        "type": "image",
                        "value": "https://gw.alicdn.com/tfs/TB1f9MmDbGYBuNjy0FoXXciBFXa-304-100.png",
                        "zIndex": 3,
                        "id": "i3"
                      },
                      "frame": {
                        "x": 0,
                        "y": 0,
                        "width": 304,
                        "height": 100
                      },
                      "exactFrame": {
                        "x": 0,
                        "y": 0,
                        "width": 304,
                        "height": 100
                      },
                      "measured": {
                        "x": 0,
                        "y": 0,
                        "width": 304,
                        "height": 100
                      },
                      "reasons": [
                        "BY_PRIMITIVE",
                        "BY_PRIMITIVE"
                      ],
                      "layout": {
                        "position": "absolute",
                        "width": 304,
                        "height": 100,
                        "left": 0,
                        "top": 0
                      },
                      "value": "https://gw.alicdn.com/tfs/TB1f9MmDbGYBuNjy0FoXXciBFXa-304-100.png",
                      "imageStyles": {
                        "resize": "stretch"
                      },
                      "clazz": {
                        "name": "w304-h100-background-i3",
                        "styles": {
                          "position": "absolute",
                          "width": "304px",
                          "height": "100px",
                          "left": 0,
                          "top": 0,
                          "resize": "stretch"
                        }
                      }
                    },
                    {
                      "name": "auto-merge",
                      "id": "g20",
                      "zIndex": 6,
                      "type": "group",
                      "raw": {
                        "name": "auto-merge",
                        "id": "g20",
                        "type": "group",
                        "zIndex": 6
                      },
                      "frame": {
                        "x": 20,
                        "y": 18,
                        "width": 112,
                        "height": 60
                      },
                      "exactFrame": {
                        "x": 20,
                        "y": 18,
                        "width": 112,
                        "height": 60
                      },
                      "measured": {
                        "x": 20,
                        "y": 18,
                        "width": 112,
                        "height": 60
                      },
                      "reasons": [
                        "BY_DEFAULT",
                        "BY_DEFAULT"
                      ],
                      "layout": {
                        "flexDirection": "column",
                        "justifyContent": "flex-start",
                        "alignItems": "center",
                        "padding": [
                          0,
                          0,
                          0,
                          0
                        ],
                        "position": "relative",
                        "margin": [
                          null,
                          null,
                          2,
                          20
                        ],
                        "alignSelf": "center"
                      },
                      "styles": {
                        "borderColor": "rgba(255,255,255,1)",
                        "borderStyle": "solid",
                        "borderWidth": 1,
                        "borderRadius": 6
                      },
                      "children": [
                        {
                          "name": "auto-merge",
                          "id": "g18",
                          "zIndex": 7,
                          "type": "group",
                          "raw": {
                            "name": "auto-merge",
                            "id": "g18",
                            "type": "group",
                            "zIndex": 7
                          },
                          "frame": {
                            "x": 20,
                            "y": 18,
                            "width": 112,
                            "height": 30
                          },
                          "exactFrame": {
                            "x": 20,
                            "y": 18,
                            "width": 112,
                            "height": 30
                          },
                          "measured": {
                            "x": 0,
                            "y": 0,
                            "width": 112,
                            "height": 30
                          },
                          "reasons": [
                            "BY_DEFAULT",
                            "BY_DEFAULT"
                          ],
                          "layout": {
                            "flexDirection": "column",
                            "justifyContent": "center",
                            "alignItems": "center",
                            "padding": [
                              1,
                              8.5,
                              1,
                              8
                            ],
                            "position": "relative",
                            "margin": [
                              0,
                              0,
                              null,
                              null
                            ],
                            "alignSelf": "center"
                          },
                          "styles": {
                            "backgroundColor": "rgba(255,255,255,1)",
                            "borderBottomLeftRadius": "0",
                            "borderBottomRightRadius": "0",
                            "borderTopLeftRadius": "6",
                            "borderTopRightRadius": "6"
                          },
                          "children": [
                            {
                              "name": "票数 3330",
                              "id": "t8",
                              "zIndex": 8,
                              "type": "text",
                              "raw": {
                                "name": "票数 3330",
                                "Id": 17,
                                "nameId": "56693B4C-B7A2-432A-9365-A0DA9650AF62",
                                "value": "票数 3330",
                                "type": "text",
                                "zIndex": 8,
                                "id": "t8"
                              },
                              "frame": {
                                "x": 28,
                                "y": 19,
                                "width": 95,
                                "height": 28
                              },
                              "exactFrame": {
                                "x": 28,
                                "y": 23,
                                "width": 95,
                                "height": 20
                              },
                              "measured": {
                                "x": 8,
                                "y": 1,
                                "width": 95,
                                "height": 28
                              },
                              "reasons": [
                                "BY_DEFAULT",
                                "BY_DEFAULT"
                              ],
                              "layout": {
                                "position": "relative",
                                "margin": [
                                  null,
                                  0.5,
                                  null,
                                  null
                                ],
                                "alignSelf": "center"
                              },
                              "value": "票数 3330",
                              "textStyles": {
                                "fontFamily": "PingFangSC-Regular",
                                "fontSize": 20,
                                "color": "#222222",
                                "lineHeight": 28,
                                "fontWeight": "normal"
                              },
                              "clazz": {
                                "name": "black-size20-t8",
                                "styles": {
                                  "position": "relative",
                                  "align-self": "center",
                                  "font-family": "PingFangSC-Regular",
                                  "font-size": 20,
                                  "color": "#222222",
                                  "line-height": "28px",
                                  "font-weight": "normal",
                                  "margin-right": "0.5px"
                                }
                              }
                            }
                          ],
                          "clazz": {
                            "name": "white-column-center-up-g18",
                            "styles": {
                              "flex-direction": "column",
                              "justify-content": "center",
                              "align-items": "center",
                              "position": "relative",
                              "align-self": "center",
                              "background-color": "rgba(255,255,255,1)",
                              "border-bottom-left-radius": "0",
                              "border-bottom-right-radius": "0",
                              "border-top-left-radius": "6",
                              "border-top-right-radius": "6",
                              "padding-top": "1px",
                              "padding-right": "8.5px",
                              "padding-bottom": "1px",
                              "padding-left": "8px",
                              "margin-top": "0px",
                              "margin-right": "0px"
                            }
                          }
                        },
                        {
                          "name": "排名 287",
                          "id": "t9",
                          "zIndex": 9,
                          "type": "text",
                          "raw": {
                            "name": "排名 287",
                            "Id": 18,
                            "nameId": "131863EF-6DC0-45AB-9F4D-A44ED77AAC4F",
                            "value": "排名 287",
                            "type": "text",
                            "zIndex": 9,
                            "id": "t9"
                          },
                          "frame": {
                            "x": 35,
                            "y": 48,
                            "width": 82,
                            "height": 28
                          },
                          "exactFrame": {
                            "x": 35,
                            "y": 52,
                            "width": 82,
                            "height": 20
                          },
                          "measured": {
                            "x": 15,
                            "y": 30,
                            "width": 82,
                            "height": 28
                          },
                          "reasons": [
                            "BY_DEFAULT",
                            "BY_DEFAULT"
                          ],
                          "layout": {
                            "position": "relative",
                            "margin": [
                              0,
                              0,
                              2,
                              null
                            ],
                            "alignSelf": "center"
                          },
                          "value": "排名 287",
                          "textStyles": {
                            "fontFamily": "PingFangSC-Regular",
                            "fontSize": 20,
                            "color": "#FFFFFF",
                            "lineHeight": 28,
                            "fontWeight": "normal"
                          },
                          "clazz": {
                            "name": "white-size20-down-t9",
                            "styles": {
                              "position": "relative",
                              "align-self": "center",
                              "font-family": "PingFangSC-Regular",
                              "font-size": 20,
                              "color": "#FFFFFF",
                              "line-height": "28px",
                              "font-weight": "normal",
                              "margin-top": "0px",
                              "margin-right": "0px",
                              "margin-bottom": "2px"
                            }
                          }
                        }
                      ],
                      "clazz": {
                        "name": "white-column-flex-start-g20",
                        "styles": {
                          "flex-direction": "column",
                          "justify-content": "flex-start",
                          "align-items": "center",
                          "position": "relative",
                          "align-self": "center",
                          "border-color": "rgba(255,255,255,1)",
                          "border-style": "solid",
                          "border-width": 1,
                          "border-radius": 6,
                          "padding-top": "0px",
                          "padding-right": "0px",
                          "padding-bottom": "0px",
                          "padding-left": "0px",
                          "margin-bottom": "2px",
                          "margin-left": "20px"
                        }
                      }
                    }
                  ],
                  "clazz": {
                    "name": "row-flex-start-w304-h100-g33",
                    "styles": {
                      "flex-direction": "row",
                      "justify-content": "flex-start",
                      "align-items": "center",
                      "position": "relative",
                      "width": "304px",
                      "height": "100px",
                      "align-self": "flex-start",
                      "margin-top": "0px",
                      "margin-left": "0px"
                    }
                  }
                },
                {
                  "name": "Bitmap Copy",
                  "id": "i4",
                  "zIndex": 4,
                  "type": "image",
                  "raw": {
                    "name": "Bitmap Copy",
                    "Id": 11,
                    "nameId": "68980BF4-2C48-43E0-96DF-4F52C92549E1",
                    "type": "image",
                    "value": "https://gw.alicdn.com/tfs/TB1NeAtDXOWBuNjy0FiXXXFxVXa-60-74.png",
                    "zIndex": 4,
                    "id": "i4"
                  },
                  "frame": {
                    "x": 224,
                    "y": 1,
                    "width": 60,
                    "height": 74
                  },
                  "exactFrame": {
                    "x": 224,
                    "y": 1,
                    "width": 60,
                    "height": 74
                  },
                  "measured": {
                    "x": 224,
                    "y": 1,
                    "width": 60,
                    "height": 74
                  },
                  "reasons": [
                    "BY_PRIMITIVE",
                    "BY_PRIMITIVE"
                  ],
                  "layout": {
                    "position": "absolute",
                    "width": 60,
                    "height": 74,
                    "right": 20,
                    "top": 1
                  },
                  "value": "https://gw.alicdn.com/tfs/TB1NeAtDXOWBuNjy0FiXXXFxVXa-60-74.png",
                  "imageStyles": {
                    "resize": "stretch"
                  },
                  "clazz": {
                    "name": "w60-h74-absolute-i4",
                    "styles": {
                      "position": "absolute",
                      "width": "60px",
                      "height": "74px",
                      "right": 20,
                      "top": 1,
                      "resize": "stretch"
                    }
                  }
                }
              ],
              "clazz": {
                "name": "column-flex-start-w304-h100-up-g34",
                "styles": {
                  "flex-direction": "column",
                  "justify-content": "flex-start",
                  "align-items": "flex-start",
                  "position": "relative",
                  "width": "304px",
                  "height": "100px",
                  "align-self": "flex-start",
                  "margin-top": "0px",
                  "margin-left": "0px"
                }
              }
            },
            {
              "name": "auto-merge",
              "id": "g27",
              "zIndex": 5,
              "type": "group",
              "raw": {
                "name": "auto-merge",
                "id": "g27",
                "type": "group",
                "zIndex": 5
              },
              "frame": {
                "x": 0,
                "y": 204,
                "width": 304,
                "height": 100
              },
              "exactFrame": {
                "x": 0,
                "y": 204,
                "width": 304,
                "height": 100
              },
              "measured": {
                "x": 0,
                "y": 204,
                "width": 304,
                "height": 100
              },
              "reasons": [
                "BY_IMAGE_AS_BACKGROUND",
                "BY_IMAGE_AS_BACKGROUND"
              ],
              "layout": {
                "flexDirection": "row",
                "justifyContent": "flex-start",
                "alignItems": "center",
                "position": "relative",
                "width": 304,
                "height": 100,
                "margin": [
                  104,
                  null,
                  0,
                  0
                ],
                "alignSelf": "flex-start"
              },
              "children": [
                {
                  "name": "Bitmap",
                  "id": "i5",
                  "zIndex": 5,
                  "type": "image",
                  "raw": {
                    "name": "Bitmap",
                    "Id": 12,
                    "nameId": "BA6025F1-EED4-4119-85C7-F8C4FFD44BFA",
                    "type": "image",
                    "value": "https://gw.alicdn.com/tfs/TB1mLZVDh9YBuNjy0FfXXXIsVXa-304-100.png",
                    "zIndex": 5,
                    "id": "i5"
                  },
                  "frame": {
                    "x": 0,
                    "y": 204,
                    "width": 304,
                    "height": 100
                  },
                  "exactFrame": {
                    "x": 0,
                    "y": 204,
                    "width": 304,
                    "height": 100
                  },
                  "measured": {
                    "x": 0,
                    "y": 0,
                    "width": 304,
                    "height": 100
                  },
                  "reasons": [
                    "BY_PRIMITIVE",
                    "BY_PRIMITIVE"
                  ],
                  "layout": {
                    "position": "absolute",
                    "width": 304,
                    "height": 100,
                    "left": 0,
                    "top": 0
                  },
                  "value": "https://gw.alicdn.com/tfs/TB1mLZVDh9YBuNjy0FfXXXIsVXa-304-100.png",
                  "imageStyles": {
                    "resize": "stretch"
                  },
                  "clazz": {
                    "name": "w304-h100-background-i5",
                    "styles": {
                      "position": "absolute",
                      "width": "304px",
                      "height": "100px",
                      "left": 0,
                      "top": 0,
                      "resize": "stretch"
                    }
                  }
                },
                {
                  "name": "auto-merge",
                  "id": "g26",
                  "zIndex": 13,
                  "type": "group",
                  "raw": {
                    "name": "auto-merge",
                    "id": "g26",
                    "type": "group",
                    "zIndex": 13,
                    "dir": "row"
                  },
                  "frame": {
                    "x": 20,
                    "y": 225,
                    "width": 261,
                    "height": 63
                  },
                  "exactFrame": {
                    "x": 20,
                    "y": 228,
                    "width": 261,
                    "height": 56
                  },
                  "measured": {
                    "x": 20,
                    "y": 21,
                    "width": 261,
                    "height": 63
                  },
                  "reasons": [
                    "BY_DEFAULT",
                    "BY_DEFAULT"
                  ],
                  "layout": {
                    "flexDirection": "row",
                    "justifyContent": "flex-start",
                    "alignItems": "center",
                    "padding": [
                      0,
                      0,
                      0,
                      0
                    ],
                    "position": "relative",
                    "margin": [
                      2.5,
                      null,
                      null,
                      20
                    ],
                    "alignSelf": "center"
                  },
                  "children": [
                    {
                      "name": "Bitmap",
                      "id": "i13",
                      "zIndex": 13,
                      "type": "image",
                      "raw": {
                        "name": "Bitmap",
                        "Id": 22,
                        "nameId": "88751A7C-D6E6-42AA-9E8A-1C724F5E8F56",
                        "type": "image",
                        "value": "https://gw.alicdn.com/tfs/TB1FfZVDh9YBuNjy0FfXXXIsVXa-56-56.png",
                        "zIndex": 13,
                        "id": "i13"
                      },
                      "frame": {
                        "x": 20,
                        "y": 228,
                        "width": 56,
                        "height": 56
                      },
                      "exactFrame": {
                        "x": 20,
                        "y": 228,
                        "width": 56,
                        "height": 56
                      },
                      "measured": {
                        "x": 0,
                        "y": 3,
                        "width": 56,
                        "height": 56
                      },
                      "reasons": [
                        "BY_PRIMITIVE",
                        "BY_PRIMITIVE"
                      ],
                      "layout": {
                        "position": "relative",
                        "width": 56,
                        "height": 56,
                        "margin": [
                          null,
                          null,
                          0.5,
                          0
                        ],
                        "alignSelf": "center"
                      },
                      "value": "https://gw.alicdn.com/tfs/TB1FfZVDh9YBuNjy0FfXXXIsVXa-56-56.png",
                      "imageStyles": {
                        "resize": "stretch"
                      },
                      "clazz": {
                        "name": "w56-h56-left-i13",
                        "styles": {
                          "position": "relative",
                          "width": "56px",
                          "height": "56px",
                          "align-self": "center",
                          "resize": "stretch",
                          "margin-bottom": "0.5px",
                          "margin-left": "0px"
                        }
                      }
                    },
                    {
                      "name": "auto-merge",
                      "id": "g25",
                      "zIndex": 14,
                      "type": "group",
                      "raw": {
                        "name": "auto-merge",
                        "id": "g25",
                        "type": "group",
                        "zIndex": 14,
                        "dir": "column"
                      },
                      "frame": {
                        "x": 86,
                        "y": 225,
                        "width": 195,
                        "height": 63
                      },
                      "exactFrame": {
                        "x": 86,
                        "y": 229,
                        "width": 195,
                        "height": 55
                      },
                      "measured": {
                        "x": 66,
                        "y": 0,
                        "width": 195,
                        "height": 63
                      },
                      "reasons": [
                        "BY_DEFAULT",
                        "BY_DEFAULT"
                      ],
                      "layout": {
                        "flexDirection": "column",
                        "justifyContent": "flex-start",
                        "alignItems": "flex-start",
                        "padding": [
                          0,
                          0,
                          0,
                          0
                        ],
                        "position": "relative",
                        "margin": [
                          null,
                          0,
                          0,
                          10
                        ],
                        "alignSelf": "center"
                      },
                      "children": [
                        {
                          "name": "auto-merge",
                          "id": "g24",
                          "zIndex": 14,
                          "type": "group",
                          "raw": {
                            "name": "auto-merge",
                            "id": "g24",
                            "type": "group",
                            "zIndex": 14,
                            "dir": "row"
                          },
                          "frame": {
                            "x": 86,
                            "y": 225,
                            "width": 195,
                            "height": 33
                          },
                          "exactFrame": {
                            "x": 86,
                            "y": 229,
                            "width": 195,
                            "height": 25
                          },
                          "measured": {
                            "x": 0,
                            "y": 0,
                            "width": 195,
                            "height": 33
                          },
                          "reasons": [
                            "BY_DEFAULT",
                            "BY_DEFAULT"
                          ],
                          "layout": {
                            "flexDirection": "row",
                            "justifyContent": "flex-start",
                            "alignItems": "center",
                            "padding": [
                              0,
                              0,
                              0,
                              0
                            ],
                            "position": "relative",
                            "margin": [
                              0,
                              0,
                              null,
                              0
                            ],
                            "alignSelf": "flex-start"
                          },
                          "children": [
                            {
                              "name": "淘大王池",
                              "id": "t14",
                              "zIndex": 14,
                              "type": "text",
                              "raw": {
                                "name": "淘大王池",
                                "Id": 23,
                                "nameId": "CF9C2145-AEA5-406B-95DE-476D5549C0F2",
                                "value": "淘大王池",
                                "type": "text",
                                "zIndex": 14,
                                "id": "t14"
                              },
                              "frame": {
                                "x": 86,
                                "y": 225,
                                "width": 96,
                                "height": 33
                              },
                              "exactFrame": {
                                "x": 86,
                                "y": 230,
                                "width": 96,
                                "height": 24
                              },
                              "measured": {
                                "x": 0,
                                "y": 0,
                                "width": 96,
                                "height": 33
                              },
                              "reasons": [
                                "BY_DEFAULT",
                                "BY_DEFAULT"
                              ],
                              "layout": {
                                "position": "relative",
                                "margin": [
                                  null,
                                  null,
                                  0,
                                  0
                                ],
                                "alignSelf": "center"
                              },
                              "value": "淘大王池",
                              "textStyles": {
                                "fontFamily": "PingFangSC-Medium",
                                "fontSize": 24,
                                "color": "#FFFFFF",
                                "lineHeight": 33,
                                "fontWeight": "bold"
                              },
                              "clazz": {
                                "name": "white-size24-left-t14",
                                "styles": {
                                  "position": "relative",
                                  "align-self": "center",
                                  "font-family": "PingFangSC-Medium",
                                  "font-size": 24,
                                  "color": "#FFFFFF",
                                  "line-height": "33px",
                                  "font-weight": "bold",
                                  "margin-bottom": "0px",
                                  "margin-left": "0px"
                                }
                              }
                            },
                            {
                              "name": "我参赛的",
                              "id": "t17",
                              "zIndex": 17,
                              "type": "text",
                              "raw": {
                                "name": "我参赛的",
                                "Id": 26,
                                "nameId": "CE214AF0-ED16-4EE8-B0B0-A3967A264509",
                                "value": "我参赛的",
                                "type": "text",
                                "zIndex": 17,
                                "id": "t17"
                              },
                              "frame": {
                                "x": 191,
                                "y": 226,
                                "width": 90,
                                "height": 28
                              },
                              "exactFrame": {
                                "x": 196,
                                "y": 230,
                                "width": 80,
                                "height": 20
                              },
                              "measured": {
                                "x": 105,
                                "y": 1,
                                "width": 90,
                                "height": 28
                              },
                              "reasons": [
                                "BY_DEFAULT",
                                "BY_DEFAULT",
                                "BY_DEFAULT",
                                "BY_DEFAULT"
                              ],
                              "layout": {
                                "padding": [
                                  0,
                                  5,
                                  0,
                                  5
                                ],
                                "position": "relative",
                                "margin": [
                                  null,
                                  0,
                                  1.5,
                                  9
                                ],
                                "alignSelf": "center"
                              },
                              "value": "我参赛的",
                              "textStyles": {
                                "fontFamily": "PingFangSC-Regular",
                                "fontSize": 20,
                                "color": "#FFFFFF",
                                "lineHeight": 24,
                                "fontWeight": "normal"
                              },
                              "styles": {
                                "backgroundColor": "rgba(255,34,34,1)",
                                "borderRadius": 4
                              },
                              "clazz": {
                                "name": "white-size20-right-t17",
                                "styles": {
                                  "position": "relative",
                                  "align-self": "center",
                                  "background-color": "rgba(255,34,34,1)",
                                  "border-radius": 4,
                                  "font-family": "PingFangSC-Regular",
                                  "font-size": 20,
                                  "color": "#FFFFFF",
                                  "line-height": "24px",
                                  "font-weight": "normal",
                                  "padding-top": "0px",
                                  "padding-right": "5px",
                                  "padding-bottom": "0px",
                                  "padding-left": "5px",
                                  "margin-right": "0px",
                                  "margin-bottom": "1.5px",
                                  "margin-left": "9px"
                                }
                              }
                            }
                          ],
                          "clazz": {
                            "name": "row-flex-start-up-g24",
                            "styles": {
                              "flex-direction": "row",
                              "justify-content": "flex-start",
                              "align-items": "center",
                              "position": "relative",
                              "align-self": "flex-start",
                              "padding-top": "0px",
                              "padding-right": "0px",
                              "padding-bottom": "0px",
                              "padding-left": "0px",
                              "margin-top": "0px",
                              "margin-right": "0px",
                              "margin-left": "0px"
                            }
                          }
                        },
                        {
                          "name": "漫威复仇者集中营",
                          "id": "t15",
                          "zIndex": 15,
                          "type": "text",
                          "raw": {
                            "name": "漫威复仇者集中营",
                            "Id": 24,
                            "nameId": "5CE45B23-65E7-4C22-A971-3C94F75C59BF",
                            "value": "漫威复仇者集中营",
                            "type": "text",
                            "zIndex": 15,
                            "id": "t15"
                          },
                          "frame": {
                            "x": 88,
                            "y": 260,
                            "width": 160,
                            "height": 28
                          },
                          "exactFrame": {
                            "x": 88,
                            "y": 264,
                            "width": 160,
                            "height": 20
                          },
                          "measured": {
                            "x": 2,
                            "y": 35,
                            "width": 160,
                            "height": 28
                          },
                          "reasons": [
                            "BY_DEFAULT",
                            "BY_DEFAULT"
                          ],
                          "layout": {
                            "position": "relative",
                            "margin": [
                              2,
                              33,
                              0,
                              2
                            ],
                            "alignSelf": "flex-start"
                          },
                          "value": "漫威复仇者集中营",
                          "textStyles": {
                            "fontFamily": "PingFangSC-Regular",
                            "fontSize": 20,
                            "color": "#FFDA44",
                            "lineHeight": 28,
                            "fontWeight": "normal"
                          },
                          "clazz": {
                            "name": "yellow-size20-down-t15",
                            "styles": {
                              "position": "relative",
                              "align-self": "flex-start",
                              "font-family": "PingFangSC-Regular",
                              "font-size": 20,
                              "color": "#FFDA44",
                              "line-height": "28px",
                              "font-weight": "normal",
                              "margin-top": "2px",
                              "margin-right": "33px",
                              "margin-bottom": "0px",
                              "margin-left": "2px"
                            }
                          }
                        }
                      ],
                      "clazz": {
                        "name": "column-flex-start-right-g25",
                        "styles": {
                          "flex-direction": "column",
                          "justify-content": "flex-start",
                          "align-items": "flex-start",
                          "position": "relative",
                          "align-self": "center",
                          "padding-top": "0px",
                          "padding-right": "0px",
                          "padding-bottom": "0px",
                          "padding-left": "0px",
                          "margin-right": "0px",
                          "margin-bottom": "0px",
                          "margin-left": "10px"
                        }
                      }
                    }
                  ],
                  "clazz": {
                    "name": "row-flex-start-g26",
                    "styles": {
                      "flex-direction": "row",
                      "justify-content": "flex-start",
                      "align-items": "center",
                      "position": "relative",
                      "align-self": "center",
                      "padding-top": "0px",
                      "padding-right": "0px",
                      "padding-bottom": "0px",
                      "padding-left": "0px",
                      "margin-top": "2.5px",
                      "margin-left": "20px"
                    }
                  }
                }
              ],
              "clazz": {
                "name": "row-flex-start-w304-h100-down-g27",
                "styles": {
                  "flex-direction": "row",
                  "justify-content": "flex-start",
                  "align-items": "center",
                  "position": "relative",
                  "width": "304px",
                  "height": "100px",
                  "align-self": "flex-start",
                  "margin-top": "104px",
                  "margin-bottom": "0px",
                  "margin-left": "0px"
                }
              }
            }
          ],
          "clazz": {
            "name": "column-flex-start-w304-g28",
            "styles": {
              "flex-direction": "column",
              "justify-content": "flex-start",
              "align-items": "flex-start",
              "position": "relative",
              "width": "304px",
              "align-self": "flex-start",
              "padding-top": "0px",
              "padding-bottom": "0px",
              "margin-top": "0px",
              "margin-left": "0px"
            }
          }
        }
      ],
      "clazz": {
        "name": "ltgray-column-flex-start-w304-h304-g29",
        "styles": {
          "flex-direction": "column",
          "justify-content": "flex-start",
          "align-items": "flex-start",
          "position": "relative",
          "width": "304px",
          "height": "304px",
          "align-self": "center",
          "background-color": "rgba(216,216,216,1)",
          "border-bottom-left-radius": "0",
          "border-bottom-right-radius": "0",
          "border-top-left-radius": "10",
          "border-top-right-radius": "10",
          "margin-top": "0px",
          "margin-right": "0px"
        }
      }
    },
    {
      "name": "钢铁侠全球限量款手办全球限量款40台…",
      "id": "t10",
      "zIndex": 10,
      "type": "text",
      "raw": {
        "name": "钢铁侠全球限量款手办全球限量款40台…",
        "Id": 19,
        "nameId": "1C7E3033-AD8B-404F-8EBA-725BE410F1F8",
        "value": "钢铁侠全球限量款手办全球限量款40台…",
        "type": "text",
        "zIndex": 10,
        "id": "t10"
      },
      "frame": {
        "x": 20,
        "y": 317,
        "width": 264,
        "height": 80
      },
      "exactFrame": {
        "x": 20,
        "y": 323,
        "width": 264,
        "height": 68
      },
      "measured": {
        "x": 20,
        "y": 317,
        "width": 264,
        "height": 80
      },
      "reasons": [
        "BY_TEXT",
        "BY_DEFAULT"
      ],
      "layout": {
        "position": "relative",
        "width": 264,
        "margin": [
          13,
          0,
          null,
          null
        ],
        "alignSelf": "center"
      },
      "value": "钢铁侠全球限量款手办全球限量款40台…",
      "textStyles": {
        "fontFamily": "PingFangSC-Medium",
        "fontSize": 28,
        "color": "#222222",
        "lineHeight": 40,
        "textAlign": "left",
        "fontWeight": "bold"
      },
      "clazz": {
        "name": "black-size28-w264-t10",
        "styles": {
          "position": "relative",
          "width": "264px",
          "align-self": "center",
          "font-family": "PingFangSC-Medium",
          "font-size": 28,
          "color": "#222222",
          "line-height": "40px",
          "text-align": "left",
          "font-weight": "bold",
          "margin-top": "13px",
          "margin-right": "0px"
        }
      }
    },
    {
      "name": "auto-merge",
      "id": "g31",
      "zIndex": 11,
      "type": "group",
      "raw": {
        "name": "auto-merge",
        "id": "g31",
        "type": "group",
        "zIndex": 11
      },
      "frame": {
        "x": 20,
        "y": 414,
        "width": 264,
        "height": 54
      },
      "exactFrame": {
        "x": 20,
        "y": 414,
        "width": 264,
        "height": 54
      },
      "measured": {
        "x": 20,
        "y": 414,
        "width": 264,
        "height": 54
      },
      "reasons": [
        "BY_IMAGE_AS_BACKGROUND",
        "BY_IMAGE_AS_BACKGROUND"
      ],
      "layout": {
        "flexDirection": "column",
        "justifyContent": "center",
        "alignItems": "center",
        "position": "relative",
        "width": 264,
        "height": 54,
        "margin": [
          17,
          0,
          20,
          null
        ],
        "alignSelf": "center"
      },
      "children": [
        {
          "name": "Bitmap",
          "id": "i11",
          "zIndex": 11,
          "type": "image",
          "raw": {
            "name": "Bitmap",
            "Id": 20,
            "nameId": "EDF359F5-9CD2-4E0B-9F53-8F006D0F5FC1",
            "type": "image",
            "value": "https://gw.alicdn.com/tfs/TB1rCquDqmWBuNjy1XaXXXCbXXa-264-54.png",
            "zIndex": 11,
            "id": "i11"
          },
          "frame": {
            "x": 20,
            "y": 414,
            "width": 264,
            "height": 54
          },
          "exactFrame": {
            "x": 20,
            "y": 414,
            "width": 264,
            "height": 54
          },
          "measured": {
            "x": 0,
            "y": 0,
            "width": 264,
            "height": 54
          },
          "reasons": [
            "BY_PRIMITIVE",
            "BY_PRIMITIVE"
          ],
          "layout": {
            "position": "absolute",
            "width": 264,
            "height": 54,
            "left": 0,
            "top": 0
          },
          "value": "https://gw.alicdn.com/tfs/TB1rCquDqmWBuNjy1XaXXXCbXXa-264-54.png",
          "imageStyles": {
            "resize": "stretch"
          },
          "clazz": {
            "name": "w264-h54-background-i11",
            "styles": {
              "position": "absolute",
              "width": "264px",
              "height": "54px",
              "left": 0,
              "top": 0,
              "resize": "stretch"
            }
          }
        },
        {
          "name": "投票分2亿",
          "id": "t12",
          "zIndex": 12,
          "type": "text",
          "raw": {
            "name": "投票分2亿",
            "Id": 21,
            "nameId": "7B659904-1836-48B7-B38A-2B864AF11EBF",
            "value": "投票分2亿",
            "type": "text",
            "zIndex": 12,
            "id": "t12"
          },
          "frame": {
            "x": 90,
            "y": 421,
            "width": 129,
            "height": 40
          },
          "exactFrame": {
            "x": 90,
            "y": 427,
            "width": 129,
            "height": 28
          },
          "measured": {
            "x": 70,
            "y": 7,
            "width": 129,
            "height": 40
          },
          "reasons": [
            "BY_DEFAULT",
            "BY_DEFAULT"
          ],
          "layout": {
            "position": "relative",
            "margin": [
              null,
              null,
              null,
              2.5
            ],
            "alignSelf": "center"
          },
          "value": "投票分2亿",
          "textStyles": {
            "fontFamily": "PingFangSC-Medium",
            "fontSize": 28,
            "color": "#925715",
            "lineHeight": 40,
            "fontWeight": "bold"
          },
          "clazz": {
            "name": "gray-size28-t12",
            "styles": {
              "position": "relative",
              "align-self": "center",
              "font-family": "PingFangSC-Medium",
              "font-size": 28,
              "color": "#925715",
              "line-height": "40px",
              "font-weight": "bold",
              "margin-left": "2.5px"
            }
          }
        }
      ],
      "clazz": {
        "name": "column-center-w264-h54-g31",
        "styles": {
          "flex-direction": "column",
          "justify-content": "center",
          "align-items": "center",
          "position": "relative",
          "width": "264px",
          "height": "54px",
          "align-self": "center",
          "margin-top": "17px",
          "margin-right": "0px",
          "margin-bottom": "20px"
        }
      }
    }
  ],
  "clazz": {
    "name": "white-column-flex-start-w304-g32",
    "styles": {
      "flex-direction": "column",
      "justify-content": "flex-start",
      "align-items": "center",
      "position": "relative",
      "width": "304px",
      "background-color": "rgba(255,255,255,1)",
      "padding-top": "0px",
      "padding-bottom": "0px"
    }
  }
}