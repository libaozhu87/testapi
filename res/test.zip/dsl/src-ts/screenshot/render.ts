import * as path from 'path'
import * as fs from 'fs'
import { createCanvas, Image as Img, registerFont } from 'canvas'
import * as Request from 'pixl-request'

import { InputNode } from './../define/input-node'
import { Node, Group, Text, Shape, Image, NodeType } from './../define/node'
import { Styles, TextStyles } from './../define/styles'
import { Frame } from './../define/frame'
import { Async } from './../primitive/Async'
import flatten from './../primitive/flatten'
import compact from './../primitive/compact'

import { TOP_INDEX, RIGHT_INDEX, BOTTOM_INDEX, LEFT_INDEX, LayoutUtil } from './../core/layout-util'
import { FrameUtil } from './../core/frame-util'

declare var __dirname

const request = new Request()
registerFont(path.resolve(__dirname, './../../PingFang-SC.ttf'), { family: 'PingFangSC' })

function drawShape(ctx, styles: Styles, frame: Frame): Async {
  const raw = () => {
    if (!styles) {
      return
    }

    const { x, y, width, height } = frame
    const radius = Math.min(styles.borderRadius || 0, Math.min(width, height) / 2)
    const fillColor = styles.backgroundColor
    const strokeColor = styles.borderColor
    //arcTo
    ctx.beginPath()
    ctx.moveTo(x + radius, y)
    ctx.lineTo(x + width - radius, y)
    ctx.arcTo(x + width, y, x + width, y + radius, radius)
    ctx.lineTo(x + width, y + height - radius)
    ctx.arcTo(x + width, y + height, x + width - radius, y + height, radius)
    ctx.lineTo(x + radius, y + height)
    ctx.arcTo(x, y + height, x, y + height - radius, radius)
    ctx.lineTo(x, y + radius)
    ctx.arcTo(x, y, x + radius, y, radius)
    ctx.closePath()

    ctx.lineWidth = styles.borderWidth || 1

    if (strokeColor !== undefined) {
      ctx.strokeStyle = strokeColor
      ctx.stroke()
    }

    if (fillColor !== undefined) {
      ctx.fillStyle = fillColor
      ctx.fill()
    }
  }

  return new Async().action(raw)
}

function breakline(ctx, line: string, width: number): string[] {
  if (ctx.measureText(line).width <= width) {
    return [line]
  } else {
    const lines = []
    let lastIndex = 0
    for (let i = 1; i < line.length; i++) {
      const prev = line.substring(lastIndex, i)
      const next = line.substring(lastIndex, i + 1)
      if (ctx.measureText(prev).width <= width && ctx.measureText(next).width > width) {
        lines.push(prev)
        lastIndex = i
      }
    }

    lines.push(line.substring(lastIndex))

    return lines
  }
}

function drawText(ctx, text: string, textStyles: TextStyles, frame: Frame): Async {
  // const draw
  const raw = () => {
    const isMultiLines: boolean = frame.height > textStyles.lineHeight * 1.5
    const { x, y, width, height } = frame

    ctx.fillStyle = textStyles.color
    ctx.font = `${textStyles.fontStyle} ${textStyles.fontSize}px PingFangSC`
    ctx.textBaseline = 'middle'

    if (isMultiLines) {
      const ls = text.split('\n').map(line => breakline(ctx, line, width))
      const lines: string[] = compact(flatten(ls))
      let offset = (height - (lines.length - 1) * textStyles.lineHeight) / 2
      for (const line of lines) {
        ctx.fillText(line, x, y + offset)
        offset += textStyles.lineHeight
      }
    } else {
      ctx.fillText(text, x, y + height / 2)
    }
  }
  return new Async().action(raw)
}

// let id = 0
// { download: `cache/tmp/${id++}.jpg` },
function drawImage(ctx, url, frame: Frame): Async {
  return new Async().then((v, next) => {
    request.get(url, (err, resp, data) => {
      if (err) {
        next.error(err)
      }
      const img = new Img()
      img.src = data
      const { x, y, width, height } = frame
      ctx.drawImage(img, x, y, width, height)

      next.next(true)
    })
  })
}

function applanate(node: Node): Node[] {
  if (node.type === NodeType.GROUP) {
    const group = node as Group
    return [node].concat(group.children.reduce((pre, cur) => pre.concat(applanate(cur)), []))
  } else {
    return [node]
  }
}

export function renderDSL(node: Node, path: string): Async {
  const { width, height } = node.measured

  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext('2d')

  const { x, y } = node.frame
  const offset = { x: -x, y: -y }

  const nodes = applanate(node)
  const workers = compact(
    flatten(
      nodes.map(child => {
        const { type } = child
        if (type === NodeType.GROUP) {
          const group = child as Group
          return [drawShape(ctx, group.styles, FrameUtil.translate(group.frame, offset))]
        } else if (type === NodeType.SHAPE) {
          const shape = child as Shape
          return [drawShape(ctx, shape.styles, FrameUtil.translate(shape.frame, offset))]
        } else if (type === NodeType.TEXT) {
          const text = child as Text

          // text.layout.padding
          const pl = LayoutUtil.getPadding(text.layout, LEFT_INDEX) || 0
          const pr = LayoutUtil.getPadding(text.layout, RIGHT_INDEX) || 0
          const pt = LayoutUtil.getPadding(text.layout, TOP_INDEX) || 0
          const pb = LayoutUtil.getPadding(text.layout, BOTTOM_INDEX) || 0

          const { x, y, width, height } = text.frame

          return [
            drawShape(ctx, text.styles, FrameUtil.translate(text.frame, offset)),
            drawText(
              ctx,
              text.value,
              text.textStyles,
              FrameUtil.translate({ x: x + pl, y: y + pt, width: width - pl - pr, height: height - pt - pb }, offset)
            )
          ]
        } else if (type === NodeType.IMAGE) {
          const image = child as Image
          return [drawImage(ctx, image.value, FrameUtil.translate(image.frame, offset))]
        } else {
          throw new Error(`${type}`)
        }
      })
    )
  )

  return new Async().sequence(...workers).action(() => flush(canvas, path))
}

export function renderInput(root: InputNode, nodes: InputNode[], path: string): Async {
  const { x, y, width, height } = root.frame
  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext('2d')

  const offset = { x: -x, y: -y }

  const workers = compact(
    flatten(
      [root, ...nodes].map(child => {
        const { type } = child
        if (type === NodeType.GROUP) {
          return [drawShape(ctx, child.styles, FrameUtil.translate(child.frame, offset))]
        } else if (type === NodeType.SHAPE) {
          return [drawShape(ctx, child.styles, FrameUtil.translate(child.frame, offset))]
        } else if (type === NodeType.TEXT) {
          return [drawText(ctx, child.value, child.textStyles, FrameUtil.translate(child.frame, offset))]
        } else if (type === NodeType.IMAGE) {
          return [drawImage(ctx, child.value, FrameUtil.translate(child.frame, offset))]
        } else {
          throw new Error(`${type}`)
        }
      })
    )
  )

  return new Async().sequence(...workers).action(() => flush(canvas, path))
}

export function renderElements(root: Node, dir: string): Async[] {
  const stack: Node[] = [root]
  const array: Node[] = []
  while (stack.length > 0) {
    const top = stack.pop()
    if (top.type === NodeType.GROUP) {
      stack.push(...(top as Group).children)
    }
    array.push(top)
  }

  return array.map(node => renderDSL(node, `${dir}/${node.id}.png`))
}

const COLORS = {
  [NodeType.GROUP]: '#f8f8f8',
  [NodeType.TEXT]: '#f0f0f0',
  [NodeType.IMAGE]: '#e8e8e8',
  [NodeType.SHAPE]: '#f0f0f0'
}

function sslStle(type: NodeType): Styles {
  return {
    opacity: undefined,
    borderRadius: undefined,
    borderStyle: undefined,
    borderWidth: undefined,
    borderColor: undefined,
    backgroundImage: undefined,
    backgroundColor: COLORS[type]
  }
}

export function toSkeletonScreenLoadingDSL(node: Node): Node {
  const { type } = node
  let result
  if (type === NodeType.GROUP) {
    const group = { ...node }
    group.children = group.children.map(toSkeletonScreenLoadingDSL)
    group.styles = sslStle(type)
    result = group
  } else {
    result = { ...node, styles: sslStle(type), type: NodeType.SHAPE }
  }

  //fix
  result.layout = { ...result.layout, width: result.measured.width, height: result.measured.height }
  return result
}

export function renderSkeletonScreenLoading(node: Node, path: string): Async {
  const sslDSL = toSkeletonScreenLoadingDSL(node)
  return renderDSL(sslDSL, path)
}

function flush(canvas, fileName: string) {
  const out = fs.createWriteStream(path.resolve(fileName))
  const stream = canvas.pngStream()

  stream.pipe(out)

  out.on('finish', () => {
    console.log(`The PNG file ${fileName} was created.`)
  })
}
