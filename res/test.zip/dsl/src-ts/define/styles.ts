export interface Styles {
  opacity: number //透明度 [0-1]
  //border
  borderRadius: number //圆角半径

  borderStyle: string //solid,dashed,dotted,
  borderWidth: number //描边粗细
  borderColor: string //描边颜色
  //background
  backgroundColor: string //纯色
  backgroundImage: string //线性渐变
}

export interface TextStyles {
  lines: number //描述最大行数，可选项
  maxWidth: number //描述最大行宽，可选项
  maxHeight: number //描述最大高度，可选项
  color: string //描述字体颜色，如 #ff00ff (rgb)
  fontSize: number //描述字体大小，如 #ff00ff (rgb)
  fontStyle: string //normal, italic, bold
  fontWeight: string //描述字体厚度，可选项
  lineHeight: number //描述每行高度，可选项
  textDecoration: string //overline,line-through,underline,blink
  textAlign: string //left, center, right
  fontFamily: string //描述字体类型，如 PingFangSC
  textOverflow: string //clip, ellipsis
}

export interface ImageStyles {
  resize: string //cover,contain,stretch default is stretch
}
