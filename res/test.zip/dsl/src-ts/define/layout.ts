import { FlexDirection, JustifyContent, AlignItems, PositionType, Transform } from './flex-type'

export interface Layout {
  //for children
  //方向
  flexDirection: FlexDirection
  //对齐方式
  justifyContent: JustifyContent //start-end, end-start, center
  alignItems: AlignItems // option disable

  padding: number[]

  position: PositionType

  width: number //option 如果给了就是 fixed-width, undefined
  height: number //option
  //when position = PositionType.absolute
  left: number //option
  right: number //option
  top: number //option
  bottom: number //option
  //when position = PositionType.relative
  margin: number[]

  //for self
  flex: number //option
  alignSelf: AlignItems

  //处理特定需求的居中
  transform?: Transform
}
