export enum SpecialLayout {
  GRID,
  SPACE_BETWEEN
}

//for row
export enum SpecialAlign {
  START,
  CENTER,
  END
}
