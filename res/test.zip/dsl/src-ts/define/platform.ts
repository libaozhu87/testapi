export enum Platform {
  WEEX = 'weex',
  FLUTTER = 'flutter',
  ANDROID = 'android',
  IOS = 'iOS'
}

export interface PlatformCfg {
  NEGATIVE_MARGEIN: boolean
  ALIGN_SELF: boolean
  POSITION_TYPE: boolean
}
