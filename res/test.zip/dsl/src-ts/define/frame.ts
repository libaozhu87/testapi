export interface Point {
  x: number
  y: number
}

export interface Frame extends Point {
  width: number
  height: number
  // padding: number
}
