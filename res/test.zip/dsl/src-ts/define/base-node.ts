import { TextStyles, Styles } from './styles'
import { Frame } from './frame'
import { NodeType } from './node'

export interface BaseNode {
  exactFrame: Frame
  zIndex: number
  type: NodeType
  id: string

  layers?: BaseNode[]
  children?: BaseNode[]
  textStyles?: TextStyles
  styles?: Styles
}
