import { Styles, TextStyles, ImageStyles } from './styles'
import { Frame } from './frame'
import { NodeType } from './node'
import { BaseNode } from './base-node'
import { FlexDirection } from './flex-type'
import { SpecialAlign } from './special'

export interface InputNode extends BaseNode {
  //desc
  name: string
  id: string

  type: NodeType // text|image|shape|group
  frame: Frame //相对页面绝对坐标

  layers: InputNode[] //如果是 group 就会有

  value: string //text or image.src

  styles: Styles //描述 shape
  textStyles: TextStyles //描述 text
  imageStyles: ImageStyles //描述 image

  //
  zIndex: number
  exactFrame: Frame //相对父容器
  dir?: FlexDirection
  specailAlign?: SpecialAlign
}
