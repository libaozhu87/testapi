export enum FlexDirection {
  ROW = 'row',
  COLUMN = 'column'
}

export enum JustifyContent {
  SPACE_BETWEEN = 'space-between',
  SPACE_AROUND = 'space-around',
  CENTER = 'center',
  FLEX_END = 'flex-end',
  FLEX_START = 'flex-start'
}

export enum AlignItems {
  STRETCH = 'stretch',
  CENTER = 'center',
  FLEX_END = 'flex-end',
  FLEX_START = 'flex-start'
}

export enum PositionType {
  ABSOLUTE = 'absolute',
  RELATIVE = 'relative'
  // FIXED = 'FIXED',
  // STICKY = 'STICKY'
}

export enum Transform {
  X_50 = 'translateX(-50%)',
  Y_50 = 'translateY(-50%)',
  XY_50 = 'translate(-50%, -50%)'
}
