import { Layout } from './layout'
import { Styles, TextStyles, ImageStyles } from './styles'
import { SpecialLayout, SpecialAlign } from './special'
import { Frame } from './frame'
import { BaseNode } from './base-node'

export enum NodeType {
  TEXT = 'text',
  IMAGE = 'image',
  SHAPE = 'shape',
  GROUP = 'group',
  COMPONENT = 'component'
}

export interface IClass {
  name: string //唯一
  styles: object
}

export interface Node extends BaseNode {
  raw: object
  clazz: IClass

  name: string
  id: string

  type: NodeType
  layout: Layout
  //origin
  frame: Frame
  exactFrame: Frame
  //measured
  measured: Frame
  reasons: string[]
  parent: Group

  zIndex: number

  specialAlign: SpecialAlign
}

export interface Text extends Node {
  value: string // text or image.src
  textStyles: TextStyles
  styles?: Styles
}

export interface Image extends Node {
  value: string // text or image.src
  imageStyles: ImageStyles
  styles?: Styles
}

export interface Shape extends Node {
  styles: Styles
}

export interface Group extends Node {
  styles: Styles
  specialLayout: SpecialLayout
  children: Node[]
}

export interface Component extends Node {
  component: string //componentName if type is COMPONENT
}
