export default {
  layers: [
    {
      name: 'Rectangle 2',
      Id: 162,
      nameId: '252A47CA-BC3A-4506-8CD4-F235E07A061B',
      frame: { width: 750, height: 412, x: 0, y: 0 },
      styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
      type: 'shape'
    },
    {
      name: 'Rectangle 2 Copy',
      Id: 164,
      nameId: 'BDB5916C-0BE0-438F-997F-5A64DC691F68',
      frame: { width: 724, height: 412, x: 26, y: 0 },
      layers: [
        {
          name: 'Rectangle 2 Copy',
          Id: 165,
          nameId: 'EB47367A-F337-4211-AC1D-651D8CDF0A0D',
          frame: { width: 720, height: 412, x: 30, y: 0 },
          styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
          type: 'shape'
        },
        {
          name: 'Group',
          Id: 167,
          nameId: '2ECB1129-A70C-44C7-8D3C-44D700F4ABE8',
          frame: { width: 668, height: 112, x: 40, y: 34 },
          layers: [
            {
              name: 'Mask',
              Id: 169,
              nameId: '26C845D4-C967-42EA-8B1D-7F396B8D9F1F',
              frame: { width: 112, height: 112, x: 40, y: 34 },
              layers: [
                {
                  name: 'Mask',
                  Id: 170,
                  nameId: 'A13AE06C-5142-44E3-AF24-FC5D31957057',
                  frame: { width: 112, height: 112, x: 40, y: 34 },
                  styles: { backgroundColor: 'rgba(244,231,229,1)', fillType: 'color', borderRadius: 112 },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 171,
                  nameId: 'DE6AF5FA-B0B2-44D1-85E4-4FC48B2C75CF',
                  frame: { width: 66, height: 92, x: 64, y: 54 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525236615460.png'
                }
              ],
              type: 'group',
              objectID: '26C845D4-C967-42EA-8B1D-7F396B8D9F1F'
            },
            {
              name: 'Mask',
              Id: 173,
              nameId: '1A8FBF80-4C2A-46FC-8D57-45412406DFCF',
              frame: { width: 112, height: 112, x: 226, y: 34 },
              layers: [
                {
                  name: 'Mask',
                  Id: 174,
                  nameId: '379BFE6B-8EB1-4D76-837B-7E15396C5829',
                  frame: { width: 112, height: 112, x: 226, y: 34 },
                  styles: { backgroundColor: 'rgba(232,234,240,1)', fillType: 'color', borderRadius: 112 },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 175,
                  nameId: '9CCEC426-4F32-457F-86B0-B2898382B6B8',
                  frame: { width: 82, height: 90, x: 240, y: 56 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525236615655.png'
                }
              ],
              type: 'group',
              objectID: '1A8FBF80-4C2A-46FC-8D57-45412406DFCF'
            },
            {
              name: 'Mask',
              Id: 177,
              nameId: 'E1BCDEFF-CC71-4D97-B847-15B47C535F50',
              frame: { width: 112, height: 112, x: 412, y: 34 },
              layers: [
                {
                  name: 'Mask',
                  Id: 178,
                  nameId: '5185C30F-E865-4329-ACBD-C51A0063A40E',
                  frame: { width: 112, height: 112, x: 412, y: 34 },
                  styles: { backgroundColor: 'rgba(245,233,232,1)', fillType: 'color', borderRadius: 112 },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 179,
                  nameId: '549E8778-D6A0-4B5D-925C-E486115CB300',
                  frame: { width: 96, height: 66, x: 420, y: 58 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525236615796.png'
                }
              ],
              type: 'group',
              objectID: 'E1BCDEFF-CC71-4D97-B847-15B47C535F50'
            },
            {
              name: 'Mask',
              Id: 181,
              nameId: 'D0DA71E6-140B-42A0-B587-D5F9A3CB0F35',
              frame: { width: 112, height: 112, x: 596, y: 34 },
              layers: [
                {
                  name: 'Mask',
                  Id: 182,
                  nameId: '0C145B04-4404-43E5-A072-262A9900404B',
                  frame: { width: 112, height: 112, x: 596, y: 34 },
                  styles: { backgroundColor: 'rgba(230,239,230,1)', fillType: 'color', borderRadius: 112 },
                  type: 'shape'
                },
                {
                  name: 'Bitmap Copy',
                  Id: 183,
                  nameId: 'D788F87F-45E7-4439-8FB9-760583764CF5',
                  frame: { width: 82, height: 84, x: 612, y: 50 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525236615971.png'
                }
              ],
              type: 'group',
              objectID: 'D0DA71E6-140B-42A0-B587-D5F9A3CB0F35'
            }
          ],
          type: 'group',
          objectID: '2ECB1129-A70C-44C7-8D3C-44D700F4ABE8'
        },
        {
          name: 'Group',
          Id: 185,
          nameId: 'CFA80D94-6B5E-4D43-8445-EE600CC39E2C',
          frame: { width: 642, height: 40, x: 54, y: 152 },
          layers: [
            {
              name: '卖手机',
              Id: 186,
              nameId: 'E16D3B43-2859-445E-8540-181C8E54FFE4',
              frame: { width: 84, height: 40, x: 54, y: 152 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'normal'
              },
              value: '卖手机',
              type: 'text'
            },
            {
              name: '卖平板',
              Id: 187,
              nameId: '4150CF6F-D976-4F02-8D31-A7ACF0BA982B',
              frame: { width: 84, height: 40, x: 240, y: 152 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'normal'
              },
              value: '卖平板',
              type: 'text'
            },
            {
              name: '卖电脑',
              Id: 188,
              nameId: '93D938D5-762A-43BD-84EA-1702F403E3F1',
              frame: { width: 84, height: 40, x: 426, y: 152 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'normal'
              },
              value: '卖电脑',
              type: 'text'
            },
            {
              name: '卖相机',
              Id: 189,
              nameId: 'AEA14224-89C2-45C8-B72B-7B50E6F1C538',
              frame: { width: 84, height: 40, x: 612, y: 152 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'normal'
              },
              value: '卖相机',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: 'CFA80D94-6B5E-4D43-8445-EE600CC39E2C'
        },
        {
          name: 'Group',
          Id: 191,
          nameId: '196DBEE5-630A-4D7C-BA8B-78696B40490B',
          frame: { width: 670, height: 112, x: 40, y: 220 },
          layers: [
            {
              name: 'Mask',
              Id: 193,
              nameId: 'BFC8B195-EA65-4A9E-BFC7-83D9737F9BE6',
              frame: { width: 112, height: 112, x: 228, y: 220 },
              layers: [
                {
                  name: 'Mask',
                  Id: 194,
                  nameId: '070B8C41-0B7F-417E-A419-E6A3558807D5',
                  frame: { width: 112, height: 112, x: 228, y: 220 },
                  styles: { backgroundColor: 'rgba(234,234,234,1)', fillType: 'color', borderRadius: 112 },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 195,
                  nameId: '76950D2D-DB18-4BA4-A981-A233DB836361',
                  frame: { width: 70, height: 84, x: 248, y: 236 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525236616095.png'
                }
              ],
              type: 'group',
              objectID: 'BFC8B195-EA65-4A9E-BFC7-83D9737F9BE6'
            },
            {
              name: 'Mask',
              Id: 197,
              nameId: '7AC421FF-73C9-4AB7-B1E7-74F20D88142C',
              frame: { width: 112, height: 112, x: 40, y: 220 },
              layers: [
                {
                  name: 'Mask',
                  Id: 198,
                  nameId: 'F10171E6-E539-47C8-9F69-2609B7C81DD7',
                  frame: { width: 112, height: 112, x: 40, y: 220 },
                  styles: { backgroundColor: 'rgba(245,239,232,1)', fillType: 'color', borderRadius: 112 },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 199,
                  nameId: '5B295AB9-E5EE-43F2-9C47-AEDDFF5A8CAD',
                  frame: { width: 66, height: 90, x: 62, y: 242 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525236616189.png'
                }
              ],
              type: 'group',
              objectID: '7AC421FF-73C9-4AB7-B1E7-74F20D88142C'
            },
            {
              name: 'Mask',
              Id: 201,
              nameId: '2CFD14AB-A947-4596-A95B-DFEAFBA55D67',
              frame: { width: 112, height: 112, x: 422, y: 220 },
              layers: [
                {
                  name: 'Mask',
                  Id: 202,
                  nameId: '16B702A1-F1E4-47AF-BE3A-2100AC67CF6C',
                  frame: { width: 112, height: 112, x: 422, y: 220 },
                  styles: { backgroundColor: 'rgba(244,232,226,1)', fillType: 'color', borderRadius: 112 },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 203,
                  nameId: '4223CE2C-3AE3-4CE0-BFC7-820E0911AFAD',
                  frame: { width: 88, height: 94, x: 446, y: 236 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525236616297.png'
                }
              ],
              type: 'group',
              objectID: '2CFD14AB-A947-4596-A95B-DFEAFBA55D67'
            },
            {
              name: 'Mask',
              Id: 205,
              nameId: '58AAA248-1610-4B1D-8FB7-9CE62ADE992C',
              frame: { width: 112, height: 112, x: 598, y: 220 },
              layers: [
                {
                  name: 'Mask',
                  Id: 206,
                  nameId: '8997C3C6-DA40-45F8-BDB6-B203872C4E3B',
                  frame: { width: 112, height: 112, x: 598, y: 220 },
                  styles: { backgroundColor: 'rgba(235,235,235,1)', fillType: 'color', borderRadius: 112 },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 207,
                  nameId: '6D1A7303-DEE9-4C26-ADB5-767C0B2D68D7',
                  frame: { width: 94, height: 94, x: 610, y: 238 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1525236616395.png'
                }
              ],
              type: 'group',
              objectID: '58AAA248-1610-4B1D-8FB7-9CE62ADE992C'
            }
          ],
          type: 'group',
          objectID: '196DBEE5-630A-4D7C-BA8B-78696B40490B'
        },
        {
          name: 'Group',
          Id: 209,
          nameId: '45F12693-391E-4B9D-A2FB-8A06563576D3',
          frame: { width: 484, height: 40, x: 212, y: 342 },
          layers: [
            {
              name: '卖智能设备',
              Id: 210,
              nameId: 'E79C5CDF-2BA2-4CE6-A816-00C22FB3AA4F',
              frame: { width: 140, height: 40, x: 212, y: 342 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'normal'
              },
              value: '卖智能设备',
              type: 'text'
            },
            {
              name: '卖运动器材',
              Id: 211,
              nameId: 'CA6A29CA-0D0B-45F0-B9C4-F2535A756347',
              frame: { width: 140, height: 40, x: 408, y: 342 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'normal'
              },
              value: '卖运动器材',
              type: 'text'
            },
            {
              name: '卖乐器',
              Id: 212,
              nameId: '4BC6FCC2-7126-4242-9D7D-AE34ACE2C359',
              frame: { width: 84, height: 40, x: 612, y: 342 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'normal'
              },
              value: '卖乐器',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '45F12693-391E-4B9D-A2FB-8A06563576D3'
        },
        {
          name: '卖家具家电',
          Id: 213,
          nameId: 'A3BBCBB7-7CEC-4D7D-9024-AF63578331AB',
          frame: { width: 140, height: 40, x: 26, y: 342 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '28',
            color: '#222222',
            textAlign: 'center',
            lineHeight: '40',
            fontWeight: 'normal'
          },
          value: '卖家具家电',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: 'BDB5916C-0BE0-438F-997F-5A64DC691F68'
    }
  ],
  nameId: 1525236615445,
  Id: 161,
  type: 'group',
  frame: { x: 0, y: 0, width: 750, height: 412 }
}
