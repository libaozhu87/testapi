export default {
  layers: [
    {
      name: 'Group 2 Copy 6',
      Id: 3,
      nameId: '2336D564-88E0-455D-B4C2-336F657C6A1D',
      frame: { width: 304, height: 488, x: 0, y: 0 },
      layers: [
        {
          name: 'Bitmap',
          Id: 5,
          nameId: '50D71703-240E-43AB-8709-7B06CDD0949E',
          frame: { width: 304, height: 304, x: 0, y: 0 },
          layers: [
            {
              name: 'Mask',
              Id: 6,
              nameId: 'B6959C1D-E7FC-4797-9C74-FE8C0EB1D0C8',
              frame: { width: 304, height: 304, x: 0, y: 0 },
              styles: {
                backgroundColor: 'rgba(216,216,216,1)',
                borderBottomLeftRadius: '0',
                borderBottomRightRadius: '0',
                borderTopLeftRadius: '10',
                borderTopRightRadius: '10'
              },
              type: 'shape'
            },
            {
              name: 'Bitmap',
              Id: 8,
              nameId: 'CB557DE2-86E0-4C66-A977-BEC20F41186C',
              frame: { width: 304, height: 304, x: 0, y: 0 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 9,
                  nameId: '1168DE09-DD3E-4C6A-BB4F-FBC3272A7E38',
                  frame: { width: 304, height: 304, x: 0, y: 0 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1YIsjDkyWBuNjy0FpXXassXXa-304-304.png'
                }
              ],
              type: 'group',
              objectID: 'CB557DE2-86E0-4C66-A977-BEC20F41186C'
            },
            {
              name: 'Bitmap',
              Id: 10,
              nameId: 'D5FC39D1-727B-4E25-A593-C56915FA5BC0',
              frame: { width: 304, height: 100, x: 0, y: 0 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1f9MmDbGYBuNjy0FoXXciBFXa-304-100.png'
            },
            {
              name: 'Bitmap Copy',
              Id: 11,
              nameId: '68980BF4-2C48-43E0-96DF-4F52C92549E1',
              frame: { width: 60, height: 73.97260273972597, x: 224, y: 1 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1NeAtDXOWBuNjy0FiXXXFxVXa-60-74.png'
            },
            {
              name: 'Bitmap',
              Id: 12,
              nameId: 'BA6025F1-EED4-4119-85C7-F8C4FFD44BFA',
              frame: { width: 304, height: 100, x: 0, y: 204 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1mLZVDh9YBuNjy0FfXXXIsVXa-304-100.png'
            }
          ],
          type: 'group',
          objectID: '50D71703-240E-43AB-8709-7B06CDD0949E'
        },
        {
          name: 'Group',
          Id: 14,
          nameId: 'A559673E-4AD3-4B72-A322-D5955557F9BF',
          frame: { width: 112, height: 60, x: 20, y: 18 },
          layers: [
            {
              name: 'Rectangle 5',
              Id: 15,
              nameId: '642AB3BF-68E6-4B8A-B902-BD00FA1305F8',
              frame: { width: 112, height: 60, x: 20, y: 18 },
              styles: { borderColor: 'rgba(255,255,255,1)', borderStyle: 'solid', borderWidth: 1, borderRadius: 6 },
              type: 'shape'
            },
            {
              name: 'Rectangle 6',
              Id: 16,
              nameId: '85269465-912C-4053-A775-38C2731FD388',
              frame: { width: 112, height: 30, x: 20, y: 18 },
              styles: {
                backgroundColor: 'rgba(255,255,255,1)',
                borderBottomLeftRadius: '0',
                borderBottomRightRadius: '0',
                borderTopLeftRadius: '6',
                borderTopRightRadius: '6'
              },
              type: 'shape'
            },
            {
              name: '票数 3330',
              Id: 17,
              nameId: '56693B4C-B7A2-432A-9365-A0DA9650AF62',
              frame: { width: 95, height: 28, x: 28, y: 19 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 20,
                color: '#222222',
                lineHeight: '28',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '票数 3330',
              type: 'text'
            },
            {
              name: '排名 287',
              Id: 18,
              nameId: '131863EF-6DC0-45AB-9F4D-A44ED77AAC4F',
              frame: { width: 82, height: 28, x: 35, y: 48 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 20,
                color: '#FFFFFF',
                lineHeight: '28',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '排名 287',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: 'A559673E-4AD3-4B72-A322-D5955557F9BF'
        },
        {
          name: '钢铁侠全球限量款手办全球限量款40台…',
          Id: 19,
          nameId: '1C7E3033-AD8B-404F-8EBA-725BE410F1F8',
          frame: { width: 264, height: 80, x: 20, y: 317 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: 28,
            color: '#222222',
            lineHeight: '40',
            textAlign: 'left',
            fontWeight: 'bold'
          },
          value: '钢铁侠全球限量款手办全球限量款40台…',
          type: 'text'
        },
        {
          name: 'Bitmap',
          Id: 20,
          nameId: 'EDF359F5-9CD2-4E0B-9F53-8F006D0F5FC1',
          frame: { width: 264, height: 54, x: 20, y: 414 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1rCquDqmWBuNjy1XaXXXCbXXa-264-54.png'
        },
        {
          name: '投票分2亿',
          Id: 21,
          nameId: '7B659904-1836-48B7-B38A-2B864AF11EBF',
          frame: { width: 129, height: 40, x: 90, y: 421 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: 28,
            color: '#925715',
            lineHeight: '40',
            textAlign: 'left',
            fontWeight: 'bold'
          },
          value: '投票分2亿',
          type: 'text'
        },
        {
          name: 'Bitmap',
          Id: 22,
          nameId: '88751A7C-D6E6-42AA-9E8A-1C724F5E8F56',
          frame: { width: 56, height: 56, x: 20, y: 228 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1FfZVDh9YBuNjy0FfXXXIsVXa-56-56.png'
        },
        {
          name: '淘大王池',
          Id: 23,
          nameId: 'CF9C2145-AEA5-406B-95DE-476D5549C0F2',
          frame: { width: 96, height: 33, x: 86, y: 225 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: 24,
            color: '#FFFFFF',
            lineHeight: '33',
            textAlign: 'left',
            fontWeight: 'bold'
          },
          value: '淘大王池',
          type: 'text'
        },
        {
          name: '漫威复仇者集中营',
          Id: 24,
          nameId: '5CE45B23-65E7-4C22-A971-3C94F75C59BF',
          frame: { width: 160, height: 28, x: 88, y: 260 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: 20,
            color: '#FFDA44',
            lineHeight: '28',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '漫威复仇者集中营',
          type: 'text'
        },
        {
          name: 'Rectangle 4',
          Id: 25,
          nameId: '614FFDA6-6CFB-4683-A814-D9E2767C8453',
          frame: { width: 90, height: 24, x: 191, y: 229 },
          styles: { backgroundColor: 'rgba(255,34,34,1)', borderRadius: 4 },
          type: 'shape'
        },
        {
          name: '我参赛的',
          Id: 26,
          nameId: 'CE214AF0-ED16-4EE8-B0B0-A3967A264509',
          frame: { width: 80, height: 28, x: 196, y: 226 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: 20,
            color: '#FFFFFF',
            lineHeight: '28',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '我参赛的',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '2336D564-88E0-455D-B4C2-336F657C6A1D'
    }
  ],
  nameId: 1531131175677,
  Id: 1,
  type: 'group',
  frame: { x: 0, y: 0, width: 304, height: 488 },
  styles: { backgroundColor: 'rgba(255,255,255,1)' }
}
