export default {
  layers: [
    {
      name: '背景',
      Id: 76,
      nameId: '9A172194-222C-4444-851D-F5BCF0C2AB52',
      frame: {
        width: 750,
        height: 1112,
        x: 0,
        y: 0
      },
      layers: [
        {
          name: '2',
          Id: 77,
          nameId: 'DF2EC52B-2EC5-4F1E-AAF5-F6AE721B4319',
          frame: {
            width: 750,
            height: 390,
            x: 0,
            y: 722
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1xMeOqwmTBuNjy1XbXXaMrVXa-750-390.png'
        },
        {
          name: '1',
          Id: 78,
          nameId: '3DB120F2-E8B6-496C-B4B2-EA838E79709B',
          frame: {
            width: 750,
            height: 722,
            x: 0,
            y: 0
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB16HnZquuSBuNjy1XcXXcYjFXa-750-722.png'
        }
      ],
      type: 'group',
      objectID: '9A172194-222C-4444-851D-F5BCF0C2AB52'
    },
    {
      name: '组 151',
      Id: 80,
      nameId: '31E4F4B4-9273-4770-90FF-F4DF07511381',
      frame: {
        width: 732,
        height: 627,
        x: 11,
        y: 377
      },
      layers: [
        {
          name: '底图',
          Id: 82,
          nameId: '95082B56-2038-4E85-82B7-CFC1FC612F7D',
          frame: {
            width: 732,
            height: 627,
            x: 11,
            y: 377
          },
          layers: [
            {
              name: '图层 611',
              Id: 83,
              nameId: '4898A8B3-FAB7-49D4-95BD-DD444D51DBFC',
              frame: {
                width: 732,
                height: 627,
                x: 11,
                y: 377
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB12bkkqqmWBuNjy1XaXXXCbXXa-732-627.png'
            }
          ],
          type: 'group',
          objectID: '95082B56-2038-4E85-82B7-CFC1FC612F7D'
        },
        {
          name: '文案',
          Id: 85,
          nameId: '00E9AB9E-DF4C-422F-8694-E1E33EB82856',
          frame: {
            width: 523,
            height: 190,
            x: 118,
            y: 567
          },
          layers: [
            {
              name: '祝福成功',
              Id: 86,
              nameId: '8F26F0E1-4DE2-4BAA-81CB-2FDD0BB188AA',
              frame: {
                width: 502,
                height: 85,
                x: 136,
                y: 567
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '30',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '42',
                fontWeight: 'normal'
              },
              value: '谢谢你帮我送了祝福\u2029  我马上能0.01元买到学长的闲置啦～',
              type: 'text'
            },
            {
              name: '你也可以0.01元买闲置  听说卖闲置还能得1000元毕业大礼包!',
              Id: 87,
              nameId: 'BB4D735B-EC35-4677-9CD9-BC1121BE7D8B',
              frame: {
                width: 523,
                height: 85,
                x: 118,
                y: 672
              },
              textStyles: {
                fontFamily: 'PingFangSC-Semibold',
                fontSize: '30',
                color: '#FF4646',
                textAlign: 'center',
                lineHeight: '42',
                fontWeight: 'normal'
              },
              value: '你也可以0.01元买闲置\u2029 听说卖闲置还能得1000元毕业大礼包!',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '00E9AB9E-DF4C-422F-8694-E1E33EB82856'
        },
        {
          name: '用户信息',
          Id: 89,
          nameId: '979C91C8-50B4-4964-A343-4BD5E7739854',
          frame: {
            width: 296,
            height: 83,
            x: 56,
            y: 424
          },
          layers: [
            {
              name: '头像',
              Id: 90,
              nameId: 'DAEA20AB-DB4C-4A8D-8878-AA3DB6478FE2',
              frame: {
                width: 74,
                height: 74,
                x: 56,
                y: 427
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1FHrZquuSBuNjy1XcXXcYjFXa-74-74.png'
            },
            {
              name: '夏天的疯子',
              Id: 91,
              nameId: '61A98C57-6779-4DAC-9072-B91C4DE6EC83',
              frame: {
                width: 195.3379654690484,
                height: 42,
                x: 149,
                y: 424.890025
              },
              textStyles: {
                fontFamily: 'PingFangSC-Semibold',
                fontSize: '32.09',
                color: '#222222',
                lineHeight: '52.27315165666775',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '夏天的疯子',
              type: 'text'
            },
            {
              name: '来自浙江大学',
              Id: 92,
              nameId: '1BDA6436-64BB-4C5A-96C9-949602BF6BEF',
              frame: {
                width: 180.3379654690484,
                height: 42,
                x: 171,
                y: 464.66751999999997
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24.06',
                color: '#999999',
                lineHeight: '52.27315165666775',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '来自浙江大学',
              type: 'text'
            },
            {
              name: 'Bitmap',
              Id: 93,
              nameId: 'E618CF1B-08EB-4C15-BDDB-D0F734596C41',
              frame: {
                width: 17,
                height: 26,
                x: 149,
                y: 474
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1rYokqqmWBuNjy1XaXXXCbXXa-17-26.png'
            },
            {
              name: '性别',
              Id: 94,
              nameId: '01D2FBDD-6505-433E-9A6B-DC4CC81FE8CF',
              frame: {
                width: 33,
                height: 33,
                x: 319,
                y: 432
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1ZrrZquuSBuNjy1XcXXcYjFXa-33-33.png'
            }
          ],
          type: 'group',
          objectID: '979C91C8-50B4-4964-A343-4BD5E7739854'
        },
        {
          name: '按钮',
          Id: 95,
          nameId: '14E2E399-A371-4941-876D-E00F953B9459',
          frame: {
            width: 487,
            height: 115,
            x: 140,
            y: 837
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1j06FqAyWBuNjy0FpXXassXXa-487-115.png'
        }
      ],
      type: 'group',
      objectID: '31E4F4B4-9273-4770-90FF-F4DF07511381'
    },
    {
      name: '好友助阵',
      Id: 97,
      nameId: 'C7EE7D86-3DF0-4A67-9E17-2BEAF1ED1F1F',
      frame: {
        width: 750,
        height: 614,
        x: 0,
        y: 1010
      },
      layers: [
        {
          name: '3',
          Id: 98,
          nameId: '37F72530-5C72-430E-AC1E-CFFF59D4D570',
          frame: {
            width: 750,
            height: 512,
            x: 0,
            y: 1112
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB173iOqwmTBuNjy1XbXXaMrVXa-750-512.png'
        },
        {
          name: '矩形 2558 拷贝 2',
          Id: 99,
          nameId: 'A78CC18B-931C-48D6-9FDE-61FB92DA166A',
          frame: {
            width: 692,
            height: 366,
            x: 29,
            y: 1010
          },
          styles: {
            backgroundColor: 'rgba(255,255,255,1)',
            fillType: 'color'
          },
          type: 'shape'
        },
        {
          name: '好友助阵',
          Id: 100,
          nameId: '9BAFF15E-3291-4D26-BCE8-20082C43E741',
          frame: {
            width: 144,
            height: 52,
            x: 300,
            y: 1032.68833
          },
          textStyles: {
            fontFamily: 'PingFangSC-Semibold',
            fontSize: '36',
            color: '#222222',
            lineHeight: '51.469431056303236',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '好友助阵',
          type: 'text'
        },
        {
          name: '组 154',
          Id: 102,
          nameId: '2CCC40B3-35CC-40E8-994C-7340D73A8FD6',
          frame: {
            width: 649,
            height: 289,
            x: 55,
            y: 1055
          },
          layers: [
            {
              name: 'Bitmap',
              Id: 103,
              nameId: 'BAC6F0FE-0712-448D-BFC2-50CA3834741F',
              frame: {
                width: 217,
                height: 4,
                x: 55,
                y: 1055
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1St6FqAyWBuNjy0FpXXassXXa-217-4.png'
            },
            {
              name: 'Bitmap',
              Id: 104,
              nameId: '922FE2C7-8F4C-4C9A-BFCD-95C71361FC76',
              frame: {
                width: 213,
                height: 4,
                x: 476,
                y: 1055
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1qgmOqwmTBuNjy1XbXXaMrVXa-213-4.png'
            },
            {
              name: 'Bitmap',
              Id: 105,
              nameId: '98446D6C-DE6F-4296-9982-7A13A970E407',
              frame: {
                width: 598,
                height: 1,
                x: 78,
                y: 1189
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1muveqrGYBuNjy0FoXXciBFXa-598-1.png'
            },
            {
              name: 'Bitmap',
              Id: 106,
              nameId: '2E15A14F-2A94-4A0A-B160-F5C756525094',
              frame: {
                width: 598,
                height: 1,
                x: 78,
                y: 1276
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1HwmOqwmTBuNjy1XbXXaMrVXa-598-1.png'
            },
            {
              name: '椭圆 583',
              Id: 108,
              nameId: '5D3ED8EA-0AD1-4435-B17B-44B6B4D2A610',
              frame: {
                width: 56,
                height: 56,
                x: 75,
                y: 1119
              },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 109,
                  nameId: '2E74AA3D-DD4F-4F65-B088-19373B47DA06',
                  frame: {
                    width: 56,
                    height: 56,
                    x: 75,
                    y: 1119
                  },
                  imageStyles: {
                    resize: 'stretch'
                  },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1FeveqrGYBuNjy0FoXXciBFXa-56-56.png'
                },
                {
                  name: '图层 589',
                  Id: 111,
                  nameId: 'C9E50E36-16CD-4378-A024-B4857636B62B',
                  frame: {
                    width: 50,
                    height: 50,
                    x: 78,
                    y: 1122
                  },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 112,
                      nameId: '33110882-D1B7-4F4C-AD4A-38C544E6B8E7',
                      frame: {
                        width: 50,
                        height: 50,
                        x: 78,
                        y: 1122
                      },
                      imageStyles: {
                        resize: 'stretch'
                      },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1RHskqqmWBuNjy1XaXXXCbXXa-50-50.png'
                    }
                  ],
                  type: 'group',
                  objectID: 'C9E50E36-16CD-4378-A024-B4857636B62B'
                }
              ],
              type: 'group',
              objectID: '5D3ED8EA-0AD1-4435-B17B-44B6B4D2A610'
            },
            {
              name: '钢铁侠宇宙...',
              Id: 113,
              nameId: '365E2722-2331-4ED4-AA06-1CC9EF7522A3',
              frame: {
                width: 140,
                height: 42,
                x: 151,
                y: 1127
              },
              textStyles: {
                fontFamily: 'PingFangSC-Semibold',
                fontSize: '24',
                color: '#222222',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '钢铁侠宇宙...',
              type: 'text'
            },
            {
              name: '  已成功帮TA送出祝福',
              Id: 114,
              nameId: 'DCEB8C65-C8C4-495D-8E6E-B8B637CEC163',
              frame: {
                width: 239,
                height: 42,
                x: 290.79999999999995,
                y: 1127
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#222222',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '  已成功帮TA送出祝福',
              type: 'text'
            },
            {
              name: '刚刚',
              Id: 115,
              nameId: '147B20B6-5687-4435-9F8F-A441D4487D38',
              frame: {
                width: 74,
                height: 42,
                x: 630,
                y: 1125
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#888888',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '刚刚',
              type: 'text'
            },
            {
              name: 'Bitmap',
              Id: 116,
              nameId: 'DD9F5541-7A22-4E23-9F0B-779641900BB2',
              frame: {
                width: 50,
                height: 50,
                x: 78,
                y: 1208
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB13rweqxGYBuNjy0FnXXX5lpXa-50-50.png'
            },
            {
              name: '等待好友助阵',
              Id: 117,
              nameId: '4E84B91D-5C5B-4E32-A035-E991A1F34F85',
              frame: {
                width: 172,
                height: 42,
                x: 152,
                y: 1212
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#888888',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '等待好友助阵',
              type: 'text'
            },
            {
              name: '等待好友助阵',
              Id: 118,
              nameId: '94F13A08-1635-4B9D-BA4D-EA63FB508317',
              frame: {
                width: 172,
                height: 42,
                x: 152,
                y: 1301
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#888888',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '等待好友助阵',
              type: 'text'
            },
            {
              name: 'Bitmap',
              Id: 119,
              nameId: 'CF323F20-C83B-4BC2-B547-EB059358C5A2',
              frame: {
                width: 50,
                height: 50,
                x: 78,
                y: 1294
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1fbwkqqmWBuNjy1XaXXXCbXXa-50-50.png'
            }
          ],
          type: 'group',
          objectID: '2CCC40B3-35CC-40E8-994C-7340D73A8FD6'
        }
      ],
      type: 'group',
      objectID: 'C7EE7D86-3DF0-4A67-9E17-2BEAF1ED1F1F'
    },
    {
      name: '组 131',
      Id: 121,
      nameId: '9A42F42F-3BB5-4938-9FF4-A591DDEDFA44',
      frame: {
        width: 750,
        height: 122,
        x: 0,
        y: 0
      },
      layers: [
        {
          name: '矩形 2',
          Id: 122,
          nameId: '46AC37D3-8E76-482D-B8EB-820D2153D08F',
          frame: {
            width: 750,
            height: 122,
            x: 0,
            y: 0
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1bKbFqAyWBuNjy0FpXXassXXa-750-122.png'
        },
        {
          name: '毕业季',
          Id: 123,
          nameId: 'B9F606DC-36E1-4F66-A2BC-0790E178BB6E',
          frame: {
            width: 137.08010680907876,
            height: 35,
            x: 305.9599465954607,
            y: 62.72944
          },
          textStyles: {
            fontFamily: 'AdobeHeitiStd-Regular',
            fontSize: '36.1',
            color: '#333333',
            textAlign: 'center',
            lineHeight: '24.60665036048064',
            fontWeight: 'normal'
          },
          value: '毕业季',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '9A42F42F-3BB5-4938-9FF4-A591DDEDFA44'
    }
  ],
  nameId: 1525851611445,
  Id: 74,
  type: 'group',
  frame: {
    x: 0,
    y: 0,
    width: 750,
    height: 1624
  },
  styles: {
    backgroundColor: 'rgba(255,255,255,1)'
  }
}
