export default {
  layers: [
    {
      name: '曝光力越高卖的越快',
      Id: 2,
      nameId: 'B00B5FD2-EFDD-4F46-9FF5-2595A4462B2B',
      frame: { width: 342, height: 53, x: 0, y: 0 },
      textStyles: {
        fontFamily: 'PingFangSC-Regular',
        fontSize: 38,
        color: '#222222',
        textAlign: 'left',
        lineHeight: '53',
        fontWeight: 'normal'
      },
      value: '曝光力越高卖的越快',
      type: 'text'
    }
  ],
  nameId: 1529647296326,
  Id: 1,
  type: 'group',
  frame: { x: 0, y: 0, width: 342, height: 53 },
  styles: { backgroundColor: 'rgba(255,255,255,1)' }
}
