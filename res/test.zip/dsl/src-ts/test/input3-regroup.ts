export default {
  type: 'group',
  id: 'Block-1',
  componentList: [],
  componentListObj: [],
  frame: {
    width: 750,
    height: 397,
    x: 0,
    y: 0
  },
  layers: [
    {
      frame: {
        width: 750,
        height: 16,
        x: 0,
        y: 0
      },
      skecthName: 'Rectangle 224 Copy 4',
      objectID: '37448775-A2B3-400D-B8DF-A14FC678586F',
      id: 0,
      layers: []
    },
    {
      frame: {
        width: 402,
        height: 36,
        x: 32,
        y: 43
      },
      skecthName: '快速建鱼塘 每月多赚1000元',
      objectID: 'A12FCBB4-2EF5-448C-BB9C-A2B7D28C1B60',
      id: 1,
      layers: []
    },
    {
      frame: {
        width: 56,
        height: 32,
        x: 442,
        y: 45
      },
      skecthName: 'Rectangle 14',
      objectID: '8065C8DD-4075-4464-9AC8-9530CF9B4005',
      id: 2,
      layers: []
    },
    {
      frame: {
        width: 44,
        height: 20,
        x: 449,
        y: 51
      },
      skecthName: '免费',
      objectID: '74AE68F7-3153-43F5-B703-214FC0C6F28B',
      id: 3,
      layers: []
    },
    {
      frame: {
        width: 718,
        height: 192,
        x: 32,
        y: 104
      },
      skecthName: 'Rectangle 9 Copy',
      objectID: 'DD515B68-64BE-47FC-859F-08D6F8B159D7',
      id: 4,
      layers: []
    },
    {
      frame: {
        width: 296,
        height: 160,
        x: 32,
        y: 104
      },
      skecthName: 'Rectangle 12',
      objectID: '5E8AF39D-8E34-4AEF-BF7C-F180A7D46D9E',
      id: 5,
      layers: []
    },
    {
      frame: {
        width: 180,
        height: 42,
        x: 56,
        y: 170
      },
      skecthName: '建鱼塘养宠物',
      objectID: '30ED5623-53D0-4755-8BA2-9F04AB98DE7A',
      id: 6,
      layers: []
    },
    {
      frame: {
        width: 223,
        height: 36,
        x: 56,
        y: 212
      },
      skecthName: '7天轻松赚2000元',
      objectID: 'E056C6F3-94FF-4062-A674-EEEBAB947B8E',
      id: 7,
      layers: []
    },
    {
      frame: {
        width: 296,
        height: 160,
        x: 344,
        y: 104
      },
      skecthName: 'Rectangle 12 Copy',
      objectID: '6F8D7BC3-F0E8-4F29-BA07-93325861B24F',
      id: 8,
      layers: []
    },
    {
      frame: {
        width: 180,
        height: 42,
        x: 368,
        y: 170
      },
      skecthName: '建鱼塘卖水果',
      objectID: '868D63F1-7376-417F-B0A4-3E0AD93A98BD',
      id: 9,
      layers: []
    },
    {
      frame: {
        width: 196,
        height: 36,
        x: 368,
        y: 212
      },
      skecthName: '轻松多卖几百箱',
      objectID: '2DF53E83-604B-44BC-9F62-1FCC653CEDB3',
      id: 10,
      layers: []
    },
    {
      frame: {
        width: 296,
        height: 160,
        x: 656,
        y: 104
      },
      skecthName: 'Rectangle 12 Copy 2',
      objectID: '2C20BC2A-FBF5-4307-B442-2F46362C0C5C',
      id: 11,
      layers: []
    },
    {
      frame: {
        width: 180,
        height: 42,
        x: 680,
        y: 170
      },
      skecthName: '建鱼塘卖水果',
      objectID: '19CB35A9-834D-44BE-BE8D-CE70ADC9536E',
      id: 12,
      layers: []
    },
    {
      frame: {
        width: 196,
        height: 36,
        x: 680,
        y: 212
      },
      skecthName: '轻松多卖几百箱',
      objectID: 'E0D2B03C-A9AC-4234-A86C-D325ECA2C2C2',
      id: 13,
      layers: []
    },
    {
      frame: {
        width: 750,
        height: 88,
        x: 0,
        y: 296
      },
      skecthName: 'Rectangle 18',
      objectID: '804C197E-C312-4453-8CEF-29481DB4A785',
      id: 14,
      layers: []
    },
    {
      frame: {
        width: 168,
        height: 40,
        x: 275,
        y: 320
      },
      skecthName: '免费创建鱼塘',
      objectID: '3D24F01D-33DB-452C-83AD-2AD54317CA81',
      id: 15,
      layers: []
    },
    {
      frame: {
        width: 14,
        height: 24,
        x: 453,
        y: 328
      },
      skecthName: 'Combined Shape',
      objectID: '371AF631-2014-4094-971D-364EF3970DFF',
      id: 16,
      layers: []
    },
    {
      frame: {
        width: 750,
        height: 16,
        x: 0,
        y: 384
      },
      skecthName: 'Rectangle 224 Copy 7',
      objectID: '085B7764-9D5C-49CD-A78D-2373FE1A5C11',
      id: 17,
      layers: []
    }
  ]
}
