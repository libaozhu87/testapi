export default {
  layers: [
    {
      name: 'Group 4',
      Id: 139,
      nameId: '39F60416-022D-45F6-897E-7D5736393AF1',
      frame: {
        width: 750,
        height: 128,
        x: 0,
        y: 0
      },
      layers: [
        {
          name: 'seatchbox',
          Id: 141,
          nameId: 'EB02EE42-6365-4A08-B9E1-92E1C2A6E003',
          frame: {
            width: 576,
            height: 64,
            x: 40,
            y: 52
          },
          layers: [
            {
              name: 'Search Field',
              Id: 142,
              nameId: 'CA42AB5E-F2B3-497D-BE74-7BCCEBDD4716',
              frame: {
                width: 576,
                height: 64,
                x: 40,
                y: 52
              },
              styles: {
                backgroundColor: 'rgba(142,142,147,0.1)',
                borderRadius: 10
              },
              type: 'shape'
            },
            {
              name: 'Group 3',
              Id: 144,
              nameId: '4757AD53-3A93-4696-A246-4452362EDE4F',
              frame: {
                width: 254,
                height: 40,
                x: 60.06968641114963,
                y: 64
              },
              layers: [
                {
                  name: 'Group 2',
                  Id: 146,
                  nameId: '9C85FC07-AB09-4F0B-8188-0CE3A94130FA',
                  frame: {
                    width: 34,
                    height: 35,
                    x: 60.06968641114963,
                    y: 67
                  },
                  layers: [
                    {
                      name: 'Search Glyph',
                      Id: 148,
                      nameId: 'B136EC92-48C0-4676-B91B-B1BDB735AB0C',
                      frame: {
                        width: 34,
                        height: 35,
                        x: 60.06968641114963,
                        y: 67
                      },
                      layers: [
                        {
                          name: 'Group 24',
                          Id: 150,
                          nameId: '1C069DAB-58B9-4873-A3D1-3746C6DF3642',
                          frame: {
                            width: 34,
                            height: 35,
                            x: 60.06968641114963,
                            y: 67
                          },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 151,
                              nameId: '5051E934-7DF0-4D5C-A965-31B217E7DAC7',
                              frame: {
                                width: 29,
                                height: 28,
                                x: 64,
                                y: 70
                              },
                              imageStyles: {
                                resize: 'stretch'
                              },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB14jo4vCBYBeNjy0FeXXbnmFXa-29-28.png'
                            }
                          ],
                          type: 'group',
                          objectID: '1C069DAB-58B9-4873-A3D1-3746C6DF3642'
                        }
                      ],
                      type: 'group',
                      objectID: 'B136EC92-48C0-4676-B91B-B1BDB735AB0C'
                    }
                  ],
                  type: 'group',
                  objectID: '9C85FC07-AB09-4F0B-8188-0CE3A94130FA'
                },
                {
                  name: '↳ Placeholder Label',
                  Id: 152,
                  nameId: 'DEE7D512-328F-4446-A29F-EBE8D7E66D0A',
                  frame: {
                    width: 210,
                    height: 40,
                    x: 104.06968641114963,
                    y: 64
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 30,
                    color: '#B3B3B3',
                    lineHeight: '40',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '请输入小区名称',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '4757AD53-3A93-4696-A246-4452362EDE4F'
            }
          ],
          type: 'group',
          objectID: 'EB02EE42-6365-4A08-B9E1-92E1C2A6E003'
        },
        {
          name: 'Group',
          Id: 154,
          nameId: '21984B26-9DEB-4C34-A856-60E0CE438262',
          frame: {
            width: 750,
            height: 40,
            x: 0,
            y: 0
          },
          layers: [
            {
              name: 'Bars/Status/Black',
              Id: 156,
              nameId: '4D202D68-9FA7-45F1-820B-8F020BBA15B8',
              frame: {
                width: 725,
                height: 24,
                x: 14,
                y: 8
              },
              layers: [
                {
                  name: 'Pin Right',
                  Id: 158,
                  nameId: '83E27557-4C81-4F54-94DD-D529ECC1870E',
                  frame: {
                    width: 113,
                    height: 24,
                    x: 626,
                    y: 8
                  },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 159,
                      nameId: 'EA32504F-F57D-4D36-B899-3A13105FCF4F',
                      frame: {
                        width: 49,
                        height: 19,
                        x: 690,
                        y: 10
                      },
                      imageStyles: {
                        resize: 'stretch'
                      },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1_7MwvxGYBuNjy0FnXXX5lpXa-49-19.png'
                    },
                    {
                      name: '100%',
                      Id: 160,
                      nameId: 'DA230C4E-E073-4BCE-B58F-00097E3FF1A9',
                      frame: {
                        width: 58,
                        height: 24,
                        x: 626,
                        y: 8
                      },
                      textStyles: {
                        fontFamily: '.SFNSDisplay',
                        fontSize: 24,
                        color: '#000000',
                        textAlign: 'right',
                        lineHeight: '24',
                        fontWeight: 'normal'
                      },
                      value: '100%',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '83E27557-4C81-4F54-94DD-D529ECC1870E'
                },
                {
                  name: 'Time',
                  Id: 161,
                  nameId: '470A0C48-BDA4-4AB6-99B1-A1001BC55EB5',
                  frame: {
                    width: 90,
                    height: 24,
                    x: 330,
                    y: 8
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 24,
                    color: '#000000',
                    textAlign: 'center',
                    lineHeight: '24',
                    fontWeight: 'normal'
                  },
                  value: '9:41 AM',
                  type: 'text'
                },
                {
                  name: 'Signal',
                  Id: 163,
                  nameId: '5E18A8C9-6F4E-47CA-8C3F-691CDB664FC5',
                  frame: {
                    width: 188,
                    height: 24,
                    x: 14,
                    y: 8
                  },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 164,
                      nameId: '8B797EC8-6A6A-44AD-84C7-6F100BB62B63',
                      frame: {
                        width: 26,
                        height: 18,
                        x: 176,
                        y: 10
                      },
                      imageStyles: {
                        resize: 'stretch'
                      },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1IawDvx9YBuNjy0FfXXXIsVXa-26-18.png'
                    },
                    {
                      name: 'Carrier',
                      Id: 165,
                      nameId: '58EE80C8-0F55-4337-9FAB-26D26CE57632',
                      frame: {
                        width: 86,
                        height: 24,
                        x: 88,
                        y: 8
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#000000',
                        textAlign: 'left',
                        lineHeight: '24',
                        fontWeight: 'normal'
                      },
                      value: 'SanityD',
                      type: 'text'
                    },
                    {
                      name: 'Bitmap',
                      Id: 166,
                      nameId: '4C833129-A55D-4060-9462-130E6F10F06D',
                      frame: {
                        width: 67,
                        height: 11,
                        x: 14,
                        y: 14
                      },
                      imageStyles: {
                        resize: 'stretch'
                      },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1o7QwvxGYBuNjy0FnXXX5lpXa-67-11.png'
                    }
                  ],
                  type: 'group',
                  objectID: '5E18A8C9-6F4E-47CA-8C3F-691CDB664FC5'
                }
              ],
              type: 'group',
              objectID: '4D202D68-9FA7-45F1-820B-8F020BBA15B8'
            }
          ],
          type: 'group',
          objectID: '21984B26-9DEB-4C34-A856-60E0CE438262'
        },
        {
          name: '取消',
          Id: 167,
          nameId: 'A9AA906C-AD51-42BD-B95A-0F592CE57F80',
          frame: {
            width: 64,
            height: 44,
            x: 646,
            y: 62
          },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: 32,
            color: '#222222',
            textAlign: 'right',
            lineHeight: '44',
            fontWeight: 'bold'
          },
          value: '取消',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '39F60416-022D-45F6-897E-7D5736393AF1'
    },
    {
      name: '历史搜索',
      Id: 169,
      nameId: '37873369-8D57-4AF1-95E4-5451120A4AEB',
      frame: {
        width: 2473,
        height: 1502,
        x: 0,
        y: -953
      },
      layers: [
        {
          name: 'Group 14 Copy 17',
          Id: 171,
          nameId: 'B6661738-5298-4C1C-9640-968DB21ECB0B',
          frame: {
            width: 671,
            height: 64,
            x: 41,
            y: 485
          },
          layers: [
            {
              name: 'Rectangle 9',
              Id: 172,
              nameId: 'CB4E4952-9AA2-4D09-AF2D-F13C96198DF7',
              frame: {
                width: 671,
                height: 64,
                x: 41,
                y: 485
              },
              styles: {
                backgroundColor: 'rgba(142,142,147,0.08)',
                borderRadius: 6
              },
              type: 'shape'
            },
            {
              name: 'Group 10',
              Id: 174,
              nameId: '9313A3C7-DA97-4F05-B661-BF9E9E6689E1',
              frame: {
                width: 625,
                height: 37,
                x: 63,
                y: 498
              },
              layers: [
                {
                  name: '小区小区小区小区小区小区…小区小区小区小',
                  Id: 175,
                  nameId: 'F92FA11E-D785-4955-BA6D-591817AF1680',
                  frame: {
                    width: 625,
                    height: 37,
                    x: 63,
                    y: 498
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 26,
                    color: '#222222',
                    textAlign: 'center',
                    lineHeight: '37',
                    fontWeight: 'normal'
                  },
                  value: '小区小区小区小区小区小区…小区小区小区小区小区小',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '9313A3C7-DA97-4F05-B661-BF9E9E6689E1'
            }
          ],
          type: 'group',
          objectID: 'B6661738-5298-4C1C-9640-968DB21ECB0B'
        },
        {
          name: 'Bitmap',
          Id: 176,
          nameId: 'E961CA30-EF01-431B-8140-B322A6A63D3A',
          frame: {
            width: 36,
            height: 36,
            x: 672,
            y: 160
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1UQjlvv9TBuNjy0FcXXbeiFXa-36-36.png'
        },
        {
          name: 'Group 16',
          Id: 178,
          nameId: '21AD8F16-7AA9-4777-A064-EB41854A9950',
          frame: {
            width: 625,
            height: 232,
            x: 40,
            y: 228
          },
          layers: [
            {
              name: 'Group 14',
              Id: 180,
              nameId: '6A5FB3F6-8873-4F0C-9A6B-8E314A826C77',
              frame: {
                width: 152,
                height: 64,
                x: 40,
                y: 228
              },
              layers: [
                {
                  name: 'Rectangle 9',
                  Id: 181,
                  nameId: 'A95D3F66-5DDE-4CAE-B63C-44B13AEDD643',
                  frame: {
                    width: 152,
                    height: 64,
                    x: 40,
                    y: 228
                  },
                  styles: {
                    backgroundColor: 'rgba(142,142,147,0.08)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'Group 10',
                  Id: 183,
                  nameId: 'D21DC770-BCA8-4BB8-B878-047A3D182B05',
                  frame: {
                    width: 106,
                    height: 38,
                    x: 63,
                    y: 241
                  },
                  layers: [
                    {
                      name: '悦西溪府',
                      Id: 184,
                      nameId: 'AED89BD0-B889-49EB-80A2-53BE7DCDA6E4',
                      frame: {
                        width: 105,
                        height: 37,
                        x: 63.5,
                        y: 241.8571428571429
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                      },
                      value: '悦西溪府',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'D21DC770-BCA8-4BB8-B878-047A3D182B05'
                }
              ],
              type: 'group',
              objectID: '6A5FB3F6-8873-4F0C-9A6B-8E314A826C77'
            },
            {
              name: 'Group 14 Copy 6',
              Id: 186,
              nameId: '72F3749D-BACA-4E26-A422-0469E64059A4',
              frame: {
                width: 152,
                height: 64,
                x: 416,
                y: 228
              },
              layers: [
                {
                  name: 'Rectangle 9',
                  Id: 187,
                  nameId: '61739F24-654F-4C7F-A683-8752F9DD7EBF',
                  frame: {
                    width: 152,
                    height: 64,
                    x: 416,
                    y: 228
                  },
                  styles: {
                    backgroundColor: 'rgba(142,142,147,0.12)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'Group 10',
                  Id: 189,
                  nameId: '5F966A05-9706-4159-82A4-027A6362DD11',
                  frame: {
                    width: 106,
                    height: 38,
                    x: 439,
                    y: 242
                  },
                  layers: [
                    {
                      name: '水岸茗苑',
                      Id: 190,
                      nameId: 'DA726CA9-15DD-4946-B692-472B60406C1F',
                      frame: {
                        width: 105,
                        height: 37,
                        x: 439.5,
                        y: 242.8571428571429
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                      },
                      value: '水岸茗苑',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '5F966A05-9706-4159-82A4-027A6362DD11'
                }
              ],
              type: 'group',
              objectID: '72F3749D-BACA-4E26-A422-0469E64059A4'
            },
            {
              name: 'Group 14 Copy 9',
              Id: 192,
              nameId: 'C398242E-C315-47CD-8005-E4C9301D36D9',
              frame: {
                width: 158,
                height: 64,
                x: 40,
                y: 396
              },
              layers: [
                {
                  name: 'Rectangle 9',
                  Id: 193,
                  nameId: '8310661C-7222-4A8C-9E69-C9DDEFEFBA3C',
                  frame: {
                    width: 158,
                    height: 64,
                    x: 40,
                    y: 396
                  },
                  styles: {
                    backgroundColor: 'rgba(142,142,147,0.08)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'Group 10',
                  Id: 195,
                  nameId: '4DC4B20A-C9B9-47A0-BD88-F7FDF3D054B1',
                  frame: {
                    width: 118,
                    height: 37,
                    x: 60,
                    y: 411
                  },
                  layers: [
                    {
                      name: '新城·峰景',
                      Id: 196,
                      nameId: '9342940A-67E5-4314-AEB3-9CA7BF99DFF8',
                      frame: {
                        width: 118,
                        height: 37,
                        x: 60,
                        y: 411
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                      },
                      value: '新城·峰景',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '4DC4B20A-C9B9-47A0-BD88-F7FDF3D054B1'
                }
              ],
              type: 'group',
              objectID: 'C398242E-C315-47CD-8005-E4C9301D36D9'
            },
            {
              name: 'Group 14 Copy 15',
              Id: 198,
              nameId: '0CBB94AF-3BA7-4155-962A-8513D2B42C03',
              frame: {
                width: 148,
                height: 64,
                x: 412,
                y: 396
              },
              layers: [
                {
                  name: 'Rectangle 9',
                  Id: 199,
                  nameId: '36E47A0B-951D-4C13-B948-A5570F185FC3',
                  frame: {
                    width: 148,
                    height: 64,
                    x: 412,
                    y: 396
                  },
                  styles: {
                    backgroundColor: 'rgba(142,142,147,0.08)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'Group 10',
                  Id: 201,
                  nameId: '6771AD35-6846-41B6-9148-CB537D5FE677',
                  frame: {
                    width: 105,
                    height: 37,
                    x: 432,
                    y: 411
                  },
                  layers: [
                    {
                      name: '大华风情',
                      Id: 202,
                      nameId: '4523DE9D-7B59-41AF-A787-D10693D35967',
                      frame: {
                        width: 105,
                        height: 37,
                        x: 432,
                        y: 411
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                      },
                      value: '大华风情',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '6771AD35-6846-41B6-9148-CB537D5FE677'
                }
              ],
              type: 'group',
              objectID: '0CBB94AF-3BA7-4155-962A-8513D2B42C03'
            },
            {
              name: 'Group 14 Copy 10',
              Id: 204,
              nameId: '27D2BCD1-B42A-48A0-8352-CCAFB9274CA1',
              frame: {
                width: 174,
                height: 64,
                x: 218,
                y: 396
              },
              layers: [
                {
                  name: 'Rectangle 9',
                  Id: 205,
                  nameId: '99559168-48BB-4183-B91A-449174DB1B74',
                  frame: {
                    width: 174,
                    height: 64,
                    x: 218,
                    y: 396
                  },
                  styles: {
                    backgroundColor: 'rgba(142,142,147,0.08)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'Group 10',
                  Id: 207,
                  nameId: '20725209-D935-4D33-9FC4-5884C5ADBC7A',
                  frame: {
                    width: 132,
                    height: 38,
                    x: 239,
                    y: 409.1428571428571
                  },
                  layers: [
                    {
                      name: '大华新天地',
                      Id: 208,
                      nameId: '7459E905-8BAE-4BEA-85F6-27786B7DA941',
                      frame: {
                        width: 131,
                        height: 37,
                        x: 239.5,
                        y: 410
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                      },
                      value: '大华新天地',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '20725209-D935-4D33-9FC4-5884C5ADBC7A'
                }
              ],
              type: 'group',
              objectID: '27D2BCD1-B42A-48A0-8352-CCAFB9274CA1'
            },
            {
              name: 'Group 14 Copy 14',
              Id: 210,
              nameId: 'A9723550-3504-4830-AB49-FC3EC165BA71',
              frame: {
                width: 249,
                height: 64,
                x: 40,
                y: 312
              },
              layers: [
                {
                  name: 'Rectangle 9',
                  Id: 211,
                  nameId: 'A0A66AFA-66FC-429E-AB5A-818CE892BB9E',
                  frame: {
                    width: 249,
                    height: 64,
                    x: 40,
                    y: 312
                  },
                  styles: {
                    backgroundColor: 'rgba(142,142,147,0.08)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'Group 10',
                  Id: 213,
                  nameId: 'E94D12FE-1565-42B5-B0F3-8DA7AED486A6',
                  frame: {
                    width: 209,
                    height: 38,
                    x: 60,
                    y: 325.1428571428571
                  },
                  layers: [
                    {
                      name: '富力西溪悦居溪区',
                      Id: 214,
                      nameId: 'CD31E02D-918E-4BAE-9974-0F18A598A23C',
                      frame: {
                        width: 209,
                        height: 37,
                        x: 60,
                        y: 326
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                      },
                      value: '富力西溪悦居溪区',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'E94D12FE-1565-42B5-B0F3-8DA7AED486A6'
                }
              ],
              type: 'group',
              objectID: 'A9723550-3504-4830-AB49-FC3EC165BA71'
            },
            {
              name: 'Group 14 Copy 7',
              Id: 216,
              nameId: 'DDA64583-0125-4882-860B-0D8DFCF95E93',
              frame: {
                width: 152,
                height: 64,
                x: 309,
                y: 312
              },
              layers: [
                {
                  name: 'Rectangle 9',
                  Id: 217,
                  nameId: 'EF5501A0-5A72-4E1E-A29A-C311BF10A54F',
                  frame: {
                    width: 152,
                    height: 64,
                    x: 309,
                    y: 312
                  },
                  styles: {
                    backgroundColor: 'rgba(142,142,147,0.12)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'Group 10',
                  Id: 219,
                  nameId: '7B5BE91F-E9CD-4D8D-8E88-5808FCBF5BAF',
                  frame: {
                    width: 106,
                    height: 38,
                    x: 333,
                    y: 326
                  },
                  layers: [
                    {
                      name: '福鼎家园',
                      Id: 220,
                      nameId: '57C039D4-42C6-495F-975E-430171562B7E',
                      frame: {
                        width: 105,
                        height: 37,
                        x: 333.5,
                        y: 326.8571428571429
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                      },
                      value: '福鼎家园',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '7B5BE91F-E9CD-4D8D-8E88-5808FCBF5BAF'
                }
              ],
              type: 'group',
              objectID: 'DDA64583-0125-4882-860B-0D8DFCF95E93'
            },
            {
              name: 'Group 14 Copy 2',
              Id: 222,
              nameId: 'ADD09712-6EFC-4C11-9893-FEBDC741028C',
              frame: {
                width: 184,
                height: 64,
                x: 212,
                y: 228
              },
              layers: [
                {
                  name: 'Rectangle 9',
                  Id: 223,
                  nameId: '08C8E424-3B47-4280-8654-071DF70AAB82',
                  frame: {
                    width: 184,
                    height: 64,
                    x: 212,
                    y: 228
                  },
                  styles: {
                    backgroundColor: 'rgba(142,142,147,0.08)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'Group 10',
                  Id: 225,
                  nameId: '4945C9E7-4266-43C5-AC11-353A7A97B793',
                  frame: {
                    width: 144,
                    height: 37,
                    x: 232,
                    y: 242
                  },
                  layers: [
                    {
                      name: '中交·悦西溪',
                      Id: 226,
                      nameId: '09B3F29E-90DD-40FD-A4E0-F316F634C546',
                      frame: {
                        width: 144,
                        height: 37,
                        x: 232,
                        y: 242
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                      },
                      value: '中交·悦西溪',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '4945C9E7-4266-43C5-AC11-353A7A97B793'
                }
              ],
              type: 'group',
              objectID: 'ADD09712-6EFC-4C11-9893-FEBDC741028C'
            },
            {
              name: 'Group 14 Copy 3',
              Id: 228,
              nameId: '490AD9B7-1AC0-4F20-9770-42CBF92F2426',
              frame: {
                width: 184,
                height: 64,
                x: 481,
                y: 312
              },
              layers: [
                {
                  name: 'Rectangle 9',
                  Id: 229,
                  nameId: '783638A6-30A8-46BC-B412-C882B9536276',
                  frame: {
                    width: 184,
                    height: 64,
                    x: 481,
                    y: 312
                  },
                  styles: {
                    backgroundColor: 'rgba(142,142,147,0.08)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'Group 10',
                  Id: 231,
                  nameId: 'DCF467DE-CF47-46F1-B5E7-21CB9F92D487',
                  frame: {
                    width: 144,
                    height: 37,
                    x: 501,
                    y: 326
                  },
                  layers: [
                    {
                      name: '合景·叠彩园',
                      Id: 232,
                      nameId: 'E00618C2-4658-4DF8-BC47-1B3ED03E65B6',
                      frame: {
                        width: 144,
                        height: 37,
                        x: 501,
                        y: 326
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 26,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '37',
                        fontWeight: 'normal'
                      },
                      value: '合景·叠彩园',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'DCF467DE-CF47-46F1-B5E7-21CB9F92D487'
                }
              ],
              type: 'group',
              objectID: '490AD9B7-1AC0-4F20-9770-42CBF92F2426'
            }
          ],
          type: 'group',
          objectID: '21AD8F16-7AA9-4777-A064-EB41854A9950'
        },
        {
          name: '历史搜索',
          Id: 233,
          nameId: '88B98412-CFB0-4E49-924B-C7DDF6640DC1',
          frame: {
            width: 112,
            height: 40,
            x: 40,
            y: 158
          },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: 28,
            color: '#888888',
            lineHeight: '40',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '历史搜索',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '37873369-8D57-4AF1-95E4-5451120A4AEB'
    },
    {
      name: '历史搜索 copy',
      Id: 235,
      nameId: '55A5D4E2-2EA1-48E9-BE23-E6CCCC42CF6D',
      frame: {
        width: 2473,
        height: 1803,
        x: 0,
        y: -953
      },
      layers: [
        {
          name: 'Group 14',
          Id: 237,
          nameId: '5744240B-B704-4F2A-B88A-0A6E5483A7A6',
          frame: {
            width: 158,
            height: 64,
            x: 40,
            y: 672
          },
          layers: [
            {
              name: 'Rectangle 9',
              Id: 238,
              nameId: '33728CE3-5D06-4D5A-BCEB-C598CADCDF92',
              frame: {
                width: 158,
                height: 64,
                x: 40,
                y: 672
              },
              styles: {
                backgroundColor: 'rgba(142,142,147,0.08)',
                borderRadius: 6
              },
              type: 'shape'
            },
            {
              name: 'Group 10',
              Id: 240,
              nameId: 'DBABFD2A-962A-4D0D-9718-35E3B3C5657B',
              frame: {
                width: 118,
                height: 37,
                x: 60,
                y: 686
              },
              layers: [
                {
                  name: '新城·峰景',
                  Id: 241,
                  nameId: '6CEFA1BA-BD92-44AD-98E0-B8DFD4BD379B',
                  frame: {
                    width: 118,
                    height: 37,
                    x: 60,
                    y: 686
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 26,
                    color: '#222222',
                    textAlign: 'center',
                    lineHeight: '37',
                    fontWeight: 'normal'
                  },
                  value: '新城·峰景',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'DBABFD2A-962A-4D0D-9718-35E3B3C5657B'
            }
          ],
          type: 'group',
          objectID: '5744240B-B704-4F2A-B88A-0A6E5483A7A6'
        },
        {
          name: 'Group 14 Copy 7',
          Id: 243,
          nameId: 'F3224D5B-293C-40EA-AEEF-5F2D72BA9770',
          frame: {
            width: 250,
            height: 64,
            x: 249,
            y: 756
          },
          layers: [
            {
              name: 'Rectangle 9',
              Id: 244,
              nameId: '65E64F2F-54E4-4DBF-B3E2-D0ACDA640935',
              frame: {
                width: 250,
                height: 64,
                x: 249,
                y: 756
              },
              styles: {
                backgroundColor: 'rgba(142,142,147,0.08)',
                borderRadius: 6
              },
              type: 'shape'
            },
            {
              name: 'Group 10',
              Id: 246,
              nameId: 'EC8FC289-19DF-49A5-8B3B-3189A2DA9104',
              frame: {
                width: 210,
                height: 37,
                x: 269,
                y: 771
              },
              layers: [
                {
                  name: '浙江大花西溪风情',
                  Id: 247,
                  nameId: '0625A546-080E-4F49-BEA7-5D3366C9C224',
                  frame: {
                    width: 209,
                    height: 37,
                    x: 269.5,
                    y: 771
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 26,
                    color: '#222222',
                    textAlign: 'center',
                    lineHeight: '37',
                    fontWeight: 'normal'
                  },
                  value: '浙江大花西溪风情',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'EC8FC289-19DF-49A5-8B3B-3189A2DA9104'
            }
          ],
          type: 'group',
          objectID: 'F3224D5B-293C-40EA-AEEF-5F2D72BA9770'
        },
        {
          name: 'Group 14 Copy 2',
          Id: 249,
          nameId: '423E9126-B650-40AC-84BA-4122612DF2E5',
          frame: {
            width: 171,
            height: 64,
            x: 218,
            y: 672
          },
          layers: [
            {
              name: 'Rectangle 9',
              Id: 250,
              nameId: 'EA7DA895-C94C-4130-AD13-EDA4922A84C8',
              frame: {
                width: 171,
                height: 64,
                x: 218,
                y: 672
              },
              styles: {
                backgroundColor: 'rgba(142,142,147,0.08)',
                borderRadius: 6
              },
              type: 'shape'
            },
            {
              name: 'Group 10',
              Id: 252,
              nameId: '431B5CFE-069A-4EE1-BFE4-85F9946527D0',
              frame: {
                width: 131,
                height: 37,
                x: 238,
                y: 686
              },
              layers: [
                {
                  name: '未来科技城',
                  Id: 253,
                  nameId: '6834F964-0D72-43F0-B490-62437DB19300',
                  frame: {
                    width: 131,
                    height: 37,
                    x: 238,
                    y: 686
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 26,
                    color: '#222222',
                    textAlign: 'center',
                    lineHeight: '37',
                    fontWeight: 'normal'
                  },
                  value: '未来科技城',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '431B5CFE-069A-4EE1-BFE4-85F9946527D0'
            }
          ],
          type: 'group',
          objectID: '423E9126-B650-40AC-84BA-4122612DF2E5'
        },
        {
          name: 'Group 14 Copy 12',
          Id: 255,
          nameId: 'EA4B3CF7-66EA-40E2-97AE-C6AB02332543',
          frame: {
            width: 189,
            height: 64,
            x: 40,
            y: 756
          },
          layers: [
            {
              name: 'Rectangle 9',
              Id: 256,
              nameId: '5E790EA5-E812-4294-8B72-0CC8C80D7B22',
              frame: {
                width: 189,
                height: 64,
                x: 40,
                y: 756
              },
              styles: {
                backgroundColor: 'rgba(142,142,147,0.08)',
                borderRadius: 6
              },
              type: 'shape'
            },
            {
              name: 'Group 10',
              Id: 258,
              nameId: 'CF12A340-4804-433C-A116-46FAEDC8344B',
              frame: {
                width: 149,
                height: 37,
                x: 60,
                y: 770
              },
              layers: [
                {
                  name: '高教园区(西)',
                  Id: 259,
                  nameId: '826A9CF6-992C-4770-84B7-E77368A23770',
                  frame: {
                    width: 148,
                    height: 37,
                    x: 60.5,
                    y: 770
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 26,
                    color: '#222222',
                    textAlign: 'center',
                    lineHeight: '37',
                    fontWeight: 'normal'
                  },
                  value: '高教园区(西)',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'CF12A340-4804-433C-A116-46FAEDC8344B'
            }
          ],
          type: 'group',
          objectID: 'EA4B3CF7-66EA-40E2-97AE-C6AB02332543'
        },
        {
          name: 'Group 14 Copy 11',
          Id: 261,
          nameId: 'DC8FF5F2-AC8F-4968-B270-A2861DA536EA',
          frame: {
            width: 171,
            height: 64,
            x: 409,
            y: 672
          },
          layers: [
            {
              name: 'Rectangle 9',
              Id: 262,
              nameId: 'CA8D3BA0-9038-4490-9B6A-2175B7AD874B',
              frame: {
                width: 171,
                height: 64,
                x: 409,
                y: 672
              },
              styles: {
                backgroundColor: 'rgba(142,142,147,0.08)',
                borderRadius: 6
              },
              type: 'shape'
            },
            {
              name: 'Group 10',
              Id: 264,
              nameId: '8E994B72-DF4C-414F-8394-401B180A57E9',
              frame: {
                width: 131,
                height: 37,
                x: 429,
                y: 686
              },
              layers: [
                {
                  name: '合景蝶彩园',
                  Id: 265,
                  nameId: 'BB9F7C5D-7EA2-4980-AA5A-DAF07D7A05C2',
                  frame: {
                    width: 131,
                    height: 37,
                    x: 429,
                    y: 686
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 26,
                    color: '#222222',
                    textAlign: 'center',
                    lineHeight: '37',
                    fontWeight: 'normal'
                  },
                  value: '合景蝶彩园',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '8E994B72-DF4C-414F-8394-401B180A57E9'
            }
          ],
          type: 'group',
          objectID: 'DC8FF5F2-AC8F-4968-B270-A2861DA536EA'
        },
        {
          name: 'Group 14 Copy 13',
          Id: 267,
          nameId: '2E475BC5-F3CB-4A64-9BA0-D31BF3F9245D',
          frame: {
            width: 171,
            height: 64,
            x: 519,
            y: 756
          },
          layers: [
            {
              name: 'Rectangle 9',
              Id: 268,
              nameId: '163C81B6-9FC4-4912-BF19-A6F21BAFCC17',
              frame: {
                width: 171,
                height: 64,
                x: 519,
                y: 756
              },
              styles: {
                backgroundColor: 'rgba(142,142,147,0.08)',
                borderRadius: 6
              },
              type: 'shape'
            },
            {
              name: 'Group 10',
              Id: 270,
              nameId: 'C0F9B586-ED19-4194-A033-DE13109415D8',
              frame: {
                width: 131,
                height: 37,
                x: 539,
                y: 770
              },
              layers: [
                {
                  name: '苏泊尔大厦',
                  Id: 271,
                  nameId: '13684FBF-F470-4315-A285-6EB61153351A',
                  frame: {
                    width: 131,
                    height: 37,
                    x: 539,
                    y: 770
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 26,
                    color: '#222222',
                    textAlign: 'center',
                    lineHeight: '37',
                    fontWeight: 'normal'
                  },
                  value: '苏泊尔大厦',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'C0F9B586-ED19-4194-A033-DE13109415D8'
            }
          ],
          type: 'group',
          objectID: '2E475BC5-F3CB-4A64-9BA0-D31BF3F9245D'
        },
        {
          name: '附近推荐',
          Id: 272,
          nameId: 'E7F688D0-74DE-4872-9C3E-EB81908651B0',
          frame: {
            width: 112,
            height: 40,
            x: 40,
            y: 602
          },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: 28,
            color: '#888888',
            lineHeight: '40',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '附近推荐',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '55A5D4E2-2EA1-48E9-BE23-E6CCCC42CF6D'
    }
  ],
  nameId: 1528107260575,
  Id: 137,
  type: 'group',
  frame: {
    x: 0,
    y: 0,
    width: 750,
    height: 1334
  },
  styles: {
    backgroundColor: 'rgba(255,255,255,1)'
  }
}
