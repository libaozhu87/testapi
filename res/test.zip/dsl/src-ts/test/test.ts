import { flexbox } from './../index'
import input from './input-50'
function test() {
  flexbox(input, { debug: false })
}
test()
