export default {
  layers: [
    {
      textStyles: { color: '#222222', lineHeight: 33, fontSize: 33 },
      frame: { y: 37, x: 31, height: 32, width: 125 },
      type: 'text',
      id: 1,
      value: '同城闲置'
    },
    { frame: { y: 132, x: 42, height: 80, width: 80 }, type: 'image', id: 2, value: 'http://47.100.92.83:8081/ui/42_132_80_80_image.png' },
    {
      textStyles: { color: '#222222', lineHeight: 39, fontSize: 39 },
      frame: { y: 139, x: 139, height: 31, width: 69 },
      type: 'text',
      id: 3,
      value: 'sany'
    },
    {
      styles: {
        opacity: 1,
        borderColor: 'rgba(56,173,255,1)',
        borderRadius: 4,
        borderWidth: 1,
        backgroundColor: 'rgba(245,251,255,1)',
        borderStyle: 'solid'
      },
      frame: { y: 137, x: 216, height: 28, width: 96 },
      type: 'shape',
      id: 4
    },
    {
      textStyles: { color: '#999999', lineHeight: 23, fontSize: 23 },
      frame: { y: 181, x: 139, height: 24, width: 132 },
      type: 'text',
      id: 5,
      value: '2分钟前来过'
    },
    {
      textStyles: { color: '#ff4444', lineHeight: 28, fontSize: 28 },
      frame: { y: 147, x: 613, height: 19, width: 15 },
      type: 'text',
      id: 6,
      value: '¥'
    },
    {
      textStyles: { color: '#ff4444', lineHeight: 36, fontSize: 36 },
      frame: { y: 138, x: 632, height: 29, width: 78 },
      type: 'text',
      id: 7,
      value: '31'
    },
    {
      frame: { y: 236, x: 36, height: 232, width: 233 },
      type: 'image',
      id: 8,
      value: 'http://47.100.92.83:8081/ui/36_236_233_232_image.png'
    },
    {
      frame: { y: 234, x: 275, height: 233, width: 233 },
      type: 'image',
      id: 9,
      value: 'http://47.100.92.83:8081/ui/275_234_233_233_image.png'
    },
    {
      frame: { y: 234, x: 516, height: 233, width: 233 },
      type: 'image',
      id: 10,
      value: 'http://47.100.92.83:8081/ui/516_234_233_233_image.png'
    },
    {
      textStyles: { color: '#222222', lineHeight: 28, fontSize: 28 },
      frame: { y: 507, x: 40, height: 30, width: 650 },
      type: 'text',
      id: 11,
      value: '美国常回的正品速石福。 不议价， 接受再拍。 质量非'
    },
    {
      textStyles: { color: '#222222', lineHeight: 28, fontSize: 28 },
      frame: { y: 549, x: 41, height: 30, width: 294 },
      type: 'text',
      id: 12,
      value: '常好的， 没有任何问题。'
    },
    {
      styles: {
        opacity: 1,
        borderColor: 'rgba(255,220,82,1)',
        borderRadius: 0,
        borderWidth: 2,
        backgroundColor: 'rgba(255,218,68,1)',
        borderStyle: 'solid'
      },
      frame: { y: 607, x: 43, height: 74, width: 4 },
      type: 'shape',
      id: 13
    },
    {
      textStyles: { color: '#999999', lineHeight: 28, fontSize: 28 },
      frame: { y: 608, x: 62, height: 29, width: 398 },
      type: 'text',
      id: 14,
      value: '主人回复： 原装正品， 最低价了'
    },
    {
      textStyles: { color: '#999999', lineHeight: 28, fontSize: 28 },
      frame: { y: 653, x: 62, height: 27, width: 601 },
      type: 'text',
      id: 15,
      value: '爱晒太阳的清风： 真货假货? 能不能再便宜点呢'
    },
    {
      textStyles: { color: '#999999', lineHeight: 28, fontSize: 28 },
      frame: { y: 672, x: 654, height: 4, width: 4 },
      type: 'text',
      id: 16,
      value: '.'
    },
    {
      styles: {
        opacity: 1,
        borderColor: 'rgba(-1,-1,-1,1)',
        borderRadius: -1,
        borderWidth: -1,
        backgroundColor: 'rgba(244,244,244,1)',
        borderStyle: 'solid'
      },
      frame: { y: 711, x: 41, height: 2, width: 671 },
      type: 'shape',
      id: 17
    },
    {
      textStyles: { color: '#969696', lineHeight: 24, fontSize: 24 },
      frame: { y: 745, x: 41, height: 24, width: 198 },
      type: 'text',
      id: 18,
      value: '来自杭州市 余杭区'
    },
    {
      textStyles: { color: '#999999', lineHeight: 23, fontSize: 23 },
      frame: { y: 742, x: 527, height: 24, width: 184 },
      type: 'text',
      id: 19,
      value: '点赞30 n 留言44'
    }
  ],
  type: 'group',
  frame: { y: 0, x: 0, height: 801, width: 754 },
  nameId: 1525943133642,
  id: 0
}
