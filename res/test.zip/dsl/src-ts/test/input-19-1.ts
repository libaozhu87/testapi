export default {
  layers: [
    {
      name: 'Rectangle 5 Copy 5',
      Id: 219,
      nameId: 'A0489084-6882-4C87-829D-09C42A448588',
      frame: { width: 750, height: 88, x: 0, y: 10 },
      layers: [
        {
          name: 'Group',
          Id: 221,
          nameId: '0C5F5A80-72D5-42AB-8F15-CB8533ABA2C3',
          frame: { width: 276, height: 50, x: 30, y: 32 },
          layers: [
            {
              name: 'Bitmap',
              Id: 222,
              nameId: 'CDC4BA38-7EF8-4132-962E-2AA5E3C7BB4F',
              frame: { width: 40, height: 40, x: 266, y: 34 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1zvS8ppuWBuNjSszbXXcS7FXa-40-40.png'
            },
            {
              name: '今日品牌速卖',
              Id: 223,
              nameId: 'D40A15B9-B6B7-4BC8-AF28-CF3443E807AA',
              frame: { width: 217, height: 50, x: 30, y: 32 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '36',
                color: '#222222',
                lineHeight: '50',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '今日品牌速卖',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '0C5F5A80-72D5-42AB-8F15-CB8533ABA2C3'
        }
      ],
      type: 'group',
      objectID: 'A0489084-6882-4C87-829D-09C42A448588'
    },
    {
      name: 'Rectangle 4',
      Id: 225,
      nameId: 'C0F451EA-EB00-423B-A0E8-5EDC50B66704',
      frame: { width: 822, height: 360, x: 0, y: 98 },
      layers: [
        // {
        //   name: 'Rectangle 4',
        //   Id: 226,
        //   nameId: 'EC71E376-A455-4F02-A969-80110943FD2D',
        //   frame: { width: 750, height: 360, x: 0, y: 98 },
        //   styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
        //   type: 'shape'
        // },
        {
          name: 'Group',
          Id: 228,
          nameId: 'B8A79AC9-4204-43AE-9FAF-44EF61B3BAD1',
          frame: { width: 550, height: 128, x: 42, y: 118 },
          layers: [
            {
              name: 'Mask',
              Id: 230,
              nameId: '446A7824-D849-4461-ADAA-E00E7A718013',
              frame: { width: 128, height: 128, x: 42, y: 118 },
              layers: [
                {
                  name: 'Mask',
                  Id: 231,
                  nameId: '6AF68F8D-B901-4946-8D68-0A7547A7ADCE',
                  frame: { width: 128, height: 128, x: 42, y: 118 },
                  styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 232,
                  nameId: '423D6F96-2532-4021-9CDA-278D447DB3DB',
                  frame: { width: 102, height: 128, x: 56, y: 118 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1hgm8ppuWBuNjSszbXXcS7FXa-102-128.png'
                }
              ],
              type: 'group',
              objectID: '446A7824-D849-4461-ADAA-E00E7A718013'
            },
            {
              name: 'Mask',
              Id: 234,
              nameId: '059B6908-FF5B-4682-800B-17EF03D08A45',
              frame: { width: 128, height: 128, x: 252, y: 118 },
              layers: [
                {
                  name: 'Mask',
                  Id: 235,
                  nameId: 'BCCE6930-9096-40B4-99CC-9E4C7DD29EDA',
                  frame: { width: 128, height: 128, x: 252, y: 118 },
                  styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 236,
                  nameId: 'CAFC6545-0529-44B5-9A51-F274126C77C5',
                  frame: { width: 128, height: 96, x: 252, y: 136 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1Z3GHpAKWBuNjy1zjXXcOypXa-128-96.png'
                }
              ],
              type: 'group',
              objectID: '059B6908-FF5B-4682-800B-17EF03D08A45'
            },
            {
              name: 'Bitmap',
              Id: 237,
              nameId: 'D475540D-1A4D-4AEC-9519-3AFB5031604D',
              frame: { width: 128, height: 126, x: 464, y: 120 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1ELvSpxWYBuNjy1zkXXXGGpXa-128-126.png'
            }
          ],
          type: 'group',
          objectID: 'B8A79AC9-4204-43AE-9FAF-44EF61B3BAD1'
        },
        {
          name: 'Group',
          Id: 239,
          nameId: '015FF5CA-6DC6-452B-8207-41F459EC7396',
          frame: { width: 560, height: 40, x: 36, y: 262 },
          layers: [
            {
              name: '小白摄像头',
              Id: 240,
              nameId: '0875AF47-7472-4D1D-895B-56BC3A5F60E0',
              frame: { width: 140, height: 40, x: 36, y: 262 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'bold'
              },
              value: '小白摄像头',
              type: 'text'
            },
            {
              name: '小米扫地机',
              Id: 241,
              nameId: 'C5FF4EBA-F6A4-4B4F-AB1F-6E706905BD59',
              frame: { width: 140, height: 40, x: 246, y: 262 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'bold'
              },
              value: '小米扫地机',
              type: 'text'
            },
            {
              name: '小米Note2',
              Id: 242,
              nameId: 'B54B6E18-347A-4B80-8F70-2768EA339E0D',
              frame: { width: 136, height: 40, x: 460, y: 262 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'bold'
              },
              value: '小米Note2',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '015FF5CA-6DC6-452B-8207-41F459EC7396'
        },
        {
          name: 'Group',
          Id: 244,
          nameId: '45E4AF5A-FCCC-4824-9B48-D3DA1AF2FE95',
          frame: { width: 707, height: 37, x: 30, y: 308 },
          layers: [
            {
              name: '最高价',
              Id: 245,
              nameId: 'F5C67D35-EB6A-435D-AAB4-952EB8685117',
              frame: { width: 79, height: 37, x: 30, y: 308 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '26',
                color: '#888888',
                lineHeight: '37',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '最高价',
              type: 'text'
            },
            {
              name: '￥254',
              Id: 246,
              nameId: '83DC6143-C74D-4C6D-B755-32B0D3602D35',
              frame: { width: 73, height: 37, x: 110, y: 308 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '26',
                color: '#FF4444',
                lineHeight: '37',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '￥254',
              type: 'text'
            },
            {
              name: '最高价',
              Id: 247,
              nameId: '759C7C96-2D39-49F3-A5CF-B69CDE3527D2',
              frame: { width: 79, height: 37, x: 232, y: 308 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '26',
                color: '#888888',
                lineHeight: '37',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '最高价',
              type: 'text'
            },
            {
              name: '￥1200',
              Id: 248,
              nameId: '665C5F7C-04F3-41B0-B8F2-4CCFDFC6981F',
              frame: { width: 84, height: 37, x: 312, y: 308 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '26',
                color: '#FF4444',
                lineHeight: '37',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '￥1200',
              type: 'text'
            },
            {
              name: '最高价',
              Id: 249,
              nameId: '0BB7DE5A-BA5B-43FE-9E4D-FCAC82640C50',
              frame: { width: 79, height: 37, x: 446, y: 308 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '26',
                color: '#888888',
                lineHeight: '37',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '最高价',
              type: 'text'
            },
            {
              name: '￥1200',
              Id: 250,
              nameId: '35B19CEC-2261-4548-9167-66853592D527',
              frame: { width: 84, height: 37, x: 526, y: 308 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '26',
                color: '#FF4444',
                lineHeight: '37',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '￥1200',
              type: 'text'
            },
            {
              name: '最高价',
              Id: 251,
              nameId: 'CC4D1238-32B4-49B2-8D9B-85282F892215',
              frame: { width: 79, height: 37, x: 658, y: 308 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '26',
                color: '#888888',
                lineHeight: '37',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '最高价',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '45E4AF5A-FCCC-4824-9B48-D3DA1AF2FE95'
        },
        {
          name: 'Group',
          Id: 253,
          nameId: 'A9494A5C-E4E1-4D9C-99D7-C73492AC8EB8',
          frame: { width: 566, height: 64, x: 34, y: 364 },
          layers: [
            {
              name: 'Rectangle',
              Id: 255,
              nameId: 'B5F14AF7-D4D9-42EE-A523-E3AAF8F71B8B',
              frame: { width: 144, height: 64, x: 34, y: 364 },
              layers: [
                {
                  name: 'Rectangle',
                  Id: 256,
                  nameId: 'BC80ABB2-B4D1-4BC5-A2FD-43F2775BAB85',
                  frame: { width: 144, height: 64, x: 34, y: 364 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1b5a5pruWBuNjSszgXXb8jVXa-144-64.png'
                },
                {
                  name: '立即速卖',
                  Id: 257,
                  nameId: '4F9913FC-E3FB-478B-B1B0-5B7ED9AC9519',
                  frame: { width: 112, height: 40, x: 50, y: 376 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: '28',
                    color: '#FFFFFF',
                    textAlign: 'center',
                    lineHeight: '40',
                    fontWeight: 'bold'
                  },
                  value: '立即速卖',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'B5F14AF7-D4D9-42EE-A523-E3AAF8F71B8B'
            },
            {
              name: 'Rectangle',
              Id: 259,
              nameId: '1AB42AFD-29F6-4928-A37C-C78662C92FA7',
              frame: { width: 144, height: 64, x: 244, y: 364 },
              layers: [
                {
                  name: 'Rectangle',
                  Id: 260,
                  nameId: 'E990A722-4C1B-4D37-9D65-2722181C905B',
                  frame: { width: 144, height: 64, x: 244, y: 364 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1X4i8ppuWBuNjSszbXXcS7FXa-144-64.png'
                },
                {
                  name: '立即速卖',
                  Id: 261,
                  nameId: '3C16D080-5532-45A4-977E-04615B41A7C8',
                  frame: { width: 112, height: 40, x: 260, y: 376 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: '28',
                    color: '#FFFFFF',
                    textAlign: 'center',
                    lineHeight: '40',
                    fontWeight: 'bold'
                  },
                  value: '立即速卖',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '1AB42AFD-29F6-4928-A37C-C78662C92FA7'
            },
            {
              name: 'Rectangle',
              Id: 263,
              nameId: 'DAB0D920-BC3F-4EA3-A4B9-F6D2A827BEFB',
              frame: { width: 144, height: 64, x: 456, y: 364 },
              layers: [
                {
                  name: 'Rectangle',
                  Id: 264,
                  nameId: '6906DF97-DDD5-4ED3-9688-E4D0F258206A',
                  frame: { width: 144, height: 64, x: 456, y: 364 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1KzdapTJYBeNjy1zeXXahzVXa-144-64.png'
                },
                {
                  name: '立即速卖',
                  Id: 265,
                  nameId: 'D40F3C76-33C8-42FC-924F-FE1ADA2B1393',
                  frame: { width: 112, height: 40, x: 472, y: 376 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: '28',
                    color: '#FFFFFF',
                    textAlign: 'center',
                    lineHeight: '40',
                    fontWeight: 'bold'
                  },
                  value: '立即速卖',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'DAB0D920-BC3F-4EA3-A4B9-F6D2A827BEFB'
            }
          ],
          type: 'group',
          objectID: 'A9494A5C-E4E1-4D9C-99D7-C73492AC8EB8'
        },
        {
          name: 'Bitmap',
          Id: 266,
          nameId: '2CF63091-F9C5-483C-B258-F86317661AC3',
          frame: { width: 122, height: 86, x: 678, y: 138 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1hEgipDlYBeNjSszcXXbwhFXa-122-86.png'
        },
        {
          name: '小米Note2',
          Id: 267,
          nameId: '5EBB74BD-A549-4E5D-A67E-2296E2A4A091',
          frame: { width: 136, height: 40, x: 672, y: 262 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: '28',
            color: '#222222',
            textAlign: 'center',
            lineHeight: '40',
            fontWeight: 'bold'
          },
          value: '小米Note2',
          type: 'text'
        },
        {
          name: '￥1200',
          Id: 268,
          nameId: '5294C45D-5A9D-4D4B-B045-1E09E865C95B',
          frame: { width: 84, height: 37, x: 738, y: 308 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: '26',
            color: '#FF4444',
            lineHeight: '37',
            textAlign: 'left',
            fontWeight: 'bold'
          },
          value: '￥1200',
          type: 'text'
        },
        {
          name: 'Rectangle',
          Id: 270,
          nameId: 'D7012040-8303-4881-A270-65A54B4D3485',
          frame: { width: 144, height: 64, x: 668, y: 364 },
          layers: [
            {
              name: 'Rectangle',
              Id: 271,
              nameId: '06C38FDD-BF41-45A1-A346-C6C428A0A7FF',
              frame: { width: 144, height: 64, x: 668, y: 364 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1RBG_pr1YBuNjSszeXXablFXa-144-64.png'
            },
            {
              name: '立即速卖',
              Id: 272,
              nameId: '7DA4FAD3-B1F5-451A-ADB0-2C3AC586B350',
              frame: { width: 112, height: 40, x: 684, y: 376 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '28',
                color: '#FFFFFF',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'bold'
              },
              value: '立即速卖',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: 'D7012040-8303-4881-A270-65A54B4D3485'
        }
      ],
      type: 'group',
      objectID: 'C0F451EA-EB00-423B-A0E8-5EDC50B66704'
    }
  ],
  nameId: 1525333664856,
  Id: 217,
  type: 'group',
  frame: { x: 0, y: 0, width: 820, height: 458 },
  styles: { backgroundColor: 'rgba(255,255,255,1)' }
}
