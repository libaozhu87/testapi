export default {
  layers: [
    {
      name: 'Group 48',
      Id: 3,
      nameId: 'C844A624-439B-4ADE-84E5-846A276C3593',
      frame: { width: 822, height: 1270, x: 0, y: 156 },
      layers: [
        {
          name: 'Banner',
          Id: 5,
          nameId: '6AE75C1A-B799-474F-BCD7-2A46025B3AAC',
          frame: { width: 750, height: 322, x: 0, y: 156 },
          layers: [
            {
              name: 'Bitmap',
              Id: 6,
              nameId: '1692948B-E2AB-4E3C-B598-6F6AD97987BF',
              frame: { width: 750, height: 240, x: 0, y: 218 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1SWkouxSYBuNjSsphXXbGvVXa-750-240.png'
            },
            {
              name: 'Group 36',
              Id: 8,
              nameId: 'D5EF8487-5A04-4DEF-A73E-05951B64A901',
              frame: { width: 750, height: 322, x: 0, y: 156 },
              layers: [
                {
                  name: 'Group 34',
                  Id: 10,
                  nameId: '5BD82038-23FB-4444-9C85-952BEDD2BF8C',
                  frame: { width: 750, height: 302, x: 0, y: 156 },
                  layers: [
                    {
                      name: 'Group 17',
                      Id: 12,
                      nameId: 'D8A2F2C8-587E-4EDB-853E-E85EAD2AAE80',
                      frame: { width: 750, height: 240, x: 0, y: 218 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 13,
                          nameId: 'AD87307E-F929-4632-A510-7ACCD94F5A9E',
                          frame: { width: 750, height: 240, x: 0, y: 218 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1aiJLuGmWBuNjy1XaXXXCbXXa-750-240.png'
                        }
                      ],
                      type: 'group',
                      objectID: 'D8A2F2C8-587E-4EDB-853E-E85EAD2AAE80'
                    },
                    {
                      name: 'Group 68 Copy',
                      Id: 15,
                      nameId: 'ABCB6BE4-E0C1-4CFB-AF60-067111E66E1A',
                      frame: { width: 110.2998280519223, height: 94.12902366407374, x: 93.14110889076937, y: 156.69531100304576 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 17,
                          nameId: 'F143A529-4A09-4DB9-9604-513D3BC7C539',
                          frame: { width: 110.2998280519223, height: 94.12902366407374, x: 93.14110889076937, y: 156.69531100304573 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 18,
                              nameId: '3176E3CC-42FB-4EAF-947E-5C4C90D2350C',
                              frame: { width: 109.17038688222078, height: 92.9995824943721, x: 93.73629174269763, y: 157.4009803778223 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1DDymuStYBeNjSspaXXaOOFXa-109-93.png'
                            }
                          ],
                          type: 'group',
                          objectID: 'F143A529-4A09-4DB9-9604-513D3BC7C539'
                        },
                        {
                          name: 'Group 62 Copy 3',
                          Id: 20,
                          nameId: 'FFF4D511-9E23-45C6-88B3-22F18C4CF70E',
                          frame: { width: 35.56936866459114, height: 38.97374853571699, x: 98.29051362629161, y: 202.93817351272833 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 21,
                              nameId: '1A887DCC-95E5-4102-B7D4-BB826B77E767',
                              frame: { width: 34.43992749488916, height: 37.84430736601536, x: 98.88569647822032, y: 203.6438428875049 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1YcZJuAyWBuNjy0FpXXassXXa-34-38.png'
                            }
                          ],
                          type: 'group',
                          objectID: 'FFF4D511-9E23-45C6-88B3-22F18C4CF70E'
                        }
                      ],
                      type: 'group',
                      objectID: 'ABCB6BE4-E0C1-4CFB-AF60-067111E66E1A'
                    },
                    {
                      name: 'Combined Shape Copy 2',
                      Id: 23,
                      nameId: 'C2002FFC-7086-44CA-AC94-1569DAD2DBE2',
                      frame: { width: 46, height: 94, x: 0, y: 218 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 24,
                          nameId: '406ABFBA-810E-4985-A48D-93AD266CBA2A',
                          frame: { width: 46, height: 94, x: 0, y: 218 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1mF.NuA9WBuNjSspeXXaz5VXa-46-94.png'
                        }
                      ],
                      type: 'group',
                      objectID: 'C2002FFC-7086-44CA-AC94-1569DAD2DBE2'
                    }
                  ],
                  type: 'group',
                  objectID: '5BD82038-23FB-4444-9C85-952BEDD2BF8C'
                },
                {
                  name: 'Group 46 Copy',
                  Id: 26,
                  nameId: 'B6D17EBE-1532-421B-A440-20C007E8B93D',
                  frame: { width: 74, height: 74, x: 42, y: 358 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 27,
                      nameId: '70CA64AC-FB95-4B3B-A8F3-AE10CA1F2BC2',
                      frame: { width: 74, height: 74, x: 42, y: 358 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1js3JuAyWBuNjy0FpXXassXXa-74-74.png'
                    },
                    {
                      name: 'Bitmap',
                      Id: 28,
                      nameId: '1DBB4270-B9B9-4435-9E58-3BFB89A62C4E',
                      frame: { width: 71, height: 72, x: 44, y: 359 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1n_CmuStYBeNjSspaXXaOOFXa-71-72.png'
                    }
                  ],
                  type: 'group',
                  objectID: 'B6D17EBE-1532-421B-A440-20C007E8B93D'
                },
                {
                  name: 'Rectangle 20',
                  Id: 29,
                  nameId: '5189B0ED-4A75-4D37-B834-577600BC4AC4',
                  frame: { width: 750, height: 56, x: 0, y: 402 },
                  styles: { backgroundColor: 'rgba(0,0,0,0.1)' },
                  type: 'shape'
                },
                {
                  name: 'Group 28',
                  Id: 31,
                  nameId: '438AFCA2-C237-450E-80E9-EFDEDE3D157B',
                  frame: { width: 692, height: 37, x: 30, y: 412 },
                  layers: [
                    {
                      name: 'Group 6',
                      Id: 33,
                      nameId: '25F3A126-CF71-443E-AA5F-F69CCDDCC6A7',
                      frame: { width: 260, height: 37, x: 30, y: 412 },
                      layers: [
                        {
                          name: '速卖流程：在线估价',
                          Id: 34,
                          nameId: 'BEBF91E9-ABDA-49E0-AB27-37548ABF26BD',
                          frame: { width: 242, height: 37, x: 30, y: 412 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: 27,
                            color: '#FFFFFF',
                            textAlign: 'right',
                            lineHeight: '37',
                            fontWeight: 'normal'
                          },
                          value: '速卖流程：在线估价',
                          type: 'text'
                        },
                        {
                          name: 'Bitmap',
                          Id: 35,
                          nameId: '8620DB2D-725E-4AEA-9484-8671BDBBF80D',
                          frame: { width: 13, height: 23, x: 277, y: 420 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1EI3JuAyWBuNjy0FpXXassXXa-13-23.png'
                        }
                      ],
                      type: 'group',
                      objectID: '25F3A126-CF71-443E-AA5F-F69CCDDCC6A7'
                    },
                    {
                      name: 'Group 6 Copy 2',
                      Id: 37,
                      nameId: '4AA9EE7B-406A-46CD-BAED-F49F1ED2B4DA',
                      frame: { width: 126, height: 37, x: 482, y: 412 },
                      layers: [
                        {
                          name: '等待质检',
                          Id: 38,
                          nameId: '8134F650-CC25-4AA9-86AD-2BA56322F19A',
                          frame: { width: 108, height: 37, x: 482, y: 412 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: 27,
                            color: '#FFFFFF',
                            textAlign: 'right',
                            lineHeight: '37',
                            fontWeight: 'normal'
                          },
                          value: '等待质检',
                          type: 'text'
                        },
                        {
                          name: 'Bitmap',
                          Id: 39,
                          nameId: 'A79693B4-44DA-489C-A804-8F757D638230',
                          frame: { width: 13, height: 23, x: 595, y: 420 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1bbMAuuGSBuNjSspbXXciipXa-13-23.png'
                        }
                      ],
                      type: 'group',
                      objectID: '4AA9EE7B-406A-46CD-BAED-F49F1ED2B4DA'
                    },
                    {
                      name: 'Group 6 Copy 3',
                      Id: 41,
                      nameId: '4297ABF9-4759-4C7F-BF44-296BF368EAD7',
                      frame: { width: 108, height: 37, x: 614, y: 412 },
                      layers: [
                        {
                          name: '结算尾款',
                          Id: 42,
                          nameId: '72FA371D-B1CE-4DC1-9B7B-ADF8A63B0F4F',
                          frame: { width: 108, height: 37, x: 614, y: 412 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: 27,
                            color: '#FFFFFF',
                            textAlign: 'right',
                            lineHeight: '37',
                            fontWeight: 'normal'
                          },
                          value: '结算尾款',
                          type: 'text'
                        }
                      ],
                      type: 'group',
                      objectID: '4297ABF9-4759-4C7F-BF44-296BF368EAD7'
                    },
                    {
                      name: 'Group 6 Copy',
                      Id: 44,
                      nameId: '60F2AAB5-DA65-4E33-B5F8-1D157AEF1E88',
                      frame: { width: 180, height: 37, x: 295, y: 412 },
                      layers: [
                        {
                          name: '下单收预付款',
                          Id: 45,
                          nameId: '9FE916A0-8C7A-47E3-8C4D-E0F3FC2F3029',
                          frame: { width: 161, height: 37, x: 295, y: 412 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: 27,
                            color: '#FFFFFF',
                            textAlign: 'right',
                            lineHeight: '37',
                            fontWeight: 'normal'
                          },
                          value: '下单收预付款',
                          type: 'text'
                        },
                        {
                          name: 'Bitmap',
                          Id: 46,
                          nameId: '203F41CD-A22D-4B8D-A8EA-A01364C5170A',
                          frame: { width: 13, height: 23, x: 462, y: 420 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1JtwrurGYBuNjy0FoXXciBFXa-13-23.png'
                        }
                      ],
                      type: 'group',
                      objectID: '60F2AAB5-DA65-4E33-B5F8-1D157AEF1E88'
                    }
                  ],
                  type: 'group',
                  objectID: '438AFCA2-C237-450E-80E9-EFDEDE3D157B'
                },
                {
                  name: 'Group 45',
                  Id: 48,
                  nameId: '93A7D5D2-12B5-4250-AD44-F0B53F64EE9E',
                  frame: { width: 472, height: 176, x: 140, y: 302 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 49,
                      nameId: 'F45BDF4B-5ED9-4972-8392-5FCD145A799E',
                      frame: { width: 472, height: 42, x: 140, y: 302 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1.olfuHSYBuNjSspfXXcZCpXa-472-42.png'
                    },
                    {
                      name: 'Group 68',
                      Id: 51,
                      nameId: '5A5FE3A7-98CD-489D-B80E-FF86CFE6F39F',
                      frame: { width: 53.82613289809888, height: 58.32040955154025, x: 243.26007351067005, y: 324.18712449379495 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 52,
                          nameId: '707300C2-8E16-4ACE-A182-68C63C6EA116',
                          frame: { width: 49.42346521284776, height: 50.297352339905615, x: 243.8755811396918, y: 325.3633264742815 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB12twrurGYBuNjy0FoXXciBFXa-49-50.png'
                        },
                        {
                          name: 'Bitmap',
                          Id: 53,
                          nameId: '61D0240C-5CF4-46E6-83BA-1F6BBBF13F0B',
                          frame: { width: 38.68124523688721, height: 45.74367997800948, x: 258.40496117188195, y: 332.7466331404513 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1RHMAuuGSBuNjSspbXXciipXa-39-46.png'
                        }
                      ],
                      type: 'group',
                      objectID: '5A5FE3A7-98CD-489D-B80E-FF86CFE6F39F'
                    },
                    {
                      name: 'Group 68 Copy 2',
                      Id: 55,
                      nameId: '80F87B6D-BE53-4201-BB88-F8353E213958',
                      frame: { width: 52.61407045376927, height: 51.972030931849076, x: 497.6439316286469, y: 425.1153829007468 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 57,
                          nameId: '746E2AA8-CBF8-4496-96B8-C360B17B2D75',
                          frame: { width: 52.61407045376927, height: 51.972030931849076, x: 497.6439316286469, y: 425.1153829007468 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 58,
                              nameId: 'F526D9DD-6A97-455B-B64F-215898FE80FD',
                              frame: { width: 52.305053459394, height: 51.02097441555395, x: 497.84112587430263, y: 425.7222843842259 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1ldArurGYBuNjy0FoXXciBFXa-52-51.png'
                            }
                          ],
                          type: 'group',
                          objectID: '746E2AA8-CBF8-4496-96B8-C360B17B2D75'
                        },
                        {
                          name: 'Group 62 Copy 3',
                          Id: 60,
                          nameId: '43CECD82-BF14-4F31-B78F-36F9A01A7575',
                          frame: { width: 26.461543724071817, height: 26.4615437240721, x: 510.0076663404843, y: 427.5875188557463 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 61,
                              nameId: '0614294B-AD3E-4264-ABDA-D465FFF11594',
                              frame: { width: 26.152526729697, height: 25.510487207777032, x: 510.20486058614006, y: 428.1944203392254 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1DQUvuv5TBuNjSspcXXbnGFXa-26-26.png'
                            }
                          ],
                          type: 'group',
                          objectID: '43CECD82-BF14-4F31-B78F-36F9A01A7575'
                        }
                      ],
                      type: 'group',
                      objectID: '80F87B6D-BE53-4201-BB88-F8353E213958'
                    }
                  ],
                  type: 'group',
                  objectID: '93A7D5D2-12B5-4250-AD44-F0B53F64EE9E'
                },
                {
                  name: 'Group 46',
                  Id: 63,
                  nameId: '105EDD2E-6363-4A9F-9D4F-14E97F5D10A1',
                  frame: { width: 75, height: 74, x: 616, y: 244 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 64,
                      nameId: '9F059D29-7615-48A3-A372-25B0AB95758D',
                      frame: { width: 73.625, height: 73.625, x: 616.6342070827677, y: 244.1966058144606 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1DPNbuNGYBuNjy0FnXXX5lpXa-74-74.png'
                    },
                    {
                      name: 'Bitmap',
                      Id: 65,
                      nameId: '98FB0520-1070-4573-B345-1BC57A47338D',
                      frame: { width: 71, height: 72, x: 618, y: 245 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1OYgAupuWBuNjSszbXXcS7FXa-71-72.png'
                    }
                  ],
                  type: 'group',
                  objectID: '105EDD2E-6363-4A9F-9D4F-14E97F5D10A1'
                },
                {
                  name: 'Bitmap',
                  Id: 66,
                  nameId: '050DC396-73E2-4C83-9AE9-4E524DC8DF3F',
                  frame: { width: 93, height: 166, x: 656, y: 279 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB116NbuNGYBuNjy0FnXXX5lpXa-93-166.png'
                }
              ],
              type: 'group',
              objectID: 'D5EF8487-5A04-4DEF-A73E-05951B64A901'
            }
          ],
          type: 'group',
          objectID: '6AE75C1A-B799-474F-BCD7-2A46025B3AAC'
        },
        {
          name: 'Group 10',
          Id: 68,
          nameId: '8AF2C653-18AD-4243-98FF-E403C5CA7BD4',
          frame: { width: 750, height: 412, x: 0, y: 458 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 69,
              nameId: '45AEABB4-6DF0-44DA-BA72-5005D2F01672',
              frame: { width: 750, height: 412, x: 0, y: 458 },
              styles: { backgroundColor: 'rgba(255,255,255,1)' },
              type: 'shape'
            },
            {
              name: 'Group 9',
              Id: 71,
              nameId: '3A315034-4136-4051-8065-05DF6E15D13E',
              frame: { width: 684, height: 352, x: 26, y: 488 },
              layers: [
                {
                  name: 'Group 7 Copy 10',
                  Id: 73,
                  nameId: 'D1BC7F27-3C43-4060-8663-A5734E0CB757',
                  frame: { width: 140, height: 162, x: 212, y: 678 },
                  layers: [
                    {
                      name: 'Group 8',
                      Id: 75,
                      nameId: '32D12886-4A3A-4D86-9697-2E0EAEDD0AC1',
                      frame: { width: 114, height: 112, x: 226, y: 678 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 76,
                          nameId: '8A3C29DF-3EDF-4DD4-A3B5-C445E7AB9EB2',
                          frame: { width: 112, height: 112, x: 228, y: 678 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1mAZvuv5TBuNjSspcXXbnGFXa-112-112.png'
                        },
                        {
                          name: 'Bitmap',
                          Id: 77,
                          nameId: '1AB0FE7E-4988-4987-A413-9C361AEC544E',
                          frame: { width: 70, height: 84, x: 248, y: 694 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1mjRbuNGYBuNjy0FnXXX5lpXa-70-84.png'
                        }
                      ],
                      type: 'group',
                      objectID: '32D12886-4A3A-4D86-9697-2E0EAEDD0AC1'
                    },
                    {
                      name: '卖智能设备',
                      Id: 78,
                      nameId: '219F3E06-2524-4BD8-8813-F44653479937',
                      frame: { width: 140, height: 40, x: 212, y: 800 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '40',
                        fontWeight: 'normal'
                      },
                      value: '卖智能设备',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'D1BC7F27-3C43-4060-8663-A5734E0CB757'
                },
                {
                  name: 'Group 7 Copy 6',
                  Id: 80,
                  nameId: 'C769CC4A-13F5-4A4D-B6E0-30D42CA2BEA5',
                  frame: { width: 140, height: 162, x: 26, y: 678 },
                  layers: [
                    {
                      name: 'Group 8',
                      Id: 82,
                      nameId: 'C57D67CF-D8E2-4D5C-8BC8-A5C2FA43454A',
                      frame: { width: 112, height: 112, x: 40, y: 678 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 83,
                          nameId: 'DD3024E6-4AD8-4C1D-8EEB-7A1BAF31408A',
                          frame: { width: 112, height: 112, x: 40, y: 678 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1CpHVupmWBuNjSspdXXbugXXa-112-112.png'
                        },
                        {
                          name: 'Bitmap',
                          Id: 85,
                          nameId: '35D4A8A9-0FDD-4869-93B6-DD600B2EAB46',
                          frame: { width: 66, height: 90, x: 62, y: 700 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 86,
                              nameId: 'EA1AA1C3-8BA8-4C45-839E-82B2E442EE48',
                              frame: { width: 66, height: 90, x: 62, y: 700 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1Xf7DuuSSBuNjy0FlXXbBpVXa-66-90.png'
                            }
                          ],
                          type: 'group',
                          objectID: '35D4A8A9-0FDD-4869-93B6-DD600B2EAB46'
                        }
                      ],
                      type: 'group',
                      objectID: 'C57D67CF-D8E2-4D5C-8BC8-A5C2FA43454A'
                    },
                    {
                      name: '卖家具家电',
                      Id: 87,
                      nameId: '8C0EBFAE-0D22-4FA5-8F6A-139EA6F90AD3',
                      frame: { width: 140, height: 40, x: 26, y: 800 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '40',
                        fontWeight: 'normal'
                      },
                      value: '卖家具家电',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'C769CC4A-13F5-4A4D-B6E0-30D42CA2BEA5'
                },
                {
                  name: 'Group 39',
                  Id: 89,
                  nameId: '787D74A1-F997-424D-B9A5-2026AF04CBB6',
                  frame: { width: 670, height: 162, x: 40, y: 488 },
                  layers: [
                    {
                      name: 'Group 7',
                      Id: 91,
                      nameId: '6C5BE7BE-4655-4389-B53A-BBA2DA656C04',
                      frame: { width: 112, height: 158, x: 40, y: 492 },
                      layers: [
                        {
                          name: 'Group 8',
                          Id: 93,
                          nameId: '34B4794E-85F6-4D93-81A8-9C7A1D4979F5',
                          frame: { width: 112, height: 112, x: 40, y: 492 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 94,
                              nameId: '127C2898-5527-42D1-A67A-26F7F4F65EDF',
                              frame: { width: 112, height: 112, x: 40, y: 492 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB16.gXuAKWBuNjy1zjXXcOypXa-112-112.png'
                            },
                            {
                              name: 'Bitmap',
                              Id: 96,
                              nameId: '7484F307-148A-4E41-924E-CD160702AE43',
                              frame: { width: 66, height: 92, x: 64, y: 512 },
                              layers: [
                                {
                                  name: 'Bitmap',
                                  Id: 97,
                                  nameId: '98874AB1-2F0E-4D89-BA89-372BC1D05B1B',
                                  frame: { width: 66, height: 92, x: 64, y: 512 },
                                  imageStyles: { resize: 'stretch' },
                                  type: 'image',
                                  value: 'https://gw.alicdn.com/tfs/TB1vf7DuuSSBuNjy0FlXXbBpVXa-66-92.png'
                                }
                              ],
                              type: 'group',
                              objectID: '7484F307-148A-4E41-924E-CD160702AE43'
                            }
                          ],
                          type: 'group',
                          objectID: '34B4794E-85F6-4D93-81A8-9C7A1D4979F5'
                        },
                        {
                          name: '卖手机',
                          Id: 98,
                          nameId: 'FFA89A44-F1D6-4BC4-B935-5DC8E3A1C967',
                          frame: { width: 84, height: 40, x: 54, y: 610 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: 28,
                            color: '#222222',
                            textAlign: 'center',
                            lineHeight: '40',
                            fontWeight: 'normal'
                          },
                          value: '卖手机',
                          type: 'text'
                        }
                      ],
                      type: 'group',
                      objectID: '6C5BE7BE-4655-4389-B53A-BBA2DA656C04'
                    },
                    {
                      name: 'Group 7 Copy',
                      Id: 100,
                      nameId: 'EE16AD0E-8BCB-45FE-9F78-C6015A37FDB2',
                      frame: { width: 112, height: 162, x: 226, y: 488 },
                      layers: [
                        {
                          name: 'Group 8',
                          Id: 102,
                          nameId: 'DBEF9A5A-2888-48D1-8E12-D2FD38621387',
                          frame: { width: 112, height: 116, x: 226, y: 488 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 103,
                              nameId: '6B1FC829-CACC-4E33-A100-5AE4C92FE41A',
                              frame: { width: 112, height: 112, x: 226, y: 492 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1fVLVupmWBuNjSspdXXbugXXa-112-112.png'
                            },
                            {
                              name: 'Bitmap',
                              Id: 105,
                              nameId: '22F00D9E-6944-4E5C-8B3D-BB508232AFC8',
                              frame: { width: 82, height: 90, x: 240, y: 514 },
                              layers: [
                                {
                                  name: 'Bitmap',
                                  Id: 106,
                                  nameId: 'A529A30D-002B-47B1-9715-E75974247AF1',
                                  frame: { width: 82, height: 90, x: 240, y: 514 },
                                  imageStyles: { resize: 'stretch' },
                                  type: 'image',
                                  value: 'https://gw.alicdn.com/tfs/TB1Rf7DuuSSBuNjy0FlXXbBpVXa-82-90.png'
                                }
                              ],
                              type: 'group',
                              objectID: '22F00D9E-6944-4E5C-8B3D-BB508232AFC8'
                            }
                          ],
                          type: 'group',
                          objectID: 'DBEF9A5A-2888-48D1-8E12-D2FD38621387'
                        },
                        {
                          name: '卖平板',
                          Id: 107,
                          nameId: '15152B97-1D63-4699-B33F-5AB2C6DC23F3',
                          frame: { width: 84, height: 40, x: 240, y: 610 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: 28,
                            color: '#222222',
                            textAlign: 'center',
                            lineHeight: '40',
                            fontWeight: 'normal'
                          },
                          value: '卖平板',
                          type: 'text'
                        }
                      ],
                      type: 'group',
                      objectID: 'EE16AD0E-8BCB-45FE-9F78-C6015A37FDB2'
                    },
                    {
                      name: 'Group 7 Copy 2',
                      Id: 109,
                      nameId: '30A48A54-7F32-49A5-A4FC-CEA89B23EA00',
                      frame: { width: 112, height: 162, x: 412, y: 488 },
                      layers: [
                        {
                          name: 'Group 8',
                          Id: 111,
                          nameId: 'D6C82182-FF57-46BF-9D4F-87FD2ED8D025',
                          frame: { width: 112, height: 116, x: 412, y: 488 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 112,
                              nameId: '9A2C6A85-C3E3-4018-9D32-629735A15609',
                              frame: { width: 112, height: 112, x: 412, y: 492 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB15qkNuA9WBuNjSspeXXaz5VXa-112-112.png'
                            },
                            {
                              name: 'Bitmap',
                              Id: 113,
                              nameId: 'C0AE1159-CBB1-4D40-8EF1-82E0649703D0',
                              frame: { width: 96, height: 66, x: 420, y: 516 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1GHdAuL1TBuNjy0FjXXajyXXa-96-66.png'
                            }
                          ],
                          type: 'group',
                          objectID: 'D6C82182-FF57-46BF-9D4F-87FD2ED8D025'
                        },
                        {
                          name: '卖电脑',
                          Id: 114,
                          nameId: '18654BE6-F668-4129-8E99-51253B7B51CE',
                          frame: { width: 84, height: 40, x: 426, y: 610 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: 28,
                            color: '#222222',
                            textAlign: 'center',
                            lineHeight: '40',
                            fontWeight: 'normal'
                          },
                          value: '卖电脑',
                          type: 'text'
                        }
                      ],
                      type: 'group',
                      objectID: '30A48A54-7F32-49A5-A4FC-CEA89B23EA00'
                    },
                    {
                      name: 'Group 7 Copy 3',
                      Id: 116,
                      nameId: 'A2C3F0AD-9C51-4248-9FEE-AB731C0FDE06',
                      frame: { width: 114, height: 162, x: 596, y: 488 },
                      layers: [
                        {
                          name: 'Group 8',
                          Id: 118,
                          nameId: '9F734286-118F-4FEB-B6FF-CEA4A20300A6',
                          frame: { width: 114, height: 116, x: 596, y: 488 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 119,
                              nameId: '21AD3175-C5D8-4677-8043-DB2E42C8001F',
                              frame: { width: 112, height: 112, x: 596, y: 492 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1dbUAur1YBuNjSszeXXablFXa-112-112.png'
                            },
                            {
                              name: 'Bitmap Copy',
                              Id: 120,
                              nameId: '3FB9FC0C-5E12-461C-9B77-12FA4E4DE2F3',
                              frame: { width: 82, height: 84, x: 612, y: 508 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB16HdAuL1TBuNjy0FjXXajyXXa-82-84.png'
                            }
                          ],
                          type: 'group',
                          objectID: '9F734286-118F-4FEB-B6FF-CEA4A20300A6'
                        },
                        {
                          name: '卖相机',
                          Id: 121,
                          nameId: '0C3C6223-D0B5-4972-81CB-C6BC8E028094',
                          frame: { width: 84, height: 40, x: 612, y: 610 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: 28,
                            color: '#222222',
                            textAlign: 'center',
                            lineHeight: '40',
                            fontWeight: 'normal'
                          },
                          value: '卖相机',
                          type: 'text'
                        }
                      ],
                      type: 'group',
                      objectID: 'A2C3F0AD-9C51-4248-9FEE-AB731C0FDE06'
                    }
                  ],
                  type: 'group',
                  objectID: '787D74A1-F997-424D-B9A5-2026AF04CBB6'
                },
                {
                  name: 'Group 7 Copy 8',
                  Id: 123,
                  nameId: '8AE5F1F1-6EB3-45B9-A715-40A4E9160A31',
                  frame: { width: 140, height: 162, x: 398, y: 678 },
                  layers: [
                    {
                      name: 'Group 8',
                      Id: 125,
                      nameId: '829E28BE-4A8B-469B-A914-090711A1FBFF',
                      frame: { width: 112, height: 112, x: 412, y: 678 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 126,
                          nameId: 'B00E0CF8-3EA1-43AB-A6CA-D1296CCAFCA9',
                          frame: { width: 112, height: 112, x: 412, y: 678 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1LGoNuA9WBuNjSspeXXaz5VXa-112-112.png'
                        },
                        {
                          name: 'Bitmap',
                          Id: 128,
                          nameId: '947EADD3-CA5A-4FFD-97F7-F7AF355BDD66',
                          frame: { width: 81, height: 88, x: 436, y: 694 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 129,
                              nameId: '3335A524-8615-4DC7-9AC5-52EA3334D629',
                              frame: { width: 81, height: 88, x: 436, y: 694 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1rbhAuL1TBuNjy0FjXXajyXXa-81-88.png'
                            }
                          ],
                          type: 'group',
                          objectID: '947EADD3-CA5A-4FFD-97F7-F7AF355BDD66'
                        }
                      ],
                      type: 'group',
                      objectID: '829E28BE-4A8B-469B-A914-090711A1FBFF'
                    },
                    {
                      name: '卖运动器材',
                      Id: 130,
                      nameId: 'D4D21548-89E4-4C4F-B666-80EA15CF6EE5',
                      frame: { width: 140, height: 40, x: 398, y: 800 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '40',
                        fontWeight: 'normal'
                      },
                      value: '卖运动器材',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '8AE5F1F1-6EB3-45B9-A715-40A4E9160A31'
                },
                {
                  name: 'Group 7 Copy 9',
                  Id: 132,
                  nameId: 'B137E379-C623-4235-9FEE-F62B46634CE9',
                  frame: { width: 112, height: 164, x: 598, y: 676 },
                  layers: [
                    {
                      name: 'Group 8',
                      Id: 134,
                      nameId: '23962A15-F5F6-415D-94A3-2F78B8EAA382',
                      frame: { width: 112, height: 114, x: 598, y: 676 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 135,
                          nameId: 'B98A85B0-697A-4C9E-87C4-DFD40C0136CA',
                          frame: { width: 112, height: 112, x: 598, y: 678 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1YUBfuHSYBuNjSspfXXcZCpXa-112-112.png'
                        },
                        {
                          name: 'Bitmap',
                          Id: 136,
                          nameId: '8D0E36D2-B82E-499C-9962-C31CD8F0DA34',
                          frame: { width: 94, height: 94, x: 610, y: 696 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1aqstupOWBuNjy0FiXXXFxVXa-94-94.png'
                        }
                      ],
                      type: 'group',
                      objectID: '23962A15-F5F6-415D-94A3-2F78B8EAA382'
                    },
                    {
                      name: '卖乐器',
                      Id: 137,
                      nameId: '3105508F-78B9-4FE5-8260-75130C0645BD',
                      frame: { width: 84, height: 40, x: 612, y: 800 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '40',
                        fontWeight: 'normal'
                      },
                      value: '卖乐器',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'B137E379-C623-4235-9FEE-F62B46634CE9'
                }
              ],
              type: 'group',
              objectID: '3A315034-4136-4051-8065-05DF6E15D13E'
            }
          ],
          type: 'group',
          objectID: '8AF2C653-18AD-4243-98FF-E403C5CA7BD4'
        },
        {
          name: 'Group 7',
          Id: 139,
          nameId: '3D920A73-897A-4BEF-A56A-9DF592F7218E',
          frame: { width: 750, height: 88, x: 0, y: 870 },
          layers: [
            {
              name: 'Group 33',
              Id: 141,
              nameId: 'F27CE6A2-5CC0-437E-BFB7-B7F365A46DA0',
              frame: { width: 690, height: 56, x: 30, y: 886 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 142,
                  nameId: 'BB9D5987-4A35-481D-B70A-02739E7E38B1',
                  frame: { width: 56, height: 56, x: 30, y: 886 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1GIXAuNWYBuNjy1zkXXXGGpXa-56-56.png'
                },
                {
                  name: '卖了iPhone 7，赚了',
                  Id: 143,
                  nameId: '405335D5-8F91-4231-A7A8-98F89C96644F',
                  frame: { width: 235, height: 37, x: 106, y: 896 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 26,
                    color: '#888888',
                    lineHeight: '37',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '卖了iPhone 7，赚了',
                  type: 'text'
                },
                {
                  name: 'Bitmap',
                  Id: 144,
                  nameId: 'D2D054D7-BA70-45B3-84A9-2A7D83D31A66',
                  frame: { width: 148, height: 28, x: 436, y: 900 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1qGstupOWBuNjy0FiXXXFxVXa-148-28.png'
                },
                {
                  name: '3分钟前',
                  Id: 145,
                  nameId: 'B28B3CF9-F010-4074-A8BC-F8B8155942B5',
                  frame: { width: 72, height: 28, x: 648, y: 900 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 20,
                    color: '#888888',
                    textAlign: 'right',
                    lineHeight: '28',
                    fontWeight: 'normal'
                  },
                  value: '3分钟前',
                  type: 'text'
                },
                {
                  name: '￥2654',
                  Id: 146,
                  nameId: '4C2BD492-1ED2-4665-B84F-15C9288EA87D',
                  frame: { width: 89, height: 37, x: 342, y: 896 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: 26,
                    color: '#FF4444',
                    lineHeight: '37',
                    textAlign: 'left',
                    fontWeight: 'bold'
                  },
                  value: '￥2654',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'F27CE6A2-5CC0-437E-BFB7-B7F365A46DA0'
            }
          ],
          type: 'group',
          objectID: '3D920A73-897A-4BEF-A56A-9DF592F7218E'
        },
        {
          name: 'Rectangle 5 Copy 6',
          Id: 147,
          nameId: 'E9D1F0C8-B525-4820-BBBD-65AE95786A9E',
          frame: { width: 750, height: 10, x: 0, y: 958 },
          styles: { backgroundColor: 'rgba(243,245,249,1)' },
          type: 'shape'
        },
        {
          name: 'Group 22',
          Id: 149,
          nameId: '83BD005A-819C-43F8-BBA4-45043E1A1DCA',
          frame: { width: 822, height: 458, x: 0, y: 968 },
          layers: [
            {
              name: 'Group 19',
              Id: 151,
              nameId: '5830E29B-960B-4FCD-BFEA-F03B82F4C739',
              frame: { width: 88, height: 40, x: 266, y: 1002 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 152,
                  nameId: 'C63A5CA1-0DC6-47C9-86AE-CDD94C53AC38',
                  frame: { width: 40, height: 40, x: 266, y: 1002 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1IoFfuHSYBuNjSspfXXcZCpXa-40-40.png'
                }
              ],
              type: 'group',
              objectID: '5830E29B-960B-4FCD-BFEA-F03B82F4C739'
            },
            {
              name: '今日品牌速卖',
              Id: 153,
              nameId: 'DAD605E4-8072-45C7-A384-2E89B8C4F371',
              frame: { width: 217, height: 44, x: 30, y: 1000 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: 36,
                color: '#222222',
                lineHeight: '44',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '今日品牌速卖',
              type: 'text'
            },
            {
              name: 'Group 18',
              Id: 155,
              nameId: 'D31E1BFA-BC44-4D40-B046-F7AD7EA16642',
              frame: { width: 822, height: 360, x: 0, y: 1066 },
              layers: [
                {
                  name: 'Group 13',
                  Id: 157,
                  nameId: '02182E8D-8201-4F59-A3D5-F504208C3B06',
                  frame: { width: 792, height: 298, x: 30, y: 1086 },
                  layers: [
                    {
                      name: 'Group 12',
                      Id: 159,
                      nameId: 'DC52446D-D61C-424A-9107-1E87350926D2',
                      frame: { width: 153, height: 298, x: 30, y: 1086 },
                      layers: [
                        {
                          name: 'Group 14',
                          Id: 161,
                          nameId: '1CF6D345-551D-41BD-BB71-80FA4FA008C9',
                          frame: { width: 128, height: 128, x: 42, y: 1086 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 163,
                              nameId: 'B156AD77-CBAE-44E3-8328-A7FDEAE73B9B',
                              frame: { width: 102, height: 128, x: 56, y: 1086 },
                              layers: [
                                {
                                  name: 'Bitmap',
                                  Id: 164,
                                  nameId: 'E1051D8C-FC77-467C-9383-E888F7AD5372',
                                  frame: { width: 102, height: 128, x: 56, y: 1086 },
                                  imageStyles: { resize: 'stretch' },
                                  type: 'image',
                                  value: 'https://gw.alicdn.com/tfs/TB1PastupOWBuNjy0FiXXXFxVXa-102-128.png'
                                }
                              ],
                              type: 'group',
                              objectID: 'B156AD77-CBAE-44E3-8328-A7FDEAE73B9B'
                            }
                          ],
                          type: 'group',
                          objectID: '1CF6D345-551D-41BD-BB71-80FA4FA008C9'
                        },
                        {
                          name: '小白摄像头',
                          Id: 165,
                          nameId: 'A465D81E-5C79-4493-860D-4FC578F0F93E',
                          frame: { width: 140, height: 40, x: 36, y: 1230 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Medium',
                            fontSize: 28,
                            color: '#222222',
                            textAlign: 'center',
                            lineHeight: '40',
                            fontWeight: 'bold'
                          },
                          value: '小白摄像头',
                          type: 'text'
                        },
                        {
                          name: 'Group 11',
                          Id: 167,
                          nameId: '209F0EE5-9375-4D3A-9E2C-40E7A98D5DCD',
                          frame: { width: 153, height: 37, x: 30, y: 1276 },
                          layers: [
                            {
                              name: '最高价',
                              Id: 168,
                              nameId: '52BEE5E4-00A8-49F3-9901-65A176267788',
                              frame: { width: 79, height: 37, x: 30, y: 1276 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 26,
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '最高价',
                              type: 'text'
                            },
                            {
                              name: '￥254',
                              Id: 169,
                              nameId: '9DA209E4-0F96-4223-9BE0-080E43CD55A1',
                              frame: { width: 73, height: 37, x: 110, y: 1276 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 26,
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '￥254',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: '209F0EE5-9375-4D3A-9E2C-40E7A98D5DCD'
                        },
                        {
                          name: 'Group 16',
                          Id: 171,
                          nameId: 'EA76089C-06D2-4033-947E-39A75062F6D5',
                          frame: { width: 142, height: 52, x: 35, y: 1332 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 172,
                              nameId: '39C9A3AA-5689-463F-9B57-FE6EBBF361EC',
                              frame: { width: 142, height: 2, x: 35, y: 1332 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1ZbwAupuWBuNjSszbXXcS7FXa-142-2.png'
                            }
                          ],
                          type: 'group',
                          objectID: 'EA76089C-06D2-4033-947E-39A75062F6D5'
                        }
                      ],
                      type: 'group',
                      objectID: 'DC52446D-D61C-424A-9107-1E87350926D2'
                    },
                    {
                      name: 'Group 12 Copy',
                      Id: 174,
                      nameId: '87FEF67B-A832-4199-BE71-238BC53543D1',
                      frame: { width: 164, height: 298, x: 232, y: 1086 },
                      layers: [
                        {
                          name: 'Group 14',
                          Id: 176,
                          nameId: '6A8C6660-F5C6-4BB7-9A6E-0923D27A668B',
                          frame: { width: 128, height: 128, x: 252, y: 1086 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 178,
                              nameId: 'FCE87071-2B19-4DEE-BB4E-DC85CE9461B8',
                              frame: { width: 128, height: 96, x: 252, y: 1104 },
                              layers: [
                                {
                                  name: 'Bitmap',
                                  Id: 179,
                                  nameId: '27E46511-4BCC-45B7-8C92-3E77DE67D446',
                                  frame: { width: 128, height: 96, x: 252, y: 1104 },
                                  imageStyles: { resize: 'stretch' },
                                  type: 'image',
                                  value: 'https://gw.alicdn.com/tfs/TB1wNgYur9YBuNjy0FgXXcxcXXa-128-96.png'
                                }
                              ],
                              type: 'group',
                              objectID: 'FCE87071-2B19-4DEE-BB4E-DC85CE9461B8'
                            }
                          ],
                          type: 'group',
                          objectID: '6A8C6660-F5C6-4BB7-9A6E-0923D27A668B'
                        },
                        {
                          name: '小米扫地机',
                          Id: 180,
                          nameId: '18C4E1A0-3E72-4C4F-AA96-FE48EFD61B46',
                          frame: { width: 140, height: 40, x: 246, y: 1230 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Medium',
                            fontSize: 28,
                            color: '#222222',
                            textAlign: 'center',
                            lineHeight: '40',
                            fontWeight: 'bold'
                          },
                          value: '小米扫地机',
                          type: 'text'
                        },
                        {
                          name: 'Group 11',
                          Id: 182,
                          nameId: '6A49977F-F947-4D6C-BF33-0102D51F0052',
                          frame: { width: 164, height: 37, x: 232, y: 1276 },
                          layers: [
                            {
                              name: '最高价',
                              Id: 183,
                              nameId: '88E8AD81-4A92-4130-92E2-10B8F6733E32',
                              frame: { width: 79, height: 37, x: 232, y: 1276 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 26,
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '最高价',
                              type: 'text'
                            },
                            {
                              name: '￥1200',
                              Id: 184,
                              nameId: 'CBBA974C-0B68-427B-894A-96EDF04C92AE',
                              frame: { width: 84, height: 37, x: 312, y: 1276 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 26,
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '￥1200',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: '6A49977F-F947-4D6C-BF33-0102D51F0052'
                        },
                        {
                          name: 'Group 16',
                          Id: 186,
                          nameId: '5E5BBDFF-0977-4EF7-BCF2-8B1212630EEB',
                          frame: { width: 142, height: 52, x: 245, y: 1332 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 187,
                              nameId: '648E829C-C03A-4DA3-BC7E-088E0F9A7B5C',
                              frame: { width: 142, height: 2, x: 245, y: 1332 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1czRIuTlYBeNjSszcXXbwhFXa-142-2.png'
                            }
                          ],
                          type: 'group',
                          objectID: '5E5BBDFF-0977-4EF7-BCF2-8B1212630EEB'
                        }
                      ],
                      type: 'group',
                      objectID: '87FEF67B-A832-4199-BE71-238BC53543D1'
                    },
                    {
                      name: 'Group 12 Copy 2',
                      Id: 189,
                      nameId: '7EFA9696-C72F-4B43-8227-606CCC40C662',
                      frame: { width: 164, height: 298, x: 446, y: 1086 },
                      layers: [
                        {
                          name: 'Group 14',
                          Id: 191,
                          nameId: '1EAE9DF9-3532-44BB-BE5C-D113305E1D54',
                          frame: { width: 128, height: 128, x: 464, y: 1086 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 193,
                              nameId: '21FC36DB-F17A-4880-83E8-F59C3013A519',
                              frame: { width: 128, height: 126, x: 464, y: 1088 },
                              layers: [
                                {
                                  name: 'Bitmap',
                                  Id: 194,
                                  nameId: '18B04617-9C06-4A7A-A4FB-C12C9AB23321',
                                  frame: { width: 128, height: 126, x: 464, y: 1088 },
                                  imageStyles: { resize: 'stretch' },
                                  type: 'image',
                                  value: 'https://gw.alicdn.com/tfs/TB1VNgYur9YBuNjy0FgXXcxcXXa-128-126.png'
                                }
                              ],
                              type: 'group',
                              objectID: '21FC36DB-F17A-4880-83E8-F59C3013A519'
                            }
                          ],
                          type: 'group',
                          objectID: '1EAE9DF9-3532-44BB-BE5C-D113305E1D54'
                        },
                        {
                          name: '小米Note2',
                          Id: 195,
                          nameId: '397F3625-F4C5-4A1C-856F-ED2A7CC87D28',
                          frame: { width: 136, height: 40, x: 460, y: 1230 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Medium',
                            fontSize: 28,
                            color: '#222222',
                            textAlign: 'center',
                            lineHeight: '40',
                            fontWeight: 'bold'
                          },
                          value: '小米Note2',
                          type: 'text'
                        },
                        {
                          name: 'Group 11',
                          Id: 197,
                          nameId: '529F4D1F-3E9D-47A1-91DF-F9868F0E7E61',
                          frame: { width: 164, height: 37, x: 446, y: 1276 },
                          layers: [
                            {
                              name: '最高价',
                              Id: 198,
                              nameId: '0B76B3C6-A0C6-4616-94B8-0D80E79D9D95',
                              frame: { width: 79, height: 37, x: 446, y: 1276 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 26,
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '最高价',
                              type: 'text'
                            },
                            {
                              name: '￥1200',
                              Id: 199,
                              nameId: 'D854D25E-CD23-406F-A7C9-4D3086D23231',
                              frame: { width: 84, height: 37, x: 526, y: 1276 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 26,
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '￥1200',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: '529F4D1F-3E9D-47A1-91DF-F9868F0E7E61'
                        },
                        {
                          name: 'Group 16',
                          Id: 201,
                          nameId: '29434C27-D0C1-4620-960C-DCB9C4AEC8E8',
                          frame: { width: 142, height: 52, x: 457, y: 1332 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 202,
                              nameId: 'F933F925-A337-47D1-898F-AD8D66E26A05',
                              frame: { width: 142, height: 2, x: 457, y: 1332 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1EHAAupuWBuNjSszbXXcS7FXa-142-2.png'
                            }
                          ],
                          type: 'group',
                          objectID: '29434C27-D0C1-4620-960C-DCB9C4AEC8E8'
                        }
                      ],
                      type: 'group',
                      objectID: '7EFA9696-C72F-4B43-8227-606CCC40C662'
                    },
                    {
                      name: 'Group 12 Copy 3',
                      Id: 204,
                      nameId: '9172E414-2BE4-4886-A9F2-D4D15CD13275',
                      frame: { width: 164, height: 298, x: 658, y: 1086 },
                      layers: [
                        {
                          name: 'Group 14',
                          Id: 206,
                          nameId: 'F6AFCD9B-A204-420A-939F-84AE53D0102D',
                          frame: { width: 124, height: 128, x: 676, y: 1086 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 207,
                              nameId: '29A4BD32-5C48-445F-AFB6-1DA9E6753502',
                              frame: { width: 122, height: 86, x: 678, y: 1106 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1exkYur9YBuNjy0FgXXcxcXXa-122-86.png'
                            }
                          ],
                          type: 'group',
                          objectID: 'F6AFCD9B-A204-420A-939F-84AE53D0102D'
                        },
                        {
                          name: '小米Note2',
                          Id: 208,
                          nameId: '74666795-971F-43AB-BED5-0C7CB504DFB6',
                          frame: { width: 136, height: 40, x: 672, y: 1230 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Medium',
                            fontSize: 28,
                            color: '#222222',
                            textAlign: 'center',
                            lineHeight: '40',
                            fontWeight: 'bold'
                          },
                          value: '小米Note2',
                          type: 'text'
                        },
                        {
                          name: 'Group 11',
                          Id: 210,
                          nameId: 'DF9F7AA8-05FE-4D46-89AA-F117C70B3A8A',
                          frame: { width: 164, height: 37, x: 658, y: 1276 },
                          layers: [
                            {
                              name: '最高价',
                              Id: 211,
                              nameId: '43284184-CF39-4B68-A6CB-BA570DC24936',
                              frame: { width: 79, height: 37, x: 658, y: 1276 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: 26,
                                color: '#888888',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '最高价',
                              type: 'text'
                            },
                            {
                              name: '￥1200',
                              Id: 212,
                              nameId: 'A7EC63D0-49D6-4135-AA5A-9B4D44658BFA',
                              frame: { width: 84, height: 37, x: 738, y: 1276 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: 26,
                                color: '#FF4444',
                                lineHeight: '37',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '￥1200',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: 'DF9F7AA8-05FE-4D46-89AA-F117C70B3A8A'
                        },
                        {
                          name: 'Group 16',
                          Id: 214,
                          nameId: 'E7603C83-D4CC-4E9F-8A03-CCE8DEB7AA1A',
                          frame: { width: 127, height: 52, x: 669, y: 1332 },
                          layers: [
                            {
                              name: 'Bitmap',
                              Id: 215,
                              nameId: '32D15170-3109-40A3-90C0-BB805FD99F2D',
                              frame: { width: 81, height: 2, x: 669, y: 1332 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1XUAXuAKWBuNjy1zjXXcOypXa-81-2.png'
                            }
                          ],
                          type: 'group',
                          objectID: 'E7603C83-D4CC-4E9F-8A03-CCE8DEB7AA1A'
                        }
                      ],
                      type: 'group',
                      objectID: '9172E414-2BE4-4886-A9F2-D4D15CD13275'
                    }
                  ],
                  type: 'group',
                  objectID: '02182E8D-8201-4F59-A3D5-F504208C3B06'
                }
              ],
              type: 'group',
              objectID: 'D31E1BFA-BC44-4D40-B046-F7AD7EA16642'
            }
          ],
          type: 'group',
          objectID: '83BD005A-819C-43F8-BBA4-45043E1A1DCA'
        }
      ],
      type: 'group',
      objectID: 'C844A624-439B-4ADE-84E5-846A276C3593'
    },
    {
      name: 'Group 44',
      Id: 217,
      nameId: '9EB61173-3161-4786-8ECE-7DAF3EAD3A0C',
      frame: { width: 750, height: 128, x: 0, y: 0 },
      layers: [
        {
          name: 'title',
          Id: 219,
          nameId: '07AB3A75-3CF4-4C1B-AD20-919CCC1A6D81',
          frame: { width: 750, height: 88, x: 0, y: 40 },
          layers: [
            {
              name: 'Bitmap',
              Id: 220,
              nameId: '00A4F2E6-1862-4E13-897D-070555A142DF',
              frame: { width: 36, height: 8, x: 680, y: 80 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1Jq8juN9YBuNjy0FfXXXIsVXa-36-8.png'
            },
            {
              name: 'Group 32',
              Id: 222,
              nameId: '48CB2FBE-5C58-4160-87F4-8E5DA4609A7D',
              frame: { width: 71, height: 61, x: 582, y: 52 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 223,
                  nameId: '1E360B03-0350-4991-A83A-4DEE1EBF476D',
                  frame: { width: 71, height: 61, x: 582, y: 52 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1FdkHuv9TBuNjy1zbXXXpepXa-71-61.png'
                }
              ],
              type: 'group',
              objectID: '48CB2FBE-5C58-4160-87F4-8E5DA4609A7D'
            },
            {
              name: 'Bitmap',
              Id: 224,
              nameId: '35AD55B7-B936-4916-8CF3-36DCAACDA076',
              frame: { width: 20, height: 36, x: 36, y: 66 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1_a8juN9YBuNjy0FfXXXIsVXa-20-36.png'
            },
            {
              name: 'Group 3',
              Id: 226,
              nameId: 'D8C05A04-63FC-48C5-8351-9E30F96B2799',
              frame: { width: 220, height: 48, x: 264, y: 60 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 227,
                  nameId: '83E1E2FF-6FC6-41C4-B4C5-A9E13BFE1D57',
                  frame: { width: 161, height: 39, x: 322, y: 64 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1NoAXuAKWBuNjy1zjXXcOypXa-161-39.png'
                },
                {
                  name: 'Group 3',
                  Id: 229,
                  nameId: 'CF6E2E26-8E63-4F89-858F-23207CB5F411',
                  frame: { width: 48, height: 48, x: 264, y: 60 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 230,
                      nameId: 'B9305A2B-7958-4EC5-9669-0B7B4E0EA07C',
                      frame: { width: 46, height: 48, x: 266, y: 60 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1rHXjuN9YBuNjy0FfXXXIsVXa-46-48.png'
                    }
                  ],
                  type: 'group',
                  objectID: 'CF6E2E26-8E63-4F89-858F-23207CB5F411'
                }
              ],
              type: 'group',
              objectID: 'D8C05A04-63FC-48C5-8351-9E30F96B2799'
            }
          ],
          type: 'group',
          objectID: '07AB3A75-3CF4-4C1B-AD20-919CCC1A6D81'
        },
        {
          name: 'Statusbar',
          Id: 232,
          nameId: '6BD8E5A4-7629-484B-BF2E-B60EBB9E0706',
          frame: { width: 750, height: 40, x: 0, y: 0 },
          layers: [
            {
              name: 'Group',
              Id: 234,
              nameId: '527D0CDD-A1F3-4965-8515-E5156267AA8D',
              frame: { width: 725, height: 24, x: 14, y: 8 },
              layers: [
                {
                  name: 'Bars/Status/Black',
                  Id: 236,
                  nameId: '408B714D-81A4-4110-ADC1-F1AB1C459624',
                  frame: { width: 725, height: 24, x: 14, y: 8 },
                  layers: [
                    {
                      name: 'Pin Right',
                      Id: 238,
                      nameId: 'B5597CA1-881D-42EA-9FE1-D7E8432FF936',
                      frame: { width: 114, height: 24, x: 625, y: 8 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 239,
                          nameId: '4317B4AF-507B-44B1-BF2F-70BC254D832C',
                          frame: { width: 49, height: 19, x: 690, y: 10 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB17H7Aur1YBuNjSszeXXablFXa-49-19.png'
                        },
                        {
                          name: '100%',
                          Id: 240,
                          nameId: 'EDF8AD96-9344-4442-9072-23C54066D41F',
                          frame: { width: 59, height: 24, x: 625, y: 8 },
                          textStyles: {
                            fontFamily: '.SFNSDisplay',
                            fontSize: 24,
                            color: '#000000',
                            textAlign: 'right',
                            lineHeight: '24',
                            fontWeight: 'normal'
                          },
                          value: '100%',
                          type: 'text'
                        }
                      ],
                      type: 'group',
                      objectID: 'B5597CA1-881D-42EA-9FE1-D7E8432FF936'
                    },
                    {
                      name: 'Time',
                      Id: 241,
                      nameId: '48ECE123-27BA-4ED0-AF4D-D0858446F1A8',
                      frame: { width: 90, height: 24, x: 330, y: 8 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#000000',
                        textAlign: 'center',
                        lineHeight: '24',
                        fontWeight: 'normal'
                      },
                      value: '9:41 AM',
                      type: 'text'
                    },
                    {
                      name: 'Signal',
                      Id: 243,
                      nameId: 'E666FCF5-954D-4C01-9982-4839D072B0FA',
                      frame: { width: 188, height: 24, x: 14, y: 8 },
                      layers: [
                        {
                          name: 'Bitmap',
                          Id: 244,
                          nameId: '383624FE-0043-4571-B0F3-8A81D3F04E2E',
                          frame: { width: 26, height: 18, x: 176, y: 10 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1H48LuSBYBeNjy0FeXXbnmFXa-26-18.png'
                        },
                        {
                          name: 'Carrier',
                          Id: 245,
                          nameId: 'E7E9B552-193A-4217-82DC-43F93D7ACF35',
                          frame: { width: 86, height: 24, x: 88, y: 8 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: 24,
                            color: '#000000',
                            textAlign: 'left',
                            lineHeight: '24',
                            fontWeight: 'normal'
                          },
                          value: 'SanityD',
                          type: 'text'
                        },
                        {
                          name: 'Bitmap',
                          Id: 246,
                          nameId: '327243BB-68C1-4753-9956-6D983D425477',
                          frame: { width: 67, height: 11, x: 14, y: 14 },
                          imageStyles: { resize: 'stretch' },
                          type: 'image',
                          value: 'https://gw.alicdn.com/tfs/TB1ij7Qux1YBuNjy1zcXXbNcXXa-67-11.png'
                        }
                      ],
                      type: 'group',
                      objectID: 'E666FCF5-954D-4C01-9982-4839D072B0FA'
                    }
                  ],
                  type: 'group',
                  objectID: '408B714D-81A4-4110-ADC1-F1AB1C459624'
                }
              ],
              type: 'group',
              objectID: '527D0CDD-A1F3-4965-8515-E5156267AA8D'
            }
          ],
          type: 'group',
          objectID: '6BD8E5A4-7629-484B-BF2E-B60EBB9E0706'
        }
      ],
      type: 'group',
      objectID: '9EB61173-3161-4786-8ECE-7DAF3EAD3A0C'
    },
    {
      name: '公告',
      Id: 248,
      nameId: 'A009687A-C2A1-42ED-8D02-3EEBDB1A1461',
      frame: { width: 750, height: 88, x: 0, y: 130 },
      layers: [
        {
          name: 'Rectangle 21',
          Id: 249,
          nameId: '3E233E12-88CC-45F5-B545-9B3CEF50C19E',
          frame: { width: 750, height: 88, x: 0, y: 130 },
          styles: { backgroundColor: 'rgba(255,250,216,1)' },
          type: 'shape'
        },
        {
          name: 'Group 25',
          Id: 251,
          nameId: '66F76505-F56E-4B57-9EF9-54EBB1D9301D',
          frame: { width: 705, height: 60, x: 23, y: 144 },
          layers: [
            {
              name: '公告：近日部分用户存在虚假交易取得闲鱼币',
              Id: 252,
              nameId: '82793D0F-1675-4361-A3D1-09FC998379BD',
              frame: { width: 705, height: 60, x: 23, y: 144 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 22,
                color: '#C57A3D',
                lineHeight: '30',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value:
                '公告：近日部分用户存在虚假交易取得闲鱼币的行为。为维护竞拍公平，闲鱼将对部分竞拍宝贝做重拍处理。刷币行为一经查实将冻结闲鱼币。',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '66F76505-F56E-4B57-9EF9-54EBB1D9301D'
        }
      ],
      type: 'group',
      objectID: 'A009687A-C2A1-42ED-8D02-3EEBDB1A1461'
    }
  ],
  nameId: 1527746576954,
  Id: 1,
  type: 'group',
  frame: { x: 0, y: 0, width: 750, height: 1334 },
  styles: { backgroundColor: 'rgba(255,255,255,1)' }
  // tslint:disable-next-line:max-file-line-count
}
