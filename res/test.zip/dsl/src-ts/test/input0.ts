export default {
  layers: [
    {
      name: 'Rectangle 5',
      Id: 2,
      nameId: '07D52814-2A05-4CD5-A908-CF4A91BF5162',
      frame: { width: 690, height: 82, x: 30, y: 26 },
      layers: [
        {
          name: 'Group',
          Id: 4,
          nameId: 'ECD3691E-5A1E-4976-9624-F1531DF1B541',
          frame: { width: 690, height: 82, x: 30, y: 26 },
          layers: [
            {
              name: 'Rectangle 11',
              Id: 5,
              nameId: 'B3E56369-CAE0-4D7C-99B3-45B6E6D17452',
              frame: { width: 80, height: 80, x: 30, y: 26 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1WqQxjYGYBuNjy0FoXXciBFXa-80-80.png'
            },
            {
              name: 'Group',
              Id: 7,
              nameId: 'B403C9C8-B258-45CD-8ED0-35E4157C4E08',
              frame: { width: 365, height: 80, x: 130, y: 28 },
              layers: [
                {
                  name: 'Group',
                  Id: 9,
                  nameId: 'DEDB8345-8078-4F47-9B3D-6EF928C8D3E4',
                  frame: { width: 234, height: 36, x: 130, y: 28 },
                  layers: [
                    {
                      name: '西溪包租婆',
                      Id: 10,
                      nameId: '2EFEA388-40E9-4FA1-8454-0123C89AFBE3',
                      frame: { width: 150, height: 36, x: 130, y: 28 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '30',
                        color: '#222222',
                        lineHeight: '36',
                        textAlign: 'left',
                        fontWeight: 'bold'
                      },
                      value: '西溪包租婆',
                      type: 'text'
                    },
                    {
                      name: 'Bitmap',
                      Id: 11,
                      nameId: '5C91D4A2-F3B2-4E2A-B02B-DB29DF927D30',
                      frame: { width: 76, height: 28, x: 288, y: 32 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1_WQxjYGYBuNjy0FoXXciBFXa-76-28.png'
                    }
                  ],
                  type: 'group',
                  objectID: 'DEDB8345-8078-4F47-9B3D-6EF928C8D3E4'
                },
                {
                  name: 'Group',
                  Id: 13,
                  nameId: '1B0843B8-6B0E-4F9A-860E-D7388B75DDD2',
                  frame: { width: 365, height: 36, x: 130, y: 72 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 14,
                      nameId: '5F48AC12-84AB-4D93-AFFE-2C9A980C75E6',
                      frame: { width: 12, height: 12, x: 130, y: 84 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1VSJqkamWBuNjy1XaXXXCbXXa-12-12.png'
                    },
                    {
                      name: '5分钟前·杭州 阿里巴巴西溪园区',
                      Id: 15,
                      nameId: 'F35F5A28-5EF2-40E9-AE7A-FA25DDE22F96',
                      frame: { width: 347, height: 36, x: 148, y: 72 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#888888',
                        lineHeight: '36',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '5分钟前·杭州 阿里巴巴西溪园区',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '1B0843B8-6B0E-4F9A-860E-D7388B75DDD2'
                }
              ],
              type: 'group',
              objectID: 'B403C9C8-B258-45CD-8ED0-35E4157C4E08'
            },
            {
              name: '¥',
              Id: 16,
              nameId: '0469A849-13CF-4189-A6B9-D9BA43820AE5',
              frame: { width: 15, height: 28, x: 576, y: 38 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#FF4444',
                textAlign: 'left',
                lineHeight: '28',
                fontWeight: 'normal'
              },
              value: '¥',
              type: 'text'
            },
            {
              name: '6000',
              Id: 17,
              nameId: '6D12AB0F-F066-480E-8B97-41C22AA7691C',
              frame: { width: 87, height: 36, x: 597, y: 30 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '36',
                color: '#FF4444',
                textAlign: 'right',
                lineHeight: '36',
                fontWeight: 'bold'
              },
              value: '6000',
              type: 'text'
            },
            {
              name: '/月',
              Id: 18,
              nameId: '45A08780-E354-48C9-A121-08EE2316F439',
              frame: { width: 36, height: 28, x: 684, y: 38 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#FF4444',
                textAlign: 'left',
                lineHeight: '28',
                fontWeight: 'normal'
              },
              value: '/月',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: 'ECD3691E-5A1E-4976-9624-F1531DF1B541'
        }
      ],
      type: 'group',
      objectID: '07D52814-2A05-4CD5-A908-CF4A91BF5162'
    },
    {
      name: 'Rectangle 5 Copy 5',
      Id: 20,
      nameId: 'C4E3A3C1-09CA-4B5D-A0BC-29C74E0444CD',
      frame: { width: 594, height: 80, x: 130, y: 122 },
      layers: [
        {
          name: 'Ducati Monster 821 国',
          Id: 21,
          nameId: '8C5C6301-ECD0-4358-84AC-1661CDD65B86',
          frame: { width: 594, height: 80, x: 130, y: 122 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '28',
            color: '#222222',
            letterSpacing: '0',
            lineHeight: '40',
            maxWidth: 594,
            maxHeight: 80,
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: 'Ducati Monster 821 国行大贸易 全国过户提档喜欢的盆友看看~',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: 'C4E3A3C1-09CA-4B5D-A0BC-29C74E0444CD'
    },
    {
      name: 'Rectangle 5 Copy',
      Id: 23,
      nameId: '9D613E6A-4F2E-473E-81D1-223D4687CFBB',
      frame: { width: 392, height: 392, x: 130, y: 222 },
      layers: [
        {
          name: 'Mask',
          Id: 25,
          nameId: '7A8DC053-EC33-47FF-A68A-E7B502E0C4CA',
          frame: { width: 392, height: 392, x: 130, y: 222 },
          layers: [
            {
              name: 'Mask',
              Id: 26,
              nameId: 'C6822D12-5903-4EBC-87AF-80C7C3A42646',
              frame: { width: 392, height: 392, x: 130, y: 222 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1cbcxjYGYBuNjy0FoXXciBFXa-392-392.png'
            }
          ],
          type: 'group',
          objectID: '7A8DC053-EC33-47FF-A68A-E7B502E0C4CA'
        }
      ],
      type: 'group',
      objectID: '9D613E6A-4F2E-473E-81D1-223D4687CFBB'
    },
    {
      name: 'Group 9',
      Id: 28,
      nameId: 'F907F075-6AC9-4918-BE62-09937FBEABBC',
      frame: { width: 590, height: 32, x: 130, y: 642 },
      layers: [
        {
          name: 'Rectangle 11 Copy 14',
          Id: 30,
          nameId: '60412121-F65A-4385-A9EA-62088E2B08A4',
          frame: { width: 590, height: 32, x: 130, y: 642 },
          layers: [
            {
              name: 'Group',
              Id: 32,
              nameId: '8E46F077-E547-41F8-9B64-EBEB92D6916D',
              frame: { width: 590, height: 32, x: 130, y: 642 },
              layers: [
                {
                  name: '160个超赞·33人收藏',
                  Id: 33,
                  nameId: 'C565DDA7-EE31-48AB-9933-E39D3F0D8DF3',
                  frame: { width: 224, height: 32, x: 130, y: 642 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '24',
                    color: '#888888',
                    letterSpacing: '0',
                    lineHeight: '32',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '160个超赞·33人收藏',
                  type: 'text'
                },
                {
                  name: 'Bitmap',
                  Id: 34,
                  nameId: '66DAEE52-AD43-4028-8B4E-6696334212AB',
                  frame: { width: 32, height: 32, x: 688, y: 642 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1fSRqkamWBuNjy1XaXXXCbXXa-32-32.png'
                }
              ],
              type: 'group',
              objectID: '8E46F077-E547-41F8-9B64-EBEB92D6916D'
            }
          ],
          type: 'group',
          objectID: '60412121-F65A-4385-A9EA-62088E2B08A4'
        }
      ],
      type: 'group',
      objectID: 'F907F075-6AC9-4918-BE62-09937FBEABBC'
    }
  ],
  nameId: 1523187960875,
  var: 0,
  type: 'group',
  frame: { x: 0, y: 0, width: 750, height: 702 }
}
