export default {
  id: 0,
  type: 'GROUP',
  raw: { type: 'group', nameId: 1523952799697, id: 0 },
  frame: { y: 0, x: 0, height: 702, width: 750 },
  measured: { y: 0, x: 0, height: 702, width: 750 },
  measuredTypes: ['BY_CONFLICT', 'BY_CONFLICT'],
  layout: { flexDirection: 'row', justifyContent: 'flex-start', alignItems: 'flex-start', position: 'relative', width: 750, height: 702 },
  children: [
    {
      id: 1,
      type: 'IMAGE',
      raw: {
        type: 'image',
        id: 1,
        value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952799698.png'
      },
      frame: { y: 26, x: 30, height: 80, width: 80 },
      measured: { y: 26, x: 30, height: 80, width: 80 },
      measuredTypes: ['BY_PRIMITIVE', 'BY_PRIMITIVE'],
      layout: { position: 'relative', width: 80, height: 80, margin: [26, null, null, 30] },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952799698.png',
      imageStyles: { resize: 'stretch' },
      clazz: {
        name: 'image-w80-h80',
        styles: { position: 'relative', width: '80px', height: '80px', resize: 'stretch', 'margin-top': '26px', 'margin-left': '30px' }
      }
    },
    {
      id: 8,
      type: 'IMAGE',
      raw: {
        type: 'image',
        id: 8,
        value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952800835.png'
      },
      frame: { y: 222, x: 130, height: 392, width: 392 },
      measured: { y: 222, x: 130, height: 392, width: 392 },
      measuredTypes: ['BY_PRIMITIVE', 'BY_PRIMITIVE'],
      layout: { position: 'absolute', width: 392, height: 392, left: 130, bottom: 88 },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952800835.png',
      imageStyles: { resize: 'stretch' },
      clazz: {
        name: 'image-w392-h392-absolute',
        styles: { position: 'absolute', width: '392px', height: '392px', left: 130, bottom: 88, resize: 'stretch' }
      }
    },
    {
      id: 9,
      type: 'TEXT',
      raw: { type: 'text', id: 9, value: '160个超赞·33人收藏' },
      frame: { y: 647, x: 131, height: 23, width: 221 },
      measured: { y: 647, x: 131, height: 23, width: 221 },
      measuredTypes: ['BY_DEFAULT', 'BY_DEFAULT'],
      layout: { position: 'absolute', left: 131, bottom: 32 },
      value: '160个超赞·33人收藏',
      textStyles: {
        fontWeight: 'normal',
        color: '#888888',
        fontFamily: 'PingFangSC-Regular',
        fontSize: '24',
        lineHeight: '24',
        textAlign: 'left'
      },
      clazz: {
        name: 'text-font24-absolute',
        styles: {
          position: 'absolute',
          left: 131,
          bottom: 32,
          'font-weight': 'normal',
          color: '#888888',
          'font-family': 'PingFangSC-Regular',
          'font-size': '24',
          'line-height': '24',
          'text-align': 'left'
        }
      }
    },
    {
      name: 'Bitmap',
      id: 4,
      type: 'IMAGE',
      raw: {
        name: 'Bitmap',
        nameId: 'CB102F67-A784-46BE-B0F5-9664ACC78982',
        value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952800630.png',
        type: 'image',
        id: 4
      },
      frame: { y: 84, width: 12, x: 131, height: 12 },
      measured: { y: 84, width: 12, x: 131, height: 12 },
      measuredTypes: ['BY_PRIMITIVE', 'BY_PRIMITIVE'],
      layout: { position: 'relative', width: 12, height: 12, margin: [84, null, null, 21] },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952800630.png',
      imageStyles: { resize: 'stretch' },
      clazz: {
        name: 'image-w12-h12',
        styles: { position: 'relative', width: '12px', height: '12px', resize: 'stretch', 'margin-top': '84px', 'margin-left': '21px' }
      }
    },
    {
      id: 7,
      type: 'TEXT',
      raw: { type: 'text', id: 7, value: 'Ducati Monster 821 国行大贸易 全国过户提档喜欢的盆友看看~' },
      frame: { y: 129, x: 131, height: 67, width: 578 },
      measured: { y: 129, x: 131, height: 67, width: 578 },
      measuredTypes: ['BY_TEXT', 'BY_DEFAULT'],
      layout: { position: 'absolute', width: 578, right: 41, top: 129 },
      value: 'Ducati Monster 821 国行大贸易 全国过户提档喜欢的盆友看看~',
      textStyles: {
        maxWidth: 594,
        fontWeight: 'normal',
        color: '#222222',
        maxHeight: 80,
        fontFamily: 'PingFangSC-Regular',
        fontSize: '28',
        lineHeight: '40',
        textAlign: 'left'
      },
      clazz: {
        name: 'text-font28-absolute',
        styles: {
          position: 'absolute',
          width: '578px',
          right: 41,
          top: 129,
          'max-width': 594,
          'font-weight': 'normal',
          color: '#222222',
          'max-height': 80,
          'font-family': 'PingFangSC-Regular',
          'font-size': '28',
          'line-height': '40',
          'text-align': 'left'
        }
      }
    },
    {
      id: 2,
      type: 'TEXT',
      raw: { type: 'text', id: 2, value: '西溪包租婆' },
      frame: { y: 32, x: 131, height: 29, width: 148 },
      measured: { y: 32, x: 131, height: 29, width: 148 },
      measuredTypes: ['BY_DEFAULT', 'BY_DEFAULT'],
      layout: { position: 'absolute', left: 131, top: 32 },
      value: '西溪包租婆',
      textStyles: {
        fontWeight: 'bold',
        color: '#222222',
        fontFamily: 'PingFangSC-Medium',
        fontSize: '30',
        lineHeight: '30',
        textAlign: 'left'
      },
      clazz: {
        name: 'text-font30-absolute',
        styles: {
          position: 'absolute',
          left: 131,
          top: 32,
          'font-weight': 'bold',
          color: '#222222',
          'font-family': 'PingFangSC-Medium',
          'font-size': '30',
          'line-height': '30',
          'text-align': 'left'
        }
      }
    },
    {
      id: 5,
      type: 'TEXT',
      raw: { type: 'text', id: 5, value: '5分钟前·杭州 阿里巴巴西溪园区' },
      frame: { y: 79, x: 150, height: 23, width: 343 },
      measured: { y: 79, x: 150, height: 23, width: 343 },
      measuredTypes: ['BY_DEFAULT', 'BY_DEFAULT'],
      layout: { position: 'absolute', left: 150, top: 79 },
      value: '5分钟前·杭州 阿里巴巴西溪园区',
      textStyles: {
        fontWeight: 'normal',
        color: '#888888',
        fontFamily: 'PingFangSC-Regular',
        fontSize: '24',
        lineHeight: '24',
        textAlign: 'left'
      },
      clazz: {
        name: 'text-font24-absolute-r1',
        styles: {
          position: 'absolute',
          left: 150,
          top: 79,
          'font-weight': 'normal',
          color: '#888888',
          'font-family': 'PingFangSC-Regular',
          'font-size': '24',
          'line-height': '24',
          'text-align': 'left'
        }
      }
    },
    {
      name: 'Bitmap',
      id: 3,
      type: 'IMAGE',
      raw: {
        name: 'Bitmap',
        nameId: '30A13452-145B-4A18-85F7-56864BB3C4CF',
        value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952800429.png',
        type: 'image',
        id: 3
      },
      frame: { y: 32, width: 76, x: 288, height: 28 },
      measured: { y: 32, width: 76, x: 288, height: 28 },
      measuredTypes: ['BY_PRIMITIVE', 'BY_PRIMITIVE'],
      layout: { position: 'relative', width: 76, height: 28, margin: [32, null, null, 145] },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952800429.png',
      imageStyles: { resize: 'stretch' },
      clazz: {
        name: 'image-w76-h28',
        styles: { position: 'relative', width: '76px', height: '28px', resize: 'stretch', 'margin-top': '32px', 'margin-left': '145px' }
      }
    },
    {
      id: 6,
      type: 'TEXT',
      raw: { type: 'text', id: 6, value: '6000' },
      frame: { y: 34, x: 576, height: 30, width: 141 },
      measured: { y: 34, x: 576, height: 30, width: 141 },
      measuredTypes: ['BY_DEFAULT', 'BY_DEFAULT'],
      layout: { position: 'absolute', right: 33, top: 34 },
      value: '6000',
      textStyles: {
        fontWeight: 'bold',
        color: '#FF4444',
        fontFamily: 'PingFangSC-Medium',
        fontSize: '36',
        lineHeight: '36',
        textAlign: 'right'
      },
      clazz: {
        name: 'text-font36-absolute',
        styles: {
          position: 'absolute',
          right: 33,
          top: 34,
          'font-weight': 'bold',
          color: '#FF4444',
          'font-family': 'PingFangSC-Medium',
          'font-size': '36',
          'line-height': '36',
          'text-align': 'right'
        }
      }
    },
    {
      id: 10,
      type: 'IMAGE',
      raw: {
        type: 'image',
        id: 10,
        value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952801300.png'
      },
      frame: { y: 642, x: 689, height: 32, width: 8 },
      measured: { y: 642, x: 689, height: 32, width: 8 },
      measuredTypes: ['BY_PRIMITIVE', 'BY_PRIMITIVE'],
      layout: { position: 'relative', width: 8, height: 32, margin: [null, null, 28, 325], alignSelf: 'flex-end' },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952801300.png',
      imageStyles: { resize: 'stretch' },
      clazz: {
        name: 'image-w8-h32',
        styles: {
          position: 'relative',
          width: '8px',
          height: '32px',
          'align-self': 'flex-end',
          resize: 'stretch',
          'margin-bottom': '28px',
          'margin-left': '325px'
        }
      }
    },
    {
      id: 11,
      type: 'IMAGE',
      raw: {
        type: 'image',
        id: 11,
        value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952801300.png'
      },
      frame: { y: 642, x: 700, height: 32, width: 8 },
      measured: { y: 642, x: 700, height: 32, width: 8 },
      measuredTypes: ['BY_PRIMITIVE', 'BY_PRIMITIVE'],
      layout: { position: 'relative', width: 8, height: 32, margin: [null, null, 28, 3], alignSelf: 'flex-end' },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952801300.png',
      imageStyles: { resize: 'stretch' },
      clazz: {
        name: 'image-w8-h32-r1',
        styles: {
          position: 'relative',
          width: '8px',
          height: '32px',
          'align-self': 'flex-end',
          resize: 'stretch',
          'margin-bottom': '28px',
          'margin-left': '3px'
        }
      }
    },
    {
      id: 12,
      type: 'IMAGE',
      raw: {
        type: 'image',
        id: 12,
        value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952801300.png'
      },
      frame: { y: 642, x: 711, height: 32, width: 8 },
      measured: { y: 642, x: 711, height: 32, width: 8 },
      measuredTypes: ['BY_PRIMITIVE', 'BY_PRIMITIVE'],
      layout: { position: 'relative', width: 8, height: 32, margin: [null, null, 28, 3], alignSelf: 'flex-end' },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952801300.png',
      imageStyles: { resize: 'stretch' },
      clazz: {
        name: 'image-w8-h32-r1',
        styles: {
          position: 'relative',
          width: '8px',
          height: '32px',
          'align-self': 'flex-end',
          resize: 'stretch',
          'margin-bottom': '28px',
          'margin-left': '3px'
        }
      }
    }
  ],
  clazz: {
    name: 'div-row-flex-start',
    styles: {
      'flex-direction': 'row',
      'justify-content': 'flex-start',
      'align-items': 'flex-start',
      position: 'relative',
      width: '750px',
      height: '702px'
    }
  }
}
