export default {
  layers: [
    { frame: { y: 26, x: 30, height: 80, width: 80 }, type: 'image', id: 1, value: 'http://47.100.92.83:8081/ui/30_26_80_80_image.png' },
    {
      textStyles: { color: '#222222', lineHeight: 43, fontSize: 30, textAlign: 'left', fontFamily: 'PingFangSC-Medium' },
      frame: { y: 29, x: 131, height: 43, width: 148 },
      type: 'text',
      id: 2,
      value: '西溪包租婆'
    },
    { frame: { y: 38, x: 288, height: 28, width: 76 }, type: 'image', id: 3, value: 'http://47.100.92.83:8081/ui/288_38_76_28_image.png' },
    {
      styles: {
        opacity: 1,
        borderColor: 'rgba(100,210,118,1)',
        borderRadius: 4,
        borderWidth: 2,
        backgroundColor: 'rgba(85,207,105,1)',
        borderStyle: 'solid'
      },
      frame: { y: 84, x: 131, height: 12, width: 12 },
      type: 'shape',
      id: 4
    },
    {
      textStyles: { color: '#888888', lineHeight: 33, fontSize: 23, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 74, x: 152, height: 33, width: 344 },
      type: 'text',
      id: 5,
      value: '5分钟前·杭州阿里巴巴西溪园区'
    },
    {
      textStyles: { color: '#ff4444', lineHeight: 35, fontSize: 24, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 35, x: 576, height: 35, width: 14 },
      type: 'text',
      id: 6,
      value: '¥'
    },
    {
      textStyles: { color: '#ff4444', lineHeight: 52, fontSize: 36, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 21, x: 598, height: 52, width: 85 },
      type: 'text',
      id: 7,
      value: '6000'
    },
    {
      textStyles: { color: '#ff4444', lineHeight: 35, fontSize: 24, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 36, x: 685, height: 35, width: 31 },
      type: 'text',
      id: 8,
      value: '/月'
    },
    {
      textStyles: { color: '#222222', lineHeight: 39, fontSize: 27, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 128, x: 131, height: 39, width: 577 },
      type: 'text',
      id: 9,
      value: 'Ducati Monster821国行大贸易全国过户提档'
    },
    {
      textStyles: { color: '#222222', lineHeight: 39, fontSize: 27, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 167, x: 131, height: 39, width: 209 },
      type: 'text',
      id: 10,
      value: '喜欢的盆友看看'
    },
    {
      frame: { y: 222, x: 131, height: 392, width: 392 },
      type: 'image',
      id: 11,
      value: 'http://47.100.92.83:8081/ui/130_222_392_392_image.png'
    },
    {
      textStyles: { color: '#888888', lineHeight: 35, fontSize: 24, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 641, x: 131, height: 35, width: 221 },
      type: 'text',
      id: 12,
      value: '60个超赞·33人收藏'
    },
    {
      frame: { y: 642, x: 689, height: 32, width: 30 },
      type: 'image',
      id: 13,
      value: 'http://47.100.92.83:8081/ui/689_642_30_32_image.png'
    }
  ],
  frame: { y: 0, x: 0, height: 702, width: 750 },
  type: 'group',
  id: 0
}
