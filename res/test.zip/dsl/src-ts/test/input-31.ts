export default {
  layers: [
    {
      name: 'Group 2 Copy 5',
      Id: 30,
      nameId: '2C7962FA-FFF3-4C7D-BED8-A8490776DAE9',
      frame: { width: 718, height: 114, x: 32, y: 30 },
      layers: [
        {
          name: 'Group',
          Id: 32,
          nameId: 'DAF1BA0F-CE5E-43D3-8D71-A84428BDB84A',
          frame: { width: 718, height: 114, x: 32, y: 30 },
          layers: [
            {
              name: 'Bitmap',
              Id: 33,
              nameId: '23F1DEFA-7285-460E-8619-6538987A3C2E',
              frame: { width: 718, height: 2, x: 32, y: 142 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1XP1GrKuSBuNjSsplXXbe8pXa-718-2.png'
            },
            {
              name: 'Group',
              Id: 35,
              nameId: 'EC6D50CE-E9CA-4FAE-8647-F299041B5366',
              frame: { width: 64, height: 64, x: 654, y: 40 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 36,
                  nameId: '40706C29-1F17-4736-A634-68776ECC5B42',
                  frame: { width: 64, height: 64, x: 654, y: 40 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1TIWqrHSYBuNjSspiXXXNzpXa-64-64.png'
                },
                {
                  name: 'Mask Copy 3',
                  Id: 37,
                  nameId: '71286FE0-4651-437A-8DAB-6AAD96A47E41',
                  frame: { width: 64, height: 63.34020618556701, x: 654, y: 40 },
                  styles: { fillType: 'gradient', borderRadius: 63.34020618556701 },
                  type: 'shape'
                },
                {
                  name: 'Mask Copy',
                  Id: 38,
                  nameId: 'CA0C676F-57C1-4874-BF31-E29ACF6C061C',
                  frame: { width: 56, height: 55.422680412371164, x: 658, y: 43.958762886597924 },
                  styles: { fillType: 'gradient', borderRadius: 55.422680412371164 },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 39,
                  nameId: '299F8F39-8326-4A81-9DE1-45C9B76F98F4',
                  frame: { width: 56, height: 58, x: 658, y: 44 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1rP1GrKuSBuNjSsplXXbe8pXa-56-58.png'
                }
              ],
              type: 'group',
              objectID: 'EC6D50CE-E9CA-4FAE-8647-F299041B5366'
            },
            {
              name: 'Group 13',
              Id: 41,
              nameId: '889DA644-E3CA-489D-95BD-90F054B2A8A2',
              frame: { width: 590, height: 72, x: 32, y: 30 },
              layers: [
                {
                  name: 'Group 15',
                  Id: 43,
                  nameId: '8741C91B-6016-439D-AAEC-02ADEFD9C590',
                  frame: { width: 590, height: 72, x: 32, y: 30 },
                  layers: [
                    {
                      name: '首次送出「免费送」宝贝',
                      Id: 44,
                      nameId: '1B6F6BA7-228F-4074-97FE-C73841F4613A',
                      frame: { width: 352, height: 45, x: 32, y: 30 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#222222',
                        lineHeight: '45',
                        textAlign: 'left',
                        fontWeight: 'bold'
                      },
                      value: '首次送出「免费送」宝贝',
                      type: 'text'
                    },
                    {
                      name: '+12',
                      Id: 45,
                      nameId: '7861B4DB-9C94-42FF-B214-59C7FE97FFCB',
                      frame: { width: 59, height: 50, x: 563, y: 52 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 36,
                        color: '#FF4444',
                        textAlign: 'right',
                        lineHeight: '50',
                        fontWeight: 'bold'
                      },
                      value: '+12',
                      type: 'text'
                    },
                    {
                      name: '2018-05-09 10:56:15',
                      Id: 46,
                      nameId: '39F4B66C-B998-43FB-9F3A-AEEF370BC653',
                      frame: { width: 286, height: 40, x: 32, y: 74 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 28,
                        color: '#888888',
                        lineHeight: '40',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '2018-05-09  10:56:15',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '8741C91B-6016-439D-AAEC-02ADEFD9C590'
                }
              ],
              type: 'group',
              objectID: '889DA644-E3CA-489D-95BD-90F054B2A8A2'
            }
          ],
          type: 'group',
          objectID: 'DAF1BA0F-CE5E-43D3-8D71-A84428BDB84A'
        }
      ],
      type: 'group',
      objectID: '2C7962FA-FFF3-4C7D-BED8-A8490776DAE9'
    }
  ],
  nameId: 1526453726534,
  Id: 28,
  type: 'group',
  frame: { x: 0, y: 0, width: 750, height: 144 },
  styles: { backgroundColor: 'rgba(255,255,255,1)' }
}
