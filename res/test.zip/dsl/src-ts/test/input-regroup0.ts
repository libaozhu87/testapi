export default {
  layers: [
    {
      name: 'Mask',
      Id: 2,
      nameId: 'C6F4D819-C895-43D7-B04C-C1DA54AF5C2A',
      frame: { width: 336, height: 136, x: 0, y: 0 },
      imageStyles: { resize: 'stretch' },
      type: 'image',
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524553744041.png'
    },
    {
      name: 'Group',
      Id: 4,
      nameId: '2B8E4586-9CBA-4286-9D18-023A5EFA02D1',
      frame: { width: 104, height: 104, x: 212, y: 16 },
      layers: [
        {
          name: 'Mask',
          Id: 5,
          nameId: 'EF24AC88-AD83-486D-B386-18A868A77443',
          frame: { width: 104, height: 104, x: 212, y: 16 },
          styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
          type: 'shape'
        },
        {
          name: 'Bitmap',
          Id: 6,
          nameId: '931942DE-A146-4FAF-B7AA-3052463AF19B',
          frame: { width: 93, height: 125, x: 219, y: 11 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524553744218.png'
        },
        {
          name: 'Rectangle 14',
          Id: 7,
          nameId: '81F77B74-B9F8-40AA-8E07-AFD979063BE7',
          frame: { width: 76, height: 32, x: 226, y: 92 },
          styles: { backgroundColor: 'rgba(127,69,223,1)', fillType: 'color', cornerRadiusString: '6', borderRadius: 6, opacity: 1 },
          type: 'shape'
        },
        {
          name: '1元拍',
          Id: 8,
          nameId: '22D886D1-E546-4EDB-9238-B5F4A964B330',
          frame: { width: 54, height: 28, x: 240, y: 98 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: '20',
            color: '#FFFFFF',
            textAlign: 'center',
            lineHeight: '28',
            maxWidth: 54,
            maxHeight: 28,
            fontWeight: 'bold'
          },
          value: '1元拍',
          type: 'text'
        },
        {
          name: 'Rectangle 14',
          Id: 9,
          nameId: '4920EE73-9D1B-476B-967E-5360873137AC',
          frame: { width: 80, height: 32, x: 218, y: 92 },
          styles: {
            backgroundColor: 'rgba(195,180,218,1)',
            fillType: 'color',
            cornerRadiusString: '6',
            borderRadius: 6,
            opacity: 0.8499999642372131
          },
          type: 'shape'
        },
        {
          name: '#乐高',
          Id: 10,
          nameId: '4D974E3E-7165-41CC-8D1A-CE450B5CEE56',
          frame: { width: 52, height: 28, x: 233, y: 96 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: '20',
            color: '#FFFFFF',
            textAlign: 'center',
            lineHeight: '28',
            fontWeight: 'bold'
          },
          value: '#乐高',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '2B8E4586-9CBA-4286-9D18-023A5EFA02D1'
    },
    {
      name: 'Group',
      Id: 12,
      nameId: '2AF08B49-5A52-4F83-BC2C-147AB89715A2',
      frame: { width: 157, height: 77, x: 24, y: 34 },
      layers: [
        {
          name: '奇趣逗玩',
          Id: 13,
          nameId: '69043454-0052-42ED-B391-63BCC5F179FF',
          frame: { width: 128, height: 45, x: 24, y: 34 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: '32',
            color: '#222222',
            lineHeight: '45',
            textAlign: 'left',
            fontWeight: 'bold'
          },
          value: '奇趣逗玩',
          type: 'text'
        },
        {
          name: '玩转趣味惊喜',
          Id: 14,
          nameId: 'F1057362-149C-42EF-A444-AC5B864FEE6F',
          frame: { width: 157, height: 37, x: 24, y: 74 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '26',
            color: '#888888',
            lineHeight: '37',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '玩转趣味惊喜',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '2AF08B49-5A52-4F83-BC2C-147AB89715A2'
    }
  ],
  nameId: 1524553744038,
  Id: 1,
  type: 'group',
  frame: { x: 0, y: 0, width: 336, height: 136 }
}
