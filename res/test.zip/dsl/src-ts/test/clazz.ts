//View

//Text

//Image

//

// interface

interface Input {
  //必选
  name: string
  type: string //['card', 'page']
  mode: string //['single', 'multiple']
  dsl: Node //

  //可选
  title: string
  spm: string
}

interface File {
  filename: string

  isDirectory: boolean
  content: string

  files: File[]
}
