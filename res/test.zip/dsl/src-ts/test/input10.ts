export default {
  layers: [
    {
      textStyles: {
        fontWeight: 'bold',
        color: '#FFFFFF',
        fontFamily: 'PingFangSC-Medium',
        fontSize: '30',
        lineHeight: '30',
        textAlign: 'left'
      },
      name: '建鱼塘养宠物',
      type: 'text',
      frame: { y: 170, width: 180, x: 56, height: 42 },
      value: '建鱼塘养宠物',
      nameId: '30ED5623-53D0-4755-8BA2-9F04AB98DE7A',
      id: 7
    },
    {
      textStyles: {
        fontWeight: 'bold',
        color: '#FFFFFF',
        fontFamily: 'PingFangSC-Medium',
        fontSize: '30',
        lineHeight: '30',
        textAlign: 'left'
      },
      frame: { y: 32, x: 131, height: 29, width: 148 },
      type: 'text',
      id: 2,
      value: '建鱼塘养宠物'
    },
    {
      name: 'Rectangle 14',
      nameId: '8065C8DD-4075-4464-9AC8-9530CF9B4005',
      frame: { y: 45, width: 56, x: 442, height: 32 },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524020582549.png',
      imageStyles: { resize: 'stretch' },
      type: 'image',
      id: 3
    },
    {
      textStyles: {
        fontWeight: 'bold',
        color: '#FFFFFF',
        fontFamily: 'PingFangSC-Medium',
        fontSize: '30',
        lineHeight: '30',
        textAlign: 'left'
      },
      name: '建鱼塘养宠物',
      type: 'text',
      frame: { y: 170, width: 180, x: 56, height: 42 },
      value: '建鱼塘养宠物',
      nameId: '30ED5623-53D0-4755-8BA2-9F04AB98DE7A',
      id: 7
    },
    {
      textStyles: {
        fontWeight: 'bold',
        color: '#222222',
        fontFamily: 'PingFangSC-Medium',
        fontSize: '32',
        lineHeight: '32',
        textAlign: 'left'
      },
      frame: { y: 79, x: 150, height: 23, width: 343 },
      type: 'text',
      id: 5,
      value: '快速建鱼塘 每月多赚1000元'
    },
    {
      name: 'Rectangle 14',
      nameId: '8065C8DD-4075-4464-9AC8-9530CF9B4005',
      frame: { y: 45, width: 56, x: 442, height: 32 },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524020582549.png',
      imageStyles: { resize: 'stretch' },
      type: 'image',
      id: 3
    },
    {
      styles: { opacity: 1, fillType: 'color', backgroundColor: 'rgba(255,255,255,1)' },
      name: 'Rectangle 9 Copy',
      nameId: 'DD515B68-64BE-47FC-859F-08D6F8B159D7',
      frame: { y: 104, width: 718, x: 32, height: 192 },
      type: 'shape',
      id: 5
    },
    {
      frame: { y: 222, x: 130, height: 392, width: 392 },
      type: 'image',
      id: 8,
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524020582934.png',
      imageStyles: { resize: 'stretch' }
    },
    {
      textStyles: {
        fontWeight: 'bold',
        color: '#FFFFFF',
        fontFamily: 'PingFangSC-Medium',
        fontSize: '28',
        lineHeight: '28',
        textAlign: 'left'
      },
      frame: { y: 647, x: 131, height: 23, width: 221 },
      type: 'text',
      id: 9,
      value: '7天轻松赚2000元'
    },
    {
      frame: { y: 642, x: 689, height: 32, width: 8 },
      type: 'image',
      id: 10,
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524020584371.png',
      imageStyles: { resize: 'stretch' }
    },
    {
      frame: { y: 642, x: 700, height: 32, width: 8 },
      type: 'image',
      id: 11,
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524020584371.png',
      imageStyles: { resize: 'stretch' }
    },
    {
      frame: { y: 642, x: 711, height: 32, width: 8 },
      type: 'image',
      id: 12,
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1524020584371.png',
      imageStyles: { resize: 'stretch' }
    }
  ],
  type: 'group',
  frame: { y: 0, x: 0, height: 702, width: 750 },
  nameId: 1524020582146,
  id: 0
}
