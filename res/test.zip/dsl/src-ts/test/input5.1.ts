export default {
  layers: [
    {
      name: 'box',
      Id: 19,
      nameId: '40B3CC4A-1265-4509-800B-4DD7B2561603',
      frame: { width: 750, height: 90, x: 0, y: 0 },
      layers: [
        {
          name: 'box',
          Id: 20,
          nameId: '66559C08-4165-4265-A232-1D0AFDC8243D',
          frame: { width: 750, height: 90, x: 0, y: 0 },
          styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 0.3244519589552239 },
          type: 'shape'
        },
        {
          name: 'Rectangle',
          Id: 22,
          nameId: '8C214AF8-3D4C-4FC3-A564-853D0B116805',
          frame: { width: 689, height: 48, x: 31, y: 20 },
          layers: [
            {
              name: 'Rectangle',
              Id: 23,
              nameId: 'D6600063-46DA-4B09-99EB-8D40E4024DCD',
              frame: { width: 689, height: 48, x: 31, y: 20 },
              styles: {
                backgroundColor: 'rgba(255,255,255,1)',
                fillType: 'color',
                borderColor: 'rgba(149,149,149,1)',
                borderStyle: 'solid',
                borderWidth: 1,
                cornerRadiusString: '10',
                borderRadius: 10,
                opacity: 1
              },
              type: 'shape'
            },
            {
              name: 'Group',
              Id: 25,
              nameId: '5E34C682-8183-4AF9-9E7A-7AFB4CC56EBA',
              frame: { width: 654, height: 36, x: 45, y: 28 },
              layers: [
                {
                  name: '搜索',
                  Id: 26,
                  nameId: 'BD9125D1-0049-446B-ADD6-F5CDEFA9BDFB',
                  frame: { width: 34, height: 33, x: 45, y: 28 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611572351.png'
                },
                {
                  name: '全部商品',
                  Id: 27,
                  nameId: 'F9BAAC7C-E552-4559-A13F-0BBC49A94DFE',
                  frame: { width: 104, height: 33, x: 83, y: 31 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Light',
                    fontSize: '24',
                    color: '#444444',
                    letterSpacing: '0.37',
                    textAlign: 'right',
                    lineHeight: '33',
                    maxWidth: 104,
                    maxHeight: 33,
                    fontWeight: 'normal'
                  },
                  value: '全部商品',
                  type: 'text'
                },
                {
                  name: '取消',
                  Id: 28,
                  nameId: '03E4D1F3-73D9-4D47-BE9A-73DDE33DFBAF',
                  frame: { width: 24, height: 24, x: 675, y: 33 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611572497.png'
                }
              ],
              type: 'group',
              objectID: '5E34C682-8183-4AF9-9E7A-7AFB4CC56EBA'
            }
          ],
          type: 'group',
          objectID: '8C214AF8-3D4C-4FC3-A564-853D0B116805'
        }
      ],
      type: 'group',
      objectID: '40B3CC4A-1265-4509-800B-4DD7B2561603'
    },
    {
      name: '8664d601de521c1f865207dc7c5bfe37bee6064510385-fc0T4h_fw658',
      Id: 29,
      nameId: '50EC8351-E996-44AC-BCA0-ECA5A94523E5',
      frame: { width: 747, height: 402, x: 3, y: 90 },
      imageStyles: { resize: 'stretch' },
      type: 'image',
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611572617.png'
    },
    {
      name: 'Group',
      Id: 31,
      nameId: '272E5931-E045-43C3-9BF4-1EE71868FA46',
      frame: { width: 799, height: 51, x: 11, y: 509 },
      layers: [
        {
          name: 'Rectangle 2',
          Id: 33,
          nameId: '58F7CFB1-944E-4337-9F5D-E0798A852EFF',
          frame: { width: 120, height: 50, x: 11, y: 510 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 34,
              nameId: '22352EC6-EE36-4D4C-A63D-96F8F81CAC6C',
              frame: { width: 120, height: 50, x: 11, y: 510 },
              styles: {
                borderColor: 'rgba(0,0,0,1)',
                borderStyle: 'solid',
                borderWidth: 1,
                cornerRadiusString: '13',
                borderRadius: 13,
                opacity: 1
              },
              type: 'shape'
            },
            {
              name: '母婴用品',
              Id: 35,
              nameId: '98130D02-755C-4866-AE61-EDD73767D0D1',
              frame: { width: 98, height: 33, x: 22, y: 519 },
              textStyles: {
                fontFamily: 'PingFangSC-Light',
                fontSize: '24',
                color: '#000000',
                letterSpacing: '0.27',
                lineHeight: '33',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '母婴用品',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '58F7CFB1-944E-4337-9F5D-E0798A852EFF'
        },
        {
          name: 'Rectangle 2',
          Id: 37,
          nameId: 'D92788C9-7AB2-480D-A2E6-A957D2308BA8',
          frame: { width: 120, height: 50, x: 145, y: 510 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 38,
              nameId: '8EB88F20-1112-45D3-A760-C529A269BF32',
              frame: { width: 120, height: 50, x: 145, y: 510 },
              styles: { backgroundColor: 'rgba(236,236,236,1)', fillType: 'color', cornerRadiusString: '13', borderRadius: 13, opacity: 1 },
              type: 'shape'
            },
            {
              name: '个护彩妆',
              Id: 39,
              nameId: '1B1CBFE0-AF95-4C49-A7D4-68C7C863EF40',
              frame: { width: 98, height: 33, x: 156, y: 519 },
              textStyles: {
                fontFamily: 'PingFangSC-Light',
                fontSize: '24',
                color: '#7D7D7D',
                letterSpacing: '0.27',
                lineHeight: '33',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '个护彩妆',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: 'D92788C9-7AB2-480D-A2E6-A957D2308BA8'
        },
        {
          name: 'Rectangle 2',
          Id: 41,
          nameId: '6AE0DED3-AFF4-4709-AD0B-85860969C747',
          frame: { width: 120, height: 50, x: 283, y: 510 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 42,
              nameId: 'D3F4FF99-C712-4895-A8B2-85C14DBDFDB9',
              frame: { width: 120, height: 50, x: 283, y: 510 },
              styles: { backgroundColor: 'rgba(236,236,236,1)', fillType: 'color', cornerRadiusString: '13', borderRadius: 13, opacity: 1 },
              type: 'shape'
            },
            {
              name: 'Rectangle 2',
              Id: 44,
              nameId: '16F01DED-88DA-4693-8523-C55E9A7F9617',
              frame: { width: 120, height: 50, x: 283, y: 510 },
              layers: [
                {
                  name: 'Rectangle 2',
                  Id: 45,
                  nameId: '5BF3CAB6-E2D5-4F97-952F-8E1370AAF1C0',
                  frame: { width: 120, height: 50, x: 283, y: 510 },
                  styles: {
                    backgroundColor: 'rgba(236,236,236,1)',
                    fillType: 'color',
                    cornerRadiusString: '13',
                    borderRadius: 13,
                    opacity: 1
                  },
                  type: 'shape'
                },
                {
                  name: '营养辅食',
                  Id: 46,
                  nameId: '64808899-BD6E-4B9A-B911-766CBC3C938C',
                  frame: { width: 98, height: 33, x: 295, y: 517 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Light',
                    fontSize: '24',
                    color: '#7D7D7D',
                    letterSpacing: '0.27',
                    lineHeight: '33',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '营养辅食',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '16F01DED-88DA-4693-8523-C55E9A7F9617'
            }
          ],
          type: 'group',
          objectID: '6AE0DED3-AFF4-4709-AD0B-85860969C747'
        },
        {
          name: 'Rectangle 2',
          Id: 48,
          nameId: 'BEA720A6-D299-4B76-884E-F3D428096EED',
          frame: { width: 120, height: 50, x: 419, y: 510 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 49,
              nameId: '552112D2-A1C6-4112-BE0F-7F5626DC010E',
              frame: { width: 120, height: 50, x: 419, y: 510 },
              styles: { backgroundColor: 'rgba(236,236,236,1)', fillType: 'color', cornerRadiusString: '13', borderRadius: 13, opacity: 1 },
              type: 'shape'
            },
            {
              name: '进口食品',
              Id: 50,
              nameId: 'F937C6D0-BD8B-49B4-8586-FB6BA5CC66B5',
              frame: { width: 98, height: 33, x: 430, y: 519 },
              textStyles: {
                fontFamily: 'PingFangSC-Light',
                fontSize: '24',
                color: '#7D7D7D',
                letterSpacing: '0.27',
                lineHeight: '33',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '进口食品',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: 'BEA720A6-D299-4B76-884E-F3D428096EED'
        },
        {
          name: 'Rectangle 2',
          Id: 52,
          nameId: '3EBC886D-462E-40EE-82AF-B5E6A7A35F3D',
          frame: { width: 120, height: 50, x: 556, y: 510 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 53,
              nameId: '112C04FF-CE1F-4757-9693-59DA35185B2C',
              frame: { width: 120, height: 50, x: 556, y: 510 },
              styles: { backgroundColor: 'rgba(236,236,236,1)', fillType: 'color', cornerRadiusString: '13', borderRadius: 13, opacity: 1 },
              type: 'shape'
            },
            {
              name: '宠物食品',
              Id: 54,
              nameId: 'A4E84B10-583C-42C1-A0FF-DD7DC975F805',
              frame: { width: 98, height: 33, x: 568, y: 519 },
              textStyles: {
                fontFamily: 'PingFangSC-Light',
                fontSize: '24',
                color: '#7D7D7D',
                letterSpacing: '0.27',
                lineHeight: '33',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '宠物食品',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '3EBC886D-462E-40EE-82AF-B5E6A7A35F3D'
        },
        {
          name: 'Rectangle 2',
          Id: 56,
          nameId: '6842FEC5-77F1-472D-98FA-8C855C864C09',
          frame: { width: 120, height: 50, x: 690, y: 509 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 57,
              nameId: '12BA22ED-A80E-4E53-90A2-D2AE55A08570',
              frame: { width: 120, height: 50, x: 690, y: 509 },
              styles: { backgroundColor: 'rgba(236,236,236,1)', fillType: 'color', cornerRadiusString: '13', borderRadius: 13, opacity: 1 },
              type: 'shape'
            },
            {
              name: '宠物食品',
              Id: 58,
              nameId: 'F4E7AE70-1F03-47FB-B5B3-CE3FCDB237DA',
              frame: { width: 98, height: 33, x: 702, y: 518 },
              textStyles: {
                fontFamily: 'PingFangSC-Light',
                fontSize: '24',
                color: '#7D7D7D',
                letterSpacing: '0.27',
                lineHeight: '33',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '宠物食品',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '6842FEC5-77F1-472D-98FA-8C855C864C09'
        }
      ],
      type: 'group',
      objectID: '272E5931-E045-43C3-9BF4-1EE71868FA46'
    },
    {
      name: 'Rectangle 2',
      Id: 60,
      nameId: '4B5E96D8-FF19-46AD-8659-793665D35E01',
      frame: { width: 750, height: 70, x: 0, y: 571 },
      layers: [
        {
          name: 'Rectangle 2',
          Id: 61,
          nameId: '87E23C59-4A25-486B-A344-20FE7A9F6D27',
          frame: { width: 750, height: 70, x: 0, y: 571 },
          styles: {
            backgroundColor: 'rgba(255,255,255,1)',
            fillType: 'color',
            borderColor: 'rgba(208,208,208,1)',
            borderStyle: 'solid',
            borderWidth: 1,
            opacity: 1
          },
          type: 'shape'
        },
        {
          name: 'Group',
          Id: 63,
          nameId: '7E0F8EBB-6FC2-4DE3-9A95-C631FA90826F',
          frame: { width: 663, height: 35, x: 53, y: 588 },
          layers: [
            {
              name: '综合',
              Id: 64,
              nameId: '2A4395BF-11E6-47A3-9BCD-7B1257B69A61',
              frame: { width: 49, height: 33, x: 53, y: 590 },
              textStyles: {
                fontFamily: 'PingFangSC-Semibold',
                fontSize: '24',
                color: '#000000',
                letterSpacing: '0.27',
                lineHeight: '33',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '综合',
              type: 'text'
            },
            {
              name: '下拉',
              Id: 65,
              nameId: '05971D63-A247-40E4-A2D2-8C5367833BDA',
              frame: { width: 9.69000000000051, height: 5.695000000000164, x: 111.65500000000065, y: 605.1199999999999 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611573307.png'
            },
            {
              name: '销量',
              Id: 66,
              nameId: 'D3DA0E29-919A-4E89-9815-EA6AEE87BA3F',
              frame: { width: 49, height: 33, x: 212, y: 590 },
              textStyles: {
                fontFamily: 'PingFangSC-Light',
                fontSize: '24',
                color: '#818181',
                letterSpacing: '0.27',
                lineHeight: '33',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '销量',
              type: 'text'
            },
            {
              name: '价格',
              Id: 67,
              nameId: 'A858F8FC-C5E2-44EC-A651-5D2F34F00167',
              frame: { width: 49, height: 33, x: 354, y: 590 },
              textStyles: {
                fontFamily: 'PingFangSC-Light',
                fontSize: '24',
                color: '#818181',
                letterSpacing: '0.27',
                lineHeight: '33',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '价格',
              type: 'text'
            },
            {
              name: '上下',
              Id: 68,
              nameId: 'F85193B5-7245-45C7-9980-91C0A0912FCB',
              frame: { width: 8.639999999999418, height: 12, x: 412.6800000000003, y: 601 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611573410.png'
            },
            {
              name: '筛选',
              Id: 69,
              nameId: '397164C7-9CFE-4BFD-A7D2-2CB469D22B0F',
              frame: { width: 49, height: 33, x: 538, y: 588 },
              textStyles: {
                fontFamily: 'PingFangSC-Light',
                fontSize: '24',
                color: '#818181',
                letterSpacing: '0.27',
                lineHeight: '33',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '筛选',
              type: 'text'
            },
            {
              name: '筛选',
              Id: 70,
              nameId: '4E1FBC31-7770-4972-826E-0F81259EF65F',
              frame: { width: 12.799999999999272, height: 13.920000000000073, x: 590.6000000000004, y: 597.04 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611573505.png'
            },
            {
              name: '分类',
              Id: 71,
              nameId: '18019107-F31B-476B-876A-6121AE9B63CB',
              frame: { width: 29, height: 29, x: 687, y: 590 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611573617.png'
            }
          ],
          type: 'group',
          objectID: '7E0F8EBB-6FC2-4DE3-9A95-C631FA90826F'
        }
      ],
      type: 'group',
      objectID: '4B5E96D8-FF19-46AD-8659-793665D35E01'
    },
    {
      name: 'Group',
      Id: 73,
      nameId: 'AA105495-7DCC-47F4-B320-8379BF8B4484',
      frame: { width: 710, height: 345, x: 21, y: 659 },
      layers: [
        {
          name: 'Mask',
          Id: 74,
          nameId: 'FE4D440C-2C31-4986-BDB0-EF4FC0113A84',
          frame: { width: 345, height: 345, x: 21, y: 659 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611573717.png'
        },
        {
          name: 'Mask',
          Id: 75,
          nameId: '0910F6CF-EE9C-41F1-A030-48B23E1C8035',
          frame: { width: 345, height: 345, x: 386, y: 659 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611573954.png'
        }
      ],
      type: 'group',
      objectID: 'AA105495-7DCC-47F4-B320-8379BF8B4484'
    },
    {
      name: 'Group',
      Id: 77,
      nameId: '71734CDB-C23F-4DAA-A120-8409146E58A2',
      frame: { width: 714, height: 97, x: 18, y: 1004 },
      layers: [
        {
          name: 'Group',
          Id: 79,
          nameId: 'C1B9E357-7FA4-44C6-9E56-DCB34433A84E',
          frame: { width: 348, height: 97, x: 18, y: 1004 },
          layers: [
            {
              name: '雅漾舒润卸妆水400ML时到',
              Id: 80,
              nameId: '30E2FF21-D870-4102-A7C8-66A27108F593',
              frame: { width: 345, height: 29, x: 20, y: 1004 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '26',
                color: '#393835',
                letterSpacing: '0',
                lineHeight: '29',
                maxWidth: 345,
                maxHeight: 29,
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '雅漾舒润卸妆水400ML时到',
              type: 'text'
            },
            {
              name: 'Group',
              Id: 82,
              nameId: '102D34DA-A590-41C0-BD0E-A2503F43558D',
              frame: { width: 348, height: 60, x: 18, y: 1041 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 84,
                  nameId: 'F5A656D5-F5D6-48EE-B369-0D54A6150CC7',
                  frame: { width: 30, height: 30, x: 18, y: 1042 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 85,
                      nameId: 'D863C796-1C5B-45AA-8CEE-72402F202750',
                      frame: { width: 27.906976744185158, height: 27.906976744186068, x: 20.093023255814842, y: 1042 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611574181.png'
                    },
                    {
                      name: 'Rectangle 5',
                      Id: 86,
                      nameId: '611101AA-015B-483C-A43F-000B64610678',
                      frame: { width: 11.1627906976737, height: 4.883720930232585, x: 18, y: 1067.1162790697674 },
                      styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
                      type: 'shape'
                    }
                  ],
                  type: 'group',
                  objectID: 'F5A656D5-F5D6-48EE-B369-0D54A6150CC7'
                },
                {
                  name: '德国',
                  Id: 87,
                  nameId: '33E32488-1ACA-43E1-A1AC-BDC70DFAF74D',
                  frame: { width: 41, height: 28, x: 50, y: 1041 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '20',
                    color: '#8F8F8F',
                    letterSpacing: '0.13',
                    lineHeight: '28',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '德国',
                  type: 'text'
                },
                {
                  name: '1 段 I Aptamil 爱他美',
                  Id: 89,
                  nameId: '3F62BB61-AF19-4A3C-9E8E-7DFF9E75DAC6',
                  frame: { width: 254, height: 60, x: 112, y: 1041 },
                  layers: [
                    {
                      name: '1 段 I Aptamil 爱他美',
                      Id: 90,
                      nameId: '442704E0-4CB7-404D-8347-A4546897088B',
                      frame: { width: 198, height: 28, x: 112, y: 1041 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '20',
                        color: '#8F8F8F',
                        letterSpacing: '0.13',
                        lineHeight: '28',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '1 段 I Aptamil 爱他美',
                      type: 'text'
                    },
                    {
                      name: '1232人 copy',
                      Id: 91,
                      nameId: '4AB39177-717F-49A2-ACF2-BE3243B76BFF',
                      frame: { width: 80, height: 33, x: 286, y: 1068 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#898989',
                        letterSpacing: '0',
                        lineHeight: '33',
                        maxWidth: 80,
                        maxHeight: 33,
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '1232人',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '3F62BB61-AF19-4A3C-9E8E-7DFF9E75DAC6'
                }
              ],
              type: 'group',
              objectID: '102D34DA-A590-41C0-BD0E-A2503F43558D'
            },
            {
              name: 'Group',
              Id: 93,
              nameId: '6B37AE12-734F-4614-90FA-EB0137160D53',
              frame: { width: 257, height: 28, x: 23, y: 1072 },
              layers: [
                {
                  name: '¥324.00',
                  Id: 94,
                  nameId: 'A9A19581-4609-4725-97AA-B9F336FFC0D3',
                  frame: { width: 109, height: 28, x: 23, y: 1072 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '28',
                    color: '#CA1D41',
                    lineHeight: '28',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '¥324.00',
                  type: 'text'
                },
                {
                  name: '爱心 copy',
                  Id: 95,
                  nameId: '31EE9AFB-3C73-44DC-AC16-7BF0BCA73735',
                  frame: { width: 21, height: 17, x: 259, y: 1077 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611574322.png'
                }
              ],
              type: 'group',
              objectID: '6B37AE12-734F-4614-90FA-EB0137160D53'
            }
          ],
          type: 'group',
          objectID: 'C1B9E357-7FA4-44C6-9E56-DCB34433A84E'
        },
        {
          name: 'Group',
          Id: 97,
          nameId: 'F93EB8A1-E597-4990-B17F-1638D030FF4F',
          frame: { width: 345, height: 78, x: 387, y: 1023 },
          layers: [
            {
              name: '雅漾舒润卸妆水400ML',
              Id: 98,
              nameId: 'D4C38C5A-37BA-418B-9C46-5FE6ACD1125B',
              frame: { width: 281, height: 29, x: 387, y: 1023 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#393835',
                letterSpacing: '0',
                lineHeight: '29',
                maxWidth: 281,
                maxHeight: 29,
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '雅漾舒润卸妆水400ML',
              type: 'text'
            },
            {
              name: 'Group',
              Id: 100,
              nameId: '3D13C29A-B87A-43AA-9532-4D0A85BF12D1',
              frame: { width: 343, height: 35, x: 389, y: 1066 },
              layers: [
                {
                  name: '¥324.00',
                  Id: 101,
                  nameId: '0D7E6E73-878D-4C0E-B2A4-AED1479230E8',
                  frame: { width: 137, height: 24, x: 389, y: 1066 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '28',
                    color: '#CA1D41',
                    lineHeight: '24',
                    maxWidth: 137,
                    maxHeight: 24,
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '¥324.00',
                  type: 'text'
                },
                {
                  name: '爱心 copy',
                  Id: 102,
                  nameId: '00C9EE7F-AA0D-4E2E-99E7-C0AAFAC3DC3B',
                  frame: { width: 21, height: 17, x: 625, y: 1077 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611574437.png'
                },
                {
                  name: '1232人 copy',
                  Id: 103,
                  nameId: '84D3F589-60DA-404B-AB17-BF4A44384EE6',
                  frame: { width: 80, height: 33, x: 652, y: 1068 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '24',
                    color: '#898989',
                    letterSpacing: '0',
                    lineHeight: '33',
                    maxWidth: 80,
                    maxHeight: 33,
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '1232人',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '3D13C29A-B87A-43AA-9532-4D0A85BF12D1'
            }
          ],
          type: 'group',
          objectID: 'F93EB8A1-E597-4990-B17F-1638D030FF4F'
        }
      ],
      type: 'group',
      objectID: '71734CDB-C23F-4DAA-A120-8409146E58A2'
    },
    {
      name: 'Line',
      Id: 104,
      nameId: '50F3324C-4D91-4AA5-BB89-AF728D2AC2CB',
      frame: { width: 760, height: 3, x: 0, y: 1120 },
      imageStyles: { resize: 'stretch' },
      type: 'image',
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611574557.png'
    },
    {
      name: 'Group',
      Id: 106,
      nameId: '2AB75C55-8E0F-4DA9-BD1E-883ADEC9CA98',
      frame: { width: 711, height: 347, x: 20, y: 1141 },
      layers: [
        {
          name: 'img',
          Id: 108,
          nameId: 'AFF4688C-9864-4659-9178-67F9C3466B21',
          frame: { width: 347, height: 347, x: 20, y: 1141 },
          layers: [
            {
              name: 'img',
              Id: 109,
              nameId: 'A567B567-558E-4C49-8B42-8231C71EB729',
              frame: { width: 345, height: 345, x: 20, y: 1141 },
              styles: { backgroundColor: 'rgba(238,238,238,1)', fillType: 'color', opacity: 1 },
              type: 'shape'
            },
            {
              name: 'img',
              Id: 111,
              nameId: '33966B81-3E90-46A7-8A7A-6015243848DC',
              frame: { width: 346, height: 346, x: 21, y: 1142 },
              layers: [
                {
                  name: 'img',
                  Id: 112,
                  nameId: '3C5F31F7-9B55-4BE8-A7BB-D451599F4501',
                  frame: { width: 345, height: 345, x: 21, y: 1142 },
                  styles: { backgroundColor: 'rgba(238,238,238,1)', fillType: 'color', opacity: 1 },
                  type: 'shape'
                },
                {
                  name: '5ceae101bb601b499c3aa03bad1c155418e46dce1fa34-F3XyVw_fw658',
                  Id: 113,
                  nameId: '4710FA3B-603F-4438-AFBF-BC348A8CBB89',
                  frame: { width: 346, height: 346, x: 21, y: 1142 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611574686.png'
                }
              ],
              type: 'group',
              objectID: '33966B81-3E90-46A7-8A7A-6015243848DC'
            }
          ],
          type: 'group',
          objectID: 'AFF4688C-9864-4659-9178-67F9C3466B21'
        },
        {
          name: 'img',
          Id: 115,
          nameId: '8DDD75A3-01CA-452E-90FD-737A678C30EA',
          frame: { width: 345, height: 345, x: 386, y: 1142 },
          layers: [
            {
              name: 'img',
              Id: 116,
              nameId: 'E01B4C3F-386C-4447-9838-F61EB053E22C',
              frame: { width: 345, height: 345, x: 386, y: 1142 },
              styles: { backgroundColor: 'rgba(238,238,238,1)', fillType: 'color', opacity: 1 },
              type: 'shape'
            },
            {
              name: 'img',
              Id: 118,
              nameId: '0F2E936E-BB41-4F01-9C64-C74B57BDBF05',
              frame: { width: 345, height: 345, x: 386, y: 1142 },
              layers: [
                {
                  name: 'img',
                  Id: 119,
                  nameId: 'A820F28E-1296-42B5-A96A-243FD942B730',
                  frame: { width: 345, height: 345, x: 386, y: 1142 },
                  styles: { backgroundColor: 'rgba(238,238,238,1)', fillType: 'color', opacity: 1 },
                  type: 'shape'
                },
                {
                  name: '000000000106716453_1',
                  Id: 121,
                  nameId: '294A3BB0-4CDD-4ED2-AF03-F7BE705F5EED',
                  frame: { width: 345, height: 345, x: 386, y: 1142 },
                  layers: [
                    {
                      name: '000000000106716453_1',
                      Id: 122,
                      nameId: 'A1F8C5C8-784C-4630-BCC4-3CA644C4B7BC',
                      frame: { width: 345, height: 345, x: 386, y: 1142 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611574899.png'
                    }
                  ],
                  type: 'group',
                  objectID: '294A3BB0-4CDD-4ED2-AF03-F7BE705F5EED'
                }
              ],
              type: 'group',
              objectID: '0F2E936E-BB41-4F01-9C64-C74B57BDBF05'
            }
          ],
          type: 'group',
          objectID: '8DDD75A3-01CA-452E-90FD-737A678C30EA'
        }
      ],
      type: 'group',
      objectID: '2AB75C55-8E0F-4DA9-BD1E-883ADEC9CA98'
    },
    {
      name: 'Oval',
      Id: 124,
      nameId: 'AC93DF87-8FE7-4E2C-B42F-870AC26A1846',
      frame: { width: 75, height: 75, x: 633, y: 1092 },
      layers: [
        {
          name: 'Oval',
          Id: 125,
          nameId: '4C3527EC-26CB-448B-9E06-6360C257497A',
          frame: { width: 75, height: 75, x: 633, y: 1092 },
          styles: { backgroundColor: 'rgba(126,126,126,1)', fillType: 'color', borderRadius: 75, opacity: 1 },
          type: 'shape'
        },
        {
          name: '分享',
          Id: 126,
          nameId: 'EDB0FAFC-E7E7-4F1E-97BC-C5EF72E8388D',
          frame: { width: 53, height: 37, x: 644, y: 1111 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '26',
            color: '#FFFFFF',
            letterSpacing: '0.17',
            lineHeight: '37',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '分享',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: 'AC93DF87-8FE7-4E2C-B42F-870AC26A1846'
    },
    {
      name: 'Background',
      Id: 128,
      nameId: 'B8B7DA39-A1FF-4BA4-9264-D5C4716BF374',
      frame: { width: 750, height: 90, x: 0, y: 1246 },
      layers: [
        {
          name: 'Background',
          Id: 129,
          nameId: 'FB89662E-441C-45B2-BD63-222EEB852E56',
          frame: { width: 750, height: 90, x: 0, y: 1246 },
          styles: {
            backgroundColor: 'rgba(255,255,255,1)',
            fillType: 'color',
            borderColor: 'rgba(205,194,235,1)',
            borderStyle: 'solid',
            borderWidth: 1,
            opacity: 1
          },
          type: 'shape'
        },
        {
          name: 'Group',
          Id: 131,
          nameId: 'D03EAA7C-3935-42B9-8949-063A305513BD',
          frame: { width: 628, height: 30, x: 59, y: 1261 },
          layers: [
            {
              name: '首页',
              Id: 132,
              nameId: '1515446B-32DE-4B23-9822-D72A684606C7',
              frame: { width: 26, height: 28, x: 59, y: 1263 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611575113.png'
            },
            {
              name: '分类',
              Id: 133,
              nameId: '709FC87A-6A76-4CEC-A40A-249033837CCB',
              frame: { width: 25, height: 23.958333333333258, x: 203, y: 1266 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611575234.png'
            },
            {
              name: '钻石',
              Id: 134,
              nameId: '8083D706-BE04-4021-984A-5A02C7239C48',
              frame: { width: 28, height: 23, x: 361, y: 1266 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611575360.png'
            },
            {
              name: '购物袋',
              Id: 135,
              nameId: '50EEF915-FE00-4EE9-84CB-E23301DD5D82',
              frame: { width: 27, height: 27, x: 508, y: 1261 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611575483.png'
            },
            {
              name: 'Shape',
              Id: 136,
              nameId: '8626E331-6925-4651-B410-2844D6268CB1',
              frame: { width: 26, height: 26, x: 661, y: 1263 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523611575611.png'
            }
          ],
          type: 'group',
          objectID: 'D03EAA7C-3935-42B9-8949-063A305513BD'
        },
        {
          name: 'Group',
          Id: 138,
          nameId: 'F690FDD3-9696-4DC5-A309-D58C00A9095E',
          frame: { width: 664, height: 30, x: 40, y: 1299 },
          layers: [
            {
              name: '首页',
              Id: 139,
              nameId: '305F581C-473A-4A4C-A99C-F08C3518A919',
              frame: { width: 68, height: 30, x: 40, y: 1299 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '22',
                color: '#A1131F',
                letterSpacing: '0.26',
                textAlign: 'center',
                lineHeight: '30',
                maxWidth: 68,
                maxHeight: 30,
                fontWeight: 'normal'
              },
              value: '首页',
              type: 'text'
            },
            {
              name: '全部',
              Id: 140,
              nameId: '8AD00920-CDC3-4345-ABB0-1958191421FE',
              frame: { width: 88, height: 30, x: 171, y: 1299 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '22',
                color: '#9092A5',
                letterSpacing: '0.12',
                textAlign: 'center',
                lineHeight: '30',
                maxWidth: 88,
                maxHeight: 30,
                fontWeight: 'bold'
              },
              value: '全部',
              type: 'text'
            },
            {
              name: '店主精选',
              Id: 141,
              nameId: 'F7B2A985-5AB2-4CEF-8CD6-9D08392D6DDD',
              frame: { width: 120, height: 30, x: 315, y: 1299 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '22',
                color: '#9092A5',
                letterSpacing: '0.26',
                textAlign: 'center',
                lineHeight: '30',
                maxWidth: 120,
                maxHeight: 30,
                fontWeight: 'bold'
              },
              value: '店主精选',
              type: 'text'
            },
            {
              name: '购物袋',
              Id: 142,
              nameId: 'F3DBED67-D4CA-4DA1-9362-D0A1602DBD0D',
              frame: { width: 106, height: 30, x: 470, y: 1299 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '22',
                color: '#9092A5',
                letterSpacing: '0.12',
                textAlign: 'center',
                lineHeight: '30',
                maxWidth: 106,
                maxHeight: 30,
                fontWeight: 'bold'
              },
              value: '购物袋',
              type: 'text'
            },
            {
              name: '我的',
              Id: 143,
              nameId: '7D4CBF4D-CB67-404C-A02B-A91A2F56F7BD',
              frame: { width: 60, height: 30, x: 644, y: 1299 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '22',
                color: '#9092A5',
                letterSpacing: '0.12',
                textAlign: 'center',
                lineHeight: '30',
                maxWidth: 60,
                maxHeight: 30,
                fontWeight: 'bold'
              },
              value: '我的',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: 'F690FDD3-9696-4DC5-A309-D58C00A9095E'
        }
      ],
      type: 'group',
      objectID: 'B8B7DA39-A1FF-4BA4-9264-D5C4716BF374'
    }
  ],
  nameId: 1523611572336,
  Id: 17,
  type: 'group',
  frame: { x: 0, y: 0, width: 750, height: 1334 }
  // tslint:disable-next-line:max-file-line-count
}
