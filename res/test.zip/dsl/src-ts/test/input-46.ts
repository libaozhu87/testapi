export default {
  layers: [
    {
      name: 'Rectangle',
      Id: 450,
      nameId: '0663AB6C-AD68-460A-AE16-0E8BAB891698',
      frame: {
        width: 750,
        height: 377,
        x: 0,
        y: 964
      },
      styles: {
        backgroundColor: 'rgba(0,0,0,0.5)'
      },
      type: 'shape'
    },
    {
      name: 'Rectangle 5 Copy',
      Id: 451,
      nameId: '6336AEF2-605C-4552-ADA9-F468833B9FE1',
      frame: {
        width: 750,
        height: 768,
        x: 0,
        y: 217
      },
      styles: {
        backgroundColor: 'rgba(255,255,255,1)'
      },
      type: 'shape'
    },
    {
      name: '自定价格',
      Id: 452,
      nameId: 'AAC2A102-9799-44B8-945D-9F1EB0DAF087',
      frame: {
        width: 96,
        height: 33,
        x: 28,
        y: 805
      },
      textStyles: {
        fontFamily: 'PingFangSC-Regular',
        fontSize: 24,
        color: '#888888',
        lineHeight: '33',
        textAlign: 'left',
        fontWeight: 'normal'
      },
      value: '自定价格',
      type: 'text'
    },
    {
      name: 'Group 26',
      Id: 454,
      nameId: 'F725F0D3-439C-4D72-90EC-1CBDD0F1F60C',
      frame: {
        width: 498,
        height: 64,
        x: 28,
        y: 869
      },
      layers: [
        {
          name: 'Group 14 Copy 10',
          Id: 456,
          nameId: '796EC31A-EBB0-485F-A701-285F9B80007F',
          frame: {
            width: 220,
            height: 64,
            x: 28,
            y: 869
          },
          layers: [
            {
              name: 'Rectangle 9',
              Id: 457,
              nameId: '5F83C2A6-F7D8-47F7-82F9-978EEDA61EB3',
              frame: {
                width: 220,
                height: 64,
                x: 28,
                y: 869
              },
              styles: {
                backgroundColor: 'rgba(142,142,147,0.1)',
                borderRadius: 10
              },
              type: 'shape'
            },
            {
              name: '1000',
              Id: 458,
              nameId: 'CED52215-3B53-4987-95DC-316BAF18FB7B',
              frame: {
                width: 58,
                height: 40,
                x: 50,
                y: 881
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 26,
                color: '#222222',
                lineHeight: '40',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '1000',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '796EC31A-EBB0-485F-A701-285F9B80007F'
        },
        {
          name: 'Group 14 Copy 11',
          Id: 460,
          nameId: '024BCAE2-58FD-414B-B40F-8D9569DD2CD9',
          frame: {
            width: 220,
            height: 64,
            x: 306,
            y: 869
          },
          layers: [
            {
              name: 'Rectangle 9',
              Id: 461,
              nameId: '6B7A41BD-3F14-4173-94CF-BC4FE8CCD89A',
              frame: {
                width: 220,
                height: 64,
                x: 306,
                y: 869
              },
              styles: {
                backgroundColor: 'rgba(142,142,147,0.1)',
                borderRadius: 10
              },
              type: 'shape'
            },
            {
              name: '6000',
              Id: 462,
              nameId: 'C4321786-C698-46A2-B403-2DA5184A04FA',
              frame: {
                width: 63,
                height: 40,
                x: 328,
                y: 881
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 26,
                color: '#222222',
                lineHeight: '40',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '6000',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '024BCAE2-58FD-414B-B40F-8D9569DD2CD9'
        },
        {
          name: 'Rectangle 5',
          Id: 463,
          nameId: '7536723A-0A5B-404D-A482-11FD674539C7',
          frame: {
            width: 24,
            height: 4,
            x: 267,
            y: 899
          },
          styles: {
            backgroundColor: 'rgba(0,0,0,0.08)',
            borderRadius: 4
          },
          type: 'shape'
        }
      ],
      type: 'group',
      objectID: 'F725F0D3-439C-4D72-90EC-1CBDD0F1F60C'
    },
    {
      name: '1000-1500元',
      Id: 464,
      nameId: 'F21E5E6F-7722-4CDA-B7A9-5885DFB7DF97',
      frame: {
        width: 169,
        height: 40,
        x: 35,
        y: 414
      },
      textStyles: {
        fontFamily: 'PingFangSC-Regular',
        fontSize: 28,
        color: '#999999',
        lineHeight: '39.20000076293945',
        textAlign: 'left',
        fontWeight: 'normal'
      },
      value: '1000-1500元',
      type: 'text'
    },
    {
      name: '1500-2000元',
      Id: 465,
      nameId: 'DD4DBC23-155A-46EA-92B3-C854D44EEAB7',
      frame: {
        width: 174,
        height: 40,
        x: 35,
        y: 500
      },
      textStyles: {
        fontFamily: 'PingFangSC-Regular',
        fontSize: 28,
        color: '#999999',
        lineHeight: '39.20000076293945',
        textAlign: 'left',
        fontWeight: 'normal'
      },
      value: '1500-2000元',
      type: 'text'
    },
    {
      name: '2000-3000元',
      Id: 466,
      nameId: '38474AC0-7AA5-415A-8D46-63AA4B7912BE',
      frame: {
        width: 180,
        height: 40,
        x: 35,
        y: 586
      },
      textStyles: {
        fontFamily: 'PingFangSC-Regular',
        fontSize: 28,
        color: '#999999',
        lineHeight: '39.20000076293945',
        textAlign: 'left',
        fontWeight: 'normal'
      },
      value: '2000-3000元',
      type: 'text'
    },
    {
      name: '3000元以上',
      Id: 467,
      nameId: '3D884517-503C-43DB-9FFE-01232484F153',
      frame: {
        width: 152,
        height: 40,
        x: 35,
        y: 672
      },
      textStyles: {
        fontFamily: 'PingFangSC-Regular',
        fontSize: 28,
        color: '#999999',
        lineHeight: '39.20000076293945',
        textAlign: 'left',
        fontWeight: 'normal'
      },
      value: '3000元以上',
      type: 'text'
    },
    {
      name: 'Bitmap',
      Id: 468,
      nameId: '7AED69E9-0B68-41C4-ABB2-55FE08EA2D6E',
      frame: {
        width: 750,
        height: 2,
        x: 0,
        y: 763
      },
      imageStyles: {
        resize: 'stretch'
      },
      type: 'image',
      value: 'https://gw.alicdn.com/tfs/TB1wlWzxY5YBuNjSspoXXbeNFXa-750-2.png'
    },
    {
      name: 'Rectangle 8',
      Id: 469,
      nameId: '7513AF58-F557-4A33-8C41-53E05AAE8D7C',
      frame: {
        width: 180,
        height: 72,
        x: 546,
        y: 863
      },
      styles: {
        backgroundColor: 'rgba(255,218,68,1)',
        borderRadius: 4
      },
      type: 'shape'
    },
    {
      name: '确定',
      Id: 470,
      nameId: '37AD6CDE-B29F-4956-B92B-3DC605C3B195',
      frame: {
        width: 65,
        height: 45,
        x: 604,
        y: 877
      },
      textStyles: {
        fontFamily: '.PingFangSC-Regular',
        fontSize: 32,
        color: '#333333',
        lineHeight: '44.79999923706055',
        textAlign: 'left',
        fontWeight: 'normal'
      },
      value: '确定',
      type: 'text'
    },
    {
      name: 'title',
      Id: 472,
      nameId: 'CE3A197B-C54B-4BA8-828B-BC862454060F',
      frame: {
        width: 750,
        height: 88,
        x: 0,
        y: 40
      },
      layers: [
        {
          name: 'Bitmap',
          Id: 473,
          nameId: 'C0B6B15C-DB04-4AB9-AEBF-104107C6DD55',
          frame: {
            width: 750,
            height: 88,
            x: 0,
            y: 40
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB12RT3x9tYBeNjSspkXXbU8VXa-750-88.png'
        },
        {
          name: 'Bitmap',
          Id: 474,
          nameId: 'D69F6AA7-25EF-48BC-9214-ED478B262DFC',
          frame: {
            width: 21,
            height: 38,
            x: 35,
            y: 65
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1LKJYx4SYBuNjSsphXXbGvVXa-21-38.png'
        },
        {
          name: 'Bitmap',
          Id: 475,
          nameId: '24C76EEC-9D4E-478A-AC96-42CA3E28409C',
          frame: {
            width: 637,
            height: 64,
            x: 92,
            y: 52
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1JdiPx4SYBuNjSspjXXX73VXa-637-64.png'
        },
        {
          name: 'Group',
          Id: 477,
          nameId: '8020C852-3A15-48B7-AE4E-D6E9EF57D66A',
          frame: {
            width: 110,
            height: 40,
            x: 112,
            y: 64
          },
          layers: [
            {
              name: 'Bitmap',
              Id: 478,
              nameId: 'FD30327F-804B-4249-8D27-16E9996FBC65',
              frame: {
                width: 28,
                height: 28,
                x: 112,
                y: 70
              },
              imageStyles: {
                resize: 'stretch'
              },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1_9mux1OSBuNjy0FdXXbDnVXa-28-28.png'
            },
            {
              name: '↳ Placeholder Label',
              Id: 479,
              nameId: '3903C688-22CC-4F85-84F8-CE6C18ADC160',
              frame: {
                width: 64,
                height: 40,
                x: 158,
                y: 64
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 32,
                color: '#222222',
                lineHeight: '40',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '西溪',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '8020C852-3A15-48B7-AE4E-D6E9EF57D66A'
        }
      ],
      type: 'group',
      objectID: 'CE3A197B-C54B-4BA8-828B-BC862454060F'
    },
    {
      name: 'Bitmap',
      Id: 480,
      nameId: '3B549086-F5BB-4E1E-A310-593CAADAB45F',
      frame: {
        width: 750,
        height: 88,
        x: 0,
        y: 128
      },
      imageStyles: {
        resize: 'stretch'
      },
      type: 'image',
      value: 'https://gw.alicdn.com/tfs/TB16Rydx1uSBuNjSsplXXbe8pXa-750-88.png'
    },
    {
      name: 'Group 11',
      Id: 482,
      nameId: '17B9FC1A-572C-4D11-9586-0B54586811F0',
      frame: {
        width: 140,
        height: 42,
        x: 30,
        y: 152
      },
      layers: [
        {
          name: '全杭州',
          Id: 483,
          nameId: '104178A6-0B86-4A43-876A-616A32FB6BD0',
          frame: {
            width: 90,
            height: 42,
            x: 30,
            y: 152
          },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: 30,
            color: '#222222',
            lineHeight: '42',
            textAlign: 'left',
            fontWeight: 'bold'
          },
          value: '全杭州',
          type: 'text'
        },
        {
          name: 'Bitmap',
          Id: 484,
          nameId: '8D754365-4E07-4649-B80F-7D695189B69A',
          frame: {
            width: 16,
            height: 10,
            x: 154,
            y: 168
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1MxZfx9tYBeNjSspaXXaOOFXa-16-10.png'
        }
      ],
      type: 'group',
      objectID: '17B9FC1A-572C-4D11-9586-0B54586811F0'
    },
    {
      name: 'Group 4',
      Id: 486,
      nameId: '0E517304-AAED-4DCA-9525-8F930196FB8E',
      frame: {
        width: 88,
        height: 42,
        x: 441,
        y: 152
      },
      layers: [
        {
          name: '租金',
          Id: 487,
          nameId: '9905FA86-9FF5-474C-B762-7CC77E4BD0DD',
          frame: {
            width: 60,
            height: 42,
            x: 441,
            y: 152
          },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: 30,
            color: '#222222',
            textAlign: 'center',
            lineHeight: '42',
            fontWeight: 'bold'
          },
          value: '租金',
          type: 'text'
        },
        {
          name: 'Bitmap',
          Id: 488,
          nameId: '2DFFC75C-78EB-4889-8312-920DEEE1FCA1',
          frame: {
            width: 16,
            height: 10,
            x: 513,
            y: 168
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1Z8Y3x9tYBeNjSspkXXbU8VXa-16-10.png'
        }
      ],
      type: 'group',
      objectID: '0E517304-AAED-4DCA-9525-8F930196FB8E'
    },
    {
      name: 'Group 9',
      Id: 490,
      nameId: '53502F07-DD37-478E-A859-E0D99EA153D1',
      frame: {
        width: 84,
        height: 42,
        x: 636,
        y: 152
      },
      layers: [
        {
          name: '筛选',
          Id: 491,
          nameId: '41A75A44-ED45-43D2-97E4-0A3B62163961',
          frame: {
            width: 60,
            height: 42,
            x: 636,
            y: 152
          },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: 30,
            color: '#888888',
            lineHeight: '42',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '筛选',
          type: 'text'
        },
        {
          name: 'Bitmap',
          Id: 492,
          nameId: 'AFDAB989-B710-4185-A426-4D924986125E',
          frame: {
            width: 20,
            height: 21,
            x: 700,
            y: 164
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1S1NYx4SYBuNjSsphXXbGvVXa-20-21.png'
        }
      ],
      type: 'group',
      objectID: '53502F07-DD37-478E-A859-E0D99EA153D1'
    },
    {
      name: 'Rectangle 3',
      Id: 493,
      nameId: '89F683E3-138D-4E1A-8588-282865228B89',
      frame: {
        width: 2,
        height: 40,
        x: 594,
        y: 152
      },
      styles: {
        backgroundColor: 'rgba(0,0,0,0.08)'
      },
      type: 'shape'
    },
    {
      name: 'Bitmap',
      Id: 494,
      nameId: '15D9EF88-BB93-4DCC-84D7-B88E88D1BB1D',
      frame: {
        width: 750,
        height: 40,
        x: 0,
        y: 0
      },
      imageStyles: {
        resize: 'stretch'
      },
      type: 'image',
      value: 'https://gw.alicdn.com/tfs/TB1SRCdx1uSBuNjSsplXXbe8pXa-750-40.png'
    },
    {
      name: 'Group 6',
      Id: 496,
      nameId: 'B7512DFE-403C-4AED-A234-6AD9D483BE79',
      frame: {
        width: 148,
        height: 42,
        x: 225,
        y: 151
      },
      layers: [
        {
          name: '综合排序',
          Id: 497,
          nameId: '0744DB2B-067D-4C13-A225-65FACDFFB23F',
          frame: {
            width: 120,
            height: 42,
            x: 225,
            y: 151
          },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: 30,
            color: '#222222',
            lineHeight: '42',
            textAlign: 'left',
            fontWeight: 'bold'
          },
          value: '综合排序',
          type: 'text'
        },
        {
          name: 'Bitmap',
          Id: 498,
          nameId: '37D34D85-978F-4B0F-81AB-908B54BFE9E5',
          frame: {
            width: 16,
            height: 10,
            x: 357,
            y: 167
          },
          imageStyles: {
            resize: 'stretch'
          },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1A43fx9tYBeNjSspaXXaOOFXa-16-10.png'
        }
      ],
      type: 'group',
      objectID: 'B7512DFE-403C-4AED-A234-6AD9D483BE79'
    },
    {
      name: '1000元以下',
      Id: 499,
      nameId: '7EAB0134-3AD6-4DFF-AB51-CF2A8369610B',
      frame: {
        width: 146,
        height: 40,
        x: 35,
        y: 328
      },
      textStyles: {
        fontFamily: 'PingFangSC-Regular',
        fontSize: 28,
        color: '#999999',
        lineHeight: '39.20000076293945',
        textAlign: 'left',
        fontWeight: 'normal'
      },
      value: '1000元以下',
      type: 'text'
    },
    {
      name: '不限',
      Id: 500,
      nameId: '2B2ED36A-03AC-4997-A1AF-4DCE0666E128',
      frame: {
        width: 56,
        height: 40,
        x: 35,
        y: 242
      },
      textStyles: {
        fontFamily: 'PingFangSC-Medium',
        fontSize: 28,
        color: '#222222',
        lineHeight: '39.20000076293945',
        textAlign: 'left',
        fontWeight: 'bold'
      },
      value: '不限',
      type: 'text'
    }
  ],
  nameId: 1529044758996,
  Id: 449,
  type: 'group',
  frame: {
    x: 0,
    y: 0,
    width: 750,
    height: 1334
  },
  styles: {
    backgroundColor: 'rgba(255,255,255,1)'
  }
}
