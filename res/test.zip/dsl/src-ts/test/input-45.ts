export default {
  layers: [
    {
      name: 'Path 9',
      Id: 2,
      nameId: '3A33F287-A351-42E8-B0A5-02A7600CEDD6',
      frame: {
        width: 1,
        height: 1,
        x: 795,
        y: 443
      },
      styles: {
        borderColor: 'rgba(151,151,151,1)',
        borderStyle: 'solid',
        borderWidth: 1
      },
      type: 'shape'
    },
    {
      name: 'Group 8',
      Id: 4,
      nameId: '76AD13AE-6130-4CB2-8128-89E846C6EB91',
      frame: {
        width: 750,
        height: 270,
        x: 0,
        y: 216
      },
      layers: [
        {
          name: 'Group 7',
          Id: 6,
          nameId: '576C4F6B-BDFA-4B48-844A-CBE04E675DF9',
          frame: {
            width: 750,
            height: 238,
            x: 0,
            y: 216
          },
          layers: [
            {
              name: 'Rectangle',
              Id: 7,
              nameId: '6F344F8B-C82D-4ED4-9F00-93D5486F3FD5',
              frame: {
                width: 750,
                height: 230,
                x: 0,
                y: 216
              },
              styles: {
                backgroundColor: 'rgba(255,255,255,1)'
              },
              type: 'shape'
            },
            {
              name: '杭州余杭租房个人出租，大华西…',
              Id: 8,
              nameId: 'E9FFCD5C-5185-44D6-B8CB-14E8612ABF17',
              frame: {
                width: 422,
                height: 42,
                x: 296,
                y: 250
              },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: 28,
                color: '#3F4045',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '杭州余杭租房个人出租，大华西…',
              type: 'text'
            },
            {
              name: 'Group 3',
              Id: 10,
              nameId: '9356EF7D-D320-4063-A96D-6A7D096DA578',
              frame: {
                width: 240,
                height: 190,
                x: 32,
                y: 256
              },
              layers: [
                {
                  name: 'Mask',
                  Id: 11,
                  nameId: '3E0FD089-FAC6-41F2-A72A-8EAB60E9B6FD',
                  frame: {
                    width: 240,
                    height: 190,
                    x: 32,
                    y: 256
                  },
                  styles: {
                    backgroundColor: 'rgba(216,216,216,1)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'c87a3eed64ba6a8331cdf1ceff2876a8fe0571821ebfd0-YqxL1Z_fw658',
                  Id: 13,
                  nameId: '2CB37ADD-52FF-4CB0-8937-81BB5F1998CB',
                  frame: {
                    width: 240,
                    height: 190,
                    x: 32,
                    y: 256
                  },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 14,
                      nameId: '93061114-0BA6-4B7F-A902-000C766DD10C',
                      frame: {
                        width: 240,
                        height: 190,
                        x: 32,
                        y: 256
                      },
                      imageStyles: {
                        resize: 'stretch'
                      },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1DNaGxkyWBuNjy0FpXXassXXa-240-190.png'
                    }
                  ],
                  type: 'group',
                  objectID: '2CB37ADD-52FF-4CB0-8937-81BB5F1998CB'
                }
              ],
              type: 'group',
              objectID: '9356EF7D-D320-4063-A96D-6A7D096DA578'
            },
            {
              name: 'Group 6',
              Id: 16,
              nameId: 'ABA50D33-AB28-40CE-89A5-CE98CDFCEB40',
              frame: {
                width: 422,
                height: 154,
                x: 296,
                y: 300
              },
              layers: [
                {
                  name: 'Group 16',
                  Id: 18,
                  nameId: '90F2FBE7-35DF-44F2-AFDC-290FE31FAA60',
                  frame: {
                    width: 143,
                    height: 46,
                    x: 296,
                    y: 408
                  },
                  layers: [
                    {
                      name: '¥',
                      Id: 19,
                      nameId: '8B5F6EB6-03BB-4EC3-85B3-840A489D4651',
                      frame: {
                        width: 15,
                        height: 33,
                        x: 296,
                        y: 417
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '33',
                        fontWeight: 'bold'
                      },
                      value: '¥',
                      type: 'text'
                    },
                    {
                      name: '3500/月',
                      Id: 20,
                      nameId: '266892F5-1ECE-4EB6-BF88-58033BFB3EC7',
                      frame: {
                        width: 125,
                        height: 45,
                        x: 314,
                        y: 408.20000076293945
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '44.79999923706055',
                        fontWeight: 'bold'
                      },
                      value: '3500/月',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '90F2FBE7-35DF-44F2-AFDC-290FE31FAA60'
                },
                {
                  name: '1室1厅1卫,大华西溪风情',
                  Id: 21,
                  nameId: '2DF1399D-6400-4CCB-953D-F47A3DF945AF',
                  frame: {
                    width: 422,
                    height: 33.599998474121094,
                    x: 296,
                    y: 300
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 24,
                    color: '#999999',
                    lineHeight: '33.59999847412109',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '1室1厅1卫,大华西溪风情',
                  type: 'text'
                },
                {
                  name: 'Group 5',
                  Id: 23,
                  nameId: '14C30448-9214-4152-899F-DE54014414D7',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 296,
                    y: 348
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 24,
                      nameId: 'E064186A-168F-480E-A979-32E91CCDA16B',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 296,
                        y: 348
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '随时看房',
                      Id: 25,
                      nameId: 'E831B490-0178-4924-9A24-17460238A7A0',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 306,
                        y: 349
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '随时看房',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '14C30448-9214-4152-899F-DE54014414D7'
                },
                {
                  name: 'Group 5 Copy',
                  Id: 27,
                  nameId: '47002A23-6095-4646-8E45-6774D4891E1D',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 428,
                    y: 348
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 28,
                      nameId: 'BAE94A72-A8EF-49F9-B922-6B2C0C90E59A',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 428,
                        y: 348
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '商圈附近',
                      Id: 29,
                      nameId: '04E60C09-2E88-4DE4-BF17-4A942010DA24',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 438,
                        y: 349
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '商圈附近',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '47002A23-6095-4646-8E45-6774D4891E1D'
                },
                {
                  name: 'Group 5 Copy 2',
                  Id: 31,
                  nameId: 'E3274078-3335-4EFD-BA50-712B39B54423',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 560,
                    y: 348
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 32,
                      nameId: '07AB4559-1422-4461-8E84-231BFE1AD6C0',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 560,
                        y: 348
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '健身会馆',
                      Id: 33,
                      nameId: '89AF8D7A-3699-411C-9946-5942A613A5CB',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 570,
                        y: 349
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '健身会馆',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'E3274078-3335-4EFD-BA50-712B39B54423'
                }
              ],
              type: 'group',
              objectID: 'ABA50D33-AB28-40CE-89A5-CE98CDFCEB40'
            }
          ],
          type: 'group',
          objectID: '576C4F6B-BDFA-4B48-844A-CBE04E675DF9'
        },
        {
          name: 'Group 9',
          Id: 35,
          nameId: '99F1AD55-4327-436F-BB38-D655799503A1',
          frame: {
            width: 718,
            height: 40,
            x: 32,
            y: 446
          },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 36,
              nameId: '9FC61F78-DAA8-48E9-B778-912515BE71D6',
              frame: {
                width: 718,
                height: 40,
                x: 32,
                y: 446
              },
              styles: {},
              type: 'shape'
            }
          ],
          type: 'group',
          objectID: '99F1AD55-4327-436F-BB38-D655799503A1'
        }
      ],
      type: 'group',
      objectID: '76AD13AE-6130-4CB2-8128-89E846C6EB91'
    },
    {
      name: 'Group 8 Copy 3',
      Id: 38,
      nameId: '31745652-3E3E-48CA-B3F8-714C14046208',
      frame: {
        width: 750,
        height: 270,
        x: 0,
        y: 1026
      },
      layers: [
        {
          name: 'Group 7',
          Id: 40,
          nameId: '59B3B772-EB9F-4383-B9F8-BF395995F00E',
          frame: {
            width: 750,
            height: 238,
            x: 0,
            y: 1026
          },
          layers: [
            {
              name: 'Rectangle',
              Id: 41,
              nameId: '8F76A1BC-E5EA-444B-AE3F-2B551F724E6E',
              frame: {
                width: 750,
                height: 230,
                x: 0,
                y: 1026
              },
              styles: {
                backgroundColor: 'rgba(255,255,255,1)'
              },
              type: 'shape'
            },
            {
              name: '杭州余杭租房个人出租，大华西…',
              Id: 42,
              nameId: 'AB01F573-792D-4443-9494-4576970373C1',
              frame: {
                width: 422,
                height: 42,
                x: 296,
                y: 1060
              },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: 28,
                color: '#3F4045',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '杭州余杭租房个人出租，大华西…',
              type: 'text'
            },
            {
              name: 'Group 3',
              Id: 44,
              nameId: '608480C8-F84D-4553-B6C8-E8A123366633',
              frame: {
                width: 240,
                height: 190,
                x: 32,
                y: 1066
              },
              layers: [
                {
                  name: 'Mask',
                  Id: 45,
                  nameId: '656E69AF-E5C8-4923-968C-9E9196F3B593',
                  frame: {
                    width: 240,
                    height: 190,
                    x: 32,
                    y: 1066
                  },
                  styles: {
                    backgroundColor: 'rgba(216,216,216,1)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'c87a3eed64ba6a8331cdf1ceff2876a8fe0571821ebfd0-YqxL1Z_fw658',
                  Id: 47,
                  nameId: '6644E2C3-5D2E-45B1-9D7E-CE4ADB1CB0E9',
                  frame: {
                    width: 240,
                    height: 190,
                    x: 32,
                    y: 1066
                  },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 48,
                      nameId: '218E0D01-F132-486A-A22A-DE955AD66CE9',
                      frame: {
                        width: 240,
                        height: 190,
                        x: 32,
                        y: 1066
                      },
                      imageStyles: {
                        resize: 'stretch'
                      },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1kuNSxgmTBuNjy1XbXXaMrVXa-240-190.png'
                    }
                  ],
                  type: 'group',
                  objectID: '6644E2C3-5D2E-45B1-9D7E-CE4ADB1CB0E9'
                }
              ],
              type: 'group',
              objectID: '608480C8-F84D-4553-B6C8-E8A123366633'
            },
            {
              name: 'Group 6',
              Id: 50,
              nameId: 'F0705342-7932-4334-A26D-52C2BD1C7538',
              frame: {
                width: 422,
                height: 154,
                x: 296,
                y: 1110
              },
              layers: [
                {
                  name: 'Group 16',
                  Id: 52,
                  nameId: '410D9595-B8DA-4B23-A3B1-FDE17740E74C',
                  frame: {
                    width: 143,
                    height: 46,
                    x: 296,
                    y: 1218
                  },
                  layers: [
                    {
                      name: '¥',
                      Id: 53,
                      nameId: '5B594EEE-F385-4B9E-9124-8B38BC1BF89D',
                      frame: {
                        width: 15,
                        height: 33,
                        x: 296,
                        y: 1227
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '33',
                        fontWeight: 'bold'
                      },
                      value: '¥',
                      type: 'text'
                    },
                    {
                      name: '3500/月',
                      Id: 54,
                      nameId: 'B77F8652-70B6-433F-A6EB-60AE83278AFF',
                      frame: {
                        width: 125,
                        height: 45,
                        x: 314,
                        y: 1218.2000007629395
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '44.79999923706055',
                        fontWeight: 'bold'
                      },
                      value: '3500/月',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '410D9595-B8DA-4B23-A3B1-FDE17740E74C'
                },
                {
                  name: '1室1厅1卫,大华西溪风情',
                  Id: 55,
                  nameId: 'F405A324-B8DF-43C3-8F81-E53A8431CED9',
                  frame: {
                    width: 422,
                    height: 33.599998474121094,
                    x: 296,
                    y: 1110
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 24,
                    color: '#999999',
                    lineHeight: '33.59999847412109',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '1室1厅1卫,大华西溪风情',
                  type: 'text'
                },
                {
                  name: 'Group 5',
                  Id: 57,
                  nameId: '35C52B17-A97A-4D34-A146-23E34244CC0B',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 296,
                    y: 1158
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 58,
                      nameId: 'FEA70B0E-D228-4D1A-8072-FA34C525B53E',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 296,
                        y: 1158
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '随时看房',
                      Id: 59,
                      nameId: '1C766255-D651-4BA3-9D3D-E46D574FCE82',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 306,
                        y: 1159
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '随时看房',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '35C52B17-A97A-4D34-A146-23E34244CC0B'
                },
                {
                  name: 'Group 5 Copy',
                  Id: 61,
                  nameId: '376CA146-BD76-415D-81CB-16F4C1AE85C4',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 428,
                    y: 1158
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 62,
                      nameId: '3B93DF2D-02D6-4717-8494-EC52F0C6A1EE',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 428,
                        y: 1158
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '商圈附近',
                      Id: 63,
                      nameId: '767E1D02-C84B-4DA1-9A79-5D550F233212',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 438,
                        y: 1159
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '商圈附近',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '376CA146-BD76-415D-81CB-16F4C1AE85C4'
                },
                {
                  name: 'Group 5 Copy 2',
                  Id: 65,
                  nameId: 'F7329719-FF4A-47CC-A11B-72D102D0AFF3',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 560,
                    y: 1158
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 66,
                      nameId: '6BCB63ED-CCE4-4889-8F70-33BBA0EB47FA',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 560,
                        y: 1158
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '健身会馆',
                      Id: 67,
                      nameId: '40C88411-B384-4586-9997-B5449C8F26E7',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 570,
                        y: 1159
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '健身会馆',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'F7329719-FF4A-47CC-A11B-72D102D0AFF3'
                }
              ],
              type: 'group',
              objectID: 'F0705342-7932-4334-A26D-52C2BD1C7538'
            }
          ],
          type: 'group',
          objectID: '59B3B772-EB9F-4383-B9F8-BF395995F00E'
        },
        {
          name: 'Group 9',
          Id: 69,
          nameId: '1058F8DD-B86B-4892-AC01-BA509E7CE017',
          frame: {
            width: 718,
            height: 40,
            x: 32,
            y: 1256
          },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 70,
              nameId: '9F7ABDE4-E708-4138-9F85-A357C1DD28C3',
              frame: {
                width: 718,
                height: 40,
                x: 32,
                y: 1256
              },
              styles: {},
              type: 'shape'
            }
          ],
          type: 'group',
          objectID: '1058F8DD-B86B-4892-AC01-BA509E7CE017'
        }
      ],
      type: 'group',
      objectID: '31745652-3E3E-48CA-B3F8-714C14046208'
    },
    {
      name: 'Group 8 Copy',
      Id: 72,
      nameId: 'B42BC7B0-25BC-45D8-92D6-958810148F92',
      frame: {
        width: 750,
        height: 270,
        x: 0,
        y: 486
      },
      layers: [
        {
          name: 'Group 7',
          Id: 74,
          nameId: 'ADE0D790-2DEA-4E0C-858D-D2273A8D2D52',
          frame: {
            width: 750,
            height: 238,
            x: 0,
            y: 486
          },
          layers: [
            {
              name: 'Rectangle',
              Id: 75,
              nameId: 'E85BCB0D-E389-453D-98CE-3C0AC55C81C1',
              frame: {
                width: 750,
                height: 230,
                x: 0,
                y: 486
              },
              styles: {
                backgroundColor: 'rgba(255,255,255,1)'
              },
              type: 'shape'
            },
            {
              name: '杭州余杭租房个人出…',
              Id: 76,
              nameId: '1F2568F7-CD81-42E8-ADD3-F6B59E1852E6',
              frame: {
                width: 322,
                height: 42,
                x: 396,
                y: 520
              },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: 28,
                color: '#3F4045',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '杭州余杭租房个人出…',
              type: 'text'
            },
            {
              name: 'tag_tangzhu',
              Id: 78,
              nameId: '75A99BBF-D1F8-4FF5-A0FD-57D4AB534FAD',
              frame: {
                width: 92,
                height: 28,
                x: 296,
                y: 526
              },
              layers: [
                {
                  name: 'Rectangle 567',
                  Id: 79,
                  nameId: '8314FEA7-5292-45B7-AF0E-7C5000BC7743',
                  frame: {
                    width: 92,
                    height: 28,
                    x: 296,
                    y: 526
                  },
                  styles: {
                    borderRadius: 4
                  },
                  type: 'shape'
                },
                {
                  name: '信用免押',
                  Id: 80,
                  nameId: '5BD7404B-DB0E-4E5E-81BF-4AE1F75E48DB',
                  frame: {
                    width: 80,
                    height: 20,
                    x: 302,
                    y: 530
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 20,
                    color: '#FFFFFF',
                    lineHeight: '20',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '信用免押',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '75A99BBF-D1F8-4FF5-A0FD-57D4AB534FAD'
            },
            {
              name: 'Group 3',
              Id: 82,
              nameId: '69F2E7E0-1018-4361-AEBC-4756CC15A5AE',
              frame: {
                width: 240,
                height: 190,
                x: 32,
                y: 526
              },
              layers: [
                {
                  name: 'Mask',
                  Id: 83,
                  nameId: '7A18A5D9-05C6-45A8-A10A-9A1A27125F1D',
                  frame: {
                    width: 240,
                    height: 190,
                    x: 32,
                    y: 526
                  },
                  styles: {
                    backgroundColor: 'rgba(216,216,216,1)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'c87a3eed64ba6a8331cdf1ceff2876a8fe0571821ebfd0-YqxL1Z_fw658',
                  Id: 85,
                  nameId: '9FC2BA28-D651-4B9F-9C28-EB3732606735',
                  frame: {
                    width: 240,
                    height: 190,
                    x: 32,
                    y: 526
                  },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 86,
                      nameId: 'CF205F22-7620-40FC-87D5-E5286B5AC349',
                      frame: {
                        width: 240,
                        height: 190,
                        x: 32,
                        y: 526
                      },
                      imageStyles: {
                        resize: 'stretch'
                      },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1ENeGxkyWBuNjy0FpXXassXXa-240-190.png'
                    }
                  ],
                  type: 'group',
                  objectID: '9FC2BA28-D651-4B9F-9C28-EB3732606735'
                }
              ],
              type: 'group',
              objectID: '69F2E7E0-1018-4361-AEBC-4756CC15A5AE'
            },
            {
              name: 'Group 6',
              Id: 88,
              nameId: 'A8AE2774-8CC4-430B-972D-C7D71F67CCA7',
              frame: {
                width: 422,
                height: 154,
                x: 296,
                y: 570
              },
              layers: [
                {
                  name: 'Group 16',
                  Id: 90,
                  nameId: '116B4DE1-5B2B-4A4B-B399-643ACB7787DF',
                  frame: {
                    width: 143,
                    height: 46,
                    x: 296,
                    y: 678
                  },
                  layers: [
                    {
                      name: '¥',
                      Id: 91,
                      nameId: '7FAFA972-F926-4F21-B398-219D7D085F2C',
                      frame: {
                        width: 15,
                        height: 33,
                        x: 296,
                        y: 687
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '33',
                        fontWeight: 'bold'
                      },
                      value: '¥',
                      type: 'text'
                    },
                    {
                      name: '3500/月',
                      Id: 92,
                      nameId: 'AA832C5A-ACA3-423B-AEAD-F676D127D133',
                      frame: {
                        width: 125,
                        height: 45,
                        x: 314,
                        y: 678.2000007629395
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '44.79999923706055',
                        fontWeight: 'bold'
                      },
                      value: '3500/月',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '116B4DE1-5B2B-4A4B-B399-643ACB7787DF'
                },
                {
                  name: '1室1厅1卫,大华西溪风情',
                  Id: 93,
                  nameId: '6C174FAE-B63A-4509-A583-68574CE98DE3',
                  frame: {
                    width: 422,
                    height: 33.599998474121094,
                    x: 296,
                    y: 570
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 24,
                    color: '#999999',
                    lineHeight: '33.59999847412109',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '1室1厅1卫,大华西溪风情',
                  type: 'text'
                },
                {
                  name: 'Group 5 Copy',
                  Id: 95,
                  nameId: 'F4F1CA6F-9DB7-4B90-9879-B3BFCCA4F97E',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 428,
                    y: 618
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 96,
                      nameId: '834F8518-4235-4536-8E87-1A8A5655D038',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 428,
                        y: 618
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '商圈附近',
                      Id: 97,
                      nameId: '9AD25B02-3E9A-4651-83C4-18E91B539189',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 438,
                        y: 619
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '商圈附近',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'F4F1CA6F-9DB7-4B90-9879-B3BFCCA4F97E'
                },
                {
                  name: 'Group 5 Copy 2',
                  Id: 99,
                  nameId: '359C89F7-2BB4-48C3-A35E-01E9CF50461D',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 560,
                    y: 618
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 100,
                      nameId: '6CC8A933-90E9-4D92-97DB-408C6D493E40',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 560,
                        y: 618
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '健身会馆',
                      Id: 101,
                      nameId: 'FBB10211-90B7-4B09-A567-84E15FAEA297',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 570,
                        y: 619
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '健身会馆',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '359C89F7-2BB4-48C3-A35E-01E9CF50461D'
                }
              ],
              type: 'group',
              objectID: 'A8AE2774-8CC4-430B-972D-C7D71F67CCA7'
            }
          ],
          type: 'group',
          objectID: 'ADE0D790-2DEA-4E0C-858D-D2273A8D2D52'
        },
        {
          name: 'Group 9',
          Id: 103,
          nameId: 'C5D94936-334A-4B0C-A321-F66612DF8F1B',
          frame: {
            width: 718,
            height: 40,
            x: 32,
            y: 716
          },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 104,
              nameId: 'E0B67C4F-33C9-4DF7-922B-E2C52DB2F220',
              frame: {
                width: 718,
                height: 40,
                x: 32,
                y: 716
              },
              styles: {},
              type: 'shape'
            }
          ],
          type: 'group',
          objectID: 'C5D94936-334A-4B0C-A321-F66612DF8F1B'
        }
      ],
      type: 'group',
      objectID: 'B42BC7B0-25BC-45D8-92D6-958810148F92'
    },
    {
      name: 'Group 8 Copy 2',
      Id: 106,
      nameId: '33CC1EC5-13D5-424E-84B5-A1C212C206CE',
      frame: {
        width: 750,
        height: 270,
        x: 0,
        y: 756
      },
      layers: [
        {
          name: 'Group 7',
          Id: 108,
          nameId: '9F9F4535-F4DB-4BC7-AF7C-E4FD5E4DF2B2',
          frame: {
            width: 750,
            height: 238,
            x: 0,
            y: 756
          },
          layers: [
            {
              name: 'Rectangle',
              Id: 109,
              nameId: '7BA22A59-62C9-4D10-A541-F1B0B3B957B3',
              frame: {
                width: 750,
                height: 230,
                x: 0,
                y: 756
              },
              styles: {
                backgroundColor: 'rgba(255,255,255,1)'
              },
              type: 'shape'
            },
            {
              name: '杭州余杭租房个人出租，大华西…',
              Id: 110,
              nameId: 'E06E9FE0-98BA-439B-ABDF-90FA4E7151E7',
              frame: {
                width: 422,
                height: 42,
                x: 296,
                y: 790
              },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: 28,
                color: '#3F4045',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '杭州余杭租房个人出租，大华西…',
              type: 'text'
            },
            {
              name: 'Group 3',
              Id: 112,
              nameId: 'C3BC7BB4-AC89-40E3-B5FB-6CE40D3A8FEB',
              frame: {
                width: 240,
                height: 190,
                x: 32,
                y: 796
              },
              layers: [
                {
                  name: 'Mask',
                  Id: 113,
                  nameId: 'FED98DE0-CA5A-4F36-B3A0-1743DC2A452D',
                  frame: {
                    width: 240,
                    height: 190,
                    x: 32,
                    y: 796
                  },
                  styles: {
                    backgroundColor: 'rgba(216,216,216,1)',
                    borderRadius: 6
                  },
                  type: 'shape'
                },
                {
                  name: 'c87a3eed64ba6a8331cdf1ceff2876a8fe0571821ebfd0-YqxL1Z_fw658',
                  Id: 115,
                  nameId: '6A21276C-4A2A-4AE7-AB94-017A1048EDA4',
                  frame: {
                    width: 240,
                    height: 190,
                    x: 32,
                    y: 796
                  },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 116,
                      nameId: 'F836FB37-6636-4409-9E59-8EC9181E3B56',
                      frame: {
                        width: 240,
                        height: 190,
                        x: 32,
                        y: 796
                      },
                      imageStyles: {
                        resize: 'stretch'
                      },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1ceRSxgmTBuNjy1XbXXaMrVXa-240-190.png'
                    }
                  ],
                  type: 'group',
                  objectID: '6A21276C-4A2A-4AE7-AB94-017A1048EDA4'
                },
                {
                  name: 'Rectangle 9',
                  Id: 117,
                  nameId: '828FA35F-C7FE-443C-8412-67445163D01C',
                  frame: {
                    width: 240,
                    height: 40,
                    x: 32,
                    y: 946
                  },
                  styles: {
                    backgroundColor: 'rgba(0,0,0,0.6)'
                  },
                  type: 'shape'
                },
                {
                  name: '距我99.9km',
                  Id: 118,
                  nameId: 'AA6AB75A-AB7E-4C55-B319-F37F2916BD13',
                  frame: {
                    width: 131,
                    height: 33,
                    x: 87,
                    y: 950
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 24,
                    color: '#FFFFFF',
                    textAlign: 'center',
                    lineHeight: '33',
                    fontWeight: 'normal'
                  },
                  value: '距我99.9km',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'C3BC7BB4-AC89-40E3-B5FB-6CE40D3A8FEB'
            },
            {
              name: 'Group 6',
              Id: 120,
              nameId: 'F25D725A-BF39-4177-9FEA-72E53DB338AF',
              frame: {
                width: 422,
                height: 154,
                x: 296,
                y: 840
              },
              layers: [
                {
                  name: 'Group 16',
                  Id: 122,
                  nameId: 'A9D300B6-483E-4F45-BEE9-34DD21929C5E',
                  frame: {
                    width: 143,
                    height: 46,
                    x: 296,
                    y: 948
                  },
                  layers: [
                    {
                      name: '¥',
                      Id: 123,
                      nameId: 'A957A0EA-59B6-4697-B219-DCE6AD17F763',
                      frame: {
                        width: 15,
                        height: 33,
                        x: 296,
                        y: 957
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 24,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '33',
                        fontWeight: 'bold'
                      },
                      value: '¥',
                      type: 'text'
                    },
                    {
                      name: '3500/月',
                      Id: 124,
                      nameId: 'E4AF8833-B4E7-490C-9D10-A45CE6B681B0',
                      frame: {
                        width: 125,
                        height: 45,
                        x: 314,
                        y: 948.2000007629395
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 32,
                        color: '#FF4444',
                        textAlign: 'left',
                        lineHeight: '44.79999923706055',
                        fontWeight: 'bold'
                      },
                      value: '3500/月',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'A9D300B6-483E-4F45-BEE9-34DD21929C5E'
                },
                {
                  name: '1室1厅1卫,大华西溪风情',
                  Id: 125,
                  nameId: 'F5518FCA-B16D-4B96-A35C-706D1350E5CD',
                  frame: {
                    width: 422,
                    height: 33.599998474121094,
                    x: 296,
                    y: 840
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 24,
                    color: '#999999',
                    lineHeight: '33.59999847412109',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '1室1厅1卫,大华西溪风情',
                  type: 'text'
                },
                {
                  name: 'Group 5',
                  Id: 127,
                  nameId: '55C3219F-D388-449F-A37F-462828E9AC94',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 296,
                    y: 888
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 128,
                      nameId: 'E9FA88FA-7A82-4C5A-BF97-29C5501AEFE1',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 296,
                        y: 888
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '随时看房',
                      Id: 129,
                      nameId: 'F5E849EC-1599-4BB2-8FFA-3F0F61E66023',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 306,
                        y: 889
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '随时看房',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '55C3219F-D388-449F-A37F-462828E9AC94'
                },
                {
                  name: 'Group 5 Copy',
                  Id: 131,
                  nameId: '1CB65ABB-2D0E-42EF-8D54-B2870FABC1A3',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 428,
                    y: 888
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 132,
                      nameId: '00F63CD1-9AE6-4804-BD37-9C88C576BD8E',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 428,
                        y: 888
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '商圈附近',
                      Id: 133,
                      nameId: '790AED16-9393-43BE-8A3D-B1C4DE4B1840',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 438,
                        y: 889
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '商圈附近',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '1CB65ABB-2D0E-42EF-8D54-B2870FABC1A3'
                },
                {
                  name: 'Group 5 Copy 2',
                  Id: 135,
                  nameId: '1401B86E-4864-4951-8AB0-F55D346CA94B',
                  frame: {
                    width: 116,
                    height: 42,
                    x: 560,
                    y: 888
                  },
                  layers: [
                    {
                      name: 'Rectangle 4',
                      Id: 136,
                      nameId: '48FC6B49-4AF5-4205-85FF-CA10AC45562F',
                      frame: {
                        width: 116,
                        height: 42,
                        x: 560,
                        y: 888
                      },
                      styles: {
                        backgroundColor: 'rgba(243,245,249,1)',
                        borderRadius: 4
                      },
                      type: 'shape'
                    },
                    {
                      name: '健身会馆',
                      Id: 137,
                      nameId: '259C8451-B4DC-494D-A85D-C94AD4AEA334',
                      frame: {
                        width: 96,
                        height: 40,
                        x: 570,
                        y: 889
                      },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: 24,
                        color: '#333333',
                        lineHeight: '39.20000076293945',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '健身会馆',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '1401B86E-4864-4951-8AB0-F55D346CA94B'
                }
              ],
              type: 'group',
              objectID: 'F25D725A-BF39-4177-9FEA-72E53DB338AF'
            }
          ],
          type: 'group',
          objectID: '9F9F4535-F4DB-4BC7-AF7C-E4FD5E4DF2B2'
        },
        {
          name: 'Group 9',
          Id: 139,
          nameId: '45DE4AE4-C120-4A01-B538-4BFEA441046B',
          frame: {
            width: 718,
            height: 40,
            x: 32,
            y: 986
          },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 140,
              nameId: '89C22E46-FD16-4099-AB5B-F2F1097EF13E',
              frame: {
                width: 718,
                height: 40,
                x: 32,
                y: 986
              },
              styles: {},
              type: 'shape'
            }
          ],
          type: 'group',
          objectID: '45DE4AE4-C120-4A01-B538-4BFEA441046B'
        }
      ],
      type: 'group',
      objectID: '33CC1EC5-13D5-424E-84B5-A1C212C206CE'
    },
    {
      name: 'Group 5 Copy 3',
      Id: 142,
      nameId: '4A727CF0-83C2-408A-83FA-279B6533AE15',
      frame: {
        width: 116,
        height: 42,
        x: 296,
        y: 618
      },
      layers: [
        {
          name: 'Rectangle 4',
          Id: 143,
          nameId: 'D5CAA980-CBB0-49B7-96AC-BD0A1EAC594C',
          frame: {
            width: 116,
            height: 42,
            x: 296,
            y: 618
          },
          styles: {
            backgroundColor: 'rgba(255,143,19,0.08)',
            borderRadius: 4
          },
          type: 'shape'
        },
        {
          name: '个人房东',
          Id: 144,
          nameId: '69F3DA68-3220-413F-B1D9-6C8F67CD9E13',
          frame: {
            width: 96,
            height: 40,
            x: 306,
            y: 619
          },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: 24,
            color: '#FF8E12',
            lineHeight: '39.20000076293945',
            textAlign: 'left',
            fontWeight: 'bold'
          },
          value: '个人房东',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '4A727CF0-83C2-408A-83FA-279B6533AE15'
    },
    {
      name: 'status',
      Id: 146,
      nameId: 'D48E6C10-F914-4D21-A3D9-F94B023B24A0',
      frame: {
        width: 750,
        height: 40,
        x: 0,
        y: 0
      },
      layers: [
        {
          name: 'Rectangle 2 Copy 3',
          Id: 147,
          nameId: '22E5F4D5-8574-4C1B-BEE4-251358B5B30F',
          frame: {
            width: 750,
            height: 40,
            x: 0,
            y: 0
          },
          styles: {
            backgroundColor: 'rgba(255,255,255,0.95)'
          },
          type: 'shape'
        },
        {
          name: 'Bars/Status/Black',
          Id: 149,
          nameId: '632E60EF-C2B6-4731-BACB-01AE03B8DB73',
          frame: {
            width: 725,
            height: 24,
            x: 14,
            y: 8
          },
          layers: [
            {
              name: 'Pin Right',
              Id: 151,
              nameId: 'CD50B8F6-A214-45EB-B0D1-79370DB548CD',
              frame: {
                width: 121,
                height: 24,
                x: 618,
                y: 8
              },
              layers: [
                {
                  name: 'Battery',
                  Id: 152,
                  nameId: '65ABAAC4-07DE-4EED-83C1-9D9C5A78E5C5',
                  frame: {
                    width: 49,
                    height: 19,
                    x: 690,
                    y: 10
                  },
                  styles: {
                    backgroundColor: 'rgba(0,0,0,1)',
                    borderRadius: 3
                  },
                  type: 'shape'
                },
                {
                  name: '100%',
                  Id: 153,
                  nameId: '9363A3D4-0BA4-4493-A453-FD1EE247850F',
                  frame: {
                    width: 66,
                    height: 24,
                    x: 618,
                    y: 8
                  },
                  textStyles: {
                    fontFamily: '.SFNSDisplay',
                    fontSize: 24,
                    color: '#000000',
                    textAlign: 'right',
                    lineHeight: '24',
                    fontWeight: 'normal'
                  },
                  value: '100%',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'CD50B8F6-A214-45EB-B0D1-79370DB548CD'
            },
            {
              name: 'Time',
              Id: 154,
              nameId: '51CB6E41-36BC-436D-9431-FF294778FD5B',
              frame: {
                width: 90,
                height: 24,
                x: 330,
                y: 8
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 24,
                color: '#000000',
                textAlign: 'center',
                lineHeight: '24',
                fontWeight: 'normal'
              },
              value: '9:41 AM',
              type: 'text'
            },
            {
              name: 'Signal',
              Id: 156,
              nameId: 'B5855FBA-3C9C-4378-8524-94031D9EBC0D',
              frame: {
                width: 188,
                height: 24,
                x: 14,
                y: 8
              },
              layers: [
                {
                  name: 'Wi-Fi',
                  Id: 157,
                  nameId: 'A64F8E4C-413C-48D4-ABAF-0AFA3486FB0D',
                  frame: {
                    width: 26,
                    height: 18,
                    x: 176,
                    y: 10
                  },
                  styles: {
                    backgroundColor: 'rgba(0,0,0,1)'
                  },
                  type: 'shape'
                },
                {
                  name: 'Carrier',
                  Id: 158,
                  nameId: '5D444979-8581-4623-AB3B-5FF3476C62FA',
                  frame: {
                    width: 86,
                    height: 24,
                    x: 88,
                    y: 8
                  },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: 24,
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '24',
                    fontWeight: 'normal'
                  },
                  value: 'SanityD',
                  type: 'text'
                },
                {
                  name: 'Mobile Signal',
                  Id: 159,
                  nameId: 'C7D5FA3B-F888-4A72-A8E5-5F7EA684B67C',
                  frame: {
                    width: 67,
                    height: 11,
                    x: 14,
                    y: 14
                  },
                  styles: {
                    backgroundColor: 'rgba(0,0,0,1)',
                    borderRadius: 11
                  },
                  type: 'shape'
                }
              ],
              type: 'group',
              objectID: 'B5855FBA-3C9C-4378-8524-94031D9EBC0D'
            }
          ],
          type: 'group',
          objectID: '632E60EF-C2B6-4731-BACB-01AE03B8DB73'
        }
      ],
      type: 'group',
      objectID: 'D48E6C10-F914-4D21-A3D9-F94B023B24A0'
    },
    {
      name: 'title',
      Id: 161,
      nameId: 'E1C0B5F8-6C60-4E65-992D-35604B607C72',
      frame: {
        width: 750,
        height: 88,
        x: 0,
        y: 40
      },
      layers: [
        {
          name: 'Rectangle 2 Copy 5',
          Id: 162,
          nameId: 'BD01725F-22F1-46A6-A79E-F64523E39F2F',
          frame: {
            width: 750,
            height: 88,
            x: 0,
            y: 40
          },
          styles: {
            backgroundColor: 'rgba(255,255,255,0.95)'
          },
          type: 'shape'
        },
        {
          name: 'ic_backarrow',
          Id: 164,
          nameId: '2DCF9AFD-CF0C-4B95-BEC5-72B219FD0C13',
          frame: {
            width: 40,
            height: 40,
            x: 32,
            y: 64
          },
          layers: [
            {
              name: 'Rectangle 6',
              Id: 165,
              nameId: '0AA4C681-8FC8-4877-A083-A5CBC8D7B39F',
              frame: {
                width: 40,
                height: 40,
                x: 32,
                y: 64
              },
              styles: {
                backgroundColor: 'rgba(226,226,226,0)'
              },
              type: 'shape'
            },
            {
              name: 'Combined Shape Copy',
              Id: 166,
              nameId: '7C551499-9717-4146-8D19-B84CD06B147C',
              frame: {
                width: 20.118915858099513,
                height: 36.31710895493222,
                x: 35.84144552253383,
                y: 65.84144552253383
              },
              styles: {
                backgroundColor: 'rgba(0,0,0,0.4)'
              },
              type: 'shape'
            }
          ],
          type: 'group',
          objectID: '2DCF9AFD-CF0C-4B95-BEC5-72B219FD0C13'
        },
        {
          name: 'Search Field',
          Id: 167,
          nameId: 'D6543D99-ED4A-4190-8F2F-3A2D7712DD86',
          frame: {
            width: 637,
            height: 64,
            x: 92,
            y: 52
          },
          styles: {
            backgroundColor: 'rgba(142,142,147,0.12)',
            borderRadius: 10
          },
          type: 'shape'
        },
        {
          name: 'Group',
          Id: 169,
          nameId: '4077B3C7-588D-45AE-95A5-3DB29764136D',
          frame: {
            width: 430,
            height: 40,
            x: 112,
            y: 64
          },
          layers: [
            {
              name: 'Group 2',
              Id: 171,
              nameId: 'CDA48613-C605-46E1-807F-EF336F5B7FCB',
              frame: {
                width: 28,
                height: 28,
                x: 112,
                y: 70
              },
              layers: [
                {
                  name: 'Search Glyph',
                  Id: 173,
                  nameId: '11E75E1E-1128-4A2E-8B2C-E2072BC89925',
                  frame: {
                    width: 28,
                    height: 28,
                    x: 112,
                    y: 70
                  },
                  layers: [
                    {
                      name: 'Search',
                      Id: 174,
                      nameId: '08DC0D8B-40ED-4755-AE95-96D98AB65E5E',
                      frame: {
                        width: 27.999739461357308,
                        height: 27.99863715063418,
                        x: 112,
                        y: 70
                      },
                      styles: {
                        backgroundColor: 'rgba(142,142,147,1)'
                      },
                      type: 'shape'
                    }
                  ],
                  type: 'group',
                  objectID: '11E75E1E-1128-4A2E-8B2C-E2072BC89925'
                }
              ],
              type: 'group',
              objectID: 'CDA48613-C605-46E1-807F-EF336F5B7FCB'
            },
            {
              name: '↳ Placeholder Label',
              Id: 175,
              nameId: 'A069D54C-AAFE-4796-9AC3-5E0ECE8267CA',
              frame: {
                width: 384,
                height: 40,
                x: 158,
                y: 64
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 32,
                color: '#CCCCCC',
                lineHeight: '40',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '请输入小区、地铁站或地址',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '4077B3C7-588D-45AE-95A5-3DB29764136D'
        }
      ],
      type: 'group',
      objectID: 'E1C0B5F8-6C60-4E65-992D-35604B607C72'
    },
    {
      name: 'Group 10',
      Id: 177,
      nameId: 'A9874010-8356-4D6A-80FE-5BCBD8E294CF',
      frame: {
        width: 750,
        height: 88,
        x: 0,
        y: 128
      },
      layers: [
        {
          name: 'Rectangle',
          Id: 178,
          nameId: '3442B230-CF89-4FB2-B8BC-F4F425FC0C2F',
          frame: {
            width: 750,
            height: 88,
            x: 0,
            y: 128
          },
          styles: {
            backgroundColor: 'rgba(255,255,255,1)'
          },
          type: 'shape'
        },
        {
          name: 'Group 4',
          Id: 180,
          nameId: '89F6CFC6-8717-45B5-8D63-F5002E8FCC17',
          frame: {
            width: 88,
            height: 42,
            x: 441,
            y: 152
          },
          layers: [
            {
              name: '租金',
              Id: 181,
              nameId: '4995B131-E60E-44F6-BD63-0E0D21C2ADDD',
              frame: {
                width: 60,
                height: 42,
                x: 441,
                y: 152
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 30,
                color: '#999999',
                textAlign: 'center',
                lineHeight: '42',
                fontWeight: 'normal'
              },
              value: '租金',
              type: 'text'
            },
            {
              name: 'Group 3',
              Id: 183,
              nameId: '0B99D917-EE7C-48CA-A7D8-C5E7BB2B6805',
              frame: {
                width: 16,
                height: 10,
                x: 513,
                y: 168
              },
              layers: [
                {
                  name: 'Combined Shape',
                  Id: 184,
                  nameId: '15C48DD6-9970-4A59-BF08-3A9E261DCA95',
                  frame: {
                    width: 15.461080837531767,
                    height: 9.552646269547381,
                    x: 512.9999999999999,
                    y: 168.44735373045285
                  },
                  styles: {
                    backgroundColor: 'rgba(0,0,0,0.12)'
                  },
                  type: 'shape'
                }
              ],
              type: 'group',
              objectID: '0B99D917-EE7C-48CA-A7D8-C5E7BB2B6805'
            }
          ],
          type: 'group',
          objectID: '89F6CFC6-8717-45B5-8D63-F5002E8FCC17'
        },
        {
          name: 'Group 9',
          Id: 186,
          nameId: '42BC28E3-6D82-439B-A779-8380E95C2043',
          frame: {
            width: 84,
            height: 42,
            x: 636,
            y: 152
          },
          layers: [
            {
              name: '筛选',
              Id: 187,
              nameId: 'BE6845AF-64FD-4CCB-BE99-0E8FA6E4EE84',
              frame: {
                width: 60,
                height: 42,
                x: 636,
                y: 152
              },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: 30,
                color: '#888888',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '筛选',
              type: 'text'
            },
            {
              name: 'Path 10',
              Id: 188,
              nameId: 'E0851A61-9A4F-41A8-BEA9-84DC677C1C0F',
              frame: {
                width: 19.67157287525356,
                height: 21,
                x: 700,
                y: 164
              },
              styles: {
                backgroundColor: 'rgba(0,0,0,0.12)'
              },
              type: 'shape'
            }
          ],
          type: 'group',
          objectID: '42BC28E3-6D82-439B-A779-8380E95C2043'
        },
        {
          name: 'Rectangle 3',
          Id: 189,
          nameId: 'E7D82979-5F5F-40A3-960D-E60E0AE17125',
          frame: {
            width: 2,
            height: 40,
            x: 594,
            y: 152
          },
          styles: {
            backgroundColor: 'rgba(0,0,0,0.08)'
          },
          type: 'shape'
        },
        {
          name: 'Group 6',
          Id: 191,
          nameId: 'A4664659-0634-4B98-B87B-0374E42A481F',
          frame: {
            width: 144,
            height: 42,
            x: 225,
            y: 151
          },
          layers: [
            {
              name: '综合排序',
              Id: 192,
              nameId: '5314C7EE-CA84-45DF-8EF1-CA8DC02C65BF',
              frame: {
                width: 120,
                height: 42,
                x: 225,
                y: 151
              },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: 30,
                color: '#222222',
                lineHeight: '42',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '综合排序',
              type: 'text'
            },
            {
              name: 'Combined Shape Copy 2',
              Id: 193,
              nameId: 'F3755D79-7864-4343-9804-6ABF8A23542C',
              frame: {
                width: 11.999917163059422,
                height: 7.796279595234353,
                x: 356.50004141847023,
                y: 166.73344241633606
              },
              styles: {
                backgroundColor: 'rgba(0,0,0,0.12)'
              },
              type: 'shape'
            }
          ],
          type: 'group',
          objectID: 'A4664659-0634-4B98-B87B-0374E42A481F'
        },
        {
          name: 'Group 11',
          Id: 195,
          nameId: 'F7906D9D-DB13-45A8-A505-26CC0D644153',
          frame: {
            width: 88,
            height: 42,
            x: 55,
            y: 152
          },
          layers: [
            {
              name: '区域',
              Id: 196,
              nameId: '88A4CD8C-CE40-4FC9-BC72-05D5BA9CB0EB',
              frame: {
                width: 60,
                height: 42,
                x: 55,
                y: 152
              },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: 30,
                color: '#222222',
                textAlign: 'center',
                lineHeight: '42',
                fontWeight: 'bold'
              },
              value: '区域',
              type: 'text'
            },
            {
              name: 'Combined Shape Copy 2',
              Id: 197,
              nameId: 'F76FF0C8-DFCD-42A9-A126-33793C76D0DF',
              frame: {
                width: 15.595233842439939,
                height: 9.863000795405839,
                x: 127,
                y: 168
              },
              styles: {
                backgroundColor: 'rgba(0,0,0,0.12)'
              },
              type: 'shape'
            }
          ],
          type: 'group',
          objectID: 'F7906D9D-DB13-45A8-A505-26CC0D644153'
        }
      ],
      type: 'group',
      objectID: 'A9874010-8356-4D6A-80FE-5BCBD8E294CF'
    }
  ],
  nameId: 1528767942051,
  Id: 1,
  type: 'group',
  frame: {
    x: 0,
    y: 0,
    width: 750,
    height: 1334
  },
  styles: {
    backgroundColor: 'rgba(255,255,255,1)'
  }
}
