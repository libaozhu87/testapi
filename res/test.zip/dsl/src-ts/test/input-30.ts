export default {
  layers: [
    {
      name: 'Group 2 Copy 3',
      Id: 3,
      nameId: '14E020A7-2AF5-4635-B483-A1618BDCD938',
      frame: { width: 375, height: 144, x: -16, y: -12 },
      layers: [
        {
          name: 'Group 3',
          Id: 5,
          nameId: '3EAC8CCE-C7D8-4ABE-BFC4-17C5C0250F8E',
          frame: { width: 375, height: 144, x: -16, y: -12 },
          layers: [
            {
              name: 'Mask Copy 2',
              Id: 6,
              nameId: '90742C58-11E9-4AFC-882D-6B4ECF47A7F2',
              frame: { width: 227, height: 143.9999999999999, x: 132, y: -12 },
              styles: {},
              type: 'shape'
            },
            {
              name: 'Group 11',
              Id: 8,
              nameId: '84A36E61-D245-4BA1-8FE0-A517B06A5881',
              frame: { width: 345, height: 120, x: 0, y: 0 },
              layers: [
                {
                  name: 'Group 2 Copy 8',
                  Id: 10,
                  nameId: 'EDC42D46-60A3-4F1A-A2DB-21624527E57B',
                  frame: { width: 213, height: 32, x: 132, y: 88 },
                  layers: [
                    {
                      name: 'Mask',
                      Id: 11,
                      nameId: 'D3750A66-8826-45F4-ADC2-17359355C88F',
                      frame: { width: 213, height: 32, x: 132, y: 88 },
                      styles: { fillType: 'gradient', cornerRadiusString: '3', borderRadius: 3 },
                      type: 'shape'
                    },
                    {
                      name: 'Group 6',
                      Id: 13,
                      nameId: '8AC506F3-31D0-4932-AD6D-B0217EE2144E',
                      frame: { width: 56, height: 20, x: 211, y: 94 },
                      layers: [
                        {
                          name: '立即兑换',
                          Id: 14,
                          nameId: '8032B245-941A-45A4-BBBA-85C975645D74',
                          frame: { width: 56, height: 20, x: 211, y: 94 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Medium',
                            fontSize: 14,
                            color: '#222222',
                            textAlign: 'center',
                            lineHeight: '20',
                            fontWeight: 'bold'
                          },
                          value: '立即兑换',
                          type: 'text'
                        }
                      ],
                      type: 'group',
                      objectID: '8AC506F3-31D0-4932-AD6D-B0217EE2144E'
                    }
                  ],
                  type: 'group',
                  objectID: 'EDC42D46-60A3-4F1A-A2DB-21624527E57B'
                },
                {
                  name: 'Avent进口硅胶奶瓶 多色可选',
                  Id: 15,
                  nameId: 'C177891D-6BF7-4044-B1B2-F359246D8F3E',
                  frame: { width: 196, height: 21, x: 132, y: 0 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: 15,
                    color: '#222222',
                    lineHeight: '21',
                    textAlign: 'left',
                    fontWeight: 'bold'
                  },
                  value: 'Avent进口硅胶奶瓶 多色可选',
                  type: 'text'
                },
                {
                  name: 'Group 26',
                  Id: 17,
                  nameId: '2CFC923C-078C-4F06-A7C6-42EB40ED27C6',
                  frame: { width: 96, height: 25, x: 132, y: 50 },
                  layers: [
                    {
                      name: 'Rectangle 12',
                      Id: 18,
                      nameId: 'BB2C5793-A227-4C4D-BB9A-178364530D45',
                      frame: { width: 84, height: 18, x: 144, y: 53 },
                      styles: {
                        backgroundColor: 'rgba(255,68,68,1)',
                        fillType: 'color',
                        borderBottomLeftRadius: '0',
                        borderBottomRightRadius: '2',
                        borderTopLeftRadius: '0',
                        borderTopRightRadius: '2'
                      },
                      type: 'shape'
                    },
                    {
                      name: '200闲鱼币',
                      Id: 19,
                      nameId: '73E52B41-6976-43AC-BB39-E855F254C628',
                      frame: { width: 68, height: 20, x: 158, y: 55 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: 14,
                        color: '#FFFFFF',
                        lineHeight: '20',
                        textAlign: 'left',
                        fontWeight: 'bold'
                      },
                      value: '200闲鱼币',
                      type: 'text'
                    },
                    {
                      name: 'Group',
                      Id: 21,
                      nameId: '49B58020-B4EC-4F08-8E2F-A7BAAFA44388',
                      frame: { width: 24, height: 24, x: 132, y: 50 },
                      layers: [
                        {
                          name: 'Mask',
                          Id: 22,
                          nameId: '46BFFD03-E7E4-4B03-9803-42EAEE6A6D93',
                          frame: { width: 24, height: 24, x: 132, y: 50 },
                          styles: { borderRadius: 24 },
                          type: 'shape'
                        },
                        {
                          name: 'Mask Copy 3',
                          Id: 23,
                          nameId: 'F20CBABD-8BA7-4EA2-93B2-7B1A0FECE800',
                          frame: { width: 24, height: 23.752577319587658, x: 132, y: 50 },
                          styles: { fillType: 'gradient', borderRadius: 23.752577319587658 },
                          type: 'shape'
                        },
                        {
                          name: 'Mask Copy',
                          Id: 24,
                          nameId: '6471D028-E6E6-4BC5-840B-DF8394F4032E',
                          frame: { width: 20, height: 20, x: 134, y: 52 },
                          styles: { fillType: 'gradient', borderRadius: 20 },
                          type: 'shape'
                        },
                        {
                          name: 'Group 5',
                          Id: 26,
                          nameId: '1F5290A7-0BC4-4CCE-B911-D1C4B1F9F61D',
                          frame: { width: 18, height: 18, x: 135, y: 53 },
                          layers: [
                            {
                              name: 'Mask',
                              Id: 27,
                              nameId: '27DEFAE7-BED0-4257-89A5-5671BB56A986',
                              frame: { width: 18, height: 18, x: 135, y: 53 },
                              styles: { fillType: 'gradient', borderRadius: 18 },
                              type: 'shape'
                            },
                            {
                              name: 'Group 7',
                              Id: 29,
                              nameId: '53D99719-F2A4-468D-99DC-7F7FF0B5B4C6',
                              frame: { width: 18, height: 18, x: 135, y: 53 },
                              layers: [
                                {
                                  name: 'stain',
                                  Id: 30,
                                  nameId: 'C8ECAC33-EA04-4542-8625-086D39D1E9BE',
                                  frame: { width: 18, height: 18, x: 135, y: 53 },
                                  styles: { fillType: 'gradient', borderRadius: 18 },
                                  type: 'shape'
                                }
                              ],
                              type: 'group',
                              objectID: '53D99719-F2A4-468D-99DC-7F7FF0B5B4C6'
                            }
                          ],
                          type: 'group',
                          objectID: '1F5290A7-0BC4-4CCE-B911-D1C4B1F9F61D'
                        }
                      ],
                      type: 'group',
                      objectID: '49B58020-B4EC-4F08-8E2F-A7BAAFA44388'
                    },
                    {
                      name: 'Group 4 Copy 5',
                      Id: 32,
                      nameId: 'C0A737C2-65FC-4FAD-9398-C01B4D637060',
                      frame: { width: 24, height: 24, x: 132, y: 50 },
                      layers: [
                        {
                          name: 'Group',
                          Id: 34,
                          nameId: 'A6A0D08B-6930-4C66-A67E-38FE1D1EBC2C',
                          frame: { width: 24, height: 24, x: 132, y: 50 },
                          layers: [
                            {
                              name: 'Mask',
                              Id: 35,
                              nameId: 'EFCDA4A8-4A80-4EEF-95D0-18D8F14B865C',
                              frame: { width: 24, height: 23.752577319587658, x: 132, y: 50 },
                              styles: { borderRadius: 23.752577319587658 },
                              type: 'shape'
                            },
                            {
                              name: 'Mask Copy 3',
                              Id: 36,
                              nameId: 'F716333B-403A-4902-A53F-E2032ED62D91',
                              frame: { width: 24, height: 23.752577319587658, x: 132, y: 50 },
                              styles: { fillType: 'gradient', borderRadius: 23.752577319587658 },
                              type: 'shape'
                            },
                            {
                              name: 'Mask Copy',
                              Id: 37,
                              nameId: '398844DC-DD56-4562-8B0D-95F6496BBE81',
                              frame: { width: 21, height: 20.78350515463916, x: 133.5, y: 51.48453608247422 },
                              styles: { fillType: 'gradient', borderRadius: 20.78350515463916 },
                              type: 'shape'
                            },
                            {
                              name: 'Group 5',
                              Id: 39,
                              nameId: 'D490800D-63B4-4749-AF79-A330182C2DEA',
                              frame: { width: 20, height: 20, x: 134.25, y: 52.226804123711304 },
                              layers: [
                                {
                                  name: 'Mask',
                                  Id: 40,
                                  nameId: 'CE56E1B0-82DD-461F-A356-6F5F2236E2DC',
                                  frame: { width: 19.5, height: 19.298969072164994, x: 134.25, y: 52.226804123711304 },
                                  styles: { fillType: 'gradient', borderRadius: 19.298969072164994 },
                                  type: 'shape'
                                },
                                {
                                  name: 'Mask',
                                  Id: 41,
                                  nameId: '409C7E89-8923-4620-8065-05BBAC684430',
                                  frame: { width: 19.5, height: 19.298969072164994, x: 134.25, y: 52.226804123711304 },
                                  styles: { fillType: 'gradient', borderRadius: 19.298969072164994 },
                                  type: 'shape'
                                },
                                {
                                  name: 'Group 15',
                                  Id: 43,
                                  nameId: '6B57B809-D73C-4DBD-8F64-9013609D339E',
                                  frame: {
                                    width: 24.397750031810915,
                                    height: 23.415354743091825,
                                    x: 134.55558060989065,
                                    y: 56.110354405830094
                                  },
                                  layers: [
                                    {
                                      name: 'Combined Shape',
                                      Id: 44,
                                      nameId: '853CBEEF-C126-472B-9597-FA11A2DB9331',
                                      frame: {
                                        width: 13.620595455013301,
                                        height: 21.57825717060615,
                                        x: 144.44401010197546,
                                        y: 57.07664134229162
                                      },
                                      styles: { fillType: 'gradient' },
                                      type: 'shape'
                                    },
                                    {
                                      name: 'Oval 7',
                                      Id: 45,
                                      nameId: '8605373C-756D-4C4B-B670-8EF50CB29534',
                                      frame: {
                                        width: 17.728233547753547,
                                        height: 20.31217363328625,
                                        x: 134.66504430866357,
                                        y: 57.94938066416006
                                      },
                                      styles: { fillType: 'gradient' },
                                      type: 'shape'
                                    },
                                    {
                                      name: 'Path 11',
                                      Id: 46,
                                      nameId: 'AB7AF74F-2D3B-4343-80D2-0713EC41F821',
                                      frame: {
                                        width: 11.4175373174632,
                                        height: 4.303086691997464,
                                        x: 136.8377247400321,
                                        y: 60.474385629154995
                                      },
                                      styles: { backgroundColor: 'rgba(255,248,224,0.8)', fillType: 'color' },
                                      type: 'shape'
                                    },
                                    {
                                      name: 'Combined Shape',
                                      Id: 47,
                                      nameId: 'B07BF9FC-E0DC-4988-8386-AA71F8CEE774',
                                      frame: {
                                        width: 2.785881058058635,
                                        height: 2.027142390437575,
                                        x: 140.76611977052897,
                                        y: 65.36831451457977
                                      },
                                      styles: { fillType: 'gradient' },
                                      type: 'shape'
                                    },
                                    {
                                      name: 'Group 16',
                                      Id: 49,
                                      nameId: '941629A0-21D0-4EA4-9E13-E22367CEAF7A',
                                      frame: {
                                        width: 12.015689378933985,
                                        height: 8.370952218853745,
                                        x: 136.43924046362548,
                                        y: 56.13871456629067
                                      },
                                      layers: [
                                        {
                                          name: 'Combined Shape',
                                          Id: 50,
                                          nameId: 'C4C88546-0DFA-4CB8-B1D7-87DF61DE9C72',
                                          frame: {
                                            width: 12.015650650851512,
                                            height: 8.370913876398902,
                                            x: 136.43925982766672,
                                            y: 56.13873373751812
                                          },
                                          styles: { fillType: 'gradient' },
                                          type: 'shape'
                                        },
                                        {
                                          name: 'Combined Shape',
                                          Id: 51,
                                          nameId: '94C7154A-904D-40CA-A7CF-A13C7E4D0F9B',
                                          frame: {
                                            width: 6.287911185350708,
                                            height: 2.335542510890548,
                                            x: 139.72976762409715,
                                            y: 59.7825173399379
                                          },
                                          styles: { fillType: 'gradient', cornerRadiusString: '0.62', borderRadius: 0.6250000000000001 },
                                          type: 'shape'
                                        }
                                      ],
                                      type: 'group',
                                      objectID: '941629A0-21D0-4EA4-9E13-E22367CEAF7A'
                                    }
                                  ],
                                  type: 'group',
                                  objectID: '6B57B809-D73C-4DBD-8F64-9013609D339E'
                                },
                                {
                                  name: 'Group 7',
                                  Id: 53,
                                  nameId: '5C43009A-6CC4-4D3B-829E-AF58FCCC66BE',
                                  frame: { width: 10.625, height: 10.63917525773195, x: 136.875, y: 56.43298969072168 },
                                  layers: [
                                    {
                                      name: 'fish',
                                      Id: 55,
                                      nameId: 'EC548D79-8F0C-4F4C-90E6-6787F8FDB804',
                                      frame: { width: 10.625, height: 10.63917525773195, x: 136.875, y: 56.43298969072168 },
                                      layers: [
                                        {
                                          name: 'Group 2',
                                          Id: 57,
                                          nameId: 'AFB7F49C-EB5D-4219-ABDF-FB81B4E52C64',
                                          frame: { width: 10.625, height: 10.515463917525778, x: 136.875, y: 56.483142936751165 },
                                          layers: [
                                            {
                                              name: 'Group 9',
                                              Id: 59,
                                              nameId: '28DAB9E3-14DB-4BB9-A5FC-2B29D8306920',
                                              frame: { width: 10.625, height: 10.515463917525778, x: 136.875, y: 56.483142936751165 },
                                              layers: [],
                                              type: 'group',
                                              objectID: '28DAB9E3-14DB-4BB9-A5FC-2B29D8306920'
                                            }
                                          ],
                                          type: 'group',
                                          objectID: 'AFB7F49C-EB5D-4219-ABDF-FB81B4E52C64'
                                        }
                                      ],
                                      type: 'group',
                                      objectID: 'EC548D79-8F0C-4F4C-90E6-6787F8FDB804'
                                    }
                                  ],
                                  type: 'group',
                                  objectID: '5C43009A-6CC4-4D3B-829E-AF58FCCC66BE'
                                }
                              ],
                              type: 'group',
                              objectID: 'D490800D-63B4-4749-AF79-A330182C2DEA'
                            }
                          ],
                          type: 'group',
                          objectID: 'A6A0D08B-6930-4C66-A67E-38FE1D1EBC2C'
                        }
                      ],
                      type: 'group',
                      objectID: 'C0A737C2-65FC-4FAD-9398-C01B4D637060'
                    }
                  ],
                  type: 'group',
                  objectID: '2CFC923C-078C-4F06-A7C6-42EB40ED27C6'
                },
                {
                  name: 'Group 10',
                  Id: 61,
                  nameId: 'A26B0FE1-9654-4626-8253-B182C213AF07',
                  frame: { width: 120, height: 120, x: 0, y: 0 },
                  layers: [
                    {
                      name: 'Mask',
                      Id: 62,
                      nameId: '93FC8017-45E1-4206-8486-C12E87CB44D9',
                      frame: { width: 120, height: 120, x: 0, y: 0 },
                      styles: { cornerRadiusString: '6', borderRadius: 6 },
                      type: 'shape'
                    },
                    {
                      name: 'Group 8',
                      Id: 64,
                      nameId: 'BC9C5290-A4F3-45B7-A8F2-406B51566437',
                      frame: { width: 80, height: 16, x: 4, y: 100 },
                      layers: [
                        {
                          name: 'Rectangle 10',
                          Id: 65,
                          nameId: 'A2C1884B-D87F-4A79-8A2B-7AF3212AD314',
                          frame: { width: 80, height: 14, x: 4, y: 102 },
                          styles: { fillType: 'gradient', cornerRadiusString: '2', borderRadius: 2 },
                          type: 'shape'
                        },
                        {
                          name: 'Group 21',
                          Id: 67,
                          nameId: '4BAD1A1D-B00A-487F-8404-2C0744C9780B',
                          frame: { width: 11, height: 14, x: 8, y: 100 },
                          layers: [
                            {
                              name: 'Path 2',
                              Id: 68,
                              nameId: '2F33C93E-4D14-4700-B4B4-82858F0144B4',
                              frame: { width: 11, height: 14, x: 8, y: 100 },
                              styles: { fillType: 'gradient' },
                              type: 'shape'
                            }
                          ],
                          type: 'group',
                          objectID: '4BAD1A1D-B00A-487F-8404-2C0744C9780B'
                        },
                        {
                          name: '27657人已换',
                          Id: 69,
                          nameId: 'D71CA4F0-79CA-4A3B-8B22-210FECC56AC0',
                          frame: { width: 60, height: 10, x: 21, y: 104 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Medium',
                            fontSize: 10,
                            color: '#FFFFFF',
                            textAlign: 'center',
                            lineHeight: '10',
                            fontWeight: 'bold'
                          },
                          value: '27657人已换',
                          type: 'text'
                        }
                      ],
                      type: 'group',
                      objectID: 'BC9C5290-A4F3-45B7-A8F2-406B51566437'
                    }
                  ],
                  type: 'group',
                  objectID: 'A26B0FE1-9654-4626-8253-B182C213AF07'
                }
              ],
              type: 'group',
              objectID: '84A36E61-D245-4BA1-8FE0-A517B06A5881'
            }
          ],
          type: 'group',
          objectID: '3EAC8CCE-C7D8-4ABE-BFC4-17C5C0250F8E'
        }
      ],
      type: 'group',
      objectID: '14E020A7-2AF5-4635-B483-A1618BDCD938'
    }
  ],
  nameId: 1526435988825,
  Id: 1,
  type: 'group',
  frame: { x: 0, y: 0, width: 345, height: 120 },
  styles: { backgroundColor: 'rgba(255,255,255,1)' }
}
