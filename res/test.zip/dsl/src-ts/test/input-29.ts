export default {
  layers: [
    {
      name: 'nav. bar',
      Id: 3,
      nameId: 'CFB687A2-B8DC-47CD-AE7B-7ACEB2F10B40',
      frame: { width: 750, height: 129, x: 0, y: 0 },
      layers: [
        {
          name: 'Group 4',
          Id: 5,
          nameId: '6DD7A7BA-9E57-49AA-931C-52EE1F23912C',
          frame: { width: 172, height: 25, x: 289, y: 69 },
          layers: [
            {
              name: '出价记录',
              Id: 6,
              nameId: '1D4280EB-E846-41AF-9043-0AF5973836D8',
              frame: { width: 128, height: 24, x: 289, y: 69 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '32',
                color: '#333333',
                lineHeight: '24',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '出价记录',
              type: 'text'
            },
            {
              name: '4',
              Id: 7,
              nameId: '856805AA-2691-4C24-A2DE-166CD374C3C0',
              frame: { width: 41, height: 24, x: 420, y: 70 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '32',
                color: '#333333',
                lineHeight: '24',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '  4',
              type: 'text'
            },
            {
              name: 'Oval',
              Id: 8,
              nameId: '44B6173B-8A27-4AB1-9499-B86909AC06C0',
              frame: { width: 4, height: 4, x: 427, y: 82 },
              styles: { backgroundColor: 'rgba(51,51,51,1)', fillType: 'color', borderRadius: 4 },
              type: 'shape'
            }
          ],
          type: 'group',
          objectID: '6DD7A7BA-9E57-49AA-931C-52EE1F23912C'
        },
        {
          name: 'Bitmap',
          Id: 9,
          nameId: 'A59590BB-25E4-4067-A634-C6C43BBA03CB',
          frame: { width: 750, height: 1, x: 0, y: 128 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1MilYqL1TBuNjy0FjXXajyXXa-750-1.png'
        },
        {
          name: 'Status Bar black',
          Id: 11,
          nameId: '9FEE7CCE-75EC-4709-BB84-1F9FB8681192',
          frame: { width: 726, height: 33, x: 12, y: 3 },
          layers: [
            {
              name: 'Signal',
              Id: 13,
              nameId: '91A5969B-03B5-4F01-9FAC-4E91B41D8652',
              frame: { width: 189, height: 27, x: 12, y: 8 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 14,
                  nameId: '9825FED7-C910-4516-ADD9-13A8CC878FC1',
                  frame: { width: 68, height: 11, x: 12, y: 15 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1DL2xqTtYBeNjy1XdXXXXyVXa-68-11.png'
                },
                {
                  name: 'CALAN',
                  Id: 15,
                  nameId: '46F18543-066B-4F34-AAEC-F48691B05262',
                  frame: { width: 78, height: 27, x: 88, y: 8 },
                  textStyles: {
                    fontFamily: 'HelveticaNeue',
                    fontSize: '22',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '27',
                    fontWeight: 'normal'
                  },
                  value: 'CALAN',
                  type: 'text'
                },
                {
                  name: 'Bitmap',
                  Id: 16,
                  nameId: '865DF760-5100-40AE-A54A-48B930DE058B',
                  frame: { width: 24, height: 19, x: 177, y: 11 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1WyhcqFOWBuNjy0FiXXXFxVXa-24-19.png'
                }
              ],
              type: 'group',
              objectID: '91A5969B-03B5-4F01-9FAC-4E91B41D8652'
            },
            {
              name: 'Bitmap',
              Id: 17,
              nameId: 'E3A49DFA-31CB-489C-91F4-717081FF8AB4',
              frame: { width: 16, height: 27, x: 602, y: 7 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1IH7AqwmTBuNjy1XbXXaMrVXa-16-27.png'
            },
            {
              name: 'Battery',
              Id: 19,
              nameId: 'F806E417-0793-43F5-B861-ABCC8278FBF8',
              frame: { width: 413, height: 33, x: 325, y: 3 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 20,
                  nameId: '82476172-6A2E-4EA3-90BE-B2B6FAD6C8F9',
                  frame: { width: 3, height: 7, x: 735, y: 17 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1_5hcqFOWBuNjy0FiXXXFxVXa-3-7.png'
                },
                {
                  name: 'Shape',
                  Id: 21,
                  nameId: 'EC4D6184-E05E-49F6-8E29-0D913C4A4DAB',
                  frame: { width: 14, height: 15, x: 691, y: 13 },
                  styles: {
                    backgroundColor: 'rgba(0,0,0,1)',
                    fillType: 'color',
                    borderBottomLeftRadius: '1',
                    borderBottomRightRadius: '0',
                    borderTopLeftRadius: '1',
                    borderTopRightRadius: '0'
                  },
                  type: 'shape'
                },
                {
                  name: 'Bitmap',
                  Id: 22,
                  nameId: '7350C588-B839-4FA5-A8A1-D36059338C87',
                  frame: { width: 45, height: 19, x: 689, y: 11 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1vas3qrGYBuNjy0FoXXciBFXa-45-19.png'
                },
                {
                  name: '22',
                  Id: 23,
                  nameId: '13833092-6FFB-4CA4-9634-939F0EF86FA7',
                  frame: { width: 28, height: 28, x: 632, y: 7 },
                  textStyles: {
                    fontFamily: 'HelveticaNeue-Light',
                    fontSize: '23',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '28',
                    fontWeight: 'normal'
                  },
                  value: '22',
                  type: 'text'
                },
                {
                  name: '%',
                  Id: 24,
                  nameId: '776637C3-759A-4769-A351-5B92BF4271E6',
                  frame: { width: 22, height: 28, x: 659.576, y: 7 },
                  textStyles: {
                    fontFamily: 'HelveticaNeue-Light',
                    fontSize: '23',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '28',
                    fontWeight: 'normal'
                  },
                  value: '%',
                  type: 'text'
                },
                {
                  name: '4 21 PM',
                  Id: 25,
                  nameId: 'E13BFC13-67E9-4502-8BB7-5C1A047E714C',
                  frame: { width: 97, height: 29, x: 325, y: 6 },
                  textStyles: {
                    fontFamily: 'HelveticaNeue',
                    fontSize: '24',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '29',
                    fontWeight: 'normal'
                  },
                  value: '4 21 PM',
                  type: 'text'
                },
                {
                  name: ':',
                  Id: 26,
                  nameId: 'A9B8B1F7-9BFD-4FE9-8A6B-8D94389CA446',
                  frame: { width: 9, height: 33, x: 338.5, y: 3 },
                  textStyles: {
                    fontFamily: 'AvenirNext-Regular',
                    fontSize: '24',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '33',
                    fontWeight: 'normal'
                  },
                  value: ':',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'F806E417-0793-43F5-B861-ABCC8278FBF8'
            }
          ],
          type: 'group',
          objectID: '9FEE7CCE-75EC-4709-BB84-1F9FB8681192'
        }
      ],
      type: 'group',
      objectID: 'CFB687A2-B8DC-47CD-AE7B-7ACEB2F10B40'
    },
    {
      name: 'Bitmap',
      Id: 27,
      nameId: 'D2310433-D6B3-42B3-8E3B-0EED41788C1F',
      frame: { width: 23, height: 40, x: 41, y: 64 },
      imageStyles: { resize: 'stretch' },
      type: 'image',
      value: 'https://gw.alicdn.com/tfs/TB1p5lcqFOWBuNjy0FiXXXFxVXa-23-40.png'
    },
    {
      name: '收藏 copy 3',
      Id: 29,
      nameId: 'E5265FA7-1BC0-411F-AE48-87BE5774A6E7',
      frame: { width: 750, height: 538, x: 0, y: 128 },
      layers: [
        {
          name: 'Group 7 Copy 3',
          Id: 31,
          nameId: 'ECF2B4AA-85D6-4D03-AFF1-FE1840F913A1',
          frame: { width: 750, height: 440, x: 0, y: 130 },
          layers: [
            {
              name: 'Group 2',
              Id: 33,
              nameId: 'C8A18C94-0360-4F62-A63B-4E55DD03211F',
              frame: { width: 750, height: 144, x: 0, y: 138 },
              layers: [
                {
                  name: 'Group',
                  Id: 35,
                  nameId: '273FEC0E-E9D2-4801-A26F-276A18C2ADFD',
                  frame: { width: 750, height: 144, x: 0, y: 138 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 36,
                      nameId: '525F9ABF-D7E1-4E4F-847F-7770571D6F9A',
                      frame: { width: 598, height: 1, x: 152, y: 281 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1EztKqKuSBuNjy1XcXXcYjFXa-598-1.png'
                    },
                    {
                      name: 'Rectangle 13 Copy',
                      Id: 37,
                      nameId: 'F94DD8E0-EEF1-4FC8-9543-554E80AA8719',
                      frame: { width: 176, height: 80, x: 542, y: 170 },
                      styles: { backgroundColor: 'rgba(255,233,91,1)', fillType: 'color', cornerRadiusString: '5', borderRadius: 5 },
                      type: 'shape'
                    },
                    {
                      name: '110闲鱼币',
                      Id: 38,
                      nameId: '52CEFEBB-910E-4300-9D83-6CFEE2EAB88D',
                      frame: { width: 138, height: 40, x: 561, y: 209 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Semibold',
                        fontSize: '28',
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '40',
                        fontWeight: 'normal'
                      },
                      value: '110闲鱼币',
                      type: 'text'
                    },
                    {
                      name: '点击出价+10',
                      Id: 39,
                      nameId: '94FBBBB6-B3B8-4FCE-9CC8-448AE77F4B87',
                      frame: { width: 135, height: 40, x: 562.5, y: 173 },
                      textStyles: {
                        opacity: '0.5',
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#222222',
                        textAlign: 'center',
                        lineHeight: '40',
                        fontWeight: 'normal'
                      },
                      value: '点击出价+10',
                      type: 'text'
                    },
                    {
                      name: 'Bitmap',
                      Id: 40,
                      nameId: '2A77C3C3-CBBE-427E-8E62-AD509AEC1531',
                      frame: { width: 96, height: 96, x: 32, y: 162 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1AL6xqTtYBeNjy1XdXXXXyVXa-96-96.png'
                    },
                    {
                      name: 'Group 13',
                      Id: 42,
                      nameId: 'F7ABADE2-8608-426A-9C17-5C1392656798',
                      frame: { width: 245, height: 84, x: 152, y: 168 },
                      layers: [
                        {
                          name: 'Group 15',
                          Id: 44,
                          nameId: 'DA8EB87A-C52D-4C59-A826-230C9E6928F2',
                          frame: { width: 245, height: 84, x: 152, y: 168 },
                          layers: [
                            {
                              name: 'kai***123',
                              Id: 45,
                              nameId: '6D6EF79D-548E-4EB8-BDA9-462AE9D6BCBB',
                              frame: { width: 224, height: 40, x: 152, y: 168 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '32',
                                color: '#222222',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: 'kai***123',
                              type: 'text'
                            },
                            {
                              name: '100闲鱼币',
                              Id: 46,
                              nameId: 'D459FDCE-3DD6-450E-A687-B01E82062258',
                              frame: { width: 129, height: 40, x: 152, y: 212 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FF0D0D',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '100闲鱼币',
                              type: 'text'
                            },
                            {
                              name: 'Bitmap',
                              Id: 47,
                              nameId: '5CFEEBD3-8F53-485D-A762-3A50DCC4A06D',
                              frame: { width: 96, height: 28, x: 301, y: 220 },
                              imageStyles: { resize: 'stretch' },
                              type: 'image',
                              value: 'https://gw.alicdn.com/tfs/TB1QvR3qNGYBuNjy0FnXXX5lpXa-96-28.png'
                            },
                            {
                              name: '出价最高',
                              Id: 48,
                              nameId: '9D8E6FFC-C85E-4A27-876F-5BC2B7DC1E36',
                              frame: { width: 80, height: 24, x: 309, y: 222 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '20',
                                color: '#4A4A4A',
                                textAlign: 'center',
                                lineHeight: '24',
                                fontWeight: 'normal'
                              },
                              value: '出价最高',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: 'DA8EB87A-C52D-4C59-A826-230C9E6928F2'
                        }
                      ],
                      type: 'group',
                      objectID: 'F7ABADE2-8608-426A-9C17-5C1392656798'
                    }
                  ],
                  type: 'group',
                  objectID: '273FEC0E-E9D2-4801-A26F-276A18C2ADFD'
                }
              ],
              type: 'group',
              objectID: 'C8A18C94-0360-4F62-A63B-4E55DD03211F'
            },
            {
              name: 'Group 2 Copy 5',
              Id: 50,
              nameId: '4DFF49DF-AE79-45F4-AA20-51C6133AB5C7',
              frame: { width: 750, height: 144, x: 0, y: 282 },
              layers: [
                {
                  name: 'Group',
                  Id: 52,
                  nameId: '1517EB3A-E09F-4FA3-BE3F-EBCE76902F92',
                  frame: { width: 750, height: 144, x: 0, y: 282 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 53,
                      nameId: 'A2EFD4F5-5393-438D-93E2-5C03DEBC0D7C',
                      frame: { width: 598, height: 1, x: 152, y: 425 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1Pf6xqTtYBeNjy1XdXXXXyVXa-598-1.png'
                    },
                    {
                      name: 'Bitmap',
                      Id: 54,
                      nameId: '5CA50CD3-C38C-47C9-9E6F-81AFCDE3DA64',
                      frame: { width: 96, height: 96, x: 32, y: 306 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1VY.AqwmTBuNjy1XbXXaMrVXa-96-96.png'
                    },
                    {
                      name: 'Group 13',
                      Id: 56,
                      nameId: '0DC3C4ED-A423-42A1-918F-FAAF7897786B',
                      frame: { width: 566, height: 84, x: 152, y: 312 },
                      layers: [
                        {
                          name: 'Group 15',
                          Id: 58,
                          nameId: '3150D377-65AB-4BCC-B397-69307EE16B4B',
                          frame: { width: 566, height: 84, x: 152, y: 312 },
                          layers: [
                            {
                              name: '王***123',
                              Id: 59,
                              nameId: '428E04FA-99EA-43B6-BA39-47AC7428324D',
                              frame: { width: 224, height: 40, x: 152, y: 312 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '32',
                                color: '#222222',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '王***123',
                              type: 'text'
                            },
                            {
                              name: '75闲鱼币 出局',
                              Id: 60,
                              nameId: '2AEEB8F3-2F88-44A6-995A-55866514B490',
                              frame: { width: 224, height: 40, x: 152, y: 356 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#888888',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '75闲鱼币 出局',
                              type: 'text'
                            },
                            {
                              name: '12分钟前',
                              Id: 61,
                              nameId: 'F49FC493-0AD2-4754-8BDA-CF14D098D378',
                              frame: { width: 97, height: 33, x: 621, y: 363 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '24',
                                color: '#A9A9A9',
                                textAlign: 'right',
                                lineHeight: '33',
                                fontWeight: 'normal'
                              },
                              value: '12分钟前',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: '3150D377-65AB-4BCC-B397-69307EE16B4B'
                        }
                      ],
                      type: 'group',
                      objectID: '0DC3C4ED-A423-42A1-918F-FAAF7897786B'
                    }
                  ],
                  type: 'group',
                  objectID: '1517EB3A-E09F-4FA3-BE3F-EBCE76902F92'
                }
              ],
              type: 'group',
              objectID: '4DFF49DF-AE79-45F4-AA20-51C6133AB5C7'
            },
            {
              name: 'Group 2 Copy 6',
              Id: 63,
              nameId: '0BB32A57-D316-4C93-98E6-884205D517C7',
              frame: { width: 750, height: 144, x: 0, y: 426 },
              layers: [
                {
                  name: 'Group',
                  Id: 65,
                  nameId: 'E02DD409-90FA-47EA-BD32-B1E01471DE5F',
                  frame: { width: 750, height: 144, x: 0, y: 426 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 66,
                      nameId: '69CDA8BA-23F9-4B36-828F-AD149DAF23EC',
                      frame: { width: 96, height: 96, x: 32, y: 450 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB19v6xqTtYBeNjy1XdXXXXyVXa-96-96.png'
                    },
                    {
                      name: 'Group 13',
                      Id: 68,
                      nameId: 'E8E2EBCD-FD25-4F47-81FC-178B15A417EA',
                      frame: { width: 566, height: 84, x: 152, y: 456 },
                      layers: [
                        {
                          name: 'Group 15',
                          Id: 70,
                          nameId: '88261586-6F39-4593-BA84-AAA26BC6EBD4',
                          frame: { width: 566, height: 84, x: 152, y: 456 },
                          layers: [
                            {
                              name: '张***大',
                              Id: 71,
                              nameId: '8D20B974-B295-4264-99D1-F9563F11E3CA',
                              frame: { width: 224, height: 40, x: 152, y: 456 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '32',
                                color: '#222222',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '张***大',
                              type: 'text'
                            },
                            {
                              name: '50闲鱼币 出局',
                              Id: 72,
                              nameId: 'C61A2603-4287-41BD-A07A-10A8B0595DB8',
                              frame: { width: 224, height: 40, x: 152, y: 500 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#888888',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '50闲鱼币 出局',
                              type: 'text'
                            },
                            {
                              name: '24分钟前',
                              Id: 73,
                              nameId: '0FAEA9B5-A429-4023-B428-2D92D2963C3A',
                              frame: { width: 101, height: 33, x: 617, y: 505 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '24',
                                color: '#A9A9A9',
                                textAlign: 'right',
                                lineHeight: '33',
                                fontWeight: 'normal'
                              },
                              value: '24分钟前',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: '88261586-6F39-4593-BA84-AAA26BC6EBD4'
                        }
                      ],
                      type: 'group',
                      objectID: 'E8E2EBCD-FD25-4F47-81FC-178B15A417EA'
                    }
                  ],
                  type: 'group',
                  objectID: 'E02DD409-90FA-47EA-BD32-B1E01471DE5F'
                }
              ],
              type: 'group',
              objectID: '0BB32A57-D316-4C93-98E6-884205D517C7'
            }
          ],
          type: 'group',
          objectID: 'ECF2B4AA-85D6-4D03-AFF1-FE1840F913A1'
        }
      ],
      type: 'group',
      objectID: 'E5265FA7-1BC0-411F-AE48-87BE5774A6E7'
    },
    {
      name: 'Group 3',
      Id: 75,
      nameId: '6E20B819-2342-4BEA-9FB6-FEA9B8763D4C',
      frame: { width: 750, height: 112, x: 0, y: 1222 },
      layers: [
        {
          name: 'bottombar/onebutton',
          Id: 77,
          nameId: '531DE86E-DBFE-4803-81A9-74D247BCEF93',
          frame: { width: 750, height: 112, x: 0, y: 1222 },
          layers: [
            {
              name: 'Group 14',
              Id: 79,
              nameId: 'EBBD08B0-A000-4655-BF50-C39396D83EE0',
              frame: { width: 686, height: 80, x: 32, y: 1238 },
              layers: [
                {
                  name: 'Group 9',
                  Id: 81,
                  nameId: '2C28EC0B-C1C5-4292-A224-B0205555AA7F',
                  frame: { width: 686, height: 80, x: 32, y: 1238 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 82,
                      nameId: '5977273B-0EDC-47D5-A8B7-EB0FC274B1FD',
                      frame: { width: 686, height: 80, x: 32, y: 1238 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB12cVsqQyWBuNjy0FpXXassXXa-686-80.png'
                    }
                  ],
                  type: 'group',
                  objectID: '2C28EC0B-C1C5-4292-A224-B0205555AA7F'
                }
              ],
              type: 'group',
              objectID: 'EBBD08B0-A000-4655-BF50-C39396D83EE0'
            }
          ],
          type: 'group',
          objectID: '531DE86E-DBFE-4803-81A9-74D247BCEF93'
        },
        {
          name: 'Bitmap',
          Id: 83,
          nameId: '7FF4D046-E467-4363-A9C1-66D37B72779E',
          frame: { width: 686, height: 80, x: 32, y: 1238 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1FjxKqKuSBuNjy1XcXXcYjFXa-686-80.png'
        },
        {
          name: '出个价',
          Id: 84,
          nameId: '8EE7F1CA-90EF-4FB5-ABDD-09D5DEA9F9F5',
          frame: { width: 96, height: 40, x: 328, y: 1258 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: '32',
            color: '#222222',
            textAlign: 'center',
            lineHeight: '40',
            fontWeight: 'bold'
          },
          value: '出个价',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '6E20B819-2342-4BEA-9FB6-FEA9B8763D4C'
    },
    {
      name: 'Rectangle 13',
      Id: 85,
      nameId: 'F74F87B4-81B4-43C7-AE72-6436345DAD1C',
      frame: { width: 459, height: 130, x: 146, y: 560 },
      styles: { backgroundColor: 'rgba(0,0,0,0.7)', fillType: 'color', cornerRadiusString: '8', borderRadius: 8 },
      type: 'shape'
    },
    {
      name: '你的闲鱼币不足，出价失败',
      Id: 86,
      nameId: '8281FAC0-4A1D-4931-89DE-55B9E55DBBBF',
      frame: { width: 336, height: 40, x: 208, y: 605 },
      textStyles: {
        fontFamily: 'PingFangSC-Medium',
        fontSize: '28',
        color: '#FFFFFF',
        lineHeight: '40',
        textAlign: 'left',
        fontWeight: 'bold'
      },
      value: '你的闲鱼币不足，出价失败',
      type: 'text'
    }
  ],
  nameId: 1525917585648,
  Id: 1,
  type: 'group',
  frame: { x: 0, y: 0, width: 750, height: 1334 },
  styles: { backgroundColor: 'rgba(255,255,255,1)' }
}
