export default {
  layers: [
    {
      frame: {
        y: 26,
        x: 30,
        height: 80,
        width: 80
      },
      type: 'image',
      id: 1,
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952799698.png',
      imageStyles: {
        resize: 'stretch'
      }
    },
    {
      textStyles: {
        fontWeight: 'bold',
        color: '#222222',
        fontFamily: 'PingFangSC-Medium',
        fontSize: '30',
        lineHeight: '30',
        textAlign: 'left'
      },
      frame: {
        y: 32,
        x: 131,
        height: 29,
        width: 148
      },
      type: 'text',
      id: 2,
      value: '西溪包租婆'
    },
    {
      name: 'Bitmap',
      nameId: '30A13452-145B-4A18-85F7-56864BB3C4CF',
      frame: {
        y: 32,
        width: 76,
        x: 288,
        height: 28
      },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952800429.png',
      imageStyles: {
        resize: 'stretch'
      },
      type: 'image',
      id: 3
    },
    {
      name: 'Bitmap',
      nameId: 'CB102F67-A784-46BE-B0F5-9664ACC78982',
      frame: {
        y: 84,
        width: 12,
        x: 131,
        height: 12
      },
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952800630.png',
      imageStyles: {
        resize: 'stretch'
      },
      type: 'image',
      id: 4
    },
    {
      textStyles: {
        fontWeight: 'normal',
        color: '#888888',
        fontFamily: 'PingFangSC-Regular',
        fontSize: '24',
        lineHeight: '24',
        textAlign: 'left'
      },
      frame: {
        y: 79,
        x: 150,
        height: 23,
        width: 343
      },
      type: 'text',
      id: 5,
      value: '5分钟前·杭州 阿里巴巴西溪园区'
    },
    {
      textStyles: {
        fontWeight: 'bold',
        color: '#FF4444',
        fontFamily: 'PingFangSC-Medium',
        fontSize: '36',
        lineHeight: '36',
        textAlign: 'right'
      },
      frame: {
        y: 34,
        x: 576,
        height: 30,
        width: 141
      },
      type: 'text',
      id: 6,
      value: '6000'
    },
    {
      textStyles: {
        maxWidth: 594,
        fontWeight: 'normal',
        color: '#222222',
        maxHeight: 80,
        fontFamily: 'PingFangSC-Regular',
        fontSize: '28',
        lineHeight: '40',
        textAlign: 'left'
      },
      frame: {
        y: 129,
        x: 131,
        height: 67,
        width: 578
      },
      type: 'text',
      id: 7,
      value: 'Ducati Monster 821 国行大贸易 全国过户提档喜欢的盆友看看~'
    },
    {
      frame: {
        y: 222,
        x: 130,
        height: 392,
        width: 392
      },
      type: 'image',
      id: 8,
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952800835.png',
      imageStyles: {
        resize: 'stretch'
      }
    },
    {
      textStyles: {
        fontWeight: 'normal',
        color: '#888888',
        fontFamily: 'PingFangSC-Regular',
        fontSize: '24',
        lineHeight: '24',
        textAlign: 'left'
      },
      frame: {
        y: 647,
        x: 131,
        height: 23,
        width: 221
      },
      type: 'text',
      id: 9,
      value: '160个超赞·33人收藏'
    },
    {
      frame: {
        y: 642,
        x: 689,
        height: 32,
        width: 8
      },
      type: 'image',
      id: 10,
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952801300.png',
      imageStyles: {
        resize: 'stretch'
      }
    },
    {
      frame: {
        y: 642,
        x: 700,
        height: 32,
        width: 8
      },
      type: 'image',
      id: 11,
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952801300.png',
      imageStyles: {
        resize: 'stretch'
      }
    },
    {
      frame: {
        y: 642,
        x: 711,
        height: 32,
        width: 8
      },
      type: 'image',
      id: 12,
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523952801300.png',
      imageStyles: {
        resize: 'stretch'
      }
    }
  ],
  type: 'group',
  frame: {
    y: 0,
    x: 0,
    height: 702,
    width: 750
  },
  nameId: 1523952799697,
  id: 0
}
