export default {
  type: 'group',
  frame: { width: 750, height: 304, x: 0, y: 0 },
  layers: [
    {
      frame: { width: 750, height: 272, x: 0, y: 16 },
      skecthName: 'Mask',
      objectID: 'D7DF9D7B-9DC3-402C-B8CD-12ECF83B2556',
      id: 0,
      layers: []
    },
    {
      frame: { width: 750, height: 96, x: 0, y: 16 },
      skecthName: 'Rectangle 5',
      objectID: 'A5B5A92C-687A-4B18-B319-4B080CA51FE3',
      id: 1,
      layers: []
    },
    {
      frame: { width: 448, height: 36, x: 32, y: 46 },
      skecthName: '选择感兴趣的标签，推荐更准确',
      objectID: '38459179-5F94-4246-BA9F-3E3832010BB6',
      id: 2,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 30, y: 112 },
      skecthName: 'Rectangle 9',
      objectID: '397420B7-03F7-4AF2-9149-1910860291C8',
      id: 3,
      layers: []
    },
    {
      frame: { width: 56, height: 40, x: 80, y: 124.75 },
      skecthName: '标签',
      objectID: 'ED1B3403-7C36-48F0-AE40-9E97AB1DF02D',
      id: 4,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 198, y: 112 },
      skecthName: 'Rectangle 9',
      objectID: 'CFAAFECA-0805-439D-9280-637EF2098E22',
      id: 5,
      layers: []
    },
    {
      frame: { width: 56, height: 40, x: 246, y: 124.75 },
      skecthName: '绘画',
      objectID: 'A798BF53-49BE-43EA-8D78-9E17F5DA66C5',
      id: 6,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 366, y: 112 },
      skecthName: 'Rectangle 9',
      objectID: '88F0C128-0F0A-463A-9B0A-FA3D72B9CE86',
      id: 7,
      layers: []
    },
    {
      frame: { width: 82, height: 40, x: 402, y: 124.75 },
      skecthName: '40mm',
      objectID: 'EACB1339-DFF9-429D-A565-6DABE1859DE5',
      id: 8,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 534, y: 112 },
      skecthName: 'Rectangle 9',
      objectID: '4E3DFC87-E1B2-4170-8B91-9D1C45EB8713',
      id: 9,
      layers: []
    },
    {
      frame: { width: 97, height: 40, x: 562.5, y: 124.75 },
      skecthName: '光圈3.5',
      objectID: 'DBC02DAC-B7AC-44C5-A42F-07C00BB37DD1',
      id: 10,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 702, y: 112 },
      skecthName: 'Rectangle 9',
      objectID: '10E3BD3D-6B6E-4AD0-913F-0A4A0F5761D1',
      id: 11,
      layers: []
    },
    {
      frame: { width: 91, height: 37, x: 748.5, y: 126.75 },
      skecthName: '光圈3.5',
      objectID: '68C6B657-F959-4961-A53C-C11751696813',
      id: 12,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 30, y: 192 },
      skecthName: 'Rectangle 9',
      objectID: 'F0CD91DD-ACAC-4372-B49F-A354D3678858',
      id: 13,
      layers: []
    },
    {
      frame: { width: 56, height: 40, x: 80, y: 204.75 },
      skecthName: '标签',
      objectID: '8D1CE7B6-8596-49B8-A8D9-6F762C81A725',
      id: 14,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 198, y: 192 },
      skecthName: 'Rectangle 9',
      objectID: '2BF364FF-05C7-44E7-8398-225BC22DE464',
      id: 15,
      layers: []
    },
    {
      frame: { width: 56, height: 40, x: 246, y: 204.75 },
      skecthName: '绘画',
      objectID: '748259FF-D2EC-431E-8861-D7E6DFEA800D',
      id: 16,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 366, y: 192 },
      skecthName: 'Rectangle 9',
      objectID: '07CFF2EC-E231-47B7-8532-28456608C2A9',
      id: 17,
      layers: []
    },
    {
      frame: { width: 82, height: 40, x: 402, y: 204.75 },
      skecthName: '40mm',
      objectID: 'FD38966D-8705-4363-9E27-085325967461',
      id: 18,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 534, y: 192 },
      skecthName: 'Rectangle 9',
      objectID: '22AD60AC-FF5C-4982-81EF-1AD868EEA0C3',
      id: 19,
      layers: []
    },
    {
      frame: { width: 97, height: 40, x: 562.5, y: 204.75 },
      skecthName: '光圈3.5',
      objectID: '371CE9FE-89D7-44A4-82D8-E74EA1263B49',
      id: 20,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 702, y: 192 },
      skecthName: 'Rectangle 9',
      objectID: 'FA1821F6-B444-4B43-818C-1047900DE1D4',
      id: 21,
      layers: []
    },
    {
      frame: { width: 91, height: 37, x: 748.5, y: 206.75 },
      skecthName: '光圈3.5',
      objectID: 'F4062EA3-8C41-464A-86FB-B844CD462A86',
      id: 22,
      layers: []
    },
    {
      frame: { width: 750, height: 16, x: 0, y: 0 },
      skecthName: 'Rectangle 62 Copy',
      objectID: 'E7013037-7E3E-4C86-9C24-4D4E42BFCCF3',
      id: 23,
      layers: []
    },
    {
      frame: { width: 750, height: 16, x: 0, y: 288 },
      skecthName: 'Rectangle 62 Copy 2',
      objectID: '2D271272-550E-48CD-9940-7EEC398CEE81',
      id: 24,
      layers: []
    }
  ]
}
