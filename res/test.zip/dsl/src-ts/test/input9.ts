export default {
  layers: [
    {
      name: '¥324.00',
      Id: 3,
      nameId: 'B4BDE11A-9A75-40EE-BC4A-188220AC6926',
      frame: { width: 348, height: 60, x: 0, y: 0 },
      layers: [
        {
          name: '¥324.00',
          Id: 4,
          nameId: 'BFEE5C22-1C91-4AD4-BB02-D5A480D665DA',
          frame: { width: 137, height: 24, x: 5, y: 25 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '28',
            color: '#CA1D41',
            lineHeight: '24',
            maxWidth: 137,
            maxHeight: 24,
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '¥324.00',
          type: 'text'
        },
        {
          name: '1+段 I Aptamil 爱他美',
          Id: 6,
          nameId: '2579D400-3177-43C2-A94E-552DD9DD4D5D',
          frame: { width: 254, height: 60, x: 94, y: 0 },
          layers: [
            {
              name: '1+段 I Aptamil 爱他美',
              Id: 7,
              nameId: 'A9199B97-91AF-43FE-8BAA-5D063DF23A97',
              frame: { width: 198, height: 28, x: 94, y: 0 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '20',
                color: '#8F8F8F',
                lineHeight: '28',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '1+段 I Aptamil 爱他美',
              type: 'text'
            },
            {
              name: '1232人 copy',
              Id: 8,
              nameId: 'B1B70885-6C80-4D24-A71A-748A91A85802',
              frame: { width: 80, height: 33, x: 268, y: 27 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#898989',
                lineHeight: '33',
                maxWidth: 80,
                maxHeight: 33,
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '1232人',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '2579D400-3177-43C2-A94E-552DD9DD4D5D'
        },
        {
          name: '德国',
          Id: 9,
          nameId: '62B18CFD-9CDF-46FE-8D6F-0464CD136219',
          frame: { width: 41, height: 28, x: 32, y: 0 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '20',
            color: '#8F8F8F',
            lineHeight: '28',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '德国',
          type: 'text'
        },
        {
          name: 'Bitmap',
          Id: 11,
          nameId: '4B96B48C-6EBA-4AD3-AEFB-B193C78B84DC',
          frame: { width: 30, height: 30, x: 0, y: 1 },
          layers: [
            {
              name: 'Bitmap',
              Id: 12,
              nameId: 'E7BA63F2-1F19-454E-A928-480801B0C7FF',
              frame: { width: 27.90697674418605, height: 27.906976744186068, x: 2.093023255814842, y: 1 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523955589821.png'
            },
            {
              name: 'Rectangle 5',
              Id: 13,
              nameId: 'B2C7460B-33DE-4F92-8D16-0303F682C25B',
              frame: { width: 11.16279069767442, height: 4.883720930232585, x: 0, y: 26.116279069767415 },
              styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
              type: 'shape'
            }
          ],
          type: 'group',
          objectID: '4B96B48C-6EBA-4AD3-AEFB-B193C78B84DC'
        }
      ],
      type: 'group',
      objectID: 'B4BDE11A-9A75-40EE-BC4A-188220AC6926'
    },
    {
      name: '爱心 copy',
      Id: 14,
      nameId: 'F704B4FE-C9F3-4624-A87C-86951FE527B7',
      frame: { width: 21, height: 17, x: 241, y: 36 },
      imageStyles: { resize: 'stretch' },
      type: 'image',
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523955589946.png'
    },
    {
      name: '¥324.00',
      Id: 15,
      nameId: '4020F07C-E42D-4C2B-84EB-AD7DB9E4A670',
      frame: { width: 137, height: 24, x: 371, y: 25 },
      textStyles: {
        fontFamily: 'PingFangSC-Regular',
        fontSize: '28',
        color: '#CA1D41',
        lineHeight: '24',
        maxWidth: 137,
        maxHeight: 24,
        textAlign: 'left',
        fontWeight: 'normal'
      },
      value: '¥324.00',
      type: 'text'
    },
    {
      name: '爱心 copy',
      Id: 16,
      nameId: 'C4906A39-18FC-4B83-A0B2-8BFD431FBFC4',
      frame: { width: 21, height: 17, x: 607, y: 36 },
      imageStyles: { resize: 'stretch' },
      type: 'image',
      value: 'http://lubanpsdupload.oss-cn-shanghai.aliyuncs.com/hongxuan-sketch/hongxuan-sketch-module1523955590051.png'
    },
    {
      name: '1232人 copy',
      Id: 17,
      nameId: '6922384E-A546-4C7A-98B9-C514FBDBFB87',
      frame: { width: 80, height: 33, x: 634, y: 27 },
      textStyles: {
        fontFamily: 'PingFangSC-Regular',
        fontSize: '24',
        color: '#898989',
        lineHeight: '33',
        maxWidth: 80,
        maxHeight: 33,
        textAlign: 'left',
        fontWeight: 'normal'
      },
      value: '1232人',
      type: 'text'
    }
  ],
  nameId: 1523955589801,
  Id: 1,
  type: 'group',
  frame: { x: 0, y: 0, width: 714, height: 60 }
}
