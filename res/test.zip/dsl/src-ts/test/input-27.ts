export default {
  layers: [
    {
      name: 'Navigation Bar',
      Id: 3,
      nameId: '408897DF-9CE7-4870-BA13-546CFF6623EE',
      frame: { width: 750, height: 129, x: 0, y: 0 },
      layers: [
        {
          name: 'Body',
          Id: 5,
          nameId: '8D0E3F2A-B216-4609-8399-6FD7DDE84855',
          frame: { width: 750, height: 129, x: 0, y: 0 },
          layers: [
            {
              name: 'Bitmap',
              Id: 6,
              nameId: '0A407AF5-04C3-4840-8C29-F8B446C8C43F',
              frame: { width: 750, height: 40, x: 0, y: 0 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1_92BqDtYBeNjy1XdXXXXyVXa-750-40.png'
            },
            {
              name: 'Bitmap',
              Id: 7,
              nameId: 'EAA51568-CCC2-47A8-A604-2BD16AD395DD',
              frame: { width: 750, height: 88, x: 0, y: 41 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1xMh.qqmWBuNjy1XaXXXCbXXa-750-88.png'
            },
            {
              name: 'Bitmap',
              Id: 8,
              nameId: 'D877E00B-FE6A-4699-A544-C334758B20E4',
              frame: { width: 44, height: 44, x: 668, y: 63 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1oC6BqDtYBeNjy1XdXXXXyVXa-44-44.png'
            },
            {
              name: '发布免费送',
              Id: 9,
              nameId: '524A1E79-3257-4D29-8958-BD4D9E257042',
              frame: { width: 170, height: 44, x: 291, y: 63 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '34',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '44',
                fontWeight: 'bold'
              },
              value: '发布免费送',
              type: 'text'
            },
            {
              name: 'Bitmap',
              Id: 10,
              nameId: 'EB859CE9-A33E-4613-8613-73C8A632F163',
              frame: { width: 31, height: 31, x: 36, y: 70 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1KwpuqAyWBuNjy0FpXXassXXa-31-31.png'
            }
          ],
          type: 'group',
          objectID: '8D0E3F2A-B216-4609-8399-6FD7DDE84855'
        },
        {
          name: 'Status Bar black',
          Id: 12,
          nameId: 'A263EADE-AAD0-4EA7-B060-1A623B2591F1',
          frame: { width: 731, height: 33, x: 13, y: 3 },
          layers: [
            {
              name: 'Signal',
              Id: 14,
              nameId: 'C1C107CA-BBE6-4CEC-A8A2-F334D39B0939',
              frame: { width: 190, height: 27, x: 13, y: 8 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 15,
                  nameId: '6E366333-99C7-4CDC-B109-8A424953EFA1',
                  frame: { width: 68, height: 11, x: 13, y: 15 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1A96BqDtYBeNjy1XdXXXXyVXa-68-11.png'
                },
                {
                  name: 'VIRGI',
                  Id: 16,
                  nameId: '5D247815-2104-495E-B53A-D6842916A5C9',
                  frame: { width: 62, height: 27, x: 89.40533333333337, y: 8 },
                  textStyles: {
                    fontFamily: 'HelveticaNeue',
                    fontSize: '22',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '27',
                    fontWeight: 'normal'
                  },
                  value: 'VIRGI',
                  type: 'text'
                },
                {
                  name: 'N',
                  Id: 17,
                  nameId: 'F177C02F-4EEF-41E1-B6D3-E449B5EAF5E9',
                  frame: { width: 17, height: 27, x: 151.01133303333336, y: 8 },
                  textStyles: {
                    fontFamily: 'HelveticaNeue',
                    fontSize: '22',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '27',
                    fontWeight: 'normal'
                  },
                  value: 'N',
                  type: 'text'
                },
                {
                  name: 'Bitmap',
                  Id: 18,
                  nameId: 'C16F60A9-FE37-4E80-8DBB-1CE377FC9BA6',
                  frame: { width: 25, height: 19, x: 178, y: 11 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB12gpuqAyWBuNjy0FpXXassXXa-25-19.png'
                }
              ],
              type: 'group',
              objectID: 'C1C107CA-BBE6-4CEC-A8A2-F334D39B0939'
            },
            {
              name: 'Bitmap',
              Id: 19,
              nameId: '15747518-B3DB-40BA-A0A8-8588007E5B12',
              frame: { width: 17, height: 27, x: 606, y: 7 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1X9lMquuSBuNjy1XcXXcYjFXa-17-27.png'
            },
            {
              name: 'Battery',
              Id: 21,
              nameId: '238C86E7-1A43-46C9-A5E4-47768B78B688',
              frame: { width: 416, height: 33, x: 327.66933333333327, y: 3 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 22,
                  nameId: 'DB3C4903-21E5-4606-BE0B-B2B2D320C522',
                  frame: { width: 4, height: 7, x: 739, y: 17 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1d3tuqAyWBuNjy0FpXXassXXa-4-7.png'
                },
                {
                  name: 'Bitmap',
                  Id: 23,
                  nameId: '8E8369D4-217F-4F8E-8ACC-213DF04A769A',
                  frame: { width: 15, height: 15, x: 695, y: 13 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1t9lMquuSBuNjy1XcXXcYjFXa-15-15.png'
                },
                {
                  name: 'Bitmap',
                  Id: 24,
                  nameId: '27462BDD-5807-45FF-BB2C-048E1DB4A0C2',
                  frame: { width: 46, height: 19, x: 693, y: 11 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1tqM6qbGYBuNjy0FoXXciBFXa-46-19.png'
                },
                {
                  name: '22',
                  Id: 25,
                  nameId: '09F4DC50-0B95-452C-89A5-55DC55CF8758',
                  frame: { width: 28, height: 28, x: 636.3066666666664, y: 7 },
                  textStyles: {
                    fontFamily: 'HelveticaNeue-Light',
                    fontSize: '23',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '28',
                    fontWeight: 'normal'
                  },
                  value: '22',
                  type: 'text'
                },
                {
                  name: '%',
                  Id: 26,
                  nameId: 'D7FEBCBB-97E4-42C1-B38F-9CAFC7862FF0',
                  frame: { width: 22, height: 28, x: 663.8826666666664, y: 7 },
                  textStyles: {
                    fontFamily: 'HelveticaNeue-Light',
                    fontSize: '23',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '28',
                    fontWeight: 'normal'
                  },
                  value: '%',
                  type: 'text'
                },
                {
                  name: '4 21 PM',
                  Id: 27,
                  nameId: '2FC88C4A-C1AB-430F-BDBE-CE3748D8164B',
                  frame: { width: 97.51733333333323, height: 29, x: 327.66933333333327, y: 6 },
                  textStyles: {
                    fontFamily: 'HelveticaNeue',
                    fontSize: '24',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '29',
                    fontWeight: 'normal'
                  },
                  value: '4 21 PM',
                  type: 'text'
                },
                {
                  name: ':',
                  Id: 28,
                  nameId: 'E56A0ACE-4971-44F9-8389-2F4824ECEBFC',
                  frame: { width: 9.048000000000002, height: 33, x: 341.2413333333334, y: 3 },
                  textStyles: {
                    fontFamily: 'AvenirNext-Regular',
                    fontSize: '24',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '33',
                    fontWeight: 'normal'
                  },
                  value: ':',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '238C86E7-1A43-46C9-A5E4-47768B78B688'
            }
          ],
          type: 'group',
          objectID: 'A263EADE-AAD0-4EA7-B060-1A623B2591F1'
        }
      ],
      type: 'group',
      objectID: '408897DF-9CE7-4870-BA13-546CFF6623EE'
    },
    {
      name: 'Group 2',
      Id: 30,
      nameId: '600295CF-0A9A-45F9-BDE7-682ADF547FFC',
      frame: { width: 750, height: 104, x: 0, y: 129 },
      layers: [
        {
          name: 'Bitmap',
          Id: 31,
          nameId: '314D3DC9-1720-4491-845D-5FB4177135C4',
          frame: { width: 750, height: 104, x: 0, y: 129 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1L9lMquuSBuNjy1XcXXcYjFXa-750-104.png'
        },
        {
          name: 'Bitmap',
          Id: 32,
          nameId: '4472CEF1-82F8-49C1-923B-072A8053D493',
          frame: { width: 710, height: 104, x: 40, y: 129 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1NGM6qbGYBuNjy0FoXXciBFXa-710-104.png'
        },
        {
          name: 'Bitmap',
          Id: 33,
          nameId: '3FDEDC60-40CE-4AF4-A012-6E35C05D4C6D',
          frame: { width: 36, height: 36, x: 671, y: 163 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1.0ZDqgmTBuNjy1XbXXaMrVXa-36-36.png'
        },
        {
          name: '标题',
          Id: 34,
          nameId: 'D6CC321F-BF08-44BC-A8B5-EAD257602E5F',
          frame: { width: 64, height: 45, x: 40, y: 159 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '32',
            color: '#B3B3B3',
            lineHeight: '45',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '标题',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '600295CF-0A9A-45F9-BDE7-682ADF547FFC'
    },
    {
      name: 'Group 6',
      Id: 36,
      nameId: '194D8635-990C-47D5-AF88-9FC47867375A',
      frame: { width: 750, height: 104, x: 0, y: 233 },
      layers: [
        {
          name: 'Bitmap',
          Id: 37,
          nameId: 'A50C6953-A1FC-4F38-A6A4-3930496E93D3',
          frame: { width: 750, height: 104, x: 0, y: 233 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB15qM6qbGYBuNjy0FoXXciBFXa-750-104.png'
        },
        {
          name: '描述一下你的宝贝…',
          Id: 38,
          nameId: 'BE41266E-A17E-49D5-9744-0EC7C5340469',
          frame: { width: 288, height: 48, x: 40, y: 261 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '32',
            color: '#B3B3B3',
            lineHeight: '48',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '描述一下你的宝贝…',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '194D8635-990C-47D5-AF88-9FC47867375A'
    },
    {
      name: 'Bitmap',
      Id: 39,
      nameId: 'DB291A6A-B200-41F4-8667-905392557110',
      frame: { width: 750, height: 542, x: 0, y: 337 },
      imageStyles: { resize: 'stretch' },
      type: 'image',
      value: 'https://gw.alicdn.com/tfs/TB1td3DqgmTBuNjy1XbXXaMrVXa-750-542.png'
    },
    {
      name: 'Group 8',
      Id: 41,
      nameId: '747FE75F-81E9-4E64-A35C-F203062D95BA',
      frame: { width: 750, height: 96, x: 0, y: 783 },
      layers: [
        {
          name: 'Group 9',
          Id: 43,
          nameId: '9DBDE3D9-AC4B-4136-96DF-BF76BC1BC3B6',
          frame: { width: 206, height: 40, x: 40, y: 811 },
          layers: [
            {
              name: 'Bitmap',
              Id: 44,
              nameId: '5EC89047-1CFE-4074-B0C2-300D2381FE9B',
              frame: { width: 40, height: 32, x: 40, y: 815 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1Bed6qxGYBuNjy0FnXXX5lpXa-40-32.png'
            },
            {
              name: '杭州市余杭区',
              Id: 45,
              nameId: '5537FAD7-8129-4AE8-8656-391A216C3772',
              frame: { width: 168, height: 40, x: 78, y: 811 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#888888',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'normal'
              },
              value: '杭州市余杭区',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '9DBDE3D9-AC4B-4136-96DF-BF76BC1BC3B6'
        },
        {
          name: 'Group 7',
          Id: 47,
          nameId: '75BBB21F-2CA1-4AAD-8F21-96B8ECFDAA0E',
          frame: { width: 176, height: 48, x: 534, y: 807 },
          layers: [
            {
              name: 'Bitmap',
              Id: 48,
              nameId: 'BE680849-D5EF-47F5-9E27-735A334C31F9',
              frame: { width: 44, height: 44, x: 544, y: 809 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1Md3DqgmTBuNjy1XbXXaMrVXa-44-44.png'
            },
            {
              name: '全新宝贝',
              Id: 49,
              nameId: '28073D27-5EF2-4505-A991-51EC130ED4F0',
              frame: { width: 112, height: 40, x: 598, y: 811 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#888888',
                textAlign: 'center',
                lineHeight: '40',
                fontWeight: 'normal'
              },
              value: '全新宝贝',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '75BBB21F-2CA1-4AAD-8F21-96B8ECFDAA0E'
        }
      ],
      type: 'group',
      objectID: '747FE75F-81E9-4E64-A35C-F203062D95BA'
    },
    {
      name: 'Group 2',
      Id: 51,
      nameId: 'A39AF966-7789-4EE2-9296-850D59B7771C',
      frame: { width: 750, height: 144, x: 0, y: 903 },
      layers: [
        {
          name: 'Bitmap',
          Id: 52,
          nameId: 'D501D875-09E1-40D9-9BD5-D426BF5F4D19',
          frame: { width: 750, height: 144, x: 0, y: 903 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1RKd6qxGYBuNjy0FnXXX5lpXa-750-144.png'
        },
        {
          name: 'Bitmap',
          Id: 53,
          nameId: 'FE1E8695-0A58-4EB0-9DAE-A84127403FFC',
          frame: { width: 710, height: 144, x: 40, y: 903 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB12Mp.qqmWBuNjy1XaXXXCbXXa-710-144.png'
        },
        {
          name: '宝贝以闲鱼币竞拍方式送出，价高者得',
          Id: 54,
          nameId: 'AB2DE501-4B11-4F5F-A24D-088CED439EAB',
          frame: { width: 408, height: 33, x: 39, y: 982 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '24',
            color: '#888888',
            lineHeight: '33',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '宝贝以闲鱼币竞拍方式送出，价高者得',
          type: 'text'
        },
        {
          name: '100闲鱼币',
          Id: 55,
          nameId: '33AF81F9-B7C0-4B67-947D-40BC71DC6DA7',
          frame: { width: 148, height: 45, x: 39, y: 932 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: '32',
            color: '#222222',
            lineHeight: '45',
            textAlign: 'left',
            fontWeight: 'bold'
          },
          value: '100闲鱼币',
          type: 'text'
        },
        {
          name: ' 起拍',
          Id: 56,
          nameId: '532C2600-E90B-4D37-A0B4-EB311FB7C507',
          frame: { width: 75, height: 45, x: 186.4559999999999, y: 932 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '32',
            color: '#222222',
            lineHeight: '45',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: ' 起拍',
          type: 'text'
        },
        {
          name: 'Bitmap',
          Id: 57,
          nameId: '80888051-91DD-49E7-B7F4-D2A5FFAC4EB9',
          frame: { width: 14, height: 24, x: 696, y: 960 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1XKh6qxGYBuNjy0FnXXX5lpXa-14-24.png'
        }
      ],
      type: 'group',
      objectID: 'A39AF966-7789-4EE2-9296-850D59B7771C'
    },
    {
      name: 'Group 2 Copy',
      Id: 59,
      nameId: 'EDB9905C-571D-4E80-8A2E-816EC54CEF26',
      frame: { width: 750, height: 96, x: 0, y: 1047 },
      layers: [
        {
          name: 'Bitmap',
          Id: 60,
          nameId: '50C0CBD0-C530-4CA8-AE68-AF4360968DA8',
          frame: { width: 750, height: 96, x: 0, y: 1047 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1hwt.qqmWBuNjy1XaXXXCbXXa-750-96.png'
        },
        {
          name: 'Bitmap',
          Id: 61,
          nameId: '03A98C04-6DDF-4B12-A716-C7AECCDAB002',
          frame: { width: 710, height: 96, x: 40, y: 1047 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1jlViquSSBuNjy0FlXXbBpVXa-710-96.png'
        },
        {
          name: '¥20',
          Id: 62,
          nameId: '2D8A6F0D-9E87-48EA-AC6A-FF82A2112FEE',
          frame: { width: 58, height: 45, x: 41, y: 1072 },
          textStyles: {
            fontFamily: 'PingFangSC-Medium',
            fontSize: '32',
            color: '#222222',
            lineHeight: '45',
            textAlign: 'left',
            fontWeight: 'bold'
          },
          value: '¥20',
          type: 'text'
        },
        {
          name: ' 运费',
          Id: 63,
          nameId: '7671887C-8D0F-4CC5-B9AF-B6F71C1023D6',
          frame: { width: 75, height: 45, x: 98.59999999999991, y: 1072 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '32',
            color: '#222222',
            lineHeight: '45',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: ' 运费',
          type: 'text'
        },
        {
          name: 'Bitmap',
          Id: 64,
          nameId: '8DEFFB46-138C-4CDA-AE20-0F4816A7FD9F',
          frame: { width: 14, height: 24, x: 696, y: 1083 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1xwt.qqmWBuNjy1XaXXXCbXXa-14-24.png'
        }
      ],
      type: 'group',
      objectID: 'EDB9905C-571D-4E80-8A2E-816EC54CEF26'
    },
    {
      name: 'Group 2 Copy',
      Id: 66,
      nameId: 'C8CF2325-5DE2-4F7C-801E-6ADCBC057290',
      frame: { width: 750, height: 96, x: 0, y: 1143 },
      layers: [
        {
          name: 'Bitmap',
          Id: 67,
          nameId: '1EEA902F-CC07-44DF-8A90-2412C8B39CC8',
          frame: { width: 750, height: 96, x: 0, y: 1143 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1CRViquSSBuNjy0FlXXbBpVXa-750-96.png'
        },
        {
          name: 'Bitmap',
          Id: 68,
          nameId: 'E34B8215-F8B6-41E9-AB67-958798EC995B',
          frame: { width: 710, height: 96, x: 40, y: 1143 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1EgBuqAyWBuNjy0FpXXassXXa-710-96.png'
        },
        {
          name: '竞拍1小时(发布后立即开拍）',
          Id: 69,
          nameId: '074C63BE-4F43-4C8B-A0F4-5B00A8A468D5',
          frame: { width: 408, height: 45, x: 40, y: 1169 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '32',
            color: '#222222',
            lineHeight: '45',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '竞拍1小时(发布后立即开拍）',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: 'C8CF2325-5DE2-4F7C-801E-6ADCBC057290'
    },
    {
      name: 'Group 2 Copy 2',
      Id: 71,
      nameId: '34197DFB-BC4D-4B08-9765-935F11EB26A1',
      frame: { width: 750, height: 96, x: 0, y: 1239 },
      layers: [
        {
          name: 'Bitmap',
          Id: 72,
          nameId: 'C1AB328E-5ED2-4289-BC44-06935AC74CB0',
          frame: { width: 750, height: 96, x: 0, y: 1239 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1SBViquSSBuNjy0FlXXbBpVXa-750-96.png'
        },
        {
          name: 'Bitmap',
          Id: 73,
          nameId: '2D6783AE-9E06-408E-8846-F15448AB2C82',
          frame: { width: 710, height: 96, x: 40, y: 1239 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1WMBuqAyWBuNjy0FpXXassXXa-710-96.png'
        },
        {
          name: 'Bitmap',
          Id: 74,
          nameId: '081BB94B-11E9-475E-9984-7C581D247C70',
          frame: { width: 14, height: 24, x: 696, y: 1275 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1YIVZqv1TBuNjy0FjXXajyXXa-14-24.png'
        },
        {
          name: '母婴用品',
          Id: 75,
          nameId: '3F8CFA3F-1F15-42A2-A993-282181487727',
          frame: { width: 128, height: 45, x: 40, y: 1265 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '32',
            color: '#222222',
            lineHeight: '45',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '母婴用品',
          type: 'text'
        }
      ],
      type: 'group',
      objectID: '34197DFB-BC4D-4B08-9765-935F11EB26A1'
    },
    {
      name: 'Group 16',
      Id: 77,
      nameId: 'FE5A2735-092A-4CC6-A3FB-10BFA5F77EAE',
      frame: { width: 750, height: 112, x: 0, y: 1455 },
      layers: [
        {
          name: 'bottombar_1btn',
          Id: 79,
          nameId: '2B9DBE02-DB95-4BAB-8074-7CDC7243C872',
          frame: { width: 750, height: 112, x: 0, y: 1455 },
          layers: [
            {
              name: 'Bitmap',
              Id: 80,
              nameId: '4D726F76-6AD0-4160-8CD2-9356FE063BEA',
              frame: { width: 750, height: 112, x: 0, y: 1455 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1eMFuqAyWBuNjy0FpXXassXXa-750-112.png'
            },
            {
              name: 'Group 14',
              Id: 82,
              nameId: 'BD78F4FA-7788-4C0E-AB5D-39FA7A328993',
              frame: { width: 686, height: 80, x: 32, y: 1471 },
              layers: [
                {
                  name: 'Group 9',
                  Id: 84,
                  nameId: 'D227D6AA-4A43-4D03-AA32-0DD1220B91AF',
                  frame: { width: 686, height: 80, x: 32, y: 1471 },
                  layers: [
                    {
                      name: 'Bitmap',
                      Id: 85,
                      nameId: '15C5A8C6-2A5B-4AD8-BB52-59407F4DFE2C',
                      frame: { width: 686, height: 80, x: 32, y: 1471 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1eI0Zqv1TBuNjy0FjXXajyXXa-686-80.png'
                    },
                    {
                      name: '确定发布',
                      Id: 86,
                      nameId: 'DEA6667C-1F18-42C3-B281-3080305BE98E',
                      frame: { width: 128, height: 40, x: 312, y: 1491 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '32',
                        color: '#FFFFFF',
                        textAlign: 'center',
                        lineHeight: '40',
                        fontWeight: 'bold'
                      },
                      value: '确定发布',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'D227D6AA-4A43-4D03-AA32-0DD1220B91AF'
                }
              ],
              type: 'group',
              objectID: 'BD78F4FA-7788-4C0E-AB5D-39FA7A328993'
            }
          ],
          type: 'group',
          objectID: '2B9DBE02-DB95-4BAB-8074-7CDC7243C872'
        }
      ],
      type: 'group',
      objectID: 'FE5A2735-092A-4CC6-A3FB-10BFA5F77EAE'
    },
    {
      name: 'Group 3',
      Id: 88,
      nameId: '7C4D96A7-0209-4B37-9A96-EADFA60619EA',
      frame: { width: 672, height: 332, x: 40, y: 451 },
      layers: [
        {
          name: 'Group 5',
          Id: 90,
          nameId: 'EAC0A2B2-3C25-46B0-9E78-0C33DA73F3F8',
          frame: { width: 162, height: 162, x: 40, y: 451 },
          layers: [
            {
              name: 'Bitmap',
              Id: 91,
              nameId: 'C904E760-B7ED-4348-9608-4F2388E8A132',
              frame: { width: 162, height: 162, x: 40, y: 451 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1pGZ6qbGYBuNjy0FoXXciBFXa-162-162.png'
            },
            {
              name: 'Group 18',
              Id: 93,
              nameId: '4DEEBBA4-6854-4340-A763-AF134BB4DDA3',
              frame: { width: 56, height: 28, x: 48, y: 575 },
              layers: [
                {
                  name: 'Bitmap',
                  Id: 94,
                  nameId: '90CB2B06-9C15-4A4D-92F6-D5039A1668F2',
                  frame: { width: 56, height: 28, x: 48, y: 575 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1DI0Zqv1TBuNjy0FjXXajyXXa-56-28.png'
                },
                {
                  name: '主图',
                  Id: 95,
                  nameId: 'F5F405E3-E102-43D2-882A-688895256002',
                  frame: { width: 40, height: 24, x: 56, y: 577 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '20',
                    color: '#222222',
                    textAlign: 'center',
                    lineHeight: '24',
                    fontWeight: 'normal'
                  },
                  value: '主图',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '4DEEBBA4-6854-4340-A763-AF134BB4DDA3'
            }
          ],
          type: 'group',
          objectID: 'EAC0A2B2-3C25-46B0-9E78-0C33DA73F3F8'
        },
        {
          name: 'Bitmap',
          Id: 96,
          nameId: 'D896DE5A-A5A8-4B26-B3DB-21A338619310',
          frame: { width: 162, height: 162, x: 40, y: 621 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1NqZ6qbGYBuNjy0FoXXciBFXa-162-162.png'
        },
        {
          name: 'Bitmap',
          Id: 97,
          nameId: '52CF712D-1F31-4703-B32D-D256EB057756',
          frame: { width: 162, height: 162, x: 210, y: 621 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1SLXfqpOWBuNjy0FiXXXFxVXa-162-162.png'
        },
        {
          name: 'Bitmap',
          Id: 98,
          nameId: '3D03D9E6-46A7-427D-B4BF-035545279536',
          frame: { width: 162, height: 162, x: 210, y: 451 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1aa36qbGYBuNjy0FoXXciBFXa-162-162.png'
        },
        {
          name: 'Bitmap',
          Id: 99,
          nameId: '159B9A18-57D6-4225-B97C-0B5D990C1ECB',
          frame: { width: 162, height: 160, x: 380, y: 451 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1XLdfqpOWBuNjy0FiXXXFxVXa-162-160.png'
        },
        {
          name: 'Bitmap',
          Id: 100,
          nameId: '86E3CEAE-9140-4290-8FB9-E9639CE5EC0E',
          frame: { width: 162, height: 162, x: 550, y: 451 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1Dep6qxGYBuNjy0FnXXX5lpXa-162-162.png'
        }
      ],
      type: 'group',
      objectID: '7C4D96A7-0209-4B37-9A96-EADFA60619EA'
    }
  ],
  nameId: 1525779050763,
  Id: 1,
  type: 'group',
  frame: { x: 0, y: 0, width: 750, height: 1567 },
  styles: { backgroundColor: 'rgba(243,245,249,1)' }
}
