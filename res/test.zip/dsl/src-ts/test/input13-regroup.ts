export default {
  type: 'group',
  frame: { width: 750, height: 272, x: 0, y: 0 },
  layers: [
    {
      frame: { width: 750, height: 272, x: 0, y: 0 },
      skecthName: 'Mask',
      objectID: '232CAB9C-2920-423C-A691-0DA037B6D459',
      id: 0,
      layers: []
    },
    {
      frame: { width: 750, height: 96, x: 0, y: 0 },
      skecthName: 'Rectangle 5',
      objectID: 'FC35250D-4E9C-4B1D-8CD3-9B5AA5FA534A',
      id: 1,
      layers: []
    },
    {
      frame: { width: 448, height: 36, x: 32, y: 30 },
      skecthName: '选择感兴趣的标签，推荐更准确',
      objectID: '0C5D5C69-20CC-4CC3-9680-6F2CF11E8AC8',
      id: 2,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 30, y: 96 },
      skecthName: 'Rectangle 9',
      objectID: '382A60D5-10E5-4086-A196-527E20314D90',
      id: 3,
      layers: []
    },
    {
      frame: { width: 56, height: 40, x: 80, y: 108.75 },
      skecthName: '标签',
      objectID: '113D9467-A7E0-42D4-AEB9-569740A3BC6F',
      id: 4,
      layers: []
    },
    {
      frame: { width: 152, height: 64, x: 30, y: 176 },
      skecthName: 'Rectangle 9',
      objectID: 'B99AA8F8-BA38-449E-8D9D-3856F9F46981',
      id: 5,
      layers: []
    },
    {
      frame: { width: 56, height: 40, x: 80, y: 188.75 },
      skecthName: '标签',
      objectID: '410090D5-98ED-41AA-BE21-A4B17E224C8F',
      id: 6,
      layers: []
    }
  ]
}
