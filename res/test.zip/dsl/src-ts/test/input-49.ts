export default {
  layers: [
    { frame: { y: 26, x: 34, height: 80, width: 80 }, type: 'image', id: 1, value: 'http://47.100.92.83:8081/ui/34_26_80_80_image.png' },
    {
      textStyles: { color: '#222222', lineHeight: 43, fontSize: 30, textAlign: 'left', fontFamily: 'PingFangSC-Medium' },
      frame: { y: 29, x: 130, height: 43, width: 150 },
      type: 'text',
      id: 2,
      value: '西溪包租婆'
    },
    { frame: { y: 38, x: 286, height: 28, width: 76 }, type: 'image', id: 3, value: 'http://47.100.92.83:8081/ui/286_38_76_28_image.png' },
    {
      styles: {
        opacity: 1,
        borderColor: 'rgba(255,68,68,1)',
        borderRadius: 4,
        borderWidth: 1,
        backgroundColor: 'rgba(255,68,68,1)',
        borderStyle: 'solid'
      },
      frame: { y: 37, x: 375, height: 28, width: 62 },
      type: 'shape',
      id: 4
    },
    {
      styles: {
        opacity: 1,
        borderColor: 'rgba(100,210,118,1)',
        borderRadius: 5,
        borderWidth: 1,
        backgroundColor: 'rgba(85,207,105,1)',
        borderStyle: 'solid'
      },
      frame: { y: 84, x: 130, height: 12, width: 12 },
      type: 'shape',
      id: 5
    },
    {
      textStyles: { color: '#888888', lineHeight: 35, fontSize: 24, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 73, x: 150, height: 23, width: 346 },
      type: 'text',
      id: 6,
      value: '5分钟前′杭州阿里巴巴西溪园区'
    },
    {
      textStyles: { color: '#ff4444', lineHeight: 35, fontSize: 24, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 35, x: 580, height: 18, width: 14 },
      type: 'text',
      id: 7,
      value: '¥'
    },
    {
      textStyles: { color: '#ff4444', lineHeight: 52, fontSize: 36, textAlign: 'left', fontFamily: 'PingFangSC-Medium' },
      frame: { y: 23, x: 601, height: 28, width: 87 },
      type: 'text',
      id: 8,
      value: '6000'
    },
    {
      textStyles: { color: '#ff4444', lineHeight: 35, fontSize: 24, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 35, x: 688, height: 23, width: 12 },
      type: 'text',
      id: 9,
      value: '/'
    },
    {
      textStyles: { color: '#222222', lineHeight: 40, fontSize: 28, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 127, x: 130, height: 66, width: 580 },
      type: 'text',
      id: 10,
      value: 'DucatiMonster821国行大贸易全国过户提档喜欢的盆友看看~'
    },
    {
      frame: { y: 222, x: 130, height: 392, width: 392 },
      type: 'image',
      id: 11,
      value: 'http://47.100.92.83:8081/ui/130_222_392_392_image.png'
    },
    {
      textStyles: { color: '#888888', lineHeight: 35, fontSize: 24, textAlign: 'left', fontFamily: 'PingFangSC-Regular' },
      frame: { y: 641, x: 130, height: 23, width: 223 },
      type: 'text',
      id: 12,
      value: '160个超赞·33人收藏'
    }
  ],
  frame: { y: 0, x: 0, height: 702, width: 750 },
  type: 'group',
  id: 0
}
