export default {
  layers: [
    {
      name: '发布_租房－pick',
      Id: 419,
      nameId: 'F966C27C-F434-4756-923B-B9163789BC16',
      frame: { width: 750, height: 1254, x: 0, y: 0 },
      imageStyles: { resize: 'stretch' },
      type: 'image',
      value: 'https://gw.alicdn.com/tfs/TB1PGA7qamWBuNjy1XaXXXCbXXa-750-1254.png'
    },
    {
      name: 'Rectangle 2',
      Id: 421,
      nameId: 'D6EDC84F-FC03-4732-896D-FE34935F3E2F',
      frame: { width: 750, height: 1334, x: 0, y: 0 },
      layers: [
        {
          name: 'Rectangle 2',
          Id: 422,
          nameId: 'BE9EE17D-322A-4D9E-B0FF-FE7EFFE31A33',
          frame: { width: 750, height: 1334, x: 0, y: 0 },
          styles: { backgroundColor: 'rgba(0,0,0,0.255)', fillType: 'color' },
          type: 'shape'
        },
        {
          name: 'Rectangle 2',
          Id: 424,
          nameId: '98812CFC-1C40-4A88-84E7-E800FFCF4897',
          frame: { width: 750, height: 1334, x: 0, y: 0 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 425,
              nameId: '4A9F8501-B235-4460-8E7C-4A2127E0F754',
              frame: { width: 750, height: 1334, x: 0, y: 0 },
              styles: { backgroundColor: 'rgba(255,255,255,0.7224999999999999)', fillType: 'color' },
              type: 'shape'
            },
            {
              name: '5',
              Id: 427,
              nameId: '6EDFE845-0DC1-4105-A117-B3E19B783BAF',
              frame: { width: 641, height: 279, x: 39, y: 0 },
              layers: [
                {
                  name: '5',
                  Id: 428,
                  nameId: '2919AF2B-83E3-4015-982B-21224FB1C200',
                  frame: { width: 641, height: 279, x: 39, y: 0 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1StbzqgmTBuNjy1XbXXaMrVXa-641-279.png'
                },
                {
                  name: '发布成功',
                  Id: 429,
                  nameId: '86FC4833-DE30-40EF-B924-CCB3268AE211',
                  frame: { width: 192, height: 68, x: 279, y: 201 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '48',
                    color: '#333333',
                    textAlign: 'center',
                    lineHeight: '67.19999694824219',
                    fontWeight: 'normal'
                  },
                  value: '发布成功',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '6EDFE845-0DC1-4105-A117-B3E19B783BAF'
            },
            {
              name: '分享到鱼塘，获得更多曝光！',
              Id: 430,
              nameId: '1582C050-2978-40CB-A4DD-1F78571640DA',
              frame: { width: 364, height: 34, x: 40, y: 314 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#222222',
                lineHeight: '33.599998474121094',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '分享到鱼塘，获得更多曝光！',
              type: 'text'
            },
            {
              name: 'Group',
              Id: 432,
              nameId: '98261951-35F5-4AC7-B25A-C4C274D4643C',
              frame: { width: 672, height: 211, x: 40, y: 370 },
              layers: [
                {
                  name: 'Rectangle 5 Copy 7',
                  Id: 434,
                  nameId: 'BB63DD45-D80E-42B0-BD19-427B3C405DE9',
                  frame: { width: 150, height: 211, x: 214, y: 370 },
                  layers: [
                    {
                      name: 'Rectangle 5 Copy 7',
                      Id: 435,
                      nameId: 'C59B1FEB-20A5-4B8F-B58D-210751F85C83',
                      frame: { width: 150, height: 211, x: 214, y: 370 },
                      styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', cornerRadiusString: '10', borderRadius: 10 },
                      type: 'shape'
                    },
                    {
                      name: '大华西溪 风情小...',
                      Id: 436,
                      nameId: '27F68E67-F8B4-4C31-8791-C34AAEF888B8',
                      frame: { width: 96, height: 66, x: 243, y: 495 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#333333',
                        lineHeight: '33',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '大华西溪\n风情小...',
                      type: 'text'
                    },
                    {
                      name: 'Group 8',
                      Id: 437,
                      nameId: '7BE55E3B-2C86-40F3-9FDF-6BF51A911E38',
                      frame: { width: 88, height: 88, x: 245, y: 394 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB11QUIqeuSBuNjy1XcXXcYjFXa-88-88.png'
                    }
                  ],
                  type: 'group',
                  objectID: 'BB63DD45-D80E-42B0-BD19-427B3C405DE9'
                },
                {
                  name: 'Rectangle 5 Copy 7',
                  Id: 439,
                  nameId: '16BADA51-6CD1-4999-A414-AC9211835AFA',
                  frame: { width: 150, height: 211, x: 40, y: 370 },
                  layers: [
                    {
                      name: 'Rectangle 5 Copy 7',
                      Id: 440,
                      nameId: 'DD552F46-5EE5-4463-A796-8A51CED0772B',
                      frame: { width: 150, height: 211, x: 40, y: 370 },
                      styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', cornerRadiusString: '10', borderRadius: 10 },
                      type: 'shape'
                    },
                    {
                      name: '阿里巴巴 西溪园区',
                      Id: 441,
                      nameId: '7B6E0C33-A5EA-4C41-B5C3-8BB7DE6935E7',
                      frame: { width: 96, height: 66, x: 68, y: 496 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#333333',
                        textAlign: 'center',
                        lineHeight: '33',
                        fontWeight: 'normal'
                      },
                      value: '阿里巴巴\n西溪园区',
                      type: 'text'
                    },
                    {
                      name: 'Group 5',
                      Id: 442,
                      nameId: '3C417835-74AC-4D4E-80C3-269213FAB5E5',
                      frame: { width: 88, height: 88, x: 71, y: 394 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1.0bzqgmTBuNjy1XbXXaMrVXa-88-88.png'
                    }
                  ],
                  type: 'group',
                  objectID: '16BADA51-6CD1-4999-A414-AC9211835AFA'
                },
                {
                  name: 'Group 5',
                  Id: 444,
                  nameId: '0D5B0A7F-5CE9-4EB1-84EB-D1176B86F1AB',
                  frame: { width: 150, height: 211, x: 388, y: 370 },
                  layers: [
                    {
                      name: 'Group 5',
                      Id: 445,
                      nameId: '48EE8F5E-F515-4E94-B43C-892745FB7DC5',
                      frame: { width: 150, height: 211, x: 388, y: 370 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1xWE7qamWBuNjy1XaXXXCbXXa-150-211.png'
                    },
                    {
                      name: '西溪北苑',
                      Id: 446,
                      nameId: 'D30027AA-2D9C-48E0-98E3-5C9017FCFAA5',
                      frame: { width: 96, height: 33, x: 415.5, y: 495 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '24',
                        color: '#333333',
                        textAlign: 'center',
                        lineHeight: '33',
                        fontWeight: 'normal'
                      },
                      value: '西溪北苑',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '0D5B0A7F-5CE9-4EB1-84EB-D1176B86F1AB'
                },
                {
                  name: 'Group 12',
                  Id: 447,
                  nameId: '2586A332-8D87-42CE-AB62-3198C25DE637',
                  frame: { width: 150, height: 211, x: 562, y: 370 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1FaE7qamWBuNjy1XaXXXCbXXa-150-211.png'
                }
              ],
              type: 'group',
              objectID: '98261951-35F5-4AC7-B25A-C4C274D4643C'
            },
            {
              name: '分享到更多平台',
              Id: 448,
              nameId: 'D7AA13EF-BC7C-4BA3-AF81-D2B7BC3A386A',
              frame: { width: 196, height: 34, x: 40, y: 670 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '28',
                color: '#222222',
                lineHeight: '33.599998474121094',
                textAlign: 'left',
                fontWeight: 'normal'
              },
              value: '分享到更多平台',
              type: 'text'
            },
            {
              name: 'Group',
              Id: 450,
              nameId: '980BFFD3-E2E1-42DE-B709-F1D303C464DE',
              frame: { width: 668, height: 104, x: 40, y: 728 },
              layers: [
                {
                  name: 'Oval 12',
                  Id: 452,
                  nameId: '15432D18-A837-4418-8DD5-AD05FDA25983',
                  frame: { width: 104, height: 104, x: 604, y: 728 },
                  layers: [
                    {
                      name: 'Oval 12',
                      Id: 453,
                      nameId: '8C0C682C-4A08-4C87-969B-4053A46B184D',
                      frame: { width: 104, height: 104, x: 604, y: 728 },
                      styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', borderRadius: 104 },
                      type: 'shape'
                    },
                    {
                      name: 'Bitmap',
                      Id: 454,
                      nameId: 'D4E68226-F4A1-42A6-879C-CF1628067D19',
                      frame: { width: 56, height: 56, x: 628, y: 752 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1CHUqqkyWBuNjy0FpXXassXXa-56-56.png'
                    }
                  ],
                  type: 'group',
                  objectID: '15432D18-A837-4418-8DD5-AD05FDA25983'
                },
                {
                  name: 'Oval 12',
                  Id: 456,
                  nameId: '87E5DB64-38B0-482C-B2B4-778A3C85D0FD',
                  frame: { width: 104, height: 104, x: 181, y: 728 },
                  layers: [
                    {
                      name: 'Oval 12',
                      Id: 457,
                      nameId: '1CCE2A57-BC11-44BC-8F08-FF1A4B8F9EBA',
                      frame: { width: 104, height: 104, x: 181, y: 728 },
                      styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', borderRadius: 104 },
                      type: 'shape'
                    },
                    {
                      name: '朋友圈',
                      Id: 458,
                      nameId: 'D37ADC82-C0AF-4827-8C4A-2F4487699449',
                      frame: { width: 52, height: 52, x: 207, y: 754 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1VWE7qamWBuNjy1XaXXXCbXXa-52-52.png'
                    }
                  ],
                  type: 'group',
                  objectID: '87E5DB64-38B0-482C-B2B4-778A3C85D0FD'
                },
                {
                  name: 'Oval 12',
                  Id: 460,
                  nameId: '9C6352BB-F2CE-44A9-9276-1A59E71AB20C',
                  frame: { width: 104, height: 104, x: 40, y: 728 },
                  layers: [
                    {
                      name: 'Oval 12',
                      Id: 461,
                      nameId: '9D09B5A7-EF3E-4D73-907E-F5EC5932C534',
                      frame: { width: 104, height: 104, x: 40, y: 728 },
                      styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', borderRadius: 104 },
                      type: 'shape'
                    },
                    {
                      name: 'Bitmap',
                      Id: 462,
                      nameId: '38BC6DD6-9485-428E-981C-BC85F5EE8B5C',
                      frame: { width: 61, height: 50, x: 62, y: 755 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1MdfzqgmTBuNjy1XbXXaMrVXa-61-50.png'
                    }
                  ],
                  type: 'group',
                  objectID: '9C6352BB-F2CE-44A9-9276-1A59E71AB20C'
                },
                {
                  name: 'Oval 12',
                  Id: 464,
                  nameId: '71247DEB-2985-4309-901A-7690A8FF356A',
                  frame: { width: 104, height: 104, x: 322, y: 728 },
                  layers: [
                    {
                      name: 'Oval 12',
                      Id: 465,
                      nameId: '0FA27FC7-4090-42A3-A09B-D65800021B4D',
                      frame: { width: 104, height: 104, x: 322, y: 728 },
                      styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', borderRadius: 104 },
                      type: 'shape'
                    },
                    {
                      name: 'QQ',
                      Id: 466,
                      nameId: '04A691DB-E586-400A-AF7A-058DEA6A748B',
                      frame: { width: 54, height: 54, x: 347, y: 753 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1dWI7qamWBuNjy1XaXXXCbXXa-54-54.png'
                    }
                  ],
                  type: 'group',
                  objectID: '71247DEB-2985-4309-901A-7690A8FF356A'
                },
                {
                  name: 'Oval 12',
                  Id: 468,
                  nameId: '77858D32-DDA5-430F-8748-446FC4399B4F',
                  frame: { width: 104, height: 104, x: 463, y: 728 },
                  layers: [
                    {
                      name: 'Oval 12',
                      Id: 469,
                      nameId: '6B9D9D63-A0D3-4372-AA36-92A3AF441D0A',
                      frame: { width: 104, height: 104, x: 463, y: 728 },
                      styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', borderRadius: 104 },
                      type: 'shape'
                    },
                    {
                      name: 'Bitmap',
                      Id: 470,
                      nameId: '71B65691-4A21-4111-AE63-0D3CDD04E518',
                      frame: { width: 60, height: 48, x: 487, y: 754 },
                      imageStyles: { resize: 'stretch' },
                      type: 'image',
                      value: 'https://gw.alicdn.com/tfs/TB1XrZqqkyWBuNjy0FpXXassXXa-60-48.png'
                    }
                  ],
                  type: 'group',
                  objectID: '77858D32-DDA5-430F-8748-446FC4399B4F'
                }
              ],
              type: 'group',
              objectID: '980BFFD3-E2E1-42DE-B709-F1D303C464DE'
            },
            {
              name: 'Group',
              Id: 472,
              nameId: 'EAC0C1C3-04C2-475F-AAA9-0A476F3B32DF',
              frame: { width: 631, height: 34, x: 68, y: 843 },
              layers: [
                {
                  name: 'QQ空间',
                  Id: 473,
                  nameId: '73D58D5E-B37E-49EB-86BA-6D4CD2BBA89F',
                  frame: { width: 85, height: 33, x: 614, y: 844 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '24',
                    color: '#333333',
                    textAlign: 'center',
                    lineHeight: '33',
                    fontWeight: 'normal'
                  },
                  value: 'QQ空间',
                  type: 'text'
                },
                {
                  name: '朋友圈',
                  Id: 474,
                  nameId: '3F54D2FF-7BB9-4CD6-B496-AE6CC7A41191',
                  frame: { width: 72, height: 33, x: 198, y: 844 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '24',
                    color: '#333333',
                    lineHeight: '33',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '朋友圈',
                  type: 'text'
                },
                {
                  name: '微信',
                  Id: 475,
                  nameId: 'D977D173-1795-4592-BE8E-29A4FA9A7C13',
                  frame: { width: 48, height: 33, x: 68, y: 844 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '24',
                    color: '#333333',
                    lineHeight: '33',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '微信',
                  type: 'text'
                },
                {
                  name: 'QQ',
                  Id: 476,
                  nameId: '7C9A8397-6942-4A01-9D46-A6EE35437AF2',
                  frame: { width: 37, height: 33, x: 356, y: 844 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '24',
                    color: '#333333',
                    lineHeight: '33',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: 'QQ',
                  type: 'text'
                },
                {
                  name: '微博',
                  Id: 477,
                  nameId: '964F4FFB-0C54-49A3-ADB5-799B6B795532',
                  frame: { width: 48, height: 33, x: 491, y: 843 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '24',
                    color: '#333333',
                    lineHeight: '33',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '微博',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: 'EAC0C1C3-04C2-475F-AAA9-0A476F3B32DF'
            },
            {
              name: 'Group 5',
              Id: 478,
              nameId: '842EBDF9-8ACC-4993-A976-6CDDB2A9F540',
              frame: { width: 29, height: 30, x: 361, y: 1222 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1frZqqkyWBuNjy0FpXXassXXa-29-30.png'
            },
            {
              name: '请警惕骗子冒充闲鱼及淘宝客服，以收取消费',
              Id: 480,
              nameId: '96B78F17-2986-476B-9944-6CABF02D9154',
              frame: { width: 672, height: 84, x: 40, y: 955 },
              layers: [
                {
                  name: 'richText',
                  Id: 482,
                  nameId: 'F54FFE1C-9FAA-4026-B60F-84BA5B58A3EA',
                  frame: { width: 672, height: 84, x: 40, y: 955 },
                  layers: [
                    {
                      name: '请警惕骗子冒充闲鱼及淘宝客服，以收取消费者保证金',
                      Id: 483,
                      nameId: '5F283570-5EC8-4FA5-AF58-726C4D337851',
                      frame: { width: 672, height: 42, x: 40, y: 955 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '28',
                        color: '#333333',
                        lineHeight: '42',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '请警惕骗子冒充闲鱼及淘宝客服，以收取消费者保证金',
                      type: 'text'
                    },
                    {
                      name: '为借口进行欺诈的行为，',
                      Id: 484,
                      nameId: '2C00FF31-BB4D-4700-8F87-A8DDD6A3B3C5',
                      frame: { width: 308, height: 42, x: 40, y: 997 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '28',
                        color: '#333333',
                        lineHeight: '42',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '为借口进行欺诈的行为，',
                      type: 'text'
                    },
                    {
                      name: '了解更多',
                      Id: 485,
                      nameId: '7AB2B083-A7E4-46F3-BA64-5068B26AC4A5',
                      frame: { width: 112, height: 42, x: 348, y: 997 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '28',
                        color: '#38ADFF',
                        lineHeight: '42',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '了解更多',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: 'F54FFE1C-9FAA-4026-B60F-84BA5B58A3EA'
                },
                {
                  name: '箭头 右',
                  Id: 486,
                  nameId: '3D6F76B5-6F3B-4D95-BEBC-B493C2729D5B',
                  frame: { width: 21, height: 23, x: 462, y: 1005 },
                  imageStyles: { resize: 'stretch' },
                  type: 'image',
                  value: 'https://gw.alicdn.com/tfs/TB1tDT1qbGYBuNjy0FoXXciBFXa-21-23.png'
                }
              ],
              type: 'group',
              objectID: '96B78F17-2986-476B-9944-6CABF02D9154'
            }
          ],
          type: 'group',
          objectID: '98812CFC-1C40-4A88-84E7-E800FFCF4897'
        }
      ],
      type: 'group',
      objectID: 'D6EDC84F-FC03-4732-896D-FE34935F3E2F'
    }
  ],
  nameId: 1525756659839,
  Id: 418,
  type: 'group',
  frame: { x: 0, y: 0, width: 750, height: 1334 }
}
