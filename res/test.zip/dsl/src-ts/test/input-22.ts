export default {
  layers: [
    {
      name: 'Group 44',
      Id: 136,
      nameId: '8121CA90-D93B-478E-8363-603B04500FF7',
      frame: { width: 750, height: 88, x: 0, y: 88 },
      layers: [
        {
          name: 'nvaibar/brand',
          Id: 138,
          nameId: 'DB68C758-B048-4F4C-8905-6F5203F8ED41',
          frame: { width: 750, height: 88, x: 0, y: 88 },
          layers: [
            {
              name: 'Bitmap',
              Id: 139,
              nameId: 'B22FEABF-AAC3-4522-86A5-71B8AF765DBF',
              frame: { width: 750, height: 88, x: 0, y: 88 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1ynuBqhSYBuNjSspjXXX73VXa-750-88.png'
            },
            {
              name: '联系客服',
              Id: 140,
              nameId: '26299D36-9847-409D-8B1F-CF9380C569AD',
              frame: { width: 128, height: 45, x: 590, y: 110 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '32',
                color: '#222222',
                textAlign: 'right',
                lineHeight: '45',
                fontWeight: 'bold'
              },
              value: '联系客服',
              type: 'text'
            },
            {
              name: '质检详情',
              Id: 141,
              nameId: '69945E4A-0F67-4EBB-A05D-EE81A26B1B95',
              frame: { width: 136, height: 48, x: 308, y: 108 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '34',
                color: '#222222',
                textAlign: 'center',
                lineHeight: '48',
                fontWeight: 'bold'
              },
              value: '质检详情',
              type: 'text'
            },
            {
              name: 'Bitmap',
              Id: 142,
              nameId: '3B86BA9B-3964-41CF-8E83-9C667B96454C',
              frame: { width: 23, height: 41, x: 38, y: 112 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1qIYKqmtYBeNjSspaXXaOOFXa-23-41.png'
            }
          ],
          type: 'group',
          objectID: 'DB68C758-B048-4F4C-8905-6F5203F8ED41'
        }
      ],
      type: 'group',
      objectID: '8121CA90-D93B-478E-8363-603B04500FF7'
    },
    {
      name: 'Group',
      Id: 144,
      nameId: '6BD75FDD-2264-459F-A110-2F15B11B9F90',
      frame: { width: 750, height: 308, x: 0, y: 176 },
      layers: [
        {
          name: 'Bitmap',
          Id: 145,
          nameId: 'CE361883-ABCD-407F-B866-02058F46FBF4',
          frame: { width: 750, height: 308, x: 0, y: 176 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1vUlwqXmWBuNjSspdXXbugXXa-750-308.png'
        },
        {
          name: 'Group 5',
          Id: 147,
          nameId: '607B006E-2140-45EF-88C9-35642E5B2606',
          frame: { width: 459, height: 249, x: 18, y: 224 },
          layers: [
            {
              name: 'Group 2',
              Id: 149,
              nameId: '1A940A20-9A84-47CC-95DE-385BE7BD2CC7',
              frame: { width: 288, height: 50, x: 30, y: 224 },
              layers: [
                {
                  name: '最终质检报价',
                  Id: 150,
                  nameId: 'F4A0F6B1-A8AB-4DFB-B244-DE0A1C4AF660',
                  frame: { width: 288, height: 50, x: 30, y: 224 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '36',
                    color: '#FFFFFF',
                    lineHeight: '50',
                    maxWidth: 288,
                    maxHeight: 50,
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '最终质检报价',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '1A940A20-9A84-47CC-95DE-385BE7BD2CC7'
            },
            {
              name: 'Group 3',
              Id: 152,
              nameId: '88BEF710-49C2-48E9-9A76-73BA6BECFEE5',
              frame: { width: 459, height: 170, x: 18, y: 303 },
              layers: [
                {
                  name: 'Group 2',
                  Id: 154,
                  nameId: '643B027B-C247-44C4-BAC6-4ED9A66041C9',
                  frame: { width: 261, height: 169, x: 18, y: 303.272727272727 },
                  layers: [
                    {
                      name: '￥',
                      Id: 155,
                      nameId: '30F923DF-09D1-4654-9405-1024109F4D80',
                      frame: { width: 64, height: 90, x: 18, y: 341.3254281949931 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '64',
                        color: '#FFFFFF',
                        textAlign: 'right',
                        lineHeight: '90',
                        maxWidth: 64,
                        maxHeight: 90,
                        fontWeight: 'bold'
                      },
                      value: '￥',
                      type: 'text'
                    },
                    {
                      name: '78',
                      Id: 156,
                      nameId: '672F86F5-9747-4C2A-A998-80CFB7957151',
                      frame: { width: 139, height: 168, x: 84, y: 303.3122529644266 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '120',
                        color: '#FFFFFF',
                        lineHeight: '168',
                        textAlign: 'left',
                        fontWeight: 'bold'
                      },
                      value: '78',
                      type: 'text'
                    },
                    {
                      name: '.5',
                      Id: 157,
                      nameId: 'F313D0D2-980B-4952-A3E7-9AAD4D7AE524',
                      frame: { width: 56, height: 168, x: 222.1199999999999, y: 303.3122529644266 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Medium',
                        fontSize: '64',
                        color: '#FFFFFF',
                        lineHeight: '168',
                        textAlign: 'left',
                        fontWeight: 'bold'
                      },
                      value: '.5',
                      type: 'text'
                    }
                  ],
                  type: 'group',
                  objectID: '643B027B-C247-44C4-BAC6-4ED9A66041C9'
                },
                {
                  name: '比预估价高￥24',
                  Id: 158,
                  nameId: 'D95EF2EC-1306-461D-9AFA-9FC43AE23624',
                  frame: { width: 173, height: 33, x: 304, y: 364 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Regular',
                    fontSize: '24',
                    color: '#FFFFFF',
                    lineHeight: '33',
                    textAlign: 'left',
                    fontWeight: 'normal'
                  },
                  value: '比预估价高￥24',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '88BEF710-49C2-48E9-9A76-73BA6BECFEE5'
            }
          ],
          type: 'group',
          objectID: '607B006E-2140-45EF-88C9-35642E5B2606'
        }
      ],
      type: 'group',
      objectID: '6BD75FDD-2264-459F-A110-2F15B11B9F90'
    },
    {
      name: 'Group 4',
      Id: 160,
      nameId: '093451CC-09E9-4622-B084-06D034A7E204',
      frame: { width: 750, height: 1208, x: 0, y: 484 },
      layers: [
        {
          name: '评估情况',
          Id: 162,
          nameId: 'A0A03F6C-F842-4A93-8412-5382212EAE86',
          frame: { width: 750, height: 88, x: 0, y: 484 },
          layers: [
            {
              name: 'card title',
              Id: 164,
              nameId: '7116419D-9565-49AC-B69A-DA0365BF44CA',
              frame: { width: 750, height: 88, x: 0, y: 484 },
              layers: [
                {
                  name: 'Rectangle Copy 3',
                  Id: 165,
                  nameId: '0EA5FE84-0B54-45D7-886F-5C3CDF2814F7',
                  frame: { width: 750, height: 88, x: 0, y: 484 },
                  styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
                  type: 'shape'
                },
                {
                  name: '检测无问题的图书(6本)',
                  Id: 166,
                  nameId: 'C7E44D6E-ACC1-49B0-B1E4-83AE66A0D8ED',
                  frame: { width: 329, height: 45, x: 30, y: 512 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: '32',
                    color: '#222222',
                    lineHeight: '45',
                    textAlign: 'left',
                    fontWeight: 'bold'
                  },
                  value: '检测无问题的图书(6本)',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '7116419D-9565-49AC-B69A-DA0365BF44CA'
            }
          ],
          type: 'group',
          objectID: 'A0A03F6C-F842-4A93-8412-5382212EAE86'
        },
        {
          name: 'Group 19',
          Id: 168,
          nameId: 'D5FF8B22-9CED-4953-8C0B-918D8880FDE8',
          frame: { width: 750, height: 224, x: 0, y: 572 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 169,
              nameId: '5FA3E2D0-5625-400C-89BA-7D772E766BD4',
              frame: { width: 750, height: 224, x: 0, y: 572 },
              styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
              type: 'shape'
            },
            {
              name: 'Bitmap',
              Id: 170,
              nameId: '66F59508-A3D3-4C82-B1AA-A35415EB8BF3',
              frame: { width: 518, height: 224, x: 232, y: 572 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB14Q9Xqf5TBuNjSspcXXbnGFXa-518-224.png'
            },
            {
              name: 'Group 10',
              Id: 172,
              nameId: 'A23DFB66-3645-4EDE-9209-8B5B8ACE37DE',
              frame: { width: 392, height: 165, x: 232, y: 600 },
              layers: [
                {
                  name: '宝宝的量子物理学',
                  Id: 173,
                  nameId: '96195726-CB2E-4D70-91EE-9EDF89B21863',
                  frame: { width: 256, height: 45, x: 232, y: 600 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: '32',
                    color: '#000000',
                    textAlign: 'left',
                    lineHeight: '45',
                    fontWeight: 'bold'
                  },
                  value: '宝宝的量子物理学',
                  type: 'text'
                },
                {
                  name: 'Group 8',
                  Id: 175,
                  nameId: '4E4BE4AE-807F-4709-8F34-7F945866BA01',
                  frame: { width: 392, height: 117, x: 232, y: 648 },
                  layers: [
                    {
                      name: '东野圭吾 | 江苏教育出版社',
                      Id: 176,
                      nameId: '9502EC07-B5AC-49A3-BABA-135C99D0EECC',
                      frame: { width: 333, height: 40, x: 232, y: 648 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '28',
                        color: '#888888',
                        lineHeight: '40',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '东野圭吾 | 江苏教育出版社',
                      type: 'text'
                    },
                    {
                      name: 'Group 7',
                      Id: 178,
                      nameId: '15342A74-0596-41A6-9A1B-3E087E251D4C',
                      frame: { width: 392, height: 45, x: 232, y: 720 },
                      layers: [
                        {
                          name: '预估可卖￥17.4',
                          Id: 179,
                          nameId: '5F15723F-F136-451E-A8AA-B4972AE57012',
                          frame: { width: 172, height: 33, x: 452, y: 724 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: '24',
                            color: '#888888',
                            lineHeight: '33',
                            textAlign: 'left',
                            textDecoration: 'line-through',
                            fontWeight: 'normal'
                          },
                          value: '预估可卖￥17.4 ',
                          type: 'text'
                        },
                        {
                          name: 'Group 9',
                          Id: 181,
                          nameId: '9F54FB27-7955-4F63-BA0A-BF065CBE82D8',
                          frame: { width: 211, height: 45, x: 232, y: 720 },
                          layers: [
                            {
                              name: '￥22.5',
                              Id: 182,
                              nameId: '8F9FE926-56FC-45B1-B0A7-A5B1F5457499',
                              frame: { width: 99, height: 45, x: 344, y: 720 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '32',
                                color: '#FF4444',
                                lineHeight: '45',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '￥22.5',
                              type: 'text'
                            },
                            {
                              name: '实际可卖',
                              Id: 183,
                              nameId: '889E714C-50A4-41C9-B650-3535B0A79CAE',
                              frame: { width: 112, height: 40, x: 232, y: 720 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FF4444',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '实际可卖',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: '9F54FB27-7955-4F63-BA0A-BF065CBE82D8'
                        }
                      ],
                      type: 'group',
                      objectID: '15342A74-0596-41A6-9A1B-3E087E251D4C'
                    }
                  ],
                  type: 'group',
                  objectID: '4E4BE4AE-807F-4709-8F34-7F945866BA01'
                }
              ],
              type: 'group',
              objectID: 'A23DFB66-3645-4EDE-9209-8B5B8ACE37DE'
            },
            {
              name: 'Bitmap',
              Id: 184,
              nameId: 'E04D416C-3EFB-469E-AEFF-F646146CD667',
              frame: { width: 176, height: 176, x: 32, y: 596 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1mmXCqbSYBuNjSspiXXXNzpXa-176-176.png'
            }
          ],
          type: 'group',
          objectID: 'D5FF8B22-9CED-4953-8C0B-918D8880FDE8'
        },
        {
          name: 'Group 19 Copy',
          Id: 186,
          nameId: '6A68985B-2F71-4697-B5EE-CF2A71CF135A',
          frame: { width: 750, height: 224, x: 0, y: 796 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 187,
              nameId: '8C332CA3-9648-4375-86EF-ED583CB5F555',
              frame: { width: 750, height: 224, x: 0, y: 796 },
              styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
              type: 'shape'
            },
            {
              name: 'Bitmap',
              Id: 188,
              nameId: 'B14E8AC9-72A3-4E10-B733-F963CE0D4F77',
              frame: { width: 518, height: 224, x: 232, y: 796 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1f8aXqf5TBuNjSspcXXbnGFXa-518-224.png'
            },
            {
              name: 'Group 10',
              Id: 190,
              nameId: '81EAC364-BD32-48E3-B91A-FA734C753DFF',
              frame: { width: 392, height: 165, x: 232, y: 824 },
              layers: [
                {
                  name: '这么慢,那么美',
                  Id: 191,
                  nameId: '052FEFB2-A9D6-4489-B44C-9798C55049FE',
                  frame: { width: 201, height: 45, x: 232, y: 824 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: '32',
                    color: '#000000',
                    lineHeight: '45',
                    textAlign: 'left',
                    fontWeight: 'bold'
                  },
                  value: '这么慢,那么美',
                  type: 'text'
                },
                {
                  name: 'Group 8',
                  Id: 193,
                  nameId: 'B231CD86-6F3C-4AF2-B84B-563790B58FD7',
                  frame: { width: 392, height: 117, x: 232, y: 872 },
                  layers: [
                    {
                      name: '东野圭吾 | 江苏教育出版社',
                      Id: 194,
                      nameId: 'D826A2B5-9669-4586-9381-CB89AFB00CEB',
                      frame: { width: 333, height: 40, x: 232, y: 872 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '28',
                        color: '#888888',
                        lineHeight: '40',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '东野圭吾 | 江苏教育出版社',
                      type: 'text'
                    },
                    {
                      name: 'Group 7',
                      Id: 196,
                      nameId: 'D9D54E04-D74D-4995-9491-046165967789',
                      frame: { width: 392, height: 45, x: 232, y: 944 },
                      layers: [
                        {
                          name: '预估可卖￥17.4',
                          Id: 197,
                          nameId: '3E15136F-DA2B-4EFD-BC88-3796F54D97B6',
                          frame: { width: 172, height: 33, x: 452, y: 948 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: '24',
                            color: '#888888',
                            lineHeight: '33',
                            textAlign: 'left',
                            textDecoration: 'line-through',
                            fontWeight: 'normal'
                          },
                          value: '预估可卖￥17.4 ',
                          type: 'text'
                        },
                        {
                          name: 'Group 9',
                          Id: 199,
                          nameId: 'E7A461D2-126B-43F6-BA1A-6ACA7135A509',
                          frame: { width: 211, height: 45, x: 232, y: 944 },
                          layers: [
                            {
                              name: '￥20.5',
                              Id: 200,
                              nameId: '2E53ADEA-DA22-48B4-82A3-4A1C3C152163',
                              frame: { width: 99, height: 45, x: 344, y: 944 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '32',
                                color: '#FF4444',
                                lineHeight: '45',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '￥20.5',
                              type: 'text'
                            },
                            {
                              name: '实际可卖',
                              Id: 201,
                              nameId: '8E865567-95E5-4320-904B-808F6CF5E930',
                              frame: { width: 112, height: 40, x: 232, y: 944 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FF4444',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '实际可卖',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: 'E7A461D2-126B-43F6-BA1A-6ACA7135A509'
                        }
                      ],
                      type: 'group',
                      objectID: 'D9D54E04-D74D-4995-9491-046165967789'
                    }
                  ],
                  type: 'group',
                  objectID: 'B231CD86-6F3C-4AF2-B84B-563790B58FD7'
                }
              ],
              type: 'group',
              objectID: '81EAC364-BD32-48E3-B91A-FA734C753DFF'
            },
            {
              name: 'Bitmap',
              Id: 202,
              nameId: '2956DFC7-AEB8-4CF2-89D1-2DEE1CAACBB2',
              frame: { width: 176, height: 176, x: 32, y: 820 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1VHmaqk9WBuNjSspeXXaz5VXa-176-176.png'
            }
          ],
          type: 'group',
          objectID: '6A68985B-2F71-4697-B5EE-CF2A71CF135A'
        },
        {
          name: 'Group 19 Copy 2',
          Id: 204,
          nameId: '62BEAD9A-7309-4204-BB2B-983FF70CE9EB',
          frame: { width: 750, height: 224, x: 0, y: 1020 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 205,
              nameId: 'D5AE1231-41B8-41D8-9587-9C6092D3DD71',
              frame: { width: 750, height: 224, x: 0, y: 1020 },
              styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
              type: 'shape'
            },
            {
              name: 'Bitmap',
              Id: 206,
              nameId: '52743A7E-53E4-45D9-BE4E-0E0B95B7C07C',
              frame: { width: 518, height: 224, x: 232, y: 1020 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB19UlwqXmWBuNjSspdXXbugXXa-518-224.png'
            },
            {
              name: 'Group 10',
              Id: 208,
              nameId: 'EC5FDC81-4E59-4A9F-A6D8-42437464AE3E',
              frame: { width: 498, height: 165, x: 232, y: 1048 },
              layers: [
                {
                  name: '所谓情商高,就是会说话:日常生活…',
                  Id: 209,
                  nameId: '2CFD3670-F877-4C85-887A-F79FF96A8EA9',
                  frame: { width: 498, height: 45, x: 232, y: 1048 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: '32',
                    color: '#000000',
                    lineHeight: '45',
                    textAlign: 'left',
                    fontWeight: 'bold'
                  },
                  value: '所谓情商高,就是会说话:日常生活…',
                  type: 'text'
                },
                {
                  name: 'Group 8',
                  Id: 211,
                  nameId: 'B0523D69-EECB-4DF5-95DD-74D28CAA54E2',
                  frame: { width: 392, height: 117, x: 232, y: 1096 },
                  layers: [
                    {
                      name: '东野圭吾 | 江苏教育出版社',
                      Id: 212,
                      nameId: '38A6DC42-FAF7-4E76-ABC8-EF3B7B27E337',
                      frame: { width: 333, height: 40, x: 232, y: 1096 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '28',
                        color: '#888888',
                        lineHeight: '40',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '东野圭吾 | 江苏教育出版社',
                      type: 'text'
                    },
                    {
                      name: 'Group 7',
                      Id: 214,
                      nameId: '7F5AE4B2-7F7C-4192-AB9E-299EC1334E51',
                      frame: { width: 392, height: 45, x: 232, y: 1168 },
                      layers: [
                        {
                          name: '预估可卖￥17.4',
                          Id: 215,
                          nameId: 'A4F349BF-570A-4AE9-9BA9-D15FD4EA0BB0',
                          frame: { width: 172, height: 33, x: 452, y: 1172 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: '24',
                            color: '#888888',
                            lineHeight: '33',
                            textAlign: 'left',
                            textDecoration: 'line-through',
                            fontWeight: 'normal'
                          },
                          value: '预估可卖￥17.4 ',
                          type: 'text'
                        },
                        {
                          name: 'Group 9',
                          Id: 217,
                          nameId: 'C907C691-D677-4670-8840-4A78FBDF7895',
                          frame: { width: 205, height: 45, x: 232, y: 1168 },
                          layers: [
                            {
                              name: '￥19.5',
                              Id: 218,
                              nameId: '20949CC2-E3B3-46B1-AAE1-43C8A7A56D72',
                              frame: { width: 93, height: 45, x: 344, y: 1168 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '32',
                                color: '#FF4444',
                                lineHeight: '45',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '￥19.5',
                              type: 'text'
                            },
                            {
                              name: '实际可卖',
                              Id: 219,
                              nameId: '5F6F8C47-D65D-4E29-997D-085315155C0D',
                              frame: { width: 112, height: 40, x: 232, y: 1168 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FF4444',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '实际可卖',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: 'C907C691-D677-4670-8840-4A78FBDF7895'
                        }
                      ],
                      type: 'group',
                      objectID: '7F5AE4B2-7F7C-4192-AB9E-299EC1334E51'
                    }
                  ],
                  type: 'group',
                  objectID: 'B0523D69-EECB-4DF5-95DD-74D28CAA54E2'
                }
              ],
              type: 'group',
              objectID: 'EC5FDC81-4E59-4A9F-A6D8-42437464AE3E'
            },
            {
              name: 'Bitmap',
              Id: 220,
              nameId: 'DBDB34E5-2CAC-40DB-A0C4-324AEA6527FB',
              frame: { width: 176, height: 176, x: 32, y: 1044 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1Mt4RqeuSBuNjSsplXXbe8pXa-176-176.png'
            }
          ],
          type: 'group',
          objectID: '62BEAD9A-7309-4204-BB2B-983FF70CE9EB'
        },
        {
          name: 'Group 19 Copy 3',
          Id: 222,
          nameId: '6C615124-2D0F-4C4E-9CC3-050F3606E38E',
          frame: { width: 750, height: 224, x: 0, y: 1244 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 223,
              nameId: '26689681-B947-4C48-8C61-B0DEF684F81D',
              frame: { width: 750, height: 224, x: 0, y: 1244 },
              styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
              type: 'shape'
            },
            {
              name: 'Bitmap',
              Id: 224,
              nameId: 'AA2F1298-2D0A-4B3D-91FD-8D57006102A8',
              frame: { width: 518, height: 224, x: 232, y: 1244 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1hYqaqk9WBuNjSspeXXaz5VXa-518-224.png'
            },
            {
              name: 'Group 10',
              Id: 226,
              nameId: 'B1764FB6-5E5F-40D6-B151-7E0AE960A3FC',
              frame: { width: 372, height: 165, x: 232, y: 1272 },
              layers: [
                {
                  name: '解忧杂货店',
                  Id: 227,
                  nameId: 'AF54A03C-0C05-40FC-BFA6-EA436447B030',
                  frame: { width: 160, height: 45, x: 232, y: 1272 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: '32',
                    color: '#000000',
                    lineHeight: '45',
                    textAlign: 'left',
                    fontWeight: 'bold'
                  },
                  value: '解忧杂货店',
                  type: 'text'
                },
                {
                  name: 'Group 8',
                  Id: 229,
                  nameId: '820212EF-97BB-4471-8DE9-2E54645E0BEA',
                  frame: { width: 372, height: 117, x: 232, y: 1320 },
                  layers: [
                    {
                      name: '东野圭吾 | 江苏教育出版社',
                      Id: 230,
                      nameId: '77B5C5BE-DF5A-42B2-B660-7EB202CB0F83',
                      frame: { width: 333, height: 40, x: 232, y: 1320 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '28',
                        color: '#888888',
                        lineHeight: '40',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '东野圭吾 | 江苏教育出版社',
                      type: 'text'
                    },
                    {
                      name: 'Group 7',
                      Id: 232,
                      nameId: 'E2F2E6EB-3C55-4807-9D65-EFCAB332103C',
                      frame: { width: 372, height: 45, x: 232, y: 1392 },
                      layers: [
                        {
                          name: '预估可卖￥17.4',
                          Id: 233,
                          nameId: '69ED5A9B-614D-4D02-BD50-6E82E8F44C6E',
                          frame: { width: 172, height: 33, x: 432, y: 1396 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: '24',
                            color: '#888888',
                            lineHeight: '33',
                            textAlign: 'left',
                            textDecoration: 'line-through',
                            fontWeight: 'normal'
                          },
                          value: '预估可卖￥17.4 ',
                          type: 'text'
                        },
                        {
                          name: 'Group 9',
                          Id: 235,
                          nameId: '8693029D-8AEF-4244-B8C7-99AE3622070F',
                          frame: { width: 183, height: 45, x: 232, y: 1392 },
                          layers: [
                            {
                              name: '￥20',
                              Id: 236,
                              nameId: '32E91D68-A86F-47A8-A1C7-8D8C3B7D13D9',
                              frame: { width: 71, height: 45, x: 344, y: 1392 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '32',
                                color: '#FF4444',
                                lineHeight: '45',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '￥20',
                              type: 'text'
                            },
                            {
                              name: '实际可卖',
                              Id: 237,
                              nameId: '561B04EF-94D9-4E39-B854-084AAF5E2792',
                              frame: { width: 112, height: 40, x: 232, y: 1392 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FF4444',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '实际可卖',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: '8693029D-8AEF-4244-B8C7-99AE3622070F'
                        }
                      ],
                      type: 'group',
                      objectID: 'E2F2E6EB-3C55-4807-9D65-EFCAB332103C'
                    }
                  ],
                  type: 'group',
                  objectID: '820212EF-97BB-4471-8DE9-2E54645E0BEA'
                }
              ],
              type: 'group',
              objectID: 'B1764FB6-5E5F-40D6-B151-7E0AE960A3FC'
            },
            {
              name: 'Bitmap',
              Id: 238,
              nameId: '7AEBC633-79F2-4B6B-BD92-3C535675DBF4',
              frame: { width: 176, height: 176, x: 32, y: 1268 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB18.F7qXuWBuNjSszbXXcS7FXa-176-176.png'
            }
          ],
          type: 'group',
          objectID: '6C615124-2D0F-4C4E-9CC3-050F3606E38E'
        },
        {
          name: 'Group 19 Copy 4',
          Id: 240,
          nameId: 'C5455CFC-955A-404F-B1D9-C545A25B5BE4',
          frame: { width: 750, height: 224, x: 0, y: 1468 },
          layers: [
            {
              name: 'Rectangle 2',
              Id: 241,
              nameId: 'CDE26EDE-D532-4ACA-AFD4-F2B91278B60F',
              frame: { width: 750, height: 224, x: 0, y: 1468 },
              styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
              type: 'shape'
            },
            {
              name: 'Group 10',
              Id: 243,
              nameId: '72CEF699-3337-4814-A6A8-807AD1309F91',
              frame: { width: 392, height: 165, x: 232, y: 1496 },
              layers: [
                {
                  name: '解忧杂货店',
                  Id: 244,
                  nameId: 'C05E287A-4A93-4A87-A1D7-5407DB58F991',
                  frame: { width: 160, height: 45, x: 232, y: 1496 },
                  textStyles: {
                    fontFamily: 'PingFangSC-Medium',
                    fontSize: '32',
                    color: '#000000',
                    lineHeight: '45',
                    textAlign: 'left',
                    fontWeight: 'bold'
                  },
                  value: '解忧杂货店',
                  type: 'text'
                },
                {
                  name: 'Group 8',
                  Id: 246,
                  nameId: 'CB1CAA98-A4C7-4B5D-AA9C-15D460594F65',
                  frame: { width: 392, height: 117, x: 232, y: 1544 },
                  layers: [
                    {
                      name: '东野圭吾 | 江苏教育出版社',
                      Id: 247,
                      nameId: '16ACFAFB-F7DA-4BD3-9042-2BB0B0C7624F',
                      frame: { width: 333, height: 40, x: 232, y: 1544 },
                      textStyles: {
                        fontFamily: 'PingFangSC-Regular',
                        fontSize: '28',
                        color: '#888888',
                        lineHeight: '40',
                        textAlign: 'left',
                        fontWeight: 'normal'
                      },
                      value: '东野圭吾 | 江苏教育出版社',
                      type: 'text'
                    },
                    {
                      name: 'Group 7',
                      Id: 249,
                      nameId: '1174BB7C-407B-4C37-A8F5-D19B445CA506',
                      frame: { width: 392, height: 45, x: 232, y: 1616 },
                      layers: [
                        {
                          name: '预估可卖￥17.4',
                          Id: 250,
                          nameId: '51E94532-B6D4-4904-98CB-81D52F6A984A',
                          frame: { width: 172, height: 33, x: 452, y: 1620 },
                          textStyles: {
                            fontFamily: 'PingFangSC-Regular',
                            fontSize: '24',
                            color: '#888888',
                            lineHeight: '33',
                            textAlign: 'left',
                            textDecoration: 'line-through',
                            fontWeight: 'normal'
                          },
                          value: '预估可卖￥17.4 ',
                          type: 'text'
                        },
                        {
                          name: 'Group 9',
                          Id: 252,
                          nameId: 'A7DC495C-3B4E-4417-9E8E-9CB46528EAB7',
                          frame: { width: 211, height: 45, x: 232, y: 1616 },
                          layers: [
                            {
                              name: '￥28.5',
                              Id: 253,
                              nameId: '45FA0802-5B21-4A01-AD69-0757B52990A4',
                              frame: { width: 99, height: 45, x: 344, y: 1616 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Medium',
                                fontSize: '32',
                                color: '#FF4444',
                                lineHeight: '45',
                                textAlign: 'left',
                                fontWeight: 'bold'
                              },
                              value: '￥28.5',
                              type: 'text'
                            },
                            {
                              name: '实际可卖',
                              Id: 254,
                              nameId: '826E6CAA-CFC4-4501-B8CE-0E79839FF3F2',
                              frame: { width: 112, height: 40, x: 232, y: 1616 },
                              textStyles: {
                                fontFamily: 'PingFangSC-Regular',
                                fontSize: '28',
                                color: '#FF4444',
                                lineHeight: '40',
                                textAlign: 'left',
                                fontWeight: 'normal'
                              },
                              value: '实际可卖',
                              type: 'text'
                            }
                          ],
                          type: 'group',
                          objectID: 'A7DC495C-3B4E-4417-9E8E-9CB46528EAB7'
                        }
                      ],
                      type: 'group',
                      objectID: '1174BB7C-407B-4C37-A8F5-D19B445CA506'
                    }
                  ],
                  type: 'group',
                  objectID: 'CB1CAA98-A4C7-4B5D-AA9C-15D460594F65'
                }
              ],
              type: 'group',
              objectID: '72CEF699-3337-4814-A6A8-807AD1309F91'
            },
            {
              name: 'Bitmap',
              Id: 255,
              nameId: '199276D3-71DE-450F-A743-F5A06671D37D',
              frame: { width: 176, height: 172, x: 32, y: 1492 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1L.pwqXmWBuNjSspdXXbugXXa-176-172.png'
            }
          ],
          type: 'group',
          objectID: 'C5455CFC-955A-404F-B1D9-C545A25B5BE4'
        }
      ],
      type: 'group',
      objectID: '093451CC-09E9-4622-B084-06D034A7E204'
    },
    {
      name: 'Statusbar',
      Id: 257,
      nameId: '3AED1138-A20E-42CC-815E-A5E36A4DCCF3',
      frame: { width: 750, height: 88, x: 0, y: 0 },
      layers: [
        {
          name: 'Rectangle 2 Copy 3',
          Id: 258,
          nameId: '2818F4A7-06B1-4D11-8A59-863B5B146ECC',
          frame: { width: 750, height: 88, x: 0, y: 0 },
          styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color' },
          type: 'shape'
        },
        {
          name: 'Light Status Bar',
          Id: 260,
          nameId: '006C0986-CC4F-48C1-84BB-25A01DEEB3F2',
          frame: { width: 679, height: 34, x: 42, y: 32 },
          layers: [
            {
              name: 'Bitmap',
              Id: 261,
              nameId: '650C2E88-D2E5-475A-AA61-782E65474296',
              frame: { width: 49, height: 24, x: 672, y: 34 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1m08RqeuSBuNjSsplXXbe8pXa-49-24.png'
            },
            {
              name: 'Bitmap',
              Id: 262,
              nameId: '6FB3FC3C-EDD1-4F3C-9E83-E555E22F6AAB',
              frame: { width: 31, height: 23, x: 631, y: 34 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1_kGLqbSYBuNjSspfXXcZCpXa-31-23.png'
            },
            {
              name: 'Bitmap',
              Id: 263,
              nameId: '22C6DB45-097A-40F6-8300-F89BADD40E46',
              frame: { width: 35, height: 22, x: 587, y: 35 },
              imageStyles: { resize: 'stretch' },
              type: 'image',
              value: 'https://gw.alicdn.com/tfs/TB1_rpFqkKWBuNjy1zjXXcOypXa-35-22.png'
            },
            {
              name: 'Time Style',
              Id: 265,
              nameId: '8C4D4900-5E46-428D-B16B-D0CBA66C4C97',
              frame: { width: 108, height: 34, x: 42, y: 32 },
              layers: [
                {
                  name: '↳ Time',
                  Id: 266,
                  nameId: '090C25C8-3759-4418-8F03-297A8C2EAB9C',
                  frame: { width: 108, height: 34, x: 42, y: 32 },
                  textStyles: {
                    fontFamily: '.SFNSDisplay',
                    fontSize: '28',
                    color: '#000000',
                    textAlign: 'center',
                    lineHeight: '33',
                    maxWidth: 108,
                    maxHeight: 34,
                    fontWeight: 'normal'
                  },
                  value: '9:41',
                  type: 'text'
                }
              ],
              type: 'group',
              objectID: '8C4D4900-5E46-428D-B16B-D0CBA66C4C97'
            }
          ],
          type: 'group',
          objectID: '006C0986-CC4F-48C1-84BB-25A01DEEB3F2'
        }
      ],
      type: 'group',
      objectID: '3AED1138-A20E-42CC-815E-A5E36A4DCCF3'
    }
  ],
  nameId: 1525686545899,
  Id: 134,
  type: 'group',
  frame: { x: 0, y: 0, width: 750, height: 1664 },
  styles: { backgroundColor: 'rgba(243,245,249,1)' }
}
