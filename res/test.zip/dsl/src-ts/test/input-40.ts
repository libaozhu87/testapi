export default {
  layers: [
    {
      styles: {
        opacity: 1,
        borderColor: 'rgba(243,245,249,1)',
        borderRadius: 0,
        borderWidth: 1,
        backgroundColor: 'rgba(243,245,249,1)',
        borderStyle: 'solid'
      },
      frame: { y: 0, x: 0, height: 16, width: 750 },
      type: 'shape',
      id: 1
    },
    {
      textStyles: { color: '#222222', lineHeight: 32, fontSize: 32 },
      frame: { y: 46, x: 33, height: 32, width: 399 },
      type: 'text',
      id: 2,
      value: '快速建鱼塘 每月 多赚1000元'
    },
    {
      styles: {
        opacity: 1,
        borderColor: 'rgba(255,230,95,1)',
        borderRadius: 3,
        borderWidth: 1,
        backgroundColor: 'rgba(255,227,81,1)',
        borderStyle: 'solid'
      },
      frame: { y: 45, x: 442, height: 32, width: 56 },
      type: 'shape',
      id: 3
    },
    {
      textStyles: { color: '#222222', lineHeight: 20, fontSize: 20 },
      frame: { y: 51, x: 450, height: 20, width: 41 },
      type: 'text',
      value: '免费'
    },
    {
      frame: { y: 104, x: 32, height: 160, width: 296 },
      type: 'image',
      id: 5,
      value: 'http://47.100.92.83:8081/ui/32_104_296_160_image.png'
    },
    {
      frame: { y: 104, x: 344, height: 160, width: 296 },
      type: 'image',
      id: 6,
      value: 'http://47.100.92.83:8081/ui/344_104_296_160_image.png'
    },
    {
      frame: { y: 104, x: 656, height: 160, width: 94 },
      type: 'image',
      id: 7,
      value: 'http://47.100.92.83:8081/ui/656_104_94_160_image.png'
    },
    {
      styles: { opacity: 1, borderStyle: 'solid', backgroundColor: 'rgba(235,235,235,1)' },
      frame: { y: 295, x: 32, height: 1, width: 718 },
      type: 'shape',
      id: 8
    },
    {
      textStyles: { color: '#888888', lineHeight: 27, fontSize: 27 },
      frame: { y: 327, x: 276, height: 27, width: 166 },
      type: 'text',
      id: 9,
      value: '免费创建鱼塘'
    },
    {
      textStyles: { color: '#dbdbdb', lineHeight: 39, fontSize: 39 },
      frame: { y: 321, x: 453, height: 39, width: 15 },
      type: 'text',
      id: 10,
      value: '>'
    },
    {
      styles: {
        opacity: 1,
        borderColor: 'rgba(243,245,249,1)',
        borderRadius: 0,
        borderWidth: 1,
        backgroundColor: 'rgba(243,245,249,1)',
        borderStyle: 'solid'
      },
      frame: { y: 384, x: 0, height: 13, width: 750 },
      type: 'shape',
      id: 11
    }
  ],
  frame: { y: 0, x: 0, height: 397, width: 750 },
  type: 'group',
  id: 0
}
