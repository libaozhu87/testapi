export default {
  name: 'input',
  layers: [
    {
      name: 'Rectangle',
      Id: 3,
      nameId: '7F42113C-CDFF-48E4-BF59-A4EB2AC526CF',
      frame: { width: 374, height: 378, x: 0, y: 0 },
      layers: [
        {
          name: 'Rectangle',
          Id: 4,
          nameId: '331C170C-4F4C-490F-91A4-3E6A86C77861',
          frame: { width: 374, height: 378, x: 0, y: 0 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1wnlXkFmWBuNjSspdXXbugXXa-374-378.png'
        },
        {
          name: 'Rectangle 54 Copy',
          Id: 5,
          nameId: 'C57A521C-B163-4E7C-8389-1B208119C386',
          frame: { width: 334, height: 332, x: 20, y: 20 },
          imageStyles: { resize: 'stretch' },
          type: 'image',
          value: 'https://gw.alicdn.com/tfs/TB1JlrCkTJYBeNjy1zeXXahzVXa-334-332.png'
        }
      ],
      type: 'group',
      objectID: '7F42113C-CDFF-48E4-BF59-A4EB2AC526CF'
    },
    {
      name: 'Rectangle 54',
      Id: 7,
      nameId: 'B8CC027C-7C73-4A72-BEF5-35AAED8BFACE',
      frame: { width: 374, height: 128, x: 0, y: 372 },
      layers: [
        {
          name: 'Rectangle 54',
          Id: 8,
          nameId: 'FF6BA02A-2D1C-481A-BA4D-9882D22F4732',
          frame: { width: 374, height: 128, x: 0, y: 372 },
          styles: { backgroundColor: 'rgba(255,255,255,1)', fillType: 'color', opacity: 1 },
          type: 'shape'
        },
        {
          name: '王小二新疆红心石榴石榴',
          Id: 9,
          nameId: '96A9FB08-F687-403F-8098-5F6A88851214',
          frame: { width: 308, height: 40, x: 30, y: 391 },
          textStyles: {
            fontFamily: 'PingFangSC-Regular',
            fontSize: '28',
            color: '#222222',
            letterSpacing: '0',
            lineHeight: '40',
            textAlign: 'left',
            fontWeight: 'normal'
          },
          value: '王小二新疆红心石榴石榴',
          type: 'text'
        },
        {
          name: 'Group',
          Id: 11,
          nameId: '2F208998-776F-43F8-B291-753D18132B09',
          frame: { width: 194, height: 38, x: 30, y: 442 },
          layers: [
            {
              name: '¥',
              Id: 12,
              nameId: 'C243DB11-8F5A-4C83-84E1-1EA1AE236D59',
              frame: { width: 15, height: 28, x: 30, y: 448 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#FF4444',
                textAlign: 'left',
                lineHeight: '28',
                fontWeight: 'normal'
              },
              value: '¥',
              type: 'text'
            },
            {
              name: '6000',
              Id: 13,
              nameId: '21815970-3667-48BA-9D97-5B31839533E3',
              frame: { width: 77, height: 36, x: 46, y: 442 },
              textStyles: {
                fontFamily: 'PingFangSC-Medium',
                fontSize: '32',
                color: '#FF4444',
                lineHeight: '36',
                textAlign: 'left',
                fontWeight: 'bold'
              },
              value: '6000',
              type: 'text'
            },
            {
              name: '￥13800',
              Id: 14,
              nameId: '5FBF614D-AAB6-4107-929C-09FC23AF85B8',
              frame: { width: 92, height: 36, x: 132, y: 444 },
              textStyles: {
                fontFamily: 'PingFangSC-Regular',
                fontSize: '24',
                color: '#888888',
                lineHeight: '36',
                textAlign: 'left',
                textDecoration: 'line-through',
                fontWeight: 'normal'
              },
              value: '￥13800',
              type: 'text'
            }
          ],
          type: 'group',
          objectID: '2F208998-776F-43F8-B291-753D18132B09'
        }
      ],
      type: 'group',
      objectID: 'B8CC027C-7C73-4A72-BEF5-35AAED8BFACE'
    }
  ],
  nameId: 1523339523718,
  Id: 1,
  type: 'group',
  frame: { x: 0, y: 0, width: 374, height: 500 }
}
