import { Node, NodeType, Image, Group, Text } from './../define/node'
import { IHtml, htmlStringify, styleStringify } from './json2html'
import isEmpty from './../primitive/isEmpty'
import { matcher, Matcher } from './../primitive/Matcher'
import reduce from './../primitive/reduce'
import compact from './../primitive/compact'
import { TOP_INDEX, RIGHT_INDEX, BOTTOM_INDEX, LEFT_INDEX } from './../core/layout-util'
import { generate } from './class-name'
import { PositionType, FlexDirection } from './../define/flex-type'

const INDEX_MAP = {
  [TOP_INDEX]: 'top',
  [RIGHT_INDEX]: 'right',
  [BOTTOM_INDEX]: 'bottom',
  [LEFT_INDEX]: 'left'
}

const TAG_MATCHER: Matcher = matcher()
  .case(NodeType.TEXT, NodeType.TEXT)
  .case(NodeType.IMAGE, NodeType.IMAGE)
  .case(NodeType.SHAPE)
  .case(NodeType.GROUP, 'div')
  .default(() => {
    throw new Error(``)
  })

function attrs(input: Node) {
  const { type } = input
  if (type === NodeType.IMAGE) {
    return { src: (input as Image).value }
  }
}

function camelCase2kebabCase(value: string): string {
  if (!isEmpty(value)) {
    const name = String(value)
    if (name.toUpperCase() === name) {
      return name.toLowerCase().replace('_', '-')
    } else {
      const arr: string[] = []
      for (let i = 0; i < name.length; i++) {
        const char = name.charAt(i)
        if (char.toUpperCase() === char) {
          arr.push('-')
        }
        arr.push(char.toLowerCase())
      }
      return arr.join('')
    }
  }
  return value
}

function paddingOrMargin(k: string, arr: any): string {
  if (arr) {
    return compact(
      arr.reduce((pre, value, index) => {
        const indexStr = INDEX_MAP[index]
        if (value !== undefined) {
          pre[k + '-' + indexStr] = value + 'px'
        }
        return pre
      }, {})
    )
  }
}

function styles(input) {
  const map = { ...input.layout, ...input.styles, ...input.textStyles, ...input.imageStyles }

  const result = reduce(
    map,
    (pre, v, k) => {
      const kk = camelCase2kebabCase(k)
      pre[kk] = v
      return pre
    },
    {}
  )

  result.width = map.width === undefined ? undefined : result.width + 'px'
  result.height = map.height === undefined ? undefined : result.height + 'px'

  result.src = map.src
  result['font-family'] = map.fontFamily
  result['background-color'] = map.backgroundColor

  result.padding = undefined
  ;(Object as any).assign(result, paddingOrMargin('padding', map.padding))
  result.margin = undefined
  ;(Object as any).assign(result, paddingOrMargin('margin', map.margin))

  result['line-height'] = map.lineHeight !== undefined ? parseInt(map.lineHeight, 10) + 'px' : undefined

  return compact(result)
}

function buildHtmlNode(input: Node, parent: Group, pageName: string): IHtml {
  let subfix: string
  if (parent !== undefined) {
    const brothers = parent.children.filter(child => child.layout.position !== PositionType.ABSOLUTE)
    if (brothers.length === 2) {
      const index = brothers.indexOf(input)
      if (index === 0) {
        subfix = parent.layout.flexDirection === FlexDirection.ROW ? 'left' : 'up'
      } else if (index === brothers.length - 1) {
        subfix = parent.layout.flexDirection === FlexDirection.ROW ? 'right' : 'down'
      }
    }
  }

  const { type } = input
  const css = styles(input)
  const result = {
    id: '',
    clazz: {
      name: generate(input, parent, css, pageName, subfix),
      styles: css
    },
    tag: TAG_MATCHER.invoke(type),
    attrs: attrs(input),
    value: type === NodeType.TEXT ? (input as Text).value : undefined,
    children: undefined
  }

  input.clazz = result.clazz

  return result
}

function buildHtmlNodeTree(input: Node, parent: Group, pageName: string): IHtml {
  const node = buildHtmlNode(input, parent, pageName)

  if (input.type === NodeType.GROUP) {
    const group = input as Group
    node.children = group.children.map(layer => buildHtmlNodeTree(layer, group, pageName))
  }

  return node
}

export function weex(node: Node, pageName: string): string {
  const html = buildHtmlNodeTree(node, undefined, camelCase2kebabCase(pageName))
  const lines = [
    `<template>`,
    `\t<scroller style="width: 750px;">`,
    htmlStringify(html, false, 2),
    `\t</scroller>`,
    `</template>`,
    `\n`,
    `<style scoped>`,
    styleStringify(html),
    `</style>`,
    `\n`,
    `<script>`,
    `</script>`
  ]
  return lines.join('\n')
}

export function weexTemplate(node: Node, pageName: string): string {
  const html = buildHtmlNodeTree(node, undefined, camelCase2kebabCase(pageName))
  return htmlStringify(html, true, 2)
}

export function localHtml(node: Node, pageName: string): string {
  const html = buildHtmlNodeTree(node, undefined, camelCase2kebabCase(pageName))
  const xml = '`' + htmlStringify(html, true, 2) + '`'
  return `
<html>
<head>
  <script src="https://cdn.jsdelivr.net/npm/vue"></script>
</head>
<body>
  <div id="app">
  </div>
  <script>
    let Profile = Vue.extend({
      template: ${xml}
    })
    new Profile().$mount('#app')
  </script>
</body>
</html>
`
}
