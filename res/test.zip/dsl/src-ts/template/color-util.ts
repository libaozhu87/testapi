import top from './../primitive/top'

const COMMON_COLORS: Array<[string, number]> = [
  ['black', 0x000000ff],
  ['blue', 0x0000ffff],
  ['cyan', 0x00ffffff],
  ['ltgray', 0xd3d3d3ff],
  ['gray', 0x808080ff],
  ['dkgray', 0xa9a9a9ff],
  ['green', 0x00ff00ff],
  ['magenta', 0xff00ffff],
  ['red', 0xff0000ff],
  ['white', 0xffffffff],
  ['yellow', 0xffff00ff]
]

function distance(v1: number, v2: number) {
  const r1 = (v1 & 0xff000000) >> 24
  const g1 = (v1 & 0x00ff0000) >> 16
  const b1 = (v1 & 0x0000ff00) >> 8
  const a1 = (v1 & 0x000000ff) >> 0

  const r2 = (v2 & 0xff000000) >> 24
  const g2 = (v2 & 0x00ff0000) >> 16
  const b2 = (v2 & 0x0000ff00) >> 8
  const a2 = (v1 & 0x000000ff) >> 0
  return Math.sqrt((r1 - r2) * (r1 - r2) + (g1 - g2) * (g1 - g2) + (b1 - b2) * (b1 - b2) + (a1 - a2) * (a1 - a2))
}

//rgba
export function color2int(color: string): number {
  const colorStr = color && color.trim()
  if (colorStr !== undefined) {
    if (colorStr[0] === '#') {
      const valueStr = colorStr.slice(1)
      if (valueStr.length === 8) {
        return parseInt(valueStr, 16)
      } else if (valueStr.length === 6) {
        return parseInt(valueStr + 'FF', 16)
      } else {
        throw new Error(`${color} is not a valid color.`)
      }
    } else if (colorStr[0] === 'r') {
      //rgba, rgb
      const index0 = colorStr.indexOf('(')
      const index1 = colorStr.indexOf(')')
      if (index0 >= 0 && index1 >= 0 && index0 < index1) {
        const values = colorStr.slice(index0 + 1, index1).split(',')
        if (values.length >= 3 && values.length <= 4) {
          //rgba
          if (values.length === 3) {
            values.push('255')
          }
          return values.map(v => parseInt(v, 10)).reduce((pre, cur) => pre * 256 + cur, 0)
        }
      }
    }

    throw new Error(`${color} is not a valid color.`)
  }
  return undefined
}

export function red(color: number): number {
  if (red !== undefined) {
    return (color & 0xff000000) >> 24
  }
}

export function green(color: number): number {
  if (red !== undefined) {
    return (color & 0x00ff0000) >> 16
  }
}

export function blue(color: number): number {
  if (red !== undefined) {
    return (color & 0x0000ff00) >> 8
  }
}

export function alpha(color: number): number {
  if (red !== undefined) {
    return (color & 0x000000ff) >> 0
  }
}

export function colorName(input: string): string {
  const value = color2int(input)
  if (value !== undefined) {
    const result = top(COMMON_COLORS, (pre, cur) => distance(pre[1], value) - distance(cur[1], value))
    return result[0]
  }
}
