import isEmpty from './../primitive/isEmpty'
import range from './../primitive/range'
import reduce from './../primitive/reduce'
import compact from './../primitive/compact'
import flatten from './../primitive/flatten'
import { classStringify, IClass } from './json2class'

export interface IHtml {
  id: string //唯一
  clazz: IClass
  attrs: object
  tag: string
  value: string
  children: IHtml[]
}

export function htmlStringify(html: IHtml, useStyle: boolean, tabs = 0): string {
  const { value, clazz, attrs, tag, children } = html

  const tabsStr = range(0, tabs + 1, 1)
    .map(() => '')
    .join('\t')

  let attrsStr =
    attrs &&
    compact(
      reduce(
        compact(attrs),
        (memo, v, k) => {
          return memo.concat(`${k}="${v}"`)
        },
        []
      )
    ).join(' ')
  attrsStr = attrsStr || ''

  let stylesStr =
    useStyle &&
    compact(
      reduce(
        compact(clazz.styles),
        (memo, v, k) => {
          return memo.concat(`${k}:${v}`)
        },
        []
      )
    ).join('; ')
  stylesStr = stylesStr ? `style="${stylesStr}"` : ''

  // const
  const classStr = !useStyle ? `class="${clazz.name}"` : ''

  const desc = compact([stylesStr, classStr, attrsStr]).join(' ')

  if (!isEmpty(children)) {
    const childrenStr = children.map(child => htmlStringify(child, useStyle, tabs + 1)).join('\n')
    return `${tabsStr}<${tag} ${desc}>` + '\n' + childrenStr + '\n' + `${tabsStr}</${tag}>`
  } else {
    return `${tabsStr}<${tag} ${desc}>${value ? value : ''}</${tag}>`
  }
}

function styleList(html: IHtml) {
  const list: IClass[] = [html.clazz]
  if (!isEmpty(html.children)) {
    return list.concat(flatten(html.children.map(styleList)))
  }
  return list
}

export function styleStringify(html: IHtml, tabs = 0): string {
  const list: IClass[] = styleList(html)
  return classStringify(list)
}
