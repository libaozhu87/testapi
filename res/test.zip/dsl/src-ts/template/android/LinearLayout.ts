// import { BaseLayout } from './BaseLayout'

// export class LinearLayout extends BaseLayout {
//   public orientation: string
//   public gravity: string

//   //paddingLeft
// }
