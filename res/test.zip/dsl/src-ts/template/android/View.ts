export class View {
  public layout
}
