export enum Orientation {
  HORIZONTAL = 'horizontal',
  VERTICAL = 'vertical'
}

export class SizeType {
  public static MATCH_PARENT = 'match_parent'
  public static WRAP_CONTENT = 'wrap_content'
  public static FIXED = 'fixed'
}

//top、bottom、left、right、center_vertical、fill_vertical、center_horizontal、fill_horizontal、center、fill、clip_vertical。
//layout_gravity, gravity
//space-between  -> relative
//absolute -> frame
//linear

export enum Gravity {
  LEFT = 'left',
  CENTER_HORIZONTAL = 'center_horizontal',
  RIGHT = 'right',
  FILL_HORIZONTAL = 'fill_horizontal',
  TOP = 'top',
  CENTER_VERTICAL = 'center_vertical',
  BOTTOM = 'bottom',
  FILL_VERTICAL = 'fill_vertical'
}

export enum Unit {
  DP = 'dp',
  PX = 'px'
}

export class View {
  //
  public layoutWidth: string
  public layoutHeight: string

  public id: string

  public gravity: string
  public layoutGravity: string
  //
  public paddingLeft: string
  public paddingRight: string
  public paddingTop: string
  public paddingBottom: string
  //
  public layoutMarginLeft: string
  public layoutMarginRight: string
  public layoutMarginTop: string
  public layoutMarginBottom: string
  //for in relativelayout
  public layoutAlignParentLeft: boolean
  public layoutAlignParentRight: boolean
  public layoutAlignParentTop: boolean
  public layoutAlignParentBottom: boolean
  public layoutAlignParentCenterHorizontal: boolean
  public layoutAlignParentCenterVertical: boolean
  public layoutAlignParentCenter: boolean
  //
  public background: string
  //4-3-3
  public layoutX: string
  public layoutY: string
}

export class Image extends View {
  public src: string
}

export class Text extends View {
  public text: string
  public lineHeight: string
  public textSize: string
  public textColor: string
  public textStyle: string //normal, bold, italic, bold|italic
  // public gravity: string //align
}

export class ViewGroup extends View {}

export class LinearLayout extends ViewGroup {}

export class RelativeLayout extends ViewGroup {}

export class FrameLayout extends ViewGroup {}
