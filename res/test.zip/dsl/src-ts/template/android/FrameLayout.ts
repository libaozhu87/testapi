export class FrameLayout {
  //
}
