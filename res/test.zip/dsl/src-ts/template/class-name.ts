import { Node, Shape, Text, Group } from './../define/node'
import compact from './../primitive/compact'
import { PositionType } from '../define/flex-type'
import { colorName } from './color-util'
import isEmpty from './../primitive/isEmpty'

function isMatchParentSize(node: Node): boolean {
  const { parent } = node
  if (parent !== undefined) {
    return (
      parent.measured.width === node.measured.width &&
      parent.measured.height === node.measured.height &&
      node.measured.x === 0 &&
      node.measured.y === 0
    )
  }
  return false
}

function generate_(node: Node, parent: Group, css: object, prefix: string, subfix: string) {
  const styles = (node as Shape).styles
  const textStyles = (node as Text).textStyles

  // const type = TAG_MATCHER.invoke(node.type)
  const dir = node.layout.flexDirection
  const justifyContent = node.layout.justifyContent

  let des
  if (node.layout.position === PositionType.ABSOLUTE) {
    des = 'absolute'
    const backgrounds = parent.children.filter(isMatchParentSize)
    if (backgrounds.indexOf(node) !== -1) {
      des = 'background'
    }
  }

  let fontSize
  if (textStyles && textStyles.fontSize !== undefined) {
    fontSize = 'size' + textStyles.fontSize
  }

  const shapeWidth = node.layout.width !== undefined ? 'w' + node.layout.width : undefined
  const shapeHeight = node.layout.height !== undefined ? 'h' + node.layout.height : undefined

  const color = colorName((textStyles && textStyles.color) || (styles && styles.backgroundColor) || (styles && styles.borderColor))

  const basic = compact([prefix, color, dir, justifyContent, fontSize, shapeWidth, shapeHeight, des, subfix]).join('-')
  const name = isEmpty(basic) ? node.id : basic + '-' + node.id

  return name
}

export function generate(node: Node, parent: Group, css: object, prefix: string, subfix: string) {
  if (!css) {
    return undefined
  }

  const name = generate_(node, parent, css, prefix, subfix)
  return name
}
