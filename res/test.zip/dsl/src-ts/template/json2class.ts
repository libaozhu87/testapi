import reduce from './../primitive/reduce'
import compact from './../primitive/compact'

export interface IClass {
  name: string //唯一
  styles: object
}

export function classStringify(clazzes: IClass[]): string {
  const names = {}

  return compact(
    clazzes.map(clazz => {
      const { name, styles } = clazz

      if (names[name]) {
        return undefined
      }

      names[name] = true

      const stylesStr =
        styles &&
        reduce(
          compact(styles),
          (pre, v, k) => {
            return pre.concat(`\t${k}: ${v};`)
          },
          []
        ).join('\n')
      return stylesStr ? `.${name} {` + '\n' + stylesStr + '\n' + `}` : `.${name} {}`
    })
  ).join('\n')
}
