import { Node, NodeType, Image, Group, Text } from './../define/node'
import { Property } from './../core/property'
import { matcher, Matcher } from './../primitive/Matcher'
import compact from './../primitive/compact'
import { TOP_INDEX, RIGHT_INDEX, BOTTOM_INDEX, LEFT_INDEX } from './../core/layout-util'

//Lona:View Lona:Text Lona:Image
// interface Lo
let id = 0
function generateId() {
  return ++id
}

interface LonaView {
  id: string
  name: string
  type: string
  params: object
  children: LonaView[]
}

const INDEX_MAP = {
  [TOP_INDEX]: 'Top',
  [RIGHT_INDEX]: 'Right',
  [BOTTOM_INDEX]: 'Bottom',
  [LEFT_INDEX]: 'Left'
}

const TAG_MATCHER: Matcher = matcher()
  .case(NodeType.TEXT, 'Lona:Text')
  .case(NodeType.IMAGE, 'Lona:Image')
  .case(NodeType.SHAPE)
  .case(NodeType.GROUP, 'Lona:View')
  .default(() => {
    throw new Error(``)
  })

function paddingOrMargin(k: string, arr: any): string {
  if (arr) {
    return compact(
      arr.reduce((pre, value, index) => {
        const indexStr = INDEX_MAP[index]
        if (value !== undefined) {
          pre[k + indexStr] = value
        }
        return pre
      }, {})
    )
  }
}

function styles(input) {
  const map = { ...input.layout, ...input.styles, ...input.textStyles, ...input.imageStyles }
  ;(Object as any).assign(map, paddingOrMargin('padding', map.padding))
  map.padding = undefined
  ;(Object as any).assign(map, paddingOrMargin('margin', map.margin))
  map.margin = undefined
  return compact(map)
}

function buildNode(input: Node, property: Property): LonaView {
  const result: LonaView = {
    id: '' + generateId(),
    name: TAG_MATCHER.invoke(input.type) + generateId(),
    type: TAG_MATCHER.invoke(input.type),
    params: styles(input),
    children: undefined
  }

  if (input.type === NodeType.IMAGE) {
    result.params = (Object as any).assign(result.params, { image: (input as Image).value })
  } else if (input.type === NodeType.TEXT) {
    result.params = (Object as any).assign(result.params, { text: (input as Text).value })
  }

  return result
}

function buildNodeTree(input: Node, property: Property): LonaView {
  const node = buildNode(input, property)
  if (input.type === NodeType.GROUP) {
    const group = input as Group
    node.children = group.children.map(layer => buildNodeTree(layer, property))
  }

  return node
}

export function lona(node: Node, property: Property): string {
  const lonaRoot = buildNodeTree(node, property)
  return JSON.stringify(lonaRoot)
}
