import { Property } from './property'
import { NodeType, Node, Group } from './../define/node'
import { NodeUtil } from './node-util'
import { SpecialLayout } from './../define/special'
import indexOf from './../primitive/indexOf'
import { isSimilarAsGrid } from './similar'
import { FlexDirection } from './../define/flex-type'
import { isMagicMargin, MIN_GRID_ITEMS } from './magic'
import { FrameUtil } from './frame-util'
import console from './../primitive/logger'

//网格
function measureGridLayout(node: Node, property: Property): boolean {
  const { type } = node
  const dir = node.layout.flexDirection

  if (type === NodeType.GROUP) {
    const group = node as Group
    if (dir === FlexDirection.ROW) {
      const linears = property.getLinearChildren(group)
      const margins = NodeUtil.getChildrenBetweens(group, linears, property)
      if (group.specialLayout === undefined && linears.length >= MIN_GRID_ITEMS && margins.every(margin => margin >= 0)) {
        const isSimailar = isSimilarAsGrid(linears, group)
        if (isSimailar) {
          group.specialLayout = SpecialLayout.GRID
          console.log('SpecialLayout.GRID', group.id, group.specialLayout === SpecialLayout.GRID)
        }
      }
    }

    group.children.forEach(child => measureGridLayout(child, property))
  }

  return false
}

//左右
function measureSpaceBetween(node: Node, property: Property) {
  const { type } = node
  if (type === NodeType.GROUP) {
    const group = node as Group
    const dir = group.layout.flexDirection

    if (dir === FlexDirection.ROW && group.specialLayout === undefined) {
      const linears = property.getLinearChildren(group)
      const bewteens = NodeUtil.getChildrenBetweens(group, linears, property)
      const centerIndex = indexOf(linears, child => FrameUtil.isCenter(child.measured, group.measured, dir))

      if (linears.length === 2 && bewteens.some(isMagicMargin) && centerIndex < 0) {
        //find max
        let isParentSpaceBetween
        let parent = group.parent
        while (parent !== undefined && parent.layout.flexDirection === FlexDirection.ROW) {
          if (parent.specialLayout === SpecialLayout.SPACE_BETWEEN) {
            isParentSpaceBetween = true
            break
          }
          parent = parent.parent
        }

        if (isParentSpaceBetween) {
          const linearsInParent = property.getLinearChildren(parent)
          const bewteensInParent = NodeUtil.getChildrenBetweens(parent, linearsInParent, property)

          if (bewteensInParent[0] < bewteens[0]) {
            parent.specialLayout = undefined
            group.specialLayout = SpecialLayout.SPACE_BETWEEN
          } else {
            parent.specialLayout = SpecialLayout.SPACE_BETWEEN
            group.specialLayout = undefined
          }
        } else {
          group.specialLayout = SpecialLayout.SPACE_BETWEEN
        }
      }
    }

    group.children.forEach(child => measureSpaceBetween(child, property))
  }
}

export function measureSpecialLayout(node: Node, property: Property): Node {
  measureSpaceBetween(node, property)
  measureGridLayout(node, property)
  return node
}
