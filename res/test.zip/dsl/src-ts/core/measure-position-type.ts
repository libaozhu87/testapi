import { Property } from './property'
import { Node, NodeType, Group } from './../define/node'
import { PositionType } from './../define/flex-type'
import { NodeUtil } from './node-util'
import { isConflicted, getDirection, findOverlapsOnDirection } from './conflict'
// import console from './../primitive/logger'

function positionType(node: Node, property: Property) {
  const { type } = node
  if (type === NodeType.GROUP) {
    const group = node as Group
    const dir = getDirection(group, property)
    if (isConflicted(group, false)) {
      const conflicts = findOverlapsOnDirection(group, property, dir)
      conflicts.forEach(child => {
        child.layout.position = PositionType.ABSOLUTE
      })
    }

    property.getChildren(node).forEach(child => {
      if (child.layout.position !== PositionType.ABSOLUTE) {
        child.layout.position = PositionType.RELATIVE
      }
    })
  }
}

export function measurePositionType(node: Node, property: Property): Node {
  return NodeUtil.visitNodeTree(node, property, positionType)
}
