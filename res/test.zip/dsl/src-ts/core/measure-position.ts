import { Property } from './property'
import { Node, NodeType, Text, Group } from './../define/node'
import { FlexDirection, JustifyContent, PositionType, AlignItems } from './../define/flex-type'
import { FrameUtil } from './frame-util'
import { LayoutUtil } from './layout-util'
import { DirectionUtil } from './direction-util'
import { NodeUtil } from './node-util'
import { isConflicted } from './conflict'

function isFirstLinearChild(child: Node, property: Property): boolean {
  return property.getLinearChildren(child.parent).indexOf(child) === 0
}

function isLastLinearChild(child: Node, property: Property): boolean {
  const linears = property.getLinearChildren(child.parent)
  return linears.indexOf(child) === linears.length - 1
}

function setPositionForAbsolute(child: Node, parent: Group, dir: FlexDirection, isChildUseCenter: boolean) {
  if (isChildUseCenter) {
    if (LayoutUtil.isFixed(child.layout, dir)) {
      LayoutUtil.setPositionStart(child.layout, dir, FrameUtil.getStart(child.measured, dir))
    } else {
      const center = FrameUtil.getCenter(child.measured, dir)
      LayoutUtil.setPositionStart(child.layout, dir, center)
      LayoutUtil.setTransformForCenter(child.layout, dir)
    }
  } else if (
    FrameUtil.getLength(child.measured, dir) === FrameUtil.getLength(parent.measured, dir) &&
    FrameUtil.getStart(child.measured, dir) === 0
  ) {
    LayoutUtil.setPositionStart(child.layout, dir, 0)
    LayoutUtil.setPositionEnd(child.layout, dir, 0)
  } else if (FrameUtil.isNearEnd(child.measured, parent.measured, dir)) {
    LayoutUtil.setPositionEnd(child.layout, dir, FrameUtil.getLength(parent.measured, dir) - FrameUtil.getEnd(child.measured, dir))
  } else {
    LayoutUtil.setPositionStart(child.layout, dir, FrameUtil.getStart(child.measured, dir))
  }
}

function newGroupForAbsolute(child: Node, parent: Group, property: Property) {
  const oldChildMeasured = { ...child.measured }

  const newGroup = NodeUtil.newGroup([child], parent)

  child.measured.x = oldChildMeasured.x
  child.measured.y = oldChildMeasured.y

  newGroup.measured.x = 0
  newGroup.measured.y = 0
  newGroup.measured.width = parent.measured.width
  newGroup.measured.height = parent.measured.height

  newGroup.layout.flexDirection = FlexDirection.COLUMN

  newGroup.layout.justifyContent = FrameUtil.isCenter(child.measured, newGroup.measured, FlexDirection.COLUMN)
    ? JustifyContent.CENTER
    : FrameUtil.isNearEnd(child.measured, newGroup.measured, FlexDirection.COLUMN)
      ? JustifyContent.FLEX_END
      : JustifyContent.FLEX_START

  newGroup.layout.alignItems = FrameUtil.isCenter(child.measured, newGroup.measured, FlexDirection.ROW)
    ? AlignItems.CENTER
    : FrameUtil.isNearEnd(child.measured, newGroup.measured, FlexDirection.ROW)
      ? AlignItems.FLEX_END
      : AlignItems.FLEX_START

  newGroup.layout.position = PositionType.ABSOLUTE

  newGroup.layout.left = 0
  newGroup.layout.top = 0
  newGroup.layout.right = 0
  newGroup.layout.bottom = 0

  // ;[FlexDirection.ROW, FlexDirection.COLUMN].forEach(dir => {
  //   LayoutUtil.setLength(newGroup.layout, dir, FrameUtil.getLength(newGroup.measured, dir))
  // })

  measurePosition(child, property)

  return newGroup
}

function needPolyfillForTextAbsoluteCenter(child: Node, property: Property) {
  const { type, parent } = child
  return (
    type === NodeType.TEXT &&
    (FrameUtil.isCenter(child.measured, parent.measured, FlexDirection.ROW) && !LayoutUtil.isFixed(child.layout, FlexDirection.ROW)) &&
    (!FrameUtil.isCenter(child.measured, parent.measured, FlexDirection.COLUMN) || property.isSingleLinesText(child)) &&
    false
  )
}

function needPolyfillForAbsoluteCenter(child: Node) {
  const { parent } = child
  const dirs = [FlexDirection.ROW, FlexDirection.COLUMN]
  return dirs.some(dir => {
    return !LayoutUtil.isFixed(child.layout, dir) && FrameUtil.isCenter(child.measured, parent.measured, dir)
  })
}

function isCrossStrictInCenter(child: Node, property: Property, dir: FlexDirection) {
  const { type } = child
  if (type === NodeType.GROUP) {
    const group = child as Group

    const mainDir = group.layout.flexDirection
    if (DirectionUtil.cross(mainDir) === dir) {
      if (!isConflicted(group, true)) {
        const linears = property.getLinearChildren(group)
        if (linears.length >= 2) {
          if (group.layout.alignItems === AlignItems.CENTER) {
            return linears.every(linear => linear.layout.alignSelf === AlignItems.CENTER || linear.layout.alignSelf === undefined)
          }
        }
      }
    }
  }
  return false
}

function needCenterForAbsolute(child: Node, property: Property, dir: FlexDirection) {
  const { parent } = child
  const isCenter = FrameUtil.isCenter(child.measured, parent.measured, dir)
  return isCenter || isCrossStrictInCenter(child, property, dir)
}

function calcAbsolute(child: Node, property: Property) {
  const { parent } = child
  const dirs = [FlexDirection.ROW, FlexDirection.COLUMN]

  const needWrap = dirs.some(
    dir => needCenterForAbsolute(child, property, dir) && (parent === undefined || !LayoutUtil.isFixed(parent.layout, dir))
  )

  if (needWrap) {
    //text 通栏？
    if (needPolyfillForTextAbsoluteCenter(child, property)) {
      const text = child as Text
      //row
      LayoutUtil.setPositionStart(text.layout, FlexDirection.ROW, 0)
      LayoutUtil.setPositionEnd(text.layout, FlexDirection.ROW, 0)
      text.textStyles.textAlign = 'center'
      //column
      setPositionForAbsolute(child, parent, FlexDirection.COLUMN, false)
    } else if (needPolyfillForAbsoluteCenter(child)) {
      newGroupForAbsolute(child, parent, property)

      child.layout.position = PositionType.RELATIVE
      calcMainAxis(child, property)
      calcCrossAxis(child, property)
    } else {
      dirs.forEach(dir => {
        setPositionForAbsolute(child, parent, dir, needCenterForAbsolute(child, property, dir))
      })
    }
  } else {
    dirs.forEach(dir => {
      setPositionForAbsolute(child, parent, dir, needCenterForAbsolute(child, property, dir))
    })
  }
}

//for relative
function calcMainAxis(child: Node, property: Property) {
  const { parent } = child
  const dir = parent.layout.flexDirection
  const justifyContent = parent.layout.justifyContent

  const isFixed = LayoutUtil.isFixed(parent.layout, dir)

  if (justifyContent === JustifyContent.SPACE_BETWEEN) {
    const children = property.getLinearChildren(parent)
    if (children[0] === child) {
      LayoutUtil.setMarginStart(child.layout, dir, FrameUtil.getStart(child.measured, dir))
    } else if (children[children.length - 1] === child) {
      LayoutUtil.setMarginEnd(child.layout, dir, FrameUtil.getLength(parent.measured, dir) - FrameUtil.getEnd(child.measured, dir))
    } else {
      //do nothing
    }
  } else if (justifyContent === JustifyContent.FLEX_START) {
    const prev = NodeUtil.prevSlibing(child, property)
    const prevEnd = prev ? FrameUtil.getEnd(prev.measured, dir) : 0

    const offset = FrameUtil.getStart(child.measured, dir) - prevEnd

    if (property.isDivider(child, dir) && prev) {
      LayoutUtil.setMarginEnd(prev.layout, dir, offset)
    } else {
      LayoutUtil.setMarginStart(child.layout, dir, offset)
    }

    const offset2 = FrameUtil.getLength(parent.measured, dir) - FrameUtil.getEnd(child.measured, dir)
    if (!isFixed && isLastLinearChild(child, property)) {
      LayoutUtil.setMarginEnd(child.layout, dir, offset2)
    }
  } else if (justifyContent === JustifyContent.CENTER) {
    const prev = NodeUtil.prevSlibing(child, property)
    if (prev) {
      const prevEnd = FrameUtil.getEnd(prev.measured, dir)
      const offset = FrameUtil.getStart(child.measured, dir) - prevEnd
      LayoutUtil.setMarginStart(child.layout, dir, offset)
    }
  } else if (justifyContent === JustifyContent.FLEX_END) {
    const next = NodeUtil.nextSlibing(child, property)
    const nextStart = next ? FrameUtil.getStart(next.measured, dir) : FrameUtil.getLength(parent.measured, dir)
    const offset = nextStart - FrameUtil.getEnd(child.measured, dir)
    if (property.isDivider(child, dir) && next) {
      LayoutUtil.setMarginStart(next.layout, dir, offset)
    } else {
      LayoutUtil.setMarginEnd(child.layout, dir, offset)
    }

    const offset2 = FrameUtil.getStart(child.measured, dir)
    if (!isFixed && isFirstLinearChild(child, property)) {
      LayoutUtil.setMarginStart(child.layout, dir, offset2)
    }
  } else {
    throw new Error(`${parent.name} ${child.name} ${justifyContent}`)
  }
}

function calcCrossAxis(child: Node, property: Property) {
  const { parent } = child
  const dir = DirectionUtil.cross(parent.layout.flexDirection)
  const align = child.layout.alignSelf || parent.layout.alignItems

  const isFixed = parent && LayoutUtil.isFixed(parent.layout, dir)

  if (align === AlignItems.FLEX_START) {
    LayoutUtil.setMarginStart(child.layout, dir, FrameUtil.getStart(child.measured, dir))
    if (!isFixed) {
      const offset = FrameUtil.getLength(parent.measured, dir) - FrameUtil.getEnd(child.measured, dir)
      LayoutUtil.setMarginEnd(child.layout, dir, offset)
    }
  } else if (align === AlignItems.CENTER) {
    const offset = FrameUtil.getCenter(child.measured, dir) - FrameUtil.getLength(parent.measured, dir) / 2
    if (offset > 0) {
      LayoutUtil.setMarginStart(child.layout, dir, offset)
    } else {
      LayoutUtil.setMarginEnd(child.layout, dir, -offset)
    }
  } else if (align === AlignItems.FLEX_END) {
    const offset = FrameUtil.getLength(parent.measured, dir) - FrameUtil.getEnd(child.measured, dir)
    LayoutUtil.setMarginEnd(child.layout, dir, offset)
    if (!isFixed) {
      LayoutUtil.setMarginStart(child.layout, dir, FrameUtil.getStart(child.measured, dir))
    }
  } else if (align === AlignItems.STRETCH) {
    LayoutUtil.setMarginStart(child.layout, dir, 0)
    LayoutUtil.setMarginEnd(child.layout, dir, 0)
  }
}

function position(node: Node, property: Property) {
  property.getChildren(node).forEach(child => {
    if (child.layout.position === PositionType.ABSOLUTE) {
      calcAbsolute(child, property)
    } else {
      calcMainAxis(child, property)
      calcCrossAxis(child, property)
    }
  })
  //last linear
}

export function measurePosition(node: Node, property: Property): Node {
  return NodeUtil.visitNodeTree(node, property, position)
}
