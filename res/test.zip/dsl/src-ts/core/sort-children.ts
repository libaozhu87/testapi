import { Property } from './property'
import { Node, Group, NodeType } from './../define/node'
import { NodeUtil } from './node-util'
import { getDirection } from './conflict'
import { isOverlap } from './math'
import { FrameUtil } from './frame-util'

function sort(node: Node, property: Property) {
  if (node.type === NodeType.GROUP) {
    const group = node as Group
    const dir = getDirection(group, property)

    group.children.sort((c0, c1) => {
      if (isOverlap(c0.exactFrame, c1.exactFrame)) {
        return property.minZIndex(c0) - property.minZIndex(c1)
      } else {
        return FrameUtil.getStart(c0.measured, dir) - FrameUtil.getStart(c1.measured, dir)
      }
    })
  }
}

export function sortChildren(node: Node, property: Property) {
  NodeUtil.visitNodeTreeReverse(node, property, sort)
}
