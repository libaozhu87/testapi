import { Property } from './property'
import { Node, NodeType, Group } from './../define/node'
import { AlignItems, PositionType } from './../define/flex-type'
import { NodeUtil } from './node-util'
import { DirectionUtil } from './direction-util'
import { FrameUtil } from './frame-util'
import { Platform } from './../define/platform'
import console from './../primitive/logger'
import { LayoutUtil } from './layout-util'
import isEmpty from './../primitive/isEmpty'
import { CENTER_ERROR } from './magic'
import { SpecialAlign } from './../define/special'

function alignSelf(node: Node, property: Property) {
  const { parent } = node
  if (!parent) {
    return
  }

  //左中右都可以
  if (node.layout.position !== PositionType.ABSOLUTE) {
    //副轴对其
    if (node.specialAlign === SpecialAlign.START) {
      node.layout.alignSelf = AlignItems.FLEX_START
    } else if (node.specialAlign === SpecialAlign.CENTER) {
      node.layout.alignSelf = AlignItems.CENTER
    } else if (node.specialAlign === SpecialAlign.END) {
      node.layout.alignSelf = AlignItems.FLEX_END
    } else {
      const dir = DirectionUtil.cross(parent.layout.flexDirection)

      const length = FrameUtil.getLength(parent.measured, dir)
      const start = FrameUtil.getStart(node.measured, dir)
      const end = length - FrameUtil.getEnd(node.measured, dir)

      // console.log('alignSelf', node.id, start, end, length)

      if (Math.abs(start) <= CENTER_ERROR && Math.abs(end) <= CENTER_ERROR) {
        node.layout.alignSelf = undefined //哪个方向都可以
      } else if (FrameUtil.isCenter(node.measured, parent.measured, dir)) {
        node.layout.alignSelf = AlignItems.CENTER
        // node.layout.alignSelf = AlignItems.FLEX_START
      } else if (FrameUtil.isNearStart(node.measured, parent.measured, dir)) {
        node.layout.alignSelf = AlignItems.FLEX_START
      } else if (FrameUtil.isNearEnd(node.measured, parent.measured, dir)) {
        node.layout.alignSelf = AlignItems.FLEX_END
      }
    }
  }
}

function alignItems(node: Node, property: Property) {
  const { type } = node
  if (type === NodeType.GROUP) {
    const group = node as Group

    const children = property.getLinearChildren(group)

    if (!isEmpty(children)) {
      const cross = DirectionUtil.cross(group.layout.flexDirection)
      const isFixed = LayoutUtil.isFixed(group.layout, cross)

      if (isFixed) {
        const aligns = [AlignItems.FLEX_START, AlignItems.CENTER, AlignItems.FLEX_END]
        let max = 0
        let maxAlign
        aligns.forEach(align => {
          const sum = children.reduce((count, child) => (child.layout.alignSelf === align ? count + 1 : count), 0)
          if (sum > 0 && (max < sum || (sum === max && align === AlignItems.CENTER))) {
            max = sum
            maxAlign = align
          }
        })

        group.layout.alignItems = maxAlign === undefined ? AlignItems.FLEX_START : maxAlign
      } else {
        const isAllStart = children.every(child => child.layout.alignSelf === AlignItems.FLEX_START || child.layout.alignSelf === undefined)

        const isAllCenter =
          !isAllStart && children.every(child => child.layout.alignSelf === AlignItems.CENTER || child.layout.alignSelf === undefined)

        if (isAllStart) {
          group.layout.alignItems = AlignItems.FLEX_START
        } else if (isAllCenter) {
          group.layout.alignItems = AlignItems.CENTER
        } else {
          const sumStart = children.reduce((count, child) => (child.layout.alignSelf === AlignItems.FLEX_START ? count + 1 : count), 0)
          const sumEnd = children.reduce((count, child) => (child.layout.alignSelf === AlignItems.FLEX_END ? count + 1 : count), 0)
          const align = sumStart >= sumEnd ? AlignItems.FLEX_START : AlignItems.FLEX_END
          group.layout.alignItems = align
        }
      }

      children.forEach(child => {
        if (child.layout.alignSelf === undefined) {
          child.layout.alignSelf = group.layout.alignItems
        }
      })

      children.forEach(child => {
        //child.layout.alignSelf === group.layout.alignItems || fixed for weex-android
        if (property.getPlatform() === Platform.FLUTTER) {
          child.layout.alignSelf = undefined
        }
      })
    }
  }
}

export function measureCrossAlign(node: Node, property: Property): Node {
  const r0 = NodeUtil.visitNodeTree(node, property, alignSelf)
  return NodeUtil.visitNodeTree(r0, property, alignItems)
}

/**
 *
 */
