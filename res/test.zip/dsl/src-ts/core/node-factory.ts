import { Layout } from './../define/layout'
import { Styles, TextStyles, ImageStyles } from './../define/styles'
import { InputNode } from './../define/input-node'
import { PositionType } from './../define/flex-type'
import { MeasuredSizeType } from './../define/measure-size-type'
import { SpecialLayout, SpecialAlign } from './../define/special'
import { Frame } from './../define/frame'
import { NodeType, IClass, Node, Text, Shape, Image, Group } from './../define/node'

class CNode implements Node {
  public zIndex: number
  public raw: InputNode
  public clazz: IClass

  public name: string
  public id: string

  public type: NodeType
  public layout: Layout
  //origin
  public frame: Frame
  public exactFrame: Frame
  //measured
  public measured: Frame
  public reasons: MeasuredSizeType[]
  public parent: Group

  public specialAlign: SpecialAlign

  public constructor(input: InputNode, parent: Group) {
    this.name = input.name
    this.id = input.id
    this.zIndex = input.zIndex
    this.type = this.nodeType(input.type)
    this.parent = parent
    this.specialAlign = input.specailAlign

    this.raw = { ...input }
    this.raw.frame = undefined
    this.raw.exactFrame = undefined
    this.raw.layers = undefined
    this.raw.styles = undefined
    this.raw.textStyles = undefined
    this.raw.imageStyles = undefined

    this.frame = { ...input.frame }
    this.exactFrame = { ...input.exactFrame }
    this.measured = { ...this.frame }

    this.reasons = []

    this.layout = {
      flexDirection: undefined, //FlexDirection.COLUMN,
      justifyContent: undefined, //JustifyContent.FLEX_START,
      alignItems: undefined, // option disable

      padding: [undefined, undefined, undefined, undefined],

      position: PositionType.RELATIVE,
      width: undefined, //option 如果给了就是 fixed-width, undefined
      height: undefined, //option
      //when position = PositionType.absolute
      left: undefined, //option
      right: undefined, //option
      top: undefined, //option
      bottom: undefined, //option
      //when position = PositionType.relative
      margin: [undefined, undefined, undefined, undefined],
      flex: undefined, //option
      alignSelf: undefined
    }
  }

  private nodeType(type: string): NodeType {
    if (type === NodeType.TEXT) {
      return NodeType.TEXT
    } else if (type === NodeType.IMAGE) {
      return NodeType.IMAGE
    } else if (type === NodeType.SHAPE) {
      return NodeType.SHAPE
    } else if (type === NodeType.GROUP) {
      return NodeType.GROUP
    } else if (type === 'component') {
      return NodeType.COMPONENT
    }

    throw new Error(`Unknow type ${type}`)
  }
}

class CText extends CNode implements Text {
  public value: string // text or image.src
  public textStyles: TextStyles

  public constructor(input: InputNode, parent: Group) {
    super(input, parent)
    this.value = input.value
    this.textStyles = input.textStyles

    if (!(this.textStyles.lineHeight > 0 && this.frame.height >= this.textStyles.lineHeight * 2)) {
      this.textStyles.maxWidth = undefined
      this.textStyles.maxHeight = undefined
    }
  }
}

class CImage extends CNode implements Image {
  public value: string // text or image.src
  public imageStyles: ImageStyles
  public constructor(input: InputNode, parent: Group) {
    super(input, parent)
    this.value = input.value
    this.imageStyles = input.imageStyles
  }
}

class CShape extends CNode implements Shape {
  public styles: Styles
  public constructor(input: InputNode, parent: Group) {
    super(input, parent)
    this.styles = input.styles

    this.styles.opacity = undefined
  }
}

class CGroup extends CNode implements Group {
  public styles: Styles
  public children: Node[]
  public specialLayout: SpecialLayout

  public constructor(input: InputNode, parent: Group) {
    super(input, parent)
    this.styles = input.styles

    this.specialLayout = undefined
  }
}

export function buildNode(input: InputNode, parent: Group): Node {
  const { type } = input
  if (type === NodeType.TEXT) {
    return new CText(input, parent)
  } else if (type === NodeType.IMAGE) {
    return new CImage(input, parent)
  } else if (type === NodeType.SHAPE) {
    return new CShape(input, parent)
  } else if (type === NodeType.GROUP) {
    return new CGroup(input, parent)
  } else {
    throw new Error(`Unknow type ${type}`)
  }
}
