import { InputNode } from './../define/input-node'
import { NodeType } from './../define/node'
import { newId, resetIdGenerator } from './id-generate'

function isValidNode(node: InputNode) {
  if (!node.type) {
    throw new Error(JSON.stringify(node))
  }

  if (node.type !== NodeType.GROUP && node.frame.width > 0 && node.frame.height > 0) {
    if (node.type === NodeType.SHAPE) {
      return (
        node.styles !== undefined &&
        (node.styles.borderColor !== undefined || node.styles.backgroundColor !== undefined || node.styles.backgroundImage !== undefined)
      )
    }

    return true
  }
}

function _applanate(node: InputNode, result: InputNode[]): InputNode[] {
  if (node.type === NodeType.GROUP) {
    node.layers.forEach(layer => _applanate(layer, result))
  } else if (isValidNode(node)) {
    node.zIndex = newId()
    node.id = node.type[0] + node.zIndex
    result.push(node)
  }

  return result
}

export default function applanate(node: InputNode): InputNode[] {
  resetIdGenerator()
  return _applanate(node, [])
}
