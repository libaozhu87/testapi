import { InputNode } from './../define/input-node'
import { FrameUtil } from './frame-util'
// import { AlignItems } from './../define/flex-type'
import {
  // isFullOverlapOnDirection,
  isOverlap,
  intersectionOnDirection,
  measureOverlapOnDir,
  isFullOverlap,
  isFullOverlapOnDirectionByScale,
  intersectionOnDirectionByScale,
  marginOnDirectionByScale
} from './math'
import { FlexDirection } from './../define/flex-type'
import fill from './../primitive/fill'
import flatten from './../primitive/flatten'
import min from './../primitive/min'

import top from './../primitive/top'
import unique from './../primitive/unique'
import console from './../primitive/logger'
import assert from './../primitive/assert'
import isEmpty from './../primitive/isEmpty'
import compact from './../primitive/compact'
import { getDirection2, isConflicted2, getDirectionByBaseNodes, strictFindOverlaps, tRawFindOverlaps } from './conflict'
import { isSimilarAsGridLine, isSimilarTree } from './similar'
import { MAGIC_MARGIN, MIN_GRID_ITEMS, isMagicMargin } from './magic'
import { NodeType } from './../define/node'
import { newId } from './id-generate'
import { SpecialAlign } from './../define/special'

function layerComparator(c0: InputNode, c1: InputNode, dir: FlexDirection) {
  if (isOverlap(c0.exactFrame, c1.exactFrame)) {
    return c0.zIndex - c1.zIndex
  } else {
    return FrameUtil.getStart(c0.exactFrame, dir) - FrameUtil.getStart(c1.exactFrame, dir)
  }
}

function decompose(layer: InputNode): InputNode[] {
  if (layer.type === NodeType.GROUP) {
    return [...layer.layers]
  }
  return [layer]
}

function compose(nodes: InputNode[], dir: FlexDirection): InputNode {
  const children: InputNode[] = compact(nodes)

  if (children.length === 0) {
    return undefined
  } else if (children.length === 1) {
    return children[0]
  }

  const zIndex = min(children.map(child => child.zIndex))

  const frames = children.map(node => node.frame)
  const exactFrames = children.map(node => node.exactFrame)

  const newFrame = frames.reduce(FrameUtil.expand, undefined)
  const newExactFrame = exactFrames.reduce(FrameUtil.expand, undefined)

  const group: InputNode = {
    name: 'auto-merge',
    id: 'g' + newId(),
    type: NodeType.GROUP,
    frame: newFrame,
    exactFrame: newExactFrame,
    layers: children,
    value: undefined,
    styles: undefined,
    textStyles: undefined,
    imageStyles: undefined,
    zIndex,
    dir
  }

  return group
}

enum SliceResultType {
  OVERLAPS_BACKGROUND = 'OVERLAPS_BACKGROUND',
  OVERLAPS_MIDGROUND = 'OVERLAPS_MIDGROUND',
  OVERLAPS_FOREGROUND = 'OVERLAPS_FOREGROUND',
  PROJECTION = 'PROJECTION',
  PROJECTION_SCALED = 'PROJECTION_SCALED',
  CONFILCT_BACKGROUND = 'CONFILCT_BACKGROUND',
  CONFILCT_FOREGROUND = 'CONFILCT_FOREGROUND'
}

function sliceResultTypeOrder(type: SliceResultType): number {
  switch (type) {
    case SliceResultType.OVERLAPS_BACKGROUND:
    case SliceResultType.OVERLAPS_MIDGROUND:
    case SliceResultType.OVERLAPS_FOREGROUND:
      return 1
    case SliceResultType.PROJECTION:
      return 2
    case SliceResultType.PROJECTION_SCALED:
      return 3
    case SliceResultType.CONFILCT_BACKGROUND:
    case SliceResultType.CONFILCT_FOREGROUND:
      return 4
    default:
      return 5
  }
}

interface SliceResult {
  start: InputNode[]
  end: InputNode[]
  dir: FlexDirection
  margin: number
  conflictRate: number
  type: SliceResultType
  isEndAsBackground?: boolean
}

//重合法
function sliceByOverlaps(nodes: InputNode[]): SliceResult {
  const dirs = [FlexDirection.ROW, FlexDirection.COLUMN]

  nodes = [...nodes].sort((n0, n1) => n0.zIndex - n1.zIndex)

  const isCoincidence = (small: InputNode, large: InputNode) => {
    return dirs.every(dir => {
      const intersection = intersectionOnDirection(small.exactFrame, large.exactFrame, dir)
      return intersection / FrameUtil.getLength(small.exactFrame, dir) >= 0.5
    })
  }

  //处理bg
  let index = 0
  for (index = 0; index < nodes.length; index++) {
    const bg = nodes[index]
    // const remains = nodes.slice(index + 1)
    if (index === nodes.length - 1 || !nodes.every(small => small === bg || isCoincidence(small, bg))) {
      if (index > 0) {
        return {
          start: nodes.slice(0, index),
          end: nodes.slice(index),
          //done
          dir: undefined,
          margin: -1,
          conflictRate: 1,
          type: SliceResultType.OVERLAPS_BACKGROUND
        }
      }
      break
    }
  }

  //处理fg
  for (index = nodes.length - 1; index >= 0; index--) {
    const fg = nodes[index]
    if (index === 0 || !nodes.every(small => small === fg || isCoincidence(small, fg))) {
      if (index < nodes.length - 1) {
        return {
          start: nodes.slice(0, index + 1),
          end: nodes.slice(index + 1),
          dir: undefined,
          margin: -1,
          conflictRate: 1,
          type: SliceResultType.OVERLAPS_FOREGROUND
        }
      }
      break
    }
  }

  //处理中间 们层
  for (index = 1; index < nodes.length; index++) {
    const mg = nodes[index]
    if (nodes.every(small => small === mg || isCoincidence(small, mg))) {
      return {
        start: nodes.slice(0, index),
        end: nodes.slice(index),
        dir: undefined,
        margin: -1,
        conflictRate: 1,
        type: SliceResultType.OVERLAPS_MIDGROUND
      }
    }
  }

  return undefined
}

function calcConflictRateOnDir(start: InputNode[], end: InputNode[], scale: number, dir: FlexDirection): number {
  const sf = FrameUtil.expandFrames(...start.map(n => n.exactFrame))
  const ef = FrameUtil.expandFrames(...end.map(n => n.exactFrame))
  const intersection = intersectionOnDirectionByScale(sf, ef, scale, dir)
  return intersection / (Math.min(FrameUtil.getLength(sf, dir), FrameUtil.getLength(ef, dir)) * scale)
}

function calcMarginOnDir(start: InputNode[], end: InputNode[], scale: number, dir: FlexDirection): number {
  const sf = FrameUtil.expandFrames(...start.map(n => n.exactFrame))
  const ef = FrameUtil.expandFrames(...end.map(n => n.exactFrame))
  return marginOnDirectionByScale(sf, ef, scale, dir)
}

function selectSliceResult(a: SliceResult, b: SliceResult): SliceResult {
  if (a === undefined || b === undefined) {
    return a || b
  }

  const orderA = sliceResultTypeOrder(a.type)
  const orderB = sliceResultTypeOrder(b.type)
  if (orderA !== orderB) {
    return orderA < orderB ? a : b
  }

  assert(a !== undefined && b !== undefined)

  //重合优先
  if (orderA === sliceResultTypeOrder(SliceResultType.OVERLAPS_BACKGROUND)) {
    return a
  }

  //投影优先
  if (orderA === sliceResultTypeOrder(SliceResultType.PROJECTION)) {
    if (a.margin >= 0 && a.dir === FlexDirection.COLUMN && a.dir !== b.dir) {
      return a
    }
    if (b.margin >= 0 && b.dir === FlexDirection.COLUMN && a.dir !== b.dir) {
      return b
    }
    return a.margin >= b.margin ? a : b
  }

  //缩放投影优先
  if (orderA === sliceResultTypeOrder(SliceResultType.PROJECTION_SCALED)) {
    return a.margin >= b.margin ? a : b
  }

  //冲突优先
  if (orderA === sliceResultTypeOrder(SliceResultType.CONFILCT_BACKGROUND)) {
    return a.conflictRate >= b.conflictRate ? a : b
  }

  throw new Error(``)
}

class NodeGraph {
  private _vectors: Array<[InputNode, InputNode]> = []
  private _nodes: InputNode[]
  private _sort: (n0: InputNode, n1: InputNode) => number

  private _majorsCache: { [key: string]: InputNode[] } = {}

  public constructor(
    nodes: InputNode[],
    isBelongTo: (n0: InputNode, n1: InputNode) => boolean,
    sort: (n0: InputNode, n1: InputNode) => number
  ) {
    this._nodes = nodes
    this._sort = sort

    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const ni = nodes[i]
        const nj = nodes[j]
        const isJToI = isBelongTo(nj, ni)
        const isIToJ = isBelongTo(ni, nj)
        if (isJToI && isIToJ) {
          if (nj.zIndex < ni.zIndex) {
            this._vectors.push([ni, nj])
          } else {
            this._vectors.push([nj, ni])
          }
        } else if (isJToI) {
          this._vectors.push([nj, ni])
        } else if (isIToJ) {
          this._vectors.push([ni, nj])
        }
      }
    }
  }

  public majors() {
    return this._nodes.filter(node => this.isMajor(node))
  }

  public getMajor(node: InputNode): InputNode {
    const major = top(this.getMajors(node), this._sort)
    return major
  }

  public getBlock(major: InputNode): InputNode[] {
    const result = this._nodes.filter(node => this.getMajor(node) === major)
    return result
  }

  public isMajor(node: InputNode): boolean {
    for (const vector of this._vectors) {
      if (vector[0] === node) {
        return false
      }
    }
    return true
  }

  private getParents(node: InputNode): InputNode[] {
    let parents: InputNode[] = []
    for (const vector of this._vectors) {
      if (vector[0] === node) {
        parents.push(vector[1])
      }
    }

    parents = unique(parents)
    return parents
  }

  private getMajors(node: InputNode): InputNode[] {
    let majors = this._majorsCache[node.id]
    if (majors !== undefined) {
      return majors
    }

    const parents = this.getParents(node)
    // console.log('parents', node.id, parents.map(p => p.id))
    if (!isEmpty(parents)) {
      majors = unique(
        flatten(
          parents.map(parent => {
            if (this.isMajor(parent)) {
              return parent
            } else {
              return this.getMajors(parent)
            }
          }),
          true
        )
      )
      this._majorsCache[node.id] = majors
      return majors
    }

    majors = [node]
    this._majorsCache[node.id] = majors
    return majors
  }
}

//投影法
function sliceByProjectionOnDir(nodes: InputNode[], dir: FlexDirection, scale: number): SliceResult {
  // zIndex
  const nodeGraph = new NodeGraph(
    nodes,
    (n0, n1) => isFullOverlapOnDirectionByScale(n0.exactFrame, n1.exactFrame, scale, dir),
    (n0, n1) => -FrameUtil.getCenter(n0.exactFrame, dir) + FrameUtil.getCenter(n1.exactFrame, dir)
  )

  const majors: InputNode[] = nodeGraph.majors()

  if (majors.length <= 1) {
    return undefined
  } else {
    const type = scale >= 0.999999 ? SliceResultType.PROJECTION : SliceResultType.PROJECTION_SCALED

    //找到最佳分解  start -> end
    majors.sort((a, b) => FrameUtil.getCenter(a.exactFrame, dir) - FrameUtil.getCenter(b.exactFrame, dir))

    const pairs: SliceResult[] = []

    for (let i = 1; i < majors.length; i++) {
      const start = majors.slice(0, i)
      const end = majors.slice(i)

      const block0: InputNode[] = flatten(start.map(major => nodeGraph.getBlock(major)), false)
      const block1: InputNode[] = flatten(end.map(major => nodeGraph.getBlock(major)), false)

      //过滤掉不合理的层级关系 ?????
      // if (block1.every(b1 => block0.every(b0 => !isOverlap(b0.exactFrame, b1.exactFrame) || b1.zIndex > b0.zIndex))) {

      const isEndAsBackground = !block1.every(b1 => block0.every(b0 => !isOverlap(b0.exactFrame, b1.exactFrame) || b1.zIndex > b0.zIndex))
      pairs.push({
        start: block0,
        end: block1,
        dir,
        margin: calcMarginOnDir(start, end, scale, dir),
        conflictRate: calcConflictRateOnDir(start, end, scale, dir),
        type,
        isEndAsBackground
      })
      // }
    }

    const result = top(pairs, (a, b) => (selectSliceResult(a, b) === a ? -1 : 1))
    //start 覆盖 end的case

    if (type === SliceResultType.PROJECTION) {
      if (result && result.conflictRate >= 0.2) {
        return undefined
      }
    }

    return result
  }
}

//投影法
function sliceByProjection(nodes: InputNode[]): SliceResult {
  const rowResult = sliceByProjectionOnDir(nodes, FlexDirection.ROW, 1)
  const colResult = sliceByProjectionOnDir(nodes, FlexDirection.COLUMN, 1)
  return selectSliceResult(rowResult, colResult)
}

//冲突解决法
function sliceBySolveConflict(nodes: InputNode[]): SliceResult {
  //首先合并
  // a -> b -> c
  const nodeGraph = new NodeGraph(
    nodes,
    (n0, n1) => isFullOverlap(n0.exactFrame, n1.exactFrame) && n0.zIndex > n1.zIndex,
    (n0, n1) => -n0.zIndex + n1.zIndex
  )

  const majors: InputNode[] = nodeGraph.majors()

  const dir = getDirectionByBaseNodes(majors)

  let majorConflicts: InputNode[] = tRawFindOverlaps(majors.map(node => ({ carry: node })), (l1, l2) =>
    measureOverlapOnDir(l1, l2, dir)
  ).map(frameCarry => frameCarry.carry)

  if (isEmpty(majorConflicts)) {
    //兜底
    majorConflicts = strictFindOverlaps(majors.map(node => ({ carry: node })), (l1, l2) => measureOverlapOnDir(l1, l2, dir))
  }

  assert(!isEmpty(majorConflicts))

  const majorRemains = majors.filter(node => majorConflicts.indexOf(node) === -1)

  //background or foreground
  const confilctIsBackground = majorConflicts.some(conflict =>
    majorRemains.some(remain => isOverlap(remain.exactFrame, conflict.exactFrame) && remain.zIndex > conflict.zIndex)
  )

  //排序 todo

  const conflicts = unique(flatten(majorConflicts.map(mc => nodeGraph.getBlock(mc)))).sort((n0, n1) => n0.zIndex - n1.zIndex)
  const remains = unique(flatten(majorRemains.map(mc => nodeGraph.getBlock(mc)))).sort((n0, n1) => n0.zIndex - n1.zIndex)

  if (confilctIsBackground) {
    return {
      start: conflicts,
      end: remains,
      margin: -1,
      conflictRate: 1,
      dir,
      type: SliceResultType.CONFILCT_BACKGROUND
    }
  } else {
    return {
      start: remains,
      end: conflicts,
      margin: -1,
      conflictRate: 1,
      dir,
      type: SliceResultType.CONFILCT_FOREGROUND
    }
  }
}

//冲突解决法
function sliceByProjectionScaled(nodes: InputNode[]): SliceResult {
  for (let scale = 0.95; scale > 0.5; scale -= 0.05) {
    const rowResult = sliceByProjectionOnDir(nodes, FlexDirection.ROW, scale)
    const colResult = sliceByProjectionOnDir(nodes, FlexDirection.COLUMN, scale)
    const result = selectSliceResult(rowResult, colResult)
    if (result) {
      return result
    }
  }
}

function slice(nodes: InputNode[]): SliceResult {
  let result = sliceByOverlaps(nodes)
  if (result !== undefined) {
    return result
  }

  result = sliceByProjection(nodes)
  if (result !== undefined) {
    return result
  }

  result = sliceByProjectionScaled(nodes)
  if (result !== undefined) {
    return result
  }

  return sliceBySolveConflict(nodes)
}

function unite(nodes: InputNode[]): InputNode {
  if (isEmpty(nodes)) {
    return undefined
  } else if (nodes.length === 1) {
    return nodes[0]
  }

  console.log('----unite----')
  console.log('all', nodes.map(n => n.id))

  const result = slice(nodes)

  assert(result !== undefined)

  console.log('start', result.start.map(n => n.id))
  console.log('end', result.end.map(n => n.id))
  console.log('dir', result.dir)
  console.log('margin', result.margin)
  console.log('conflictRate', result.conflictRate)
  console.log('type', result.type)

  const { type } = result
  switch (type) {
    case SliceResultType.OVERLAPS_BACKGROUND:
      return compose(
        [...result.start, unite(result.end)],
        result.dir
      )
    case SliceResultType.OVERLAPS_FOREGROUND:
      return compose(
        [unite(result.start), ...result.end],
        result.dir
      )
    case SliceResultType.OVERLAPS_MIDGROUND:
      return compose(
        [unite(result.start), unite(result.end)],
        result.dir
      )
    case SliceResultType.PROJECTION:
    case SliceResultType.PROJECTION_SCALED:
      return compose(
        [unite(result.start), unite(result.end)],
        result.dir
      )
    case SliceResultType.CONFILCT_BACKGROUND:
      // return compose([...decompose(unite(result.start)), unite(result.end)], result.dir)
      return compose(
        [unite(result.start), unite(result.end)],
        result.dir
      )
    case SliceResultType.CONFILCT_FOREGROUND:
      // return compose([unite(result.start), ...decompose(unite(result.end))], result.dir)
      return compose(
        [unite(result.start), unite(result.end)],
        result.dir
      )
    default:
      throw new Error(`${type}`)
  }
}

function flattenNodeOnDirection(node: InputNode, parentDir: FlexDirection): InputNode[] {
  if (node.type === NodeType.GROUP) {
    const { dir } = node
    if (dir === undefined) {
      const g = flattenGroup(node)
      return [g]
    } else {
      if (dir === parentDir) {
        return flatten(node.layers.map(l => flattenNodeOnDirection(l, dir)), true)
      } else {
        const g = flattenGroup(node)
        return [g]
      }
    }
  } else {
    return [node]
  }
}

function flattenGroup(node: InputNode): InputNode {
  if (node.type === NodeType.GROUP) {
    const { dir } = node
    node.layers = flatten(node.layers.map(l => flattenNodeOnDirection(l, dir)), true)
  }
  return node
}

function sortOneGroup(group: InputNode) {
  const dir = getDirection2(group)
  group.layers.sort((c0, c1) => layerComparator(c0, c1, dir))
}

function sortChildren(node: InputNode): InputNode {
  const { type } = node
  if (type === NodeType.GROUP) {
    sortOneGroup(node)
    node.layers.forEach(sortChildren)
  }

  return node
}

function seperate(pre: number, cur: number, nxt: number): boolean {
  pre = pre === undefined ? cur : pre
  nxt = nxt === undefined ? cur : nxt
  if (pre * 2 <= cur && cur >= MAGIC_MARGIN) {
    return true
  }
  if (nxt * 2 <= cur && cur >= MAGIC_MARGIN) {
    return true
  }
  return false
}

function scanBySeperate(group: InputNode): InputNode {
  const { type } = group
  if (type === NodeType.GROUP) {
    const contents = group.layers
    const dir = group.dir

    if (dir === FlexDirection.ROW && contents.length > 2 && !isConflicted2(group)) {
      const bewteens = contents.map((child, index) => {
        const cur = child
        const nxt = contents[index + 1]
        const start = nxt ? FrameUtil.getStart(nxt.exactFrame, dir) : 9999999
        const end = FrameUtil.getEnd(cur.exactFrame, dir)
        return start - end
      })

      const sliceIndexs = []
      for (let i = 0; i < bewteens.length; i++) {
        const pre = bewteens[i - 1]
        const cur = bewteens[i]
        const nxt = bewteens[i + 1]
        if (seperate(pre, cur, nxt)) {
          sliceIndexs.push(i)
        }
      }

      if (sliceIndexs.length < contents.length && sliceIndexs.length > 1) {
        const newLayers: InputNode[] = []

        for (let i = 0; i < sliceIndexs.length; i++) {
          const start = i === 0 ? -1 : sliceIndexs[i - 1]
          const end = sliceIndexs[i]
          const newgroup = compose(
            Array.apply(undefined, Array(end - start)).map((v, index) => {
              return contents[start + index + 1]
            }),
            FlexDirection.ROW
          )
          newLayers.push(newgroup)
        }

        group.layers = newLayers
        sortOneGroup(group)
      }
    }

    group.layers.forEach(scanBySeperate)
  }

  return group
}

function isGridLineLike(g: InputNode): boolean {
  //1. row
  //2. not confilcted
  //3. grid-num >= 3
  //4. space similar
  //5. 相互之间有较高的相似度【要么box， 要么结构】
  const row = FlexDirection.ROW
  const isRow = getDirection2(g) === FlexDirection.ROW
  const notConfilcted = !isConflicted2(g)
  const isGridNum = g.type === NodeType.GROUP && g.layers.length >= MIN_GRID_ITEMS

  if (isRow && notConfilcted && isGridNum) {
    const spaces = g.layers
      .map(l => l.exactFrame)
      .map((f, i, arr) => {
        if (i >= 1) {
          const p = arr[i - 1]
          return FrameUtil.getStart(f, row) - FrameUtil.getEnd(p, row)
        }
        return 0
      })
      .slice(1)

    const isPositive = spaces.every(s => s > 0)

    //左右间距
    const isMarginSimilar = spaces.every(s => Math.abs(s - spaces[0]) / spaces[0] <= 0.2)

    //居中间距
    const centers = g.layers
      .map(l => l.exactFrame)
      .map(f => FrameUtil.getCenter(f, row))
      .map((v, i, arr) => {
        if (i >= 1) {
          const p = arr[i - 1]
          return v - p
        }
        return 0
      })
      .slice(1)

    const isCenterSimilar = centers.every(s => Math.abs(s - centers[0]) / centers[0] <= 0.2)

    return isPositive && (isMarginSimilar || isCenterSimilar) && isSimilarAsGridLine(g.layers)
  }

  return false
}

function isSimilarGridLine(preLayers: InputNode[], nextLayer: InputNode): boolean {
  const gs = [...preLayers, nextLayer]
  //每一行的网格属性
  const isAllGridLine = gs.every(isGridLineLike)
  if (isAllGridLine) {
    const gridNum = gs[0].layers.length
    const seperator =
      FrameUtil.getStart(nextLayer.exactFrame, FlexDirection.COLUMN) -
      FrameUtil.getEnd(preLayers[preLayers.length - 1].exactFrame, FlexDirection.COLUMN)
    const isSameGridNum = gs.every(g => g.type === NodeType.GROUP) && gs.every(g => g.layers.length === gridNum)
    //上下行的间距不那么大
    const isNotLargeMargin = seperator <= MAGIC_MARGIN
    if (isSameGridNum && isNotLargeMargin) {
      const dir = FlexDirection.ROW
      //首尾不相似
      const isNotRepeated = !gs[0].layers.every((l, i) => isSimilarTree(l, nextLayer.layers[i]))
      // const bSimilar = gs.every(g => isSimilarGridLine(g.layers))
      //是否可以合并
      const frames = fill(gridNum).map((_, i) => FrameUtil.expandFrames(...gs.map(g => g.layers[i].exactFrame)))
      const bewteens = frames
        .map((f, i) => {
          const pre = frames[i - 1]
          const cur = f
          if (pre !== undefined) {
            return FrameUtil.getStart(cur, dir) - FrameUtil.getEnd(pre, dir)
          }
        })
        .slice(1)
      const isBewteens = bewteens.every(b => b >= 0)
      return isNotRepeated && isBewteens
    }
  }

  return false
}

function mergeLines(gs: InputNode[]): InputNode {
  const colums = gs[0].layers.length
  return compose(
    fill(colums).map((_, i) =>
      compose(
        gs.map(g => g.layers[i]),
        FlexDirection.COLUMN
      )
    ),
    FlexDirection.ROW
  )
}

//网格
function scanByGridlayout(group: InputNode): InputNode {
  const { type } = group
  if (type === NodeType.GROUP) {
    const dir = getDirection2(group)
    if (dir === FlexDirection.COLUMN && group.layers.length >= 2) {
      const layers = [...group.layers]
      let preGridLayers: InputNode[]
      for (let i = 1; i < layers.length; i++) {
        const layer = layers[i]
        let flush = true

        const prev = layers[i - 1]
        preGridLayers = preGridLayers || [prev]
        if (isSimilarGridLine(preGridLayers, layer)) {
          flush = false
          preGridLayers.push(layer)
        }

        //包含 i
        if (!flush && i === layers.length - 1) {
          i = layers.length
          flush = true
        }

        if (flush) {
          if (preGridLayers !== undefined && preGridLayers.length > 1) {
            layers.splice(i - preGridLayers.length, preGridLayers.length, mergeLines(preGridLayers))
            i = i - (preGridLayers.length - 1)
          }
          preGridLayers = undefined
        }
      }

      group.layers = layers
    }

    group.layers.forEach(scanByGridlayout)
  }

  return group
}

function isLeftRightLine(line: InputNode) {
  const { type } = line
  if (type === NodeType.GROUP) {
    const row = FlexDirection.ROW
    const isRow = getDirection2(line) === FlexDirection.ROW
    const notConfilcted = !isConflicted2(line)
    const is2Num = line.layers.length === 2
    const left = line.layers[0]
    const right = line.layers[1]
    const space = FrameUtil.getEnd(right.exactFrame, row) - FrameUtil.getStart(left.exactFrame, row)

    return (
      isRow &&
      notConfilcted &&
      is2Num &&
      space >= MAGIC_MARGIN &&
      FrameUtil.getStart(left.exactFrame, FlexDirection.COLUMN) !== FrameUtil.getStart(right.exactFrame, FlexDirection.COLUMN) &&
      FrameUtil.getEnd(left.exactFrame, FlexDirection.COLUMN) !== FrameUtil.getEnd(right.exactFrame, FlexDirection.COLUMN) &&
      FrameUtil.getCenter(left.exactFrame, FlexDirection.COLUMN) !== FrameUtil.getCenter(right.exactFrame, FlexDirection.COLUMN)
    )
  }
  return false
}

function isLeftLine(line: InputNode) {
  const children = decompose(line)
  if (children.length >= 2) {
    const notConfilcted = !isConflicted2(line)
    const isRow = getDirection2(line) === FlexDirection.ROW
    if (isRow && notConfilcted) {
      const spaces = children
        .map(l => l.exactFrame)
        .map((f, i, arr) => {
          if (i >= 1) {
            const p = arr[i - 1]
            return FrameUtil.getStart(f, FlexDirection.ROW) - FrameUtil.getEnd(p, FlexDirection.ROW)
          }
          return 0
        })
        .slice(1)

      return spaces.every(space => space < MAGIC_MARGIN)
    } else {
      return false
    }
  }
  return true
}

function tryMergeLeftRightLine(line0: InputNode, line1: InputNode): InputNode {
  if (line0 === undefined || line1 === undefined) {
    return
  }

  let left0: InputNode
  let left1: InputNode
  let right: InputNode
  let offset: number

  if (isLeftLine(line0) && isLeftRightLine(line1)) {
    left0 = line0
    left1 = line1.layers[0]
    right = line1.layers[1]

    offset = FrameUtil.getCenter(left1.exactFrame, FlexDirection.COLUMN) - FrameUtil.getCenter(right.exactFrame, FlexDirection.COLUMN)
  } else if (isLeftRightLine(line0) && isLeftLine(line1)) {
    left0 = line0.layers[0]
    right = line0.layers[1]
    left1 = line1

    offset = FrameUtil.getCenter(left0.exactFrame, FlexDirection.COLUMN) - FrameUtil.getCenter(right.exactFrame, FlexDirection.COLUMN)
  }

  if (left0 && left1 && right) {
    const leftFrame = FrameUtil.expandFrames(left0.exactFrame, left1.exactFrame)
    const rightFrame = right.exactFrame

    const hasMargin = isMagicMargin(FrameUtil.getEnd(rightFrame, FlexDirection.ROW) - FrameUtil.getStart(leftFrame, FlexDirection.ROW))

    const newOffset = FrameUtil.getCenter(leftFrame, FlexDirection.COLUMN) - FrameUtil.getCenter(rightFrame, FlexDirection.COLUMN)

    if (hasMargin && Math.abs(newOffset) <= Math.abs(offset) + 2) {
      return compose(
        [
          compose(
            [left0, left1],
            FlexDirection.COLUMN
          ),
          right
        ],
        FlexDirection.ROW
      )
    }
  }
}

//左右
function scanByRightCenter(group: InputNode): InputNode {
  const { type } = group
  if (type === NodeType.GROUP) {
    const dir = getDirection2(group)
    if (dir === FlexDirection.COLUMN && group.layers.length >= 2) {
      const layers = [...group.layers]

      for (let i = 0; i < layers.length; i++) {
        const merge = tryMergeLeftRightLine(layers[i - 1], layers[i])
        if (merge !== undefined) {
          layers.splice(i - 1, 2, merge)
          i--
        }
      }
      group.layers = layers
    }

    group.layers.forEach(scanByRightCenter)
  }

  return group
}

function log(input: InputNode, tabs = 0) {
  const prefix = fill(tabs + 1, '').join('\t')
  console.log(prefix + input.id)

  if (input.type === NodeType.GROUP) {
    input.layers.forEach(l => log(l, tabs + 1))
  }
}

//打上left center ？左中右
function isAuxiliaryLineLike(layer: InputNode, auxiliaryLine: number, align: SpecialAlign): boolean {
  if (layer !== undefined && !isConflicted2(layer)) {
    const arr = decompose(layer)
    const child = arr[0]
    if (align === SpecialAlign.START) {
      if (FrameUtil.getStart(child.exactFrame, FlexDirection.ROW) === auxiliaryLine) {
        return true
      }
    } else if (align === SpecialAlign.CENTER) {
      if (FrameUtil.getCenter(child.exactFrame, FlexDirection.ROW) === auxiliaryLine) {
        return true
      }
    } else if (align === SpecialAlign.END) {
      if (FrameUtil.getEnd(child.exactFrame, FlexDirection.ROW) === auxiliaryLine) {
        return true
      }
    }
  }
  return false
}

function extendAuxiliaryLine(layers: InputNode[], auxiliaryLine: number, align: SpecialAlign): InputNode[] {
  const arr = []
  for (const layer of layers) {
    if (isAuxiliaryLineLike(layer, auxiliaryLine, align)) {
      arr.push(layer)
    } else {
      break
    }
  }
  return arr
}

function scanByAuxiliaryLine(group: InputNode) {
  groupByAuxiliaryLineRaw(group, SpecialAlign.START, true)
  return group
}

function groupByAuxiliaryLineRaw(group: InputNode, align: SpecialAlign, isTopToBottom: boolean): InputNode {
  const { type } = group
  if (type === NodeType.GROUP) {
    const dir = getDirection2(group)
    if (dir === FlexDirection.COLUMN) {
      const layers = isTopToBottom ? decompose(group) : decompose(group).reverse()

      for (let i = 0; i < layers.length - 1; i++) {
        const curLayer = layers[i]

        if (!isConflicted2(curLayer)) {
          const arr = align !== SpecialAlign.END ? decompose(curLayer) : decompose(curLayer).reverse()

          //找一个最合适的 ？
          for (let j = 1; j < arr.length; j++) {
            const child = arr[j]

            let auxiliaryLine
            if (align === SpecialAlign.START) {
              auxiliaryLine = FrameUtil.getStart(child.exactFrame, FlexDirection.ROW)
            } else if (align === SpecialAlign.END) {
              auxiliaryLine = FrameUtil.getEnd(child.exactFrame, FlexDirection.ROW)
            } else if (align === SpecialAlign.CENTER) {
              auxiliaryLine = FrameUtil.getCenter(child.exactFrame, FlexDirection.ROW)
            }

            const lines = extendAuxiliaryLine(layers.slice(i + 1), auxiliaryLine, align)

            if (lines.length >= 1) {
              lines.forEach(line => {
                line.specailAlign = SpecialAlign.START
                console.log('specailAlign', line.id)
              })
              break
            }
          }
        }
      }

      group.layers = isTopToBottom ? layers : layers.reverse()
    }

    group.layers.forEach(layer => groupByAuxiliaryLineRaw(layer, align, isTopToBottom))
  }
  return group
}

function mergeBackground(group: InputNode) {
  const { type } = group
  if (type === NodeType.GROUP) {
    const backgrounds = group.layers.filter(child => child.type === NodeType.SHAPE && FrameUtil.equals(group.exactFrame, child.exactFrame))
    const bg0 = backgrounds[0]
    //zIndex
    if (backgrounds.length >= 1 && isEmpty(group.styles) && (group.layers[0] === bg0 || bg0.styles.backgroundColor === undefined)) {
      if (bg0.styles === undefined || bg0.styles.opacity === undefined || bg0.styles.opacity === 1) {
        group.styles = { ...bg0.styles }
        group.layers = group.layers.filter(child => child !== bg0)
        console.log('mergeBackground', bg0.id, group.id)
      }
    }

    group.layers.forEach(mergeBackground)
  }

  return group
}

function mergeOneChild(group: InputNode, parent?: InputNode) {
  const { type } = group
  if (type === NodeType.GROUP) {
    if (parent !== undefined) {
      if (group.layers.length === 1) {
        const child = group.layers[0]
        const couldGroupIgnored = isEmpty(group.styles)
        const couldChildIgnored = child.type === NodeType.GROUP && isEmpty(child.styles)

        if (couldGroupIgnored) {
          const index = parent.layers.indexOf(group)
          parent.layers.splice(index, 1, child)
          console.log('mergeOneChild-group', child.id, group.id)
        } else if (couldChildIgnored) {
          group.layers = child.layers
          console.log('mergeOneChild-child', child.id, group.id)
        }
      }
    }

    group.layers.forEach(child => mergeOneChild(child, group))
  }

  return group
}

//增加一层扫描？  left， right， left
// （左右2个元素）   基线不对齐，
// 下一行一个 。。。一个

//扫描 text， shape，

export function regroup(elements: InputNode[], polyfilled: InputNode): InputNode {
  // resetIdGenerator()
  // const cloned = clone(input)
  // //polyfilled
  // const polyfilled = inputPolyfil(cloned)
  // //拍平
  // const elements = applanate(polyfilled)
  //递归构建
  let root = unite(elements)
  //尽量扁平
  root = flattenGroup(root)
  //排序
  root = sortChildren(root)
  //感知基线
  root = scanByAuxiliaryLine(root)
  //尽量合并
  root = scanBySeperate(root)
  //处理grid
  root = scanByGridlayout(root)
  //基线|中间线
  root = scanByRightCenter(root)
  //合并bg
  root = mergeBackground(root)
  //合并one-child
  root = mergeOneChild(root)

  root.frame = { ...polyfilled.frame }
  root.exactFrame = { ...polyfilled.exactFrame }
  root.styles = { ...polyfilled.styles }

  log(root)

  return root
  // tslint:disable-next-line:max-file-line-count
}
