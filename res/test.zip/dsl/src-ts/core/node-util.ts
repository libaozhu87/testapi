import { Property } from './property'
import { NodeType, Node, Group } from './../define/node'
import { buildNode } from './node-factory'
import isEmpty from './../primitive/isEmpty'
import { InputNode } from './../define/input-node'
import { FrameUtil } from './frame-util'
import remove from './../primitive/remove'
import { newId } from './id-generate'

export interface RootContainer {
  root: Node
}

export abstract class NodeUtil {
  public static visitNodeTree(
    node: Node,
    property: Property,
    visiter: (node: Node, property: Property, rootContainer: RootContainer) => any
  ): Node {
    const container = { root: node }
    NodeUtil._visitNodeTree(node, property, visiter, container)
    return container.root
  }

  private static _visitNodeTree(
    node: Node,
    property: Property,
    visiter: (node: Node, property: Property, rootContainer?: RootContainer) => any,
    rootContainer: RootContainer
  ) {
    visiter(node, property, rootContainer)

    if (node.type === NodeType.GROUP) {
      property.getChildren(node).forEach(child => NodeUtil._visitNodeTree(child, property, visiter, rootContainer))
    }
  }

  public static visitNodeTreeReverse(
    node: Node,
    property: Property,
    visiter: (node: Node, property: Property, rootContainer?: RootContainer) => any,
    rootContainer?: RootContainer
  ): Node {
    const container = { root: node }
    NodeUtil._visitNodeTreeReverse(node, property, visiter, container)
    return container.root
  }

  private static _visitNodeTreeReverse(
    node: Node,
    property: Property,
    visiter: (node: Node, property: Property, rootContainer: RootContainer) => any,
    rootContainer: RootContainer
  ) {
    if (node.type === NodeType.GROUP) {
      property.getChildren(node).forEach(child => NodeUtil._visitNodeTreeReverse(child, property, visiter, rootContainer))
    }

    visiter(node, property, rootContainer)
  }

  public static prevSlibing(child: Node, property: Property) {
    const { parent } = child
    const contentChildren = property.getLinearChildren(parent)
    const index = contentChildren.indexOf(child)
    if (index === -1) {
      throw new Error(``)
    }
    return contentChildren[index - 1]
  }

  public static nextSlibing(child: Node, property: Property) {
    const { parent } = child
    const contentChildren = property.getLinearChildren(parent)
    const index = contentChildren.indexOf(child)
    if (index === -1) {
      throw new Error(``)
    }
    return contentChildren[index + 1]
  }

  public static newGroup(nodes: Node[], parent: Group): Group {
    if (nodes.length === 0) {
      throw new Error(``)
    }

    const frame = nodes.map(node => node.frame).reduce(FrameUtil.expand, undefined)
    const exactFrame = nodes.map(node => node.exactFrame).reduce(FrameUtil.expand, undefined)

    const input: InputNode = {
      name: '@GeneratedGroup',
      id: 'a' + newId(),
      type: NodeType.GROUP, // text|image|shape|group
      frame, //相对父容器
      exactFrame,
      layers: undefined, //如果是 group 就会有
      value: undefined, //text or image.src
      styles: undefined, //描述 shape
      textStyles: undefined, //描述 text
      imageStyles: undefined, //描述 image
      zIndex: 0
    }

    const newGroup = buildNode(input, parent) as Group

    newGroup.measured = nodes.map(node => node.measured).reduce(FrameUtil.expand, undefined)

    newGroup.children = nodes
    nodes.forEach(child => {
      child.parent = newGroup
      child.measured.x = child.measured.x - newGroup.measured.x
      child.measured.y = child.measured.y - newGroup.measured.y
    })

    const index = parent.children.indexOf(nodes[0])

    if (index < 0) {
      throw new Error(``)
    }

    nodes.forEach(node => {
      remove(parent.children, node)
    })

    parent.children.splice(index, 0, newGroup)

    return newGroup
  }

  public static getChildrenBetweens(group: Group, children: Node[], property: Property): number[] {
    if (isEmpty(children)) {
      return []
    }

    const dir = group.layout.flexDirection
    return children
      .map(child => {
        const prevChild = NodeUtil.prevSlibing(child, property)
        const end = prevChild ? FrameUtil.getEnd(prevChild.measured, dir) : 0
        const start = FrameUtil.getStart(child.measured, dir)
        return start - end
      })
      .slice(1)
  }

  public static getChildrenArounds(group: Group, children: Node[], property: Property): number[] {
    if (isEmpty(children)) {
      return []
    }

    const head = children[0]
    const tail = children[children.length - 1]

    const dir = group.layout.flexDirection

    const first = FrameUtil.getStart(head.measured, dir)
    return [first]
      .concat(NodeUtil.getChildrenBetweens(group, children, property))
      .concat(FrameUtil.getLength(group.measured, dir) - FrameUtil.getEnd(tail.measured, dir))
  }
}
