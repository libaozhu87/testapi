/**
 * test - absolute - center ?
 * column-flex-end margin-bottom ?
 *
 * 1. background - absolute ？
 * 2. zIndex done
 * 3. big margin 合并的问题， similar 合并问题 done
 *
 *
 * 3. 相识合并问题 ?
 *  2个 左右
 *  3个 左中右
 *  4个？
 * 4. 可干预的固定的模式 ？
 * 5. 水平，垂直合并优先级 ? => margin 和 居中匹配对
 *
 * 4. 去重 done
 *
 * 特别大的padding
 * max-height ?
 *
 *
 * similar grid-layout ？
 *
 *  padding && margin   => add
 *
 *  flex-start -> flex-start
 *
 * 纯色图片
 * 图片打框 -》 精确大小 ？
 * 图片压缩 =》 分割线
 *
 * 绝对
 *
 * //
 * 左中右
 * //
 *
 * 高度不定 副轴布局中用 margin ？
 *
 *  图片
 *  //image-view id - src => start
 *  LinearLayout => gravity padding margin orientation layout_width layout_height
 *  RelativeLayout => space-between
 *  FrameLayout => absolut fixed
 *      -》
 *
 * 纯色图片， 需要合并的图片（absolute），超过屏幕范围的shape
 */
