import { Property } from './property'
import { Node, NodeType, Text, Shape, Group } from './../define/node'
import { NodeUtil } from './node-util'
import { PositionType } from './../define/flex-type'

function randomColor() {
  const r = ('0' + Math.floor(Math.random() * 256).toString(16)).slice(-2)
  const g = ('0' + Math.floor(Math.random() * 256).toString(16)).slice(-2)
  const b = ('0' + Math.floor(Math.random() * 256).toString(16)).slice(-2)

  return '#' + r + g + b
}

export function randomBackground(node: Node, property: Property) {
  const def = {
    opacity: undefined,
    //border
    borderStyle: undefined,
    borderWidth: undefined,
    borderRadius: undefined,
    borderColor: undefined,
    //background
    backgroundColor: undefined,
    backgroundImage: undefined
  }

  const { type } = node
  if (type === NodeType.GROUP) {
    const group = node as Group
    group.styles = group.styles || def
    group.styles.backgroundColor = randomColor()
  } else if (type === NodeType.TEXT) {
    const text = node as Text
    text.styles = text.styles || def
    text.styles.backgroundColor = randomColor()
  } else if (type === NodeType.SHAPE) {
    const shape = node as Shape
    shape.styles = shape.styles || def
    shape.styles.backgroundColor = randomColor()
  }
}

export function debug(node: Node, property: Property) {
  if (property.isDebug()) {
    NodeUtil.visitNodeTree(node, property, (n, p) => {
      if (n.layout.position === PositionType.ABSOLUTE) {
        randomBackground(n, p)
      }
    })
  }
}
