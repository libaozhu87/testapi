import { Node, NodeType, Group, Text } from './../define/node'
import { PositionType, FlexDirection } from './../define/flex-type'
import { Platform } from './../define/platform'
import isEmpty from './../primitive/isEmpty'
import min from './../primitive/min'
import { Cfg } from './cfg'
import endsWith from './../primitive/endsWith'

export class Property {
  private _logicalWidth = 750
  private _platform = Platform.WEEX
  private _debug = false
  private _page: string

  public constructor(cfg: Cfg) {
    this._platform = cfg.platform
    this._debug = cfg.debug
    this._page = cfg.page
  }

  public minZIndex(node: Node) {
    const { type } = node
    if (type === NodeType.GROUP) {
      const group = node as Group
      return min(group.children.map(child => this.minZIndex(child)))
    } else {
      return node.zIndex
    }
  }

  public getChildren(node: Node) {
    if (node.type === NodeType.GROUP) {
      return (node as Group).children
    }
    return []
  }

  // public getChildrenExceptBackground(node: Node) {
  //   return this.getChildren(node).filter(child => !this.isMatchParentSize(child))
  // }

  public getMarkedChildren(node: Node) {
    return this.getChildren(node).filter(child => this.isMarkedNode(child))
  }

  public getBackgroundChildren(node: Node) {
    return this.getChildren(node).filter(child => this.isMatchParentSize(child))
  }

  public getLinearChildren(node: Node) {
    return this.getChildren(node).filter(child => child.layout.position !== PositionType.ABSOLUTE)
  }

  public isDivider(node: Node, dir: FlexDirection) {
    const { type } = node
    if (type === NodeType.SHAPE || type === NodeType.IMAGE) {
      if (dir === FlexDirection.COLUMN) {
        return node.measured.width / node.measured.height >= 32 && node.measured.width >= 200
      } else if (dir === FlexDirection.ROW) {
        return node.measured.height / node.measured.width >= 32 && node.measured.height >= 200
      }
    }
    return false
  }

  //text special
  public isFixedTextWidth(node: Node) {
    if (node.type === NodeType.TEXT) {
      const text = node as Text
      if (text.textStyles.lineHeight > 0 && text.frame.height > text.textStyles.lineHeight * 1.5) {
        return true
      } else if (endsWith(text.value, '…') || endsWith(text.value, '...')) {
        return true
      }
    }
    return false
  }

  public isMultiLinesText(node: Node) {
    if (node.type === NodeType.TEXT) {
      const text = node as Text
      if (text.textStyles.lines > 0) {
        return true
      } else if (text.textStyles.lineHeight > 0 && text.frame.height > text.textStyles.lineHeight * 1.5) {
        return true
      }
    }
    return false
  }

  public isSingleLinesText(node: Node) {
    if (node.type === NodeType.TEXT) {
      return !this.isMultiLinesText(node)
    }
    return false
  }

  public getLogicalWidth() {
    return this._logicalWidth
  }

  public setLogicalWidth(value: number) {
    this._logicalWidth = value
  }

  public getPlatform() {
    return this._platform
  }

  public isDebug() {
    return this._debug
  }

  public getPage(): string {
    return this._page
  }

  public hasValidBackground(node: Node) {
    const { type } = node
    if (type === NodeType.GROUP) {
      const group = node as Group
      const { styles } = group
      if (styles) {
        if (!isEmpty(styles)) {
          return true
        }
      }
    }
    return false
  }

  public isMatchParentSize(node: Node): boolean {
    const { parent } = node
    if (parent !== undefined) {
      return (
        parent.measured.width === node.measured.width &&
        parent.measured.height === node.measured.height &&
        node.measured.x === 0 &&
        node.measured.y === 0
      )
    }
    return false
  }

  //是不是标记的layer
  private isMarkedNode(node: Node) {
    return false
  }
}
