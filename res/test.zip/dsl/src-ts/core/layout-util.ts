import { FlexDirection, Transform } from './../define/flex-type'
import { Layout } from './../define/layout'
import { Node } from './../define/node'
import { Frame } from './../define/frame'

export const TOP_INDEX = 0
export const RIGHT_INDEX = 1
export const BOTTOM_INDEX = 2
export const LEFT_INDEX = 3

export abstract class LayoutUtil {
  public static setLength(layout: Layout, dir: FlexDirection, value: number) {
    if (dir === FlexDirection.ROW) {
      layout.width = value
    } else {
      layout.height = value
    }
  }

  public static getLength(layout: Layout, dir: FlexDirection): number {
    if (dir === FlexDirection.ROW) {
      return layout.width
    } else {
      return layout.height
    }
  }

  public static isFixed(layout: Layout, dir: FlexDirection): boolean {
    return LayoutUtil.getLength(layout, dir) !== undefined
  }

  public static setPositionStart(layout: Layout, dir: FlexDirection, value: number) {
    if (dir === FlexDirection.ROW) {
      layout.left = value
    } else {
      layout.top = value
    }
  }

  public static setPositionEnd(layout: Layout, dir: FlexDirection, value: number) {
    if (dir === FlexDirection.ROW) {
      layout.right = value
    } else {
      layout.bottom = value
    }
  }

  public static setMarginStart(layout: Layout, dir: FlexDirection, value: number) {
    if (dir === FlexDirection.ROW) {
      layout.margin[LEFT_INDEX] = value
    } else {
      layout.margin[TOP_INDEX] = value
    }
  }

  public static setMarginEnd(layout: Layout, dir: FlexDirection, value: number) {
    if (dir === FlexDirection.ROW) {
      layout.margin[RIGHT_INDEX] = value
    } else {
      layout.margin[BOTTOM_INDEX] = value
    }
  }

  public static setPaddingStart(layout: Layout, dir: FlexDirection, value: number) {
    if (dir === FlexDirection.ROW) {
      layout.padding[LEFT_INDEX] = value
    } else {
      layout.padding[TOP_INDEX] = value
    }
  }

  public static setPaddingEnd(layout: Layout, dir: FlexDirection, value: number) {
    if (dir === FlexDirection.ROW) {
      layout.padding[RIGHT_INDEX] = value
    } else {
      layout.padding[BOTTOM_INDEX] = value
    }
  }

  public static getFrameBoxWithMargin(node: Node): Frame {
    const box = { ...node.measured }

    let left = box.x
    let right = box.x + box.width
    let top = box.y
    let bottom = box.y + box.height

    if (node.layout.margin) {
      node.layout.margin.forEach((v, index) => {
        if (v !== undefined) {
          switch (index) {
            case TOP_INDEX:
              top -= v
              break
            case RIGHT_INDEX:
              right += v
              break
            case BOTTOM_INDEX:
              bottom += v
              break
            case LEFT_INDEX:
              left -= v
          }
        }
      })
    }

    return { x: left, y: top, width: right - left, height: bottom - top }
  }

  public static setTransformForCenter(layout: Layout, dir: FlexDirection) {
    const add = dir === FlexDirection.ROW ? Transform.X_50 : Transform.Y_50
    if (layout.transform === undefined || layout.transform === add) {
      layout.transform = add
    } else if (layout.transform !== add) {
      layout.transform = Transform.XY_50
    }
  }

  public static getPadding(layout: Layout, index: number): number {
    if (layout && layout.padding) {
      return layout.padding[index]
    }
  }
}
