import { FlexDirection } from './../define/flex-type'

export abstract class DirectionUtil {
  public static cross(dir: FlexDirection): FlexDirection {
    if (dir === FlexDirection.COLUMN) {
      return FlexDirection.ROW
    } else if (dir === FlexDirection.ROW) {
      return FlexDirection.COLUMN
    }
  }
}
