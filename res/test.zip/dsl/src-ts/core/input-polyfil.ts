import { InputNode } from './../define/input-node'
import { FrameUtil } from './frame-util'
import isEmpty from './../primitive/isEmpty'
import { NodeType } from './../define/node'

export default function inputPolyfil(node: InputNode) {
  const { type } = node
  if (type === NodeType.GROUP && !isEmpty(node.layers)) {
    node.layers.forEach(inputPolyfil)
  }

  node.frame = FrameUtil.round(node.frame)
  node.exactFrame = { ...node.frame }

  // node.exactFrame = node.layers.map(layer => layer.exactFrame).reduce(FrameUtil.expand, undefined)
  //node.exactFrame = { ...node.frame }

  if (type === NodeType.GROUP) {
    node.exactFrame = node.layers.map(layer => layer.exactFrame).reduce(FrameUtil.expand, undefined)
  } else if (type === NodeType.TEXT) {
    const { textStyles } = node
    textStyles.fontSize = Math.round(Number(textStyles.fontSize))
    if (textStyles.lineHeight !== undefined) {
      textStyles.lineHeight = Math.round(Number(textStyles.lineHeight))
      if (textStyles.lineHeight > textStyles.fontSize) {
        const padding = (textStyles.lineHeight - textStyles.fontSize) / 2
        node.exactFrame.y += padding
        node.exactFrame.height -= padding * 2
        node.exactFrame = FrameUtil.round(node.exactFrame)
      }
    }

    if (textStyles.lineHeight === undefined || node.frame.height <= textStyles.lineHeight * 1.5) {
      textStyles.textAlign = undefined
    }
  }

  if (type === NodeType.SHAPE) {
    if (node.styles.borderRadius !== undefined) {
      node.styles.borderRadius = Math.round(node.styles.borderRadius)
    }

    ;['cornerRadiusString', 'fillType'].forEach(k => (node.styles[k] = undefined))
  }

  return node
}
