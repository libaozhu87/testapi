import { Property } from './property'
import { Node, NodeType, Group } from './../define/node'
import { NodeUtil } from './node-util'
import { LayoutUtil } from './layout-util'
import { JustifyContent, FlexDirection } from './../define/flex-type'
import { CENTER_ERROR, MAGIC_MARGIN } from './magic'
import { FrameUtil } from './frame-util'

function justifyContent(node: Node, property: Property) {
  if (node.layout.justifyContent === undefined) {
    node.layout.justifyContent = forecastJustifyContent(node, property)
  }
}

function fixNodeMainAxis(node: Node, property: Property) {
  const { type } = node
  if (type === NodeType.GROUP) {
    const group = node as Group
    if (group.layout.justifyContent === JustifyContent.SPACE_BETWEEN || group.specialLayout !== undefined) {
      const dir = node.layout.flexDirection
      if (!LayoutUtil.isFixed(node.layout, dir)) {
        LayoutUtil.setLength(node.layout, dir, FrameUtil.getLength(node.measured, dir))
      }
    }
  }
}

export function measureJustifyContent(node: Node, property: Property): Node {
  return NodeUtil.visitNodeTreeReverse(node, property, justifyContent)
}

export function fixMainAxis(node: Node, property: Property): Node {
  return NodeUtil.visitNodeTreeReverse(node, property, fixNodeMainAxis)
}

//居中率
function isCenter(start: number, end: number, length: number): boolean {
  const min = Math.min(start, end)
  const max = Math.max(start, end)
  const offset = max - min
  if (min === 0) {
    return false
  }
  const centerRate = 1 - offset / min
  return centerRate >= 0.9 && offset <= CENTER_ERROR * 2
}

function handleCommon(group: Group, property: Property) {
  const contentChildren = property.getLinearChildren(group)
  const length = contentChildren.length

  if (length >= 1) {
    const dir = group.layout.flexDirection

    const spaces = NodeUtil.getChildrenArounds(group, contentChildren, property)
    const start = spaces[0]
    const end = spaces[spaces.length - 1]
    const length = FrameUtil.getLength(group.measured, dir)

    if (isCenter(start, end, length)) {
      return JustifyContent.CENTER
    } else if (start - end >= MAGIC_MARGIN && dir === FlexDirection.ROW) {
      return JustifyContent.FLEX_END
    } else {
      return JustifyContent.FLEX_START
    }
  } else {
    //no child
    return JustifyContent.FLEX_START
  }
}

function forecastJustifyContent(node: Node, property: Property): JustifyContent {
  if (node.layout.justifyContent) {
    return node.layout.justifyContent
  }

  const { type } = node
  if (type === NodeType.GROUP) {
    const group = node as Group
    if (group.specialLayout !== undefined) {
      return JustifyContent.SPACE_BETWEEN
    }
    return handleCommon(group, property)
  }
}
