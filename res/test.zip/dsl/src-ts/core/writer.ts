import * as fs from 'fs'
import * as path from 'path'

import { Async } from './../primitive/Async'

export interface Writeable {
  type: string
  path: string
  context: any
}

export abstract class WriteUtil {
  public static write(rPath: string, context: string, cb?) {
    const full = path.resolve(rPath)
    console.log(full)

    console.log('-------------')
    console.log(WriteUtil.ensureDir(path.dirname(full)))

    const worker = new Async()
      //dir

      .sequence(WriteUtil.ensureDir(path.dirname(full)))
      //file
      .then((v, ctx) => {
        fs.writeFile(full, context, err => {
          ctx.accept(err, `write ${full} success!`)
        })
      })
      .log()

    worker.invoke(true, (e, v, ctx) => {
      if (cb) {
        cb(e, v)
      }
    })
  }

  public static writeObject(rPath: string, obj: object, cb?) {
    const str = 'export default ' + JSON.stringify(obj, undefined, 2)
    WriteUtil.write(rPath, str, cb)
  }

  public static async(writeable: Writeable): Async {
    return new Async().then((v, ctx) => {
      if (writeable.type === 'object') {
        WriteUtil.writeObject(writeable.path, writeable.context, err => ctx.accept(err, true))
      } else if (writeable.type === 'string') {
        WriteUtil.write(writeable.path, writeable.context, err => ctx.accept(err, true))
      } else {
        throw new Error(`${writeable.type}`)
      }
    })
  }

  public static ensureDir(dirname): Async {
    return new Async().then((v, ctx) => {
      fs.exists(dirname, exists => {
        if (exists) {
          ctx.next(true)
        } else {
          WriteUtil.ensureDir(path.dirname(dirname)).invoke(true, err => {
            if (err) {
              ctx.error(err)
            } else {
              fs.mkdir(dirname, undefined, err => {
                if (!err) {
                  console.log(`mkdir ${dirname} success!`)
                }
                ctx.accept(err, true)
              })
            }
          })
        }
      })
    })
  }
}
