import { Node } from './../define/node'
import { Property } from './property'
import { NodeUtil } from './node-util'

export function clean(root: Node, property: Property): Node {
  NodeUtil.visitNodeTree(root, property, child => {
    child.parent = undefined

    if (child.layout.padding.every(padding => padding === undefined)) {
      child.layout.padding = undefined
    }

    if (child.layout.margin.every(margin => margin === undefined)) {
      child.layout.margin = undefined
    }
  })
  return root
}
