import { InputNode } from './../../define/input-node'
import { Frame } from './../../define/frame'
import unique from './../../primitive/unique'
import flatten from './../../primitive/flatten'
import compact from './../../primitive/compact'
import clone from './../../primitive/clone'
import inputPolyfil from './../input-polyfil'
import { color2int, alpha } from './../../template/color-util'
import { NodeType } from './../../define/node'

import { newId } from './../id-generate'

function isValidNode(node: InputNode) {
  if (!node.type) {
    throw new Error(JSON.stringify(node))
  }

  return node.type !== NodeType.GROUP && node.frame.width > 0 && node.frame.height > 0
}

function applanate(node: InputNode, result: InputNode[] = []): InputNode[] {
  if (node.type === NodeType.GROUP) {
    node.layers.forEach(layer => applanate(layer, result))
  } else if (isValidNode(node)) {
    node.zIndex = newId()
    node.id = node.type[0] + node.zIndex
    result.push(node)
  }
  return result
}

interface Drawable extends Frame {
  fill: number
  ref: string
}

interface Canvas {
  draw(drawable: Drawable)
  getUsedRefs(): string[]
}

interface Pixel {
  fill: number
  refs: string[]
}

class FastCanvas implements Canvas {
  private canvas: Pixel[]
  private width: number
  // private height: number

  public constructor(width: number, height: number) {
    this.width = width
    // this.height = height
    this.canvas = Array.apply(undefined, Array(width * height))
  }

  public draw(drawable: Drawable) {
    const { x, y, width, height, fill, ref } = drawable
    const r = x + width
    const b = y + height

    //-1 => any
    if (fill === -1) {
      for (let i = x; i < r; i++) {
        for (let j = y; j < b; j++) {
          const index = i + j * this.width
          const pix: Pixel = this.canvas[index] || (this.canvas[index] = { fill: undefined, refs: [] })
          pix.fill = fill
          pix.refs.push(ref)
        }
      }
    } else {
      for (let i = x; i < r; i++) {
        for (let j = y; j < b; j++) {
          const index = i + j * this.width
          const pix: Pixel = this.canvas[index] || (this.canvas[index] = { fill: undefined, refs: [] })
          if (pix.fill !== fill) {
            pix.fill = fill
            pix.refs = [ref]
          }
        }
      }
    }
  }

  public getUsedRefs() {
    const compacted: Pixel[] = compact(this.canvas)
    return unique(flatten(compacted.map(p => p.refs)))
  }
}

function node2drawables(input: InputNode, width: number, height: number): Drawable[] {
  const { type, styles } = input
  const ref = '' + input.id
  if (type === NodeType.SHAPE && styles.backgroundImage === undefined) {
    if (styles.borderColor || styles.backgroundColor) {
      const backgroundColor = color2int(styles.backgroundColor)
      if (backgroundColor !== undefined && alpha(backgroundColor) !== 255) {
        return [{ ...input.exactFrame, fill: -1, ref }]
      }

      const box = input.exactFrame
      const ds: Drawable[] = []
      const borderColor = color2int(styles.borderColor)
      const offset = (styles.borderRadius || 0) + (styles.borderWidth || 0)

      if (borderColor !== undefined) {
        //any
        ds.push({ x: box.x, y: box.y, width: box.width, height: offset, fill: -1, ref })
        ds.push({ x: box.x, y: box.y + box.height - offset, width: box.width, height: offset, fill: -1, ref })
        ds.push({ x: box.x, y: offset, width: offset, height: box.height - offset * 2, fill: -1, ref })
        ds.push({
          x: box.x + box.width - offset,
          y: box.y + offset,
          width: offset,
          height: box.height - offset * 2,
          fill: -1,
          ref
        })
      }

      if (backgroundColor !== undefined) {
        //color
        ds.push({
          x: box.x + offset,
          y: box.y + offset,
          width: box.width - offset * 2,
          height: box.height - offset * 2,
          fill: backgroundColor,
          ref
        })
      }
      return ds
    } else {
      return []
    }
  } else {
    //shape-backgroundImage, text, image
    return [{ ...input.exactFrame, fill: -1, ref }]
  }
}

export default function clean(input: InputNode): InputNode {
  //fill
  const cloned = clone(input)
  //polyfilled
  const polyfilled = inputPolyfil(cloned)

  const { width, height } = polyfilled.exactFrame
  // elements
  const canvas = new FastCanvas(width, height)

  const elements = applanate(polyfilled)
  flatten(elements.map(ele => node2drawables(ele, width, height))).forEach(drawable => {
    canvas.draw(drawable)
  })

  const refs = canvas.getUsedRefs()

  elements.filter(ele => refs.indexOf(ele.id) !== -1)
  //new group
  return undefined
}
