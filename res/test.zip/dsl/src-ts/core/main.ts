import { InputNode } from './../define/input-node'
import { Node } from './../define/node'
import { build } from './build'
import { regroup } from './regroup-new'
import { Property } from './property'
import { clean } from './clean'
import { weex } from './../template/weex'
import { measureDirection } from './measure-direction'
import { debug } from './debug'
import { measureSize } from './measure-size'
import { measurePositionType } from './measure-position-type'
import { measureJustifyContent, fixMainAxis } from './measure-justify-content'
import { measurePadding, fixCrossAxis } from './measure-padding'
import { measurePosition } from './measure-position'
import { measureCrossAlign } from './measure-cross-align'
import { measureSpecialLayout } from './measure-special-layout'
import { measurePositionTypePolyfill } from './measure-position-type-polyfill'
import { simplify } from './simplify'
// import console from './../primitive/logger'
import inputPolyfil from './input-polyfil'
import { Cfg, DefaultCfg } from './cfg'
import { WriteUtil } from './writer'
import format from './../primitive/format'
import compact from './../primitive/compact'
import applanate from './applanate'
import clone from './../primitive/clone'
//import { OSS } from 'ali-oss'

import { renderDSL, renderInput, renderElements, renderSkeletonScreenLoading, toSkeletonScreenLoadingDSL } from './../screenshot/render'
import { Async } from './../primitive/Async'
let OSS = require('ali-oss')

export interface Result {
  dsl: Node
  weex: string
  skeletonScreenLoadingDSL: Node
}

function genLabel(cfg: Cfg) {
  return compact([format('{_:d,yyyy-MM-dd}/{_:d,hh-mm-ss}', new Date()), cfg.fileName, cfg.artBoard]).join('_')
}

export function flexbox(input: InputNode, cfg: Cfg = DefaultCfg, needLog: boolean = true): Result {
  //property
  const property = new Property(cfg)
  property.setLogicalWidth(input.frame.width)
  const label = genLabel(cfg)

  const cloned = clone(input)

  //polyfilled
  const polyfilled = inputPolyfil(cloned)

  const elements = applanate(polyfilled)

  //regroup
  const regrouped = regroup(elements, polyfilled)

  //build
  let root = build(regrouped, property)

  //measure
  root = measureDirection(root, property)
  root = measurePositionType(root, property)
  root = measureSize(root, property)

  root = measureSpecialLayout(root, property)

  root = measurePositionTypePolyfill(root, property)

  //specialLayout
  root = fixMainAxis(root, property)
  //副轴 适当的扩张
  root = fixCrossAxis(root, property)

  //主轴
  root = measureJustifyContent(root, property)

  root = measureCrossAlign(root, property)

  root = measurePosition(root, property)

  root = measurePadding(root, property)

  //simplify
  root = simplify(root, property)

  debug(root, property)

  const weexContext = weex(root, undefined)
  // const html5 = localHtml(root, undefined)

  //clean
  clean(root, property)

  const ssl = toSkeletonScreenLoadingDSL(root)

  if (needLog) {
    /*     const client = new OSS({
      region: 'oss-cn-shanghai',
      endpoint: 'https://oss-cn-shanghai.aliyuncs.com',
      accessKeyId: 'LTAI9M8mYxezKscr',
      accessKeySecret: 'b9oKSR9mK29MDoXpXb8XkdwgAsENSu',
      bucket: 'sketchtest'
    }) */
    new Async()
      .sequence(
        // WriteUtil.async({ type: 'string', path: `public/logs/${label}/index.html`, context: html5 }),
        WriteUtil.async({ type: 'object', path: `public/logs/${label}/input.js`, context: input }),
        WriteUtil.async({ type: 'object', path: `public/logs/${label}/elements.js`, context: elements }),
        WriteUtil.async({ type: 'object', path: `public/logs/${label}/regrouped.js`, context: regrouped }),
        WriteUtil.async({ type: 'object', path: `public/logs/${label}/dsl.js`, context: root }),
        WriteUtil.async({ type: 'object', path: `public/logs/${label}/ssl.js`, context: ssl }),
        WriteUtil.async({ type: 'string', path: `public/logs/${label}/index.vue`, context: weexContext }),

        renderInput(polyfilled, elements, `public/logs/${label}/input-screenshot.png`),
        renderDSL(root, `public/logs/${label}/screenshot.png`),
        renderDSL(ssl, `public/logs/${label}/skeleton-screen-loading.png`),
        WriteUtil.ensureDir(`public/logs/${label}/nodes`),
        ...renderElements(root, `public/logs/${label}/nodes`),
        WriteUtil.ensureDir(`public/logs/${label}/cards`),
        ...root.children.map((child, i) => renderDSL(child as Node, `public/logs/${label}/cards/card${i}-${child.id}.png`))
      )
      .invoke(true)
  }

  // fixType(root)

  return {
    dsl: root,
    skeletonScreenLoadingDSL: ssl,
    weex: weexContext
  }
}

// export { regroup } from './regroup'
export { weex } from './../template/weex'
