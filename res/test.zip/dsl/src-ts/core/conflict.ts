import { Node, Group, NodeType } from './../define/node'
import { FlexDirection, PositionType } from './../define/flex-type'
import { BaseNode } from './../define/base-node'
import { Property } from './property'
import { zipDiagonal } from './../primitive/zip'
import { measureOverlapOnDir, area } from './math'
import { Frame } from './../define/frame'
import top from './../primitive/top'
import flatten from './../primitive/flatten'
import unique from './../primitive/unique'
import assert from './../primitive/assert'
import { CONFLICT_ERROR } from './magic'
import { InputNode } from './../define/input-node'
import console from './../primitive/logger'

// weight   count, area
export interface FrameCarry<T extends BaseNode> {
  carry: T

  count?: number //冲突数量
  conflictValue?: number
  conflictRate?: number //冲突比例
  maxEffect?: number //冲突他人影响力
}

function filterConflicts<T extends BaseNode>(fc: FrameCarry<T>): boolean {
  const max = Math.max(fc.conflictRate, fc.maxEffect)
  return max >= CONFLICT_ERROR && (fc.conflictValue > 4 || max >= 1)
}

function findConflict<T extends BaseNode>(
  frameCarrys: Array<FrameCarry<T>>,
  conflictFunc: (l0: Frame, l1: Frame) => [number, number, number]
): Array<[FrameCarry<T>, FrameCarry<T>]> {
  const pairs: Array<[FrameCarry<T>, FrameCarry<T>]> = zipDiagonal(frameCarrys, frameCarrys)
  return pairs.filter(pair => conflictFunc(pair[0].carry.exactFrame, pair[1].carry.exactFrame).some(v => v > 0))
}

function solveConflict<T extends BaseNode>(
  conflicts: Array<[FrameCarry<T>, FrameCarry<T>]>,
  conflictFunc: (l0: Frame, l1: Frame) => [number, number, number],
  preferInTwo = false
): Array<FrameCarry<T>> {
  let conflictPairs = conflicts

  let solvedMode

  //-1, 0, 1
  function getLayerZIndexMode(carry: FrameCarry<T>): number {
    let mode
    for (const pair of conflictPairs) {
      let other
      if (pair[0] === carry) {
        other = pair[1]
      } else if (pair[1] === carry) {
        other = pair[0]
      }

      if (other !== undefined) {
        const newMode = other.carry.zIndex > carry.carry.zIndex ? -1 : 1
        if (mode === undefined) {
          mode = newMode
        } else if (mode !== newMode) {
          return 0
        }
      }
    }

    assert(mode !== undefined)
    return mode
  }

  function recount() {
    conflictPairs.forEach(pair => {
      pair.forEach(fc => {
        fc.count = 0
        fc.conflictRate = 0
        fc.maxEffect = 0
        fc.conflictValue = 0
      })
    })
    conflictPairs.forEach(pair => {
      const v2 = conflictFunc(pair[0].carry.exactFrame, pair[1].carry.exactFrame)
      pair.forEach((fc, i) => {
        fc.count++
        fc.conflictValue += v2[2]
        fc.conflictRate += v2[i]
        fc.maxEffect += v2[1 - i]
      })
    })
  }

  function findMostOverlap(): FrameCarry<T> {
    recount()
    const frameCarrys: Array<FrameCarry<T>> = unique(flatten(conflictPairs))

    frameCarrys.sort((f0, f1) => {
      if (f0.count === f1.count) {
        if (f0.maxEffect === f1.maxEffect) {
          return area(f0.carry.exactFrame) - area(f1.carry.exactFrame)
        }
        // return f0.count === 1 ? f0.maxEffect - f1.maxEffect : f1.maxEffect - f0.maxEffect
        return f1.maxEffect - f0.maxEffect
      }
      return f1.count - f0.count
    })

    //过滤不产生矛盾
    for (const one of frameCarrys) {
      const mode = getLayerZIndexMode(one)
      if (mode !== 0) {
        if (solvedMode === undefined || solvedMode === mode) {
          solvedMode = mode
          return one
        }
      }
    }

    //兜底
    return frameCarrys[0]
  }

  function removeOverlap(f: FrameCarry<T>) {
    conflictPairs = conflictPairs.filter(pair => pair[0] !== f && pair[1] !== f)
  }

  const overlaps: Array<FrameCarry<T>> = []

  while (conflictPairs.length > 0) {
    const frameCarry: FrameCarry<T> = findMostOverlap()
    assert(frameCarry !== undefined)
    overlaps.push({ ...frameCarry })
    removeOverlap(frameCarry)
  }

  if (preferInTwo && conflicts.length === 1) {
    const first = top(conflicts[0], (pre, cur) => {
      if (pre.carry.type !== cur.carry.type) {
        if (pre.carry.type === NodeType.IMAGE) {
          return -1
        } else if (cur.carry.type === NodeType.IMAGE) {
          return 1
        } else if (pre.carry.type === NodeType.GROUP) {
          return 1
        } else if (cur.carry.type === NodeType.GROUP) {
          return -1
        }
      }
      return area(pre.carry.exactFrame) - area(cur.carry.exactFrame)
    })
    return [{ ...first }]
  }

  return overlaps
}

export function tFindOverlaps<T extends BaseNode>(
  frameCarrys: Array<FrameCarry<T>>,
  conflictFunc: (l0: Frame, l1: Frame) => [number, number, number]
): T[] {
  return tRawFindOverlaps(frameCarrys, conflictFunc).map(frameCarry => frameCarry.carry)
}

export function strictFindOverlaps<T extends BaseNode>(
  frameCarrys: Array<FrameCarry<T>>,
  conflictFunc: (l0: Frame, l1: Frame) => [number, number, number]
): T[] {
  const conflicts = findConflict(frameCarrys, conflictFunc)
  const solvedConflicts = solveConflict(conflicts, conflictFunc)
  return solvedConflicts.map(frameCarry => frameCarry.carry)
}

export function tRawStrictFindOverlaps<T extends BaseNode>(
  frameCarrys: Array<FrameCarry<T>>,
  conflictFunc: (l0: Frame, l1: Frame) => [number, number, number]
): Array<FrameCarry<T>> {
  const conflicts = findConflict(frameCarrys, conflictFunc)
  const solvedConflicts = solveConflict(conflicts, conflictFunc)
  return solvedConflicts
}

export function tRawFindOverlaps<T extends BaseNode>(
  frameCarrys: Array<FrameCarry<T>>,
  conflictFunc: (l0: Frame, l1: Frame) => [number, number, number],
  preferImageInTwo = false
): Array<FrameCarry<T>> {
  const conflicts = findConflict(frameCarrys, conflictFunc)
  const solvedConflicts = solveConflict(conflicts, conflictFunc, preferImageInTwo)
  return solvedConflicts.filter(filterConflicts)
}

export function findOverlapsOnDirection(group: Group, property: Property, dir: FlexDirection): Node[] {
  const conflictFunc = (f0: Frame, f1: Frame) => measureOverlapOnDir(f0, f1, dir)
  const frameCarrys: Array<FrameCarry<Node>> = property
    .getChildren(group)
    .filter(child => child.layout.position !== PositionType.ABSOLUTE)
    .map(node => ({ carry: node }))
  const result = tRawFindOverlaps(frameCarrys, conflictFunc, true)
  return result.map(fc => fc.carry)
}

function calcDir<T extends BaseNode>(rowOverlaps: Array<FrameCarry<T>>, columnOverlaps: Array<FrameCarry<T>>): FlexDirection {
  if (rowOverlaps.length === columnOverlaps.length) {
    const dif = rowOverlaps.reduce((pre, cur) => pre + cur.maxEffect, 0) - columnOverlaps.reduce((pre, cur) => pre + cur.maxEffect, 0)
    return dif < 0 ? FlexDirection.ROW : FlexDirection.COLUMN
  }
  return rowOverlaps.length < columnOverlaps.length ? FlexDirection.ROW : FlexDirection.COLUMN
}

export function getDirection(group: Group, property: Property): FlexDirection {
  const nodes = property.getChildren(group)
  const frameCarrys: Array<FrameCarry<Node>> = nodes.map(node => ({ carry: node }))
  const rowOverlaps = tRawStrictFindOverlaps(frameCarrys, (l1, l2) => measureOverlapOnDir(l1, l2, FlexDirection.ROW))
  const columOverlaps = tRawStrictFindOverlaps(frameCarrys, (l1, l2) => measureOverlapOnDir(l1, l2, FlexDirection.COLUMN))
  return calcDir(rowOverlaps, columOverlaps)
}

export function getDirectionByBaseNodes<T extends BaseNode>(nodes: T[]): FlexDirection {
  const frameCarrys: Array<FrameCarry<T>> = nodes.map(node => ({ carry: node }))
  const rowOverlaps = tRawStrictFindOverlaps(frameCarrys, (l1, l2) => measureOverlapOnDir(l1, l2, FlexDirection.ROW))
  const columOverlaps = tRawStrictFindOverlaps(frameCarrys, (l1, l2) => measureOverlapOnDir(l1, l2, FlexDirection.COLUMN))
  return calcDir(rowOverlaps, columOverlaps)
}

export function getDirection2(group: InputNode): FlexDirection {
  if (group.type === NodeType.GROUP) {
    const nodes = group.layers
    return getDirectionByBaseNodes(nodes)
  }
  return undefined
}

function isConflictedByNodes<T extends BaseNode>(nodes: T[]): boolean {
  const frameCarrys: Array<FrameCarry<T>> = nodes.map(node => ({ carry: node }))
  return [FlexDirection.COLUMN, FlexDirection.ROW].every(
    dir => tRawFindOverlaps(frameCarrys, (l1, l2) => measureOverlapOnDir(l1, l2, dir)).length > 0
  )
}

//宽松的 background 要处理？
export function isConflicted(group: Group, filterBG: boolean): boolean {
  const nodes = group.children.filter(child => {
    if (filterBG) {
      return !(
        (child.type === NodeType.SHAPE || child.type === NodeType.IMAGE) &&
        group.measured.width === child.measured.width &&
        group.measured.height === child.measured.height &&
        child.measured.x === 0 &&
        child.measured.y === 0
      )
    } else {
      return true
    }
  })
  return isConflictedByNodes(nodes)
}

export function isConflicted2(group: InputNode): boolean {
  if (group.type === NodeType.GROUP) {
    const nodes = group.layers
    return isConflictedByNodes(nodes)
  }
  return false
}

export function isConflictedOnDirection<T extends BaseNode>(nodes: T[], dir: FlexDirection): boolean {
  const frameCarrys: Array<FrameCarry<T>> = nodes.map(node => ({ carry: node }))
  return tRawFindOverlaps(frameCarrys, (l1, l2) => measureOverlapOnDir(l1, l2, dir)).length > 0
}
