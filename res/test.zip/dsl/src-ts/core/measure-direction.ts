import { Property } from './property'
import { Node, NodeType, Group } from './../define/node'
import { NodeUtil } from './node-util'

import { getDirection } from './conflict'

function calcNode(node: Node, property: Property) {
  const { type } = node
  if (type === NodeType.GROUP) {
    const group = node as Group
    group.layout.flexDirection = getDirection(group, property)
  }
}

export function measureDirection(node: Node, property: Property): Node {
  return NodeUtil.visitNodeTree(node, property, calcNode)
}
