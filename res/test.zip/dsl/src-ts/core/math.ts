import { Point, Frame } from './../define/frame'
import { FlexDirection } from './../define/flex-type'
import { FrameUtil } from './frame-util'

export function compare(a: number, b: number): number {
  if (a < b) {
    return -1
  } else if (a > b) {
    return 1
  } else {
    return 0
  }
}

export function area(frame: Frame) {
  return frame.width * frame.height
}

export function isInRange(v: number, range: number[]) {
  return v >= range[0] && v < range[1]
}

export function isInBox(p: Point, frame: Frame) {
  return p.x >= frame.x && p.x < frame.x + frame.width && p.y >= frame.y && p.y < frame.y + frame.height
}

export function isOverlap(f0: Frame, f1: Frame) {
  return [FlexDirection.ROW, FlexDirection.COLUMN].every(dir => isOverlapOnDirection(f0, f1, dir))
}

export function isOverlapOnDirection(f0: Frame, f1: Frame, dir: FlexDirection) {
  if (dir === FlexDirection.ROW) {
    return (
      isInRange(f0.x, [f1.x, f1.x + f1.width]) ||
      isInRange(f0.x + f0.width - 1, [f1.x, f1.x + f1.width]) ||
      isInRange(f1.x, [f0.x, f0.x + f0.width]) ||
      isInRange(f1.x + f1.width - 1, [f0.x, f0.x + f0.width])
    )
  } else {
    return (
      isInRange(f0.y, [f1.y, f1.y + f1.height]) ||
      isInRange(f0.y + f0.height - 1, [f1.y, f1.y + f1.height]) ||
      isInRange(f1.y, [f0.y, f0.y + f0.height]) ||
      isInRange(f1.y + f1.height - 1, [f0.y, f0.y + f0.height])
    )
  }
}

export function isOverlapOnDirByShelling(f0: Frame, f1: Frame, dir: FlexDirection): boolean {
  return isOverlapOnDirection(FrameUtil.shelling(f0), FrameUtil.shelling(f1), dir)
  // return isOverlapOnDirection(f0, f1, dir)
}

export function measureOverlapOnDir(f0: Frame, f1: Frame, dir: FlexDirection): [number, number, number] {
  const intersect = intersectionOnDirection(f0, f1, dir)
  const l0 = FrameUtil.getLength(f0, dir)
  const l1 = FrameUtil.getLength(f1, dir)
  return [intersect / l0, intersect / l1, intersect]
}

export function isFullOverlap(small: Frame, large: Frame) {
  return (
    isInBox({ x: small.x, y: small.y }, large) &&
    isInBox({ x: small.x + small.width - 1, y: small.y }, large) &&
    isInBox({ x: small.x + small.width - 1, y: small.y + small.height - 1 }, large) &&
    isInBox({ x: small.x, y: small.y + small.height - 1 }, large)
    //   ||
    // (isInBox({ x: large.x, y: large.y }, small) &&
    //   isInBox({ x: large.x + large.width - 1, y: large.y }, small) &&
    //   isInBox({ x: large.x + large.width - 1, y: large.y + large.height - 1 }, small) &&
    //   isInBox({ x: large.x, y: large.y + large.height - 1 }, small))
  )
}

export function isFullOverlapOnDirection(small: Frame, large: Frame, dir: FlexDirection) {
  if (dir === FlexDirection.ROW) {
    return isInRange(small.x, [large.x, large.x + large.width]) && isInRange(small.x + small.width - 1, [large.x, large.x + large.width])
  } else {
    return isInRange(small.y, [large.y, large.y + large.height]) && isInRange(small.y + small.height - 1, [large.y, large.y + large.height])
  }
}

export function isFullOverlapOnDirectionByScale(small: Frame, large: Frame, scale: number, dir: FlexDirection) {
  if (dir === FlexDirection.ROW) {
    const sl = small.x + small.width * (1 - scale) / 2
    const sr = small.x + small.width * (scale + 1) / 2
    const ll = large.x + large.width * (1 - scale) / 2
    const lr = large.x + large.width * (scale + 1) / 2
    return isInRange(sl, [ll, lr]) && isInRange(sr - scale, [ll, lr])
  } else {
    const st = small.y + small.height * (1 - scale) / 2
    const sb = small.y + small.height * (scale + 1) / 2
    const lt = large.y + large.height * (1 - scale) / 2
    const lb = large.y + large.height * (scale + 1) / 2
    return isInRange(st, [lt, lb]) && isInRange(sb - scale, [lt, lb])
  }
}

export function intersection(f0: Frame, f1: Frame): Frame {
  if (isOverlap(f0, f1)) {
    const left = Math.max(f0.x, f1.x)
    const top = Math.max(f0.y, f1.y)
    const righ = Math.min(f0.x + f0.width, f1.x + f1.width)
    const bottom = Math.min(f0.y + f0.height, f1.y + f1.height)
    return {
      x: left,
      y: top,
      width: righ - left,
      height: bottom - top
    }
  }
  return undefined
}

export function intersectionOnDirection(f0: Frame, f1: Frame, dir: FlexDirection): number {
  return intersectionOnDirectionByScale(f0, f1, 1, dir)
}

export function intersectionOnDirectionByScale(f0: Frame, f1: Frame, scale: number, dir: FlexDirection): number {
  const center0 = FrameUtil.getCenter(f0, dir)
  const center1 = FrameUtil.getCenter(f1, dir)
  const len0 = FrameUtil.getLength(f0, dir)
  const len1 = FrameUtil.getLength(f1, dir)
  const intersect = (len0 + len1) * scale / 2 - Math.abs(center1 - center0)
  return Math.max(intersect, 0)
}

export function marginOnDirectionByScale(start: Frame, end: Frame, scale: number, dir: FlexDirection): number {
  const center0 = FrameUtil.getCenter(start, dir)
  const center1 = FrameUtil.getCenter(end, dir)
  const len0 = FrameUtil.getLength(start, dir)
  const len1 = FrameUtil.getLength(end, dir)
  const intersect = center1 - center0 - (len0 + len1) * scale / 2
  return Math.max(intersect, -1)
}

export function frameEquals(f0: Frame, f1: Frame): boolean {
  return f0 === f1 || (f0 && f1 && f0.x === f1.x && f0.y === f1.y && f0.width === f1.width && f0.height === f1.height)
}
