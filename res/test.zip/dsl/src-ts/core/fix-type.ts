import { Node, NodeType, Group } from './../define/node'
export default function fixType(node: Node) {
  if (node.type === NodeType.GROUP) {
    const group = node as Group
    group.children.forEach(fixType)
  }

  ;(Object as any).assign(node, { type: node.type.toUpperCase() })
}
