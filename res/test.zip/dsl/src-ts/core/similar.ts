import { TextStyles, Styles } from './../define/styles'
import { Frame } from './../define/frame'
import { Node, NodeType, Group } from './../define/node'
import { BaseNode } from './../define/base-node'
import { getDirectionByBaseNodes } from './conflict'
import { zipMatrix } from './../primitive/zip'
import { SIMILAR_THRESHOLD, SIMILAR_BOX, MIN_GRID_ITEMS } from './magic'

import console from './../primitive/logger'
import assert from './../primitive/assert'
import { FrameUtil } from './frame-util'
import { FlexDirection } from './../define/flex-type'
import min from './../primitive/min'
import max from './../primitive/max'

const AREA_RATE = 0.3

export function similarBox(n0: Frame, n1: Frame): number {
  const widthDif = Math.min(n0.width, n1.width) / Math.max(n0.width, n1.width)
  const heightDif = Math.min(n0.height, n1.height) / Math.max(n0.height, n1.height)
  const result = widthDif * heightDif
  assert(result >= 0 && result <= 1, result)
  return result
}

function textSimilar(s0: TextStyles, s1: TextStyles): number {
  const weights = [0.3, 0.4, 0.1, 0.1, 0.1]
  const bits = [
    s0.color === s1.color,
    s0.fontSize === s1.fontSize,
    s0.fontStyle === s1.fontStyle,
    s0.textDecoration === s1.textDecoration,
    s0.fontFamily === s1.fontFamily
  ]
  const result = weights.reduce((pre, cur, i) => pre + (bits[i] ? cur : 0), 0)

  assert(result >= 0 && result <= 1, result)
  return result
}

function imageSimilar(f0: Frame, f1: Frame): number {
  const result = similarBox(f0, f1)
  assert(result >= 0 && result <= 1, result)
  return result
}

function shapeSimilar(s0: Styles, s1: Styles): number {
  const weights = [0.3, 0.3, 0.3, 0.1, 0.0]
  const bits = [
    s0.backgroundColor === s1.backgroundColor,
    s0.borderColor === s1.borderColor,
    s0.borderRadius === s1.borderRadius,
    s0.borderWidth === s1.borderWidth,
    s0.borderStyle === s1.borderStyle
  ]
  const weight = weights.reduce((pre, cur, i) => pre + (bits[i] ? cur : 0), 0)
  const STRUCT_RATE = 0.3
  const result = STRUCT_RATE + (1 - STRUCT_RATE) * weight
  assert(result >= 0 && result <= 1, result)
  return result
}

//S(m, n) = Max(s(m[0], n[i]) + S(m.slice(1), n.slice(i+1) ))
function arraySimilarRaw<T extends BaseNode>(layers0: T[], layers1: T[], cachePair: object, cacheArray: object): number {
  if (layers0.length === 0 || layers1.length === 0) {
    return 0
  }

  const kArray: string = layers0[0].id + '-' + layers1[0].id
  const vArray: number = cacheArray[kArray]

  if (vArray === undefined) {
    let max = -1

    const m = layers0[0]
    const remains = layers0.slice(1)

    for (let i = 0; i < layers1.length; i++) {
      const kPair = m.id + '-' + layers1[i].id
      const vPair: number = cachePair[kPair]
      assert(typeof vPair === 'number')
      max = Math.max(vPair + arraySimilarRaw(remains, layers1.slice(i + 1), cachePair, cacheArray), max)
    }

    cacheArray[kArray] = max

    assert(max <= Math.min(layers0.length, layers1.length), max)

    return max
  }

  return vArray
}

function groupSimilar<T extends BaseNode>(layers0: T[], layers1: T[], calc: (t0: T, t1: T) => number): number {
  if (layers0.length === 0 || layers1.length === 0) {
    return layers0.length === layers1.length ? 1 : 0
  }

  const d0 = getDirectionByBaseNodes(layers0)
  const d1 = getDirectionByBaseNodes(layers1)

  if (d0 === d1) {
    const pairs = zipMatrix(layers0, layers1)
    const cachePair = {}
    pairs.forEach(pair => {
      const kPair = pair[0].id + '-' + pair[1].id
      const vPair = calc(pair[0], pair[1])
      cachePair[kPair] = vPair

      assert(vPair >= 0 && vPair <= 1, vPair)
    })

    const sum = arraySimilarRaw(layers0, layers1, cachePair, {})

    const result = sum * 2 / (layers0.length + layers1.length)
    assert(result >= 0 && result <= 1, result, sum, layers0.length, layers1.length)
    return result
  }

  return 0
}

//0-1
export function similarTree(n0: BaseNode, n1: BaseNode): number {
  const areaSimilar = similarBox(n0.exactFrame, n1.exactFrame)
  const t0 = n0.type
  const t1 = n1.type
  if (t0 === t1) {
    if (t0 === NodeType.GROUP) {
      return areaSimilar * AREA_RATE + (1 - AREA_RATE) * groupSimilar(n0.layers || n0.children, n1.layers || n1.children, similarTree)
    } else if (n0.type === NodeType.TEXT) {
      //文字不需要大小
      return textSimilar(n0.textStyles, n1.textStyles)
    } else if (n0.type === NodeType.IMAGE) {
      const boxR = imageSimilar(n0.exactFrame, n1.exactFrame)
      return 1 - (1 - boxR) * (1 - boxR)
    } else if (n0.type === NodeType.SHAPE) {
      return areaSimilar * AREA_RATE + (1 - AREA_RATE) * shapeSimilar(n0.styles, n1.styles)
    }
  }
  return areaSimilar * AREA_RATE
}

export function isSimilarTree(n0: BaseNode, n1: BaseNode, threshold = SIMILAR_THRESHOLD): boolean {
  return similarTree(n0, n1) >= threshold
}

function isSimilarBox(n0: BaseNode, n1: BaseNode, threshold = SIMILAR_BOX) {
  return similarBox(n0.exactFrame, n1.exactFrame) >= threshold
}

//大小相似 结构相似
export function isSimilarAsGridLine(nodes: BaseNode[], threshold = SIMILAR_THRESHOLD): boolean {
  if (nodes && nodes.length >= MIN_GRID_ITEMS) {
    if (nodes.every(child => isSimilarTree(child, nodes[0], SIMILAR_THRESHOLD))) {
      console.log('isSimilarGridLine', true, nodes.map(node => node.id))
      console.log(nodes.map(child => similarTree(child, nodes[0])))
      return true
    } else if (nodes.every(child => isSimilarBox(child, nodes[0], SIMILAR_BOX))) {
      // const pairs = zipDiagonal(nodes, nodes)
      // values = pairs.map(pair => similarTree(pair[0], pair[1]))
      // const avg = (nodes.length + values.reduce((pre, cur) => pre + cur, 0)) / (nodes.length + pairs.length)
      // result = avg >= threshold
      // // if (result) {
      // console.log('isSimilarGridLine', result, nodes.map(node => node.id))
      // console.log(values)
      // console.log(avg)
      // }
      console.log('isSimilarGridLine', true, nodes.map(node => node.id))
      console.log(nodes.map(child => isSimilarBox(child, nodes[0])))
      return true
    } else {
      console.log('isSimilarGridLine', false, nodes.map(node => node.id))
      console.log(nodes.map(child => isSimilarBox(child, nodes[0])))
      console.log(nodes.map(child => similarTree(child, nodes[0])))
    }
  }

  return false
}

export function isSimilarAsGrid(nodes: Node[], parent: Group, threshold = SIMILAR_THRESHOLD): boolean {
  if (nodes && nodes.length >= MIN_GRID_ITEMS && parent !== undefined && parent.layout.flexDirection === FlexDirection.ROW) {
    if (nodes.every(child => isSimilarBox(child, nodes[0], SIMILAR_BOX))) {
      console.log('isSimilarGridLine', true, parent.id)
      console.log(nodes.map(child => isSimilarBox(child, nodes[0])))
      //左右间距
      const f = FrameUtil.expandFrames(...nodes.map(node => node.measured))
      const pf = parent.measured
      const left = FrameUtil.getStart(f, FlexDirection.ROW)
      const right = FrameUtil.getLength(pf, FlexDirection.ROW) - FrameUtil.getEnd(f, FlexDirection.ROW)

      if (Math.abs(left - right) < 4) {
        //居中
        const centers = nodes.map(child => FrameUtil.getCenter(child.measured, FlexDirection.ROW))
        const betweens = centers
          .map((v, i, arr) => {
            return i > 0 ? v - arr[i - 1] : 0
          })
          .slice(1)

        const minValue: number = min(betweens)
        const maxValue: number = max(betweens)

        if (maxValue - minValue < 4 || (maxValue - minValue) / minValue < 0.1) {
          return true
        } else {
          console.log('isSimilarGridLine(MIN,MAX)', false, parent.id, minValue, maxValue)
        }
      } else {
        console.log('isSimilarGridLine(L,R)', false, parent.id, left, right)
      }
    } else {
      console.log('isSimilarGridLine', false, parent.id)
      console.log(nodes.map(child => isSimilarBox(child, nodes[0])))
      console.log(nodes.map(child => similarTree(child, nodes[0])))
    }
  }

  return false
}
