import { Property } from './property'
import { Node, Text, NodeType } from './../define/node'
import { FlexDirection } from './../define/flex-type'
import { NodeUtil, RootContainer } from './node-util'
import { LayoutUtil } from './layout-util'
import { FrameUtil } from './frame-util'
import clone from './../primitive/clone'
import { MAGIC_MARGIN } from './magic'

function simplifyText(node: Node, property: Property, rootContainer: RootContainer) {
  const { type } = node
  if (type === NodeType.TEXT) {
    const text = node as Text
    const group = text.parent

    if (group !== undefined && property.getChildren(group).length === 1) {
      const isCenter = [FlexDirection.ROW, FlexDirection.COLUMN].every(dir => FrameUtil.isCenter(text.measured, group.measured, dir, 4))

      const row = FlexDirection.ROW
      const col = FlexDirection.COLUMN
      const paddings = [
        FrameUtil.getStart(text.measured, row),
        FrameUtil.getLength(group.measured, row) - FrameUtil.getEnd(text.measured, row),
        FrameUtil.getStart(text.measured, col),
        FrameUtil.getLength(group.measured, col) - FrameUtil.getEnd(text.measured, col)
      ]

      if (isCenter && paddings.every(padding => padding <= MAGIC_MARGIN)) {
        const grandparent = group.parent
        if (grandparent !== undefined && FrameUtil.getLength(grandparent.measured, row) === FrameUtil.getLength(group.measured, row)) {
          return
        }

        ;[FlexDirection.ROW, FlexDirection.COLUMN].forEach(dir => {
          LayoutUtil.setPaddingStart(group.layout, dir, FrameUtil.getStart(text.measured, dir))
          LayoutUtil.setPaddingEnd(group.layout, dir, FrameUtil.getLength(group.measured, dir) - FrameUtil.getEnd(text.measured, dir))
        })

        if (text.textStyles.maxHeight > 0) {
          text.textStyles.maxHeight +=
            FrameUtil.getStart(text.measured, col) + FrameUtil.getLength(group.measured, col) - FrameUtil.getEnd(text.measured, col)
        }

        const { parent } = group
        if (parent !== undefined) {
          const index = parent.children.indexOf(group)
          parent.children.splice(index, 1, text)
        } else {
          rootContainer.root = text
        }

        text.parent = parent
        group.parent = undefined
        group.children = []

        text.layout = clone(group.layout)
        text.layout.flexDirection = undefined
        text.layout.justifyContent = undefined
        text.layout.alignItems = undefined

        text.frame = { ...group.frame }
        text.measured = { ...group.measured }
        text.reasons = text.reasons.concat(group.reasons)
        text.styles = group.styles

        if (text.textStyles.lineHeight !== undefined) {
          text.textStyles.lineHeight = Math.min(text.textStyles.lineHeight, group.exactFrame.height)
        }

        console.log('simplifyText', text.name)
      }
    }
  }
}

export function simplify(node: Node, property: Property): Node {
  return NodeUtil.visitNodeTreeReverse(node, property, simplifyText)
  // return node
}
