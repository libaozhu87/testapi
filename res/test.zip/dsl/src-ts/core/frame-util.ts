import { FlexDirection } from './../define/flex-type'
import { CENTER_ERROR } from './magic'
import { Point, Frame } from './../define/frame'

export abstract class FrameUtil {
  public static round(f: Frame): Frame {
    return {
      x: Math.round(f.x),
      y: Math.round(f.y),
      width: Math.round(f.width),
      height: Math.round(f.height)
    }
  }

  public static equals(f0: Frame, f1: Frame) {
    return f0.x === f1.x && f0.y === f1.y && f0.width === f1.width && f0.height === f1.height
  }

  public static expandFrames(...fs: Frame[]): Frame {
    return fs.reduce(FrameUtil.expand, undefined)
  }

  public static expandPoint(f: Frame, p: Point): Frame {
    const l = Math.min(f.x, p.x)
    const t = Math.min(f.y, p.y)
    const r = Math.max(l + f.width, p.x)
    const b = Math.max(t + f.height, p.y)
    return { x: l, y: t, width: r - l, height: b - t }
  }

  public static expand(f0: Frame, f1: Frame): Frame {
    if (f0 === undefined && f1 === undefined) {
      return undefined
    } else if (f0 === undefined) {
      return { ...f1 }
    } else if (f1 === undefined) {
      return { ...f0 }
    }

    const l = Math.min(f0.x, f1.x)
    const t = Math.min(f0.y, f1.y)
    const r = Math.max(f0.x + f0.width, f1.x + f1.width)
    const b = Math.max(f0.y + f0.height, f1.y + f1.height)
    return { x: l, y: t, width: r - l, height: b - t }
  }

  public static getLength(f: Frame, dir: FlexDirection): number {
    if (dir === FlexDirection.ROW) {
      return f.width
    } else {
      return f.height
    }
  }

  public static setLength(f: Frame, dir: FlexDirection, value: number): void {
    if (dir === FlexDirection.ROW) {
      f.width = value
    } else {
      f.height = value
    }
  }

  public static getStart(f: Frame, dir: FlexDirection): number {
    if (dir === FlexDirection.ROW) {
      return f.x
    } else {
      return f.y
    }
  }

  public static setStart(f: Frame, dir: FlexDirection, value: number): void {
    if (dir === FlexDirection.ROW) {
      f.x = value
    } else {
      f.y = value
    }
  }

  public static setStartOffset(f: Frame, dir: FlexDirection, offset: number): void {
    if (dir === FlexDirection.ROW) {
      f.x += offset
    } else {
      f.y += offset
    }
  }

  public static getEnd(f: Frame, dir: FlexDirection): number {
    if (dir === FlexDirection.ROW) {
      return f.x + f.width
    } else {
      return f.y + f.height
    }
  }

  public static getCenter(f: Frame, dir: FlexDirection): number {
    if (dir === FlexDirection.ROW) {
      return f.x + f.width / 2
    } else {
      return f.y + f.height / 2
    }
  }

  public static isCenter(child: Frame, parent: Frame, dir: FlexDirection, thred = CENTER_ERROR): boolean {
    // const cLen = FrameUtil.getLength(child, dir)
    const pLen = FrameUtil.getLength(parent, dir)
    const center = FrameUtil.getCenter(child, dir)

    //cLen <= pLen - MIN_SPACE &&
    if (Math.abs(center - pLen / 2) < CENTER_ERROR) {
      return true
    } else {
      return false
    }
  }

  public static isNearStart(child: Frame, parent: Frame, dir: FlexDirection, thred = CENTER_ERROR): boolean {
    if (FrameUtil.isCenter(child, parent, dir)) {
      return false
    } else if (dir === FlexDirection.ROW) {
      return child.x + child.width / 2 - parent.width / 2 <= -thred
    } else {
      return child.y + child.height / 2 - parent.height / 2 <= -thred
    }
  }

  public static isNearEnd(child: Frame, parent: Frame, dir: FlexDirection): boolean {
    return !FrameUtil.isCenter(child, parent, dir) && !FrameUtil.isNearStart(child, parent, dir)
  }

  public static toLeft(frame: Frame): number {
    return frame.x
  }

  public static toRight(frame: Frame): number {
    return frame.x + frame.width
  }

  public static toTop(frame: Frame): number {
    return frame.y
  }

  public static toBottom(frame: Frame): number {
    return frame.x + frame.height
  }

  public static shelling(frame: Frame): Frame {
    return {
      x: frame.width >= 4 ? frame.x - 1 : frame.x,
      y: frame.height >= 4 ? frame.y - 1 : frame.y,
      width: frame.width >= 4 ? frame.width - 2 : frame.width,
      height: frame.height >= 4 ? frame.height - 2 : frame.height
    }
  }

  public static scale(frame: Frame, rate: number): Frame {
    const f = { ...frame }
    const offsetX = Math.round((rate - 1) * frame.width * 0.5)
    const offsetY = Math.round((rate - 1) * frame.height * 0.5)
    f.x -= offsetX
    f.y -= offsetY
    f.width += offsetX * 2
    f.height += offsetY * 2
    return f
  }

  public static SCALE_ROW_START = 'row-start'
  public static SCALE_ROW_END = 'row-end'
  public static SCALE_COL_START = 'col-start'
  public static SCALE_COL_END = 'col-end'

  public static scaleOnType(frame: Frame, rate: number, scaleType: string): Frame {
    const f = { ...frame }
    const offsetX = Math.round((rate - 1) * frame.width)
    const offsetY = Math.round((rate - 1) * frame.height)

    if (scaleType === FrameUtil.SCALE_ROW_START) {
      f.x -= offsetX
    } else if (scaleType === FrameUtil.SCALE_ROW_END) {
      f.width += offsetX
    } else if (scaleType === FrameUtil.SCALE_COL_START) {
      f.y -= offsetY
    } else if (scaleType === FrameUtil.SCALE_COL_END) {
      f.height += offsetY
    }

    return f
  }

  public static translate(frame: Frame, { x, y }): Frame {
    return { x: frame.x + x, y: frame.y + y, width: frame.width, height: frame.height }
  }
}
