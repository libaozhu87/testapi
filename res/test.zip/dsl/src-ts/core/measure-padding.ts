import { Property } from './property'
import { Node, NodeType, Group } from './../define/node'
import { NodeUtil } from './node-util'
import { FlexDirection } from './../define/flex-type'
import { LayoutUtil } from './layout-util'
import isEmpty from './../primitive/isEmpty'
import { FrameUtil } from './frame-util'
import { DirectionUtil } from './direction-util'
import { isFullOverlapOnDirection } from './math'
import { MAGIC_MARGIN } from './magic'
// import console from './../primitive/logger'

function fixOnCrossDir(node: Node, property: Property) {
  const { type } = node
  if (type === NodeType.GROUP) {
    const group = node as Group

    const children = property.getChildren(group)

    const crossDir = DirectionUtil.cross(group.layout.flexDirection)

    if (!isEmpty(children)) {
      if (!LayoutUtil.isFixed(group.layout, crossDir)) {
        let shouldFixed = false
        const frames = children.map(child => LayoutUtil.getFrameBoxWithMargin(child))
        if (frames.length >= 2) {
          shouldFixed = true
          for (let i = 0; i < frames.length && shouldFixed; i++) {
            //适当的扩张
            const testFrame = { ...frames[i] }
            FrameUtil.setStartOffset(testFrame, crossDir, -MAGIC_MARGIN / 2)
            FrameUtil.setLength(testFrame, crossDir, FrameUtil.getLength(testFrame, crossDir) + MAGIC_MARGIN)
            shouldFixed = !frames.every(f => isFullOverlapOnDirection(f, testFrame, crossDir))
          }
        }

        if (shouldFixed) {
          LayoutUtil.setLength(group.layout, crossDir, FrameUtil.getLength(group.measured, crossDir))
        }
      }
    }
  }
}

function paddingOnNotFixed(node: Node, property: Property) {
  const { type } = node
  if (type === NodeType.GROUP) {
    const group = node as Group

    //shape-background
    const children = property.getChildren(group).filter(child => !(property.isMatchParentSize(child) && child.type === NodeType.SHAPE))

    if (!isEmpty(children)) {
      const dirs = [FlexDirection.ROW, FlexDirection.COLUMN]
      dirs.forEach(dir => {
        if (!LayoutUtil.isFixed(group.layout, dir)) {
          //to do margin or not
          const frame = children.map(child => LayoutUtil.getFrameBoxWithMargin(child)).reduce(FrameUtil.expand, undefined)
          const paddingStart = FrameUtil.getStart(frame, dir)
          const paddingEnd = FrameUtil.getLength(group.measured, dir) - FrameUtil.getEnd(frame, dir)

          LayoutUtil.setPaddingStart(group.layout, dir, paddingStart)
          LayoutUtil.setPaddingEnd(group.layout, dir, paddingEnd)
        }
      })
    }
  }
}

export function measurePadding(node: Node, property: Property): Node {
  return NodeUtil.visitNodeTree(node, property, paddingOnNotFixed)
}

export function fixCrossAxis(node: Node, property: Property): Node {
  return NodeUtil.visitNodeTree(node, property, fixOnCrossDir)
}
