let G_ID = 0
export function newId() {
  return ++G_ID
}

export function resetIdGenerator() {
  G_ID = 0
}
