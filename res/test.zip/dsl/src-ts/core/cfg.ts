import { Platform } from './../define/platform'

export interface Cfg {
  debug: boolean
  platform: Platform
  fileName: string
  artBoard: string
  page: string
}

export const DefaultCfg = { debug: false, platform: Platform.WEEX, page: undefined, fileName: '', artBoard: '' }
