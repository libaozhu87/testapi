import { InputNode } from './../define/input-node'
import { Node, NodeType, Group } from './../define/node'
import { buildNode } from './node-factory'
import { Property } from './property'
import { NodeUtil } from './node-util'
import compact from './../primitive/compact'
import { sortChildren } from './sort-children'

function buildNodeTree(input: InputNode, parent: Group, property: Property): Node {
  const node = buildNode(input, parent)

  if (node.type === NodeType.GROUP) {
    const group = node as Group
    group.children = compact(input.layers.map(layer => buildNodeTree(layer, group, property)))
  }

  return node
}

function absolute2relative(node: Node, property: Property) {
  const { parent } = node
  node.measured.x = node.measured.x - (parent ? parent.frame.x : 0)
  node.measured.y = node.measured.y - (parent ? parent.frame.y : 0)
}

export function build(input: InputNode, property: Property): Node {
  const root = buildNodeTree(input, undefined, property)
  NodeUtil.visitNodeTreeReverse(root, property, absolute2relative)
  sortChildren(root, property)
  return root
}
