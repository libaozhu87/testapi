import { Property } from './property'
import { NodeType, Node, Group } from './../define/node'
import { NodeUtil } from './node-util'
import { MeasuredSizeType } from './../define/measure-size-type'
import { FrameUtil } from './frame-util'
import { LayoutUtil } from './layout-util'
import { FlexDirection } from './../define/flex-type'
import { isConflicted } from './conflict'
import { isMargicPadding } from './magic'
import console from './../primitive/logger'

interface ResizeStruct {
  length: number
  offset: number
  fixed: boolean
  type: string
}

interface IFlexboxResize {
  isMatch(node: Node, dir: FlexDirection, property: Property): boolean
  apply(node: Node, dir: FlexDirection, property: Property): ResizeStruct
}

class ResizeByInput implements IFlexboxResize {
  public isMatch(node: Node, dir: FlexDirection, property: Property) {
    return !node.parent
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    return {
      length: FrameUtil.getLength(node.measured, dir),
      offset: 0,
      fixed: dir === FlexDirection.ROW,
      type: MeasuredSizeType.BY_INPUT
    }
  }
}

class ResizeByLargePadding implements IFlexboxResize {
  public isMatch(node: Node, dir: FlexDirection, property: Property) {
    const { type } = node
    if (type === NodeType.GROUP) {
      const group = node as Group
      const linears = property.getLinearChildren(group)
      const frame = linears.map(child => child.measured).reduce(FrameUtil.expand, undefined)
      if (frame !== undefined) {
        const start = FrameUtil.getStart(frame, dir)
        const end = FrameUtil.getLength(group.measured, dir) - FrameUtil.getEnd(frame, dir)
        return isMargicPadding(start) || isMargicPadding(end)
      }
    }
    return false
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    return {
      length: FrameUtil.getLength(node.measured, dir),
      offset: 0,
      fixed: true,
      type: 'ResizeByLargePadding'
    }
  }
}

class ResizeByStretchWidth implements IFlexboxResize {
  public isMatch(node: Node, dir: FlexDirection, property: Property) {
    if (dir === FlexDirection.ROW) {
      const { type, parent } = node
      if (
        type === NodeType.GROUP &&
        !property.hasValidBackground(node) &&
        parent &&
        parent.layout.flexDirection === FlexDirection.COLUMN &&
        parent.measured.width === property.getLogicalWidth()
      ) {
        return true
      }
    }
    return false
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    return {
      length: property.getLogicalWidth(),
      offset: -FrameUtil.getStart(node.measured, dir),
      fixed: true,
      type: MeasuredSizeType.BY_SKETCH_WIDTH
    }
  }
}

class ResizeByMark implements IFlexboxResize {
  public isMatch(node: Node, dir: FlexDirection, property: Property) {
    return false
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    return {
      length: FrameUtil.getLength(node.measured, dir),
      offset: 0,
      fixed: true,
      type: MeasuredSizeType.BY_MARK
    }
  }
}

//background ?
class ResizeByConflict implements IFlexboxResize {
  public isMatch(node: Node, dir: FlexDirection, property: Property) {
    const { type } = node
    if (type === NodeType.GROUP) {
      const group = node as Group
      return isConflicted(group, true)
    }
    return false
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    return {
      length: FrameUtil.getLength(node.measured, dir),
      offset: 0,
      fixed: true,
      type: MeasuredSizeType.BY_CONFLICT
    }
  }
}

class ResizeByImageAsBackground implements IFlexboxResize {
  public isMatch(node: Node, dir: FlexDirection, property: Property) {
    return property.getBackgroundChildren(node).some(child => child.type === NodeType.IMAGE)
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    return {
      length: FrameUtil.getLength(node.measured, dir),
      offset: 0,
      fixed: true,
      type: MeasuredSizeType.BY_IMAGE_AS_BACKGROUND
    }
  }
}

class ResizeByShapeAsBackground implements IFlexboxResize {
  public isMatch(node: Node, dir: FlexDirection, property: Property) {
    return (
      property.getBackgroundChildren(node).some(child => child.type === NodeType.SHAPE) && property.getBackgroundChildren(node).length === 1
    )
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    return {
      length: FrameUtil.getLength(node.measured, dir),
      offset: 0,
      fixed: false,
      type: MeasuredSizeType.BY_SHAPE_AS_BACKGROUND
    }
  }
}

class ResizeByPritimive implements IFlexboxResize {
  public isMatch(node: Node, dir: FlexDirection, property: Property) {
    if (node.type === NodeType.IMAGE) {
      return true
    } else if (node.type === NodeType.SHAPE) {
      return !property.isMatchParentSize(node)
    }
    return false
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    return {
      length: FrameUtil.getLength(node.measured, dir),
      offset: 0,
      fixed: true,
      type: MeasuredSizeType.BY_PRIMITIVE
    }
  }
}

class ResizeByText implements IFlexboxResize {
  public isMatch(node: Node, dir: FlexDirection, property: Property) {
    if (node.type === NodeType.TEXT) {
      //todo 目前没有处理多行动态高度
      if (dir === FlexDirection.ROW) {
        return property.isFixedTextWidth(node)
      }
    }
    return false
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    return {
      length: FrameUtil.getLength(node.measured, dir),
      offset: 0,
      fixed: true,
      type: MeasuredSizeType.BY_TEXT
    }
  }
}

class ResizeByDefault implements IFlexboxResize {
  public isMatch(node: Node, dir: FlexDirection, property: Property) {
    return true
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    return {
      length: FrameUtil.getLength(node.measured, dir),
      offset: 0,
      fixed: false,
      type: MeasuredSizeType.BY_DEFAULT
    }
  }
}

class FlexboxResizer {
  private _resizers: IFlexboxResize[]
  public constructor(resizers: IFlexboxResize[]) {
    this._resizers = resizers
  }

  public apply(node: Node, dir: FlexDirection, property: Property) {
    for (const resizer of this._resizers) {
      if (resizer.isMatch(node, dir, property)) {
        return resizer.apply(node, dir, property)
      }
    }
  }
}

const RESIZER = new FlexboxResizer([
  new ResizeByPritimive(),
  new ResizeByMark(),
  new ResizeByConflict(),
  new ResizeByImageAsBackground(),
  new ResizeByShapeAsBackground(), //break ResizeByStretchWidth
  new ResizeByInput(),
  new ResizeByStretchWidth(),
  new ResizeByText(),
  new ResizeByLargePadding(),
  new ResizeByDefault()
])

export function firstRound(node: Node, property: Property) {
  const dirs = [FlexDirection.ROW, FlexDirection.COLUMN]

  dirs.forEach(dir => {
    const struct = RESIZER.apply(node, dir, property)

    FrameUtil.setLength(node.measured, dir, struct.length)
    FrameUtil.setStartOffset(node.measured, dir, struct.offset)

    if (struct.fixed) {
      LayoutUtil.setLength(node.layout, dir, struct.length)
    }

    node.reasons.push(struct.type)

    property.getChildren(node).forEach(child => {
      FrameUtil.setStartOffset(child.measured, dir, -struct.offset)
    })
  })
}

export function measureSize(node: Node, property: Property): Node {
  return NodeUtil.visitNodeTree(node, property, firstRound)
}
