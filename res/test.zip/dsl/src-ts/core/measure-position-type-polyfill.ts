import { Property } from './property'
import { Node, NodeType, Group } from './../define/node'
import { PositionType, FlexDirection } from './../define/flex-type'
import { NodeUtil } from './node-util'
import { isConflicted, getDirection } from './conflict'
import console from './../primitive/logger'
import { FrameUtil } from './frame-util'
import indexOf from './../primitive/indexOf'
import { isMagicMargin } from './magic'
import { LayoutUtil } from './layout-util'

//large margin & center ? => absolute
function positionTypePolyfill(node: Node, property: Property) {
  const { type } = node
  if (type === NodeType.GROUP) {
    const group = node as Group
    const dir = getDirection(group, property)
    if (dir === FlexDirection.ROW && !isConflicted(group, true) && group.specialLayout === undefined) {
      const linears = property.getLinearChildren(group)
      const bewteens = NodeUtil.getChildrenBetweens(group, linears, property)

      //like android relative
      if (bewteens.some(isMagicMargin) && linears.length <= 3) {
        const centerIndex = indexOf(linears, child => FrameUtil.isCenter(child.measured, group.measured, dir))
        if (centerIndex >= 0) {
          linears.forEach(child => (child.layout.position = PositionType.ABSOLUTE))
          linears[centerIndex].layout.position = PositionType.RELATIVE
          LayoutUtil.setLength(group.layout, dir, FrameUtil.getLength(group.measured, dir))
        }
      }
    }
  }
}

export function measurePositionTypePolyfill(node: Node, property: Property): Node {
  return NodeUtil.visitNodeTree(node, property, positionTypePolyfill)
}
