export const MAGIC_MARGIN = 40
export const MAGIC_PADDING = 48
export const CENTER_ERROR = 3
export const CONFLICT_ERROR = 0.1
export const SIMILAR_THRESHOLD = 0.725
export const SIMILAR_BOX = 0.825
export const MIN_SPACE = 8
export const MIN_GRID_ITEMS = 3

export function isMagicMargin(margin: number): boolean {
  return margin >= MAGIC_MARGIN
}

export function isMargicPadding(padding: number): boolean {
  return padding >= MAGIC_PADDING
}
