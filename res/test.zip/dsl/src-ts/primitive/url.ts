import typof from './typof'
import toString from './toString'

function stringify(rootObj) {
  const type = typof(rootObj)
  if (type === null || type !== 'object') {
    return toString(rootObj)
  } else {
    const kvParis = []
    for (const key in rootObj) {
      if (rootObj.hasOwnProperty(key)) {
        const value = toString(rootObj[key])
        const enValue = encodeURIComponent(value)
        kvParis.push(`${key}=${enValue}`)
      }
    }
    return kvParis.join('&')
  }
}

function parse(url) {
  if (url) {
    const index = url.indexOf('?')
    const str = index === -1 ? url : url.substr(index + 1)
    const pairs = str.split('&')
    const target = {}
    for (let i = 0; pairs && i < pairs.length; i++) {
      const kv = pairs[i].split('=')
      const k = kv[0]
      const v = decodeURIComponent(kv[1])

      let rawV
      try {
        rawV = JSON.parse(v)
      } catch (e) {
        rawV = v
      }
      target[k] = rawV
    }
    return target
  }

  return url
}

function join(...args) {
  return args
    .filter(v => v)
    .map(stringify)
    .join('&')
    .replace(/[?|&]+/g, '&')
    .replace('&', '?')
}

export default {
  stringify,
  parse,
  join
}
