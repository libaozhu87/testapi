import equals from './equals'

export interface FoldedItem<T> {
  value: T
  index: number
  count: number
}

export function folded<T>(arr: T[], equalsFunc?: (a: T, b: T) => boolean): Array<FoldedItem<T>> {
  equalsFunc = equalsFunc || equals
  return arr.reduce((pre: Array<FoldedItem<T>>, cur: T, index: number) => {
    const tail = pre[pre.length - 1]
    if (tail && equals(tail.value, cur)) {
      tail.count++
    } else {
      pre.push({ value: cur, index, count: 1 })
    }
    return pre
  }, [])
}

export interface Folded2Item<T> {
  arr: T[]
  count: number
}

function hasRepeat<T>(head: T[], remains: T[], equalsFunc: (a: T, b: T) => boolean): boolean {
  if (head.length <= remains.length) {
    return head.every((item, i) => equalsFunc(item, remains[i]))
  }
  return false
}

export function folded2<T>(arr: T[], equalsFunc?: (a: T, b: T) => boolean): Array<Folded2Item<T>> {
  if (arr === undefined || arr.length === 0) {
    return []
  } else if (arr.length <= 3) {
    return [{ arr: [...arr], count: 1 }]
  }
  equalsFunc = equalsFunc || equals

  const head = arr[0]

  let i = 1
  for (; i <= arr.length / 2; i++) {
    if (!equalsFunc(head, arr[i])) {
      i++
      break
    }
  }

  for (; i <= arr.length / 2; i++) {
    const frag = arr.slice(0, i)
    let remains = arr.slice(i)
    const result = { arr: [...frag], count: 1 }
    while (hasRepeat(frag, remains, equalsFunc)) {
      result.count++
      remains = remains.slice(i)
    }
    if (result.count > 1) {
      return [result].concat(folded2(remains, equalsFunc))
    }
  }

  const result = folded2(arr.slice(1), equalsFunc)
  if (result[0].count === 1) {
    result[0].arr.unshift(head)
  } else {
    result.unshift({ arr: [head], count: 1 })
  }
  return result
}

// console.log(JSON.stringify(folded2([1, 1, 2, 2])))
