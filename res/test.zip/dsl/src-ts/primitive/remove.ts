export default function remove<T>(arr: T[], value: T): number {
  if (arr === undefined) {
    return -1
  }
  const index = arr.indexOf(value)
  if (index !== -1) {
    arr.splice(index, 1)
  }
  return index
}
