// import isEmpty from './isEmpty'

// function compareNumber(t0, t1) {
//   return t0 - t1
// }

// export default function most<T>(arr: T[]): T {
//   if (isEmpty(arr)) {
//     return undefined
//   } else {
//     //
//   }
// }
