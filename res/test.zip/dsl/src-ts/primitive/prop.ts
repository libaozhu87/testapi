export default function prop(key: any, target: object): any {
  key = String(key)
  return key === '_' || key === undefined ? target : key.split('.').reduce((pre, cur) => pre && pre[cur], target)
}
