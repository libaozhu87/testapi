import isEmpty from './isEmpty'

export default function isNotEmpty(v) {
  return !isEmpty(v)
}
