import toString from './toString'

let RawLogger = console.log.bind(console)

export default {
  log(...args) {
    const date = new Date()
    const time = date.toLocaleTimeString()
    const mills = date.getMilliseconds()
    const millsStr = mills < 10 ? `00${mills}` : mills < 100 ? `0${mills}` : `${mills}`
    const n = args.length
    const text = [].map.call(args, toString).join('\t')
    RawLogger(`Logger(${n}) ${time} ${millsStr}: ${text}`)
  },

  setLogger(newLogger) {
    RawLogger = newLogger || RawLogger
  }
}
