import isEmpty from './isEmpty'

function compareNumber(t0, t1) {
  return t0 - t1
}

export default function top<T>(arr: T[], compare?: (t0: T, t1: T) => number): T {
  if (isEmpty(arr)) {
    return undefined
  } else {
    compare = compare || compareNumber
    return arr.reduce((pre: T, cur: T) => {
      if (pre !== undefined && compare(pre, cur) <= 0) {
        return pre
      }
      return cur
    }, undefined)
  }
}
