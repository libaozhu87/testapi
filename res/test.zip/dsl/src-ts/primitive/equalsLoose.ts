import typof from './typof'

function equalsString(s1, s2) {
  return s1.toLowerCase() === s2.toLowerCase()
}

function equalsNumber(n1, n2) {
  return n1 === n2 || (!isNaN(n1) && n1.toFixed(6) === n2.toFixed(6))
}

export default function equalsLoose(a, b) {
  const at = typof(a)
  const bt = typof(b)
  if (at === 'boolean' || bt === 'boolean') {
    return !!a === !!b
  } else if (at === 'string' || bt === 'string') {
    return equalsString(String(a), String(b))
  } else if (at === 'number' || bt === 'number') {
    return equalsNumber(Number(a), Number(b))
  } else if ((at === 'undefined' || at === 'null') && (bt === 'undefined' || bt === 'null')) {
    return true
  } else {
    return a === b
  }
}
