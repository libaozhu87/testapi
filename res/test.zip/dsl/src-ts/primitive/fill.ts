export default function fill<T>(capity: number, value?: T): T[] {
  const arr = Array.apply(undefined, Array(capity))
  return value === undefined ? arr : arr.map(() => value)
}
