export default function startsWith(str: string, prefix: string) {
  return str !== undefined && prefix !== undefined && str.slice(0, prefix.length) === prefix
}
