export default function range(start, stop, step) {
  if (stop === undefined) {
    stop = start || 0
    start = 0
  }
  step = step || 1

  const length = Math.max(Math.ceil((stop - start) / step), 0)
  const arr = Array(length)

  for (let idx = 0; idx < length; idx++, start += step) {
    arr[idx] = start
  }

  return arr
}
