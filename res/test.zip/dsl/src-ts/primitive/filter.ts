import typof from './typof'

export default function filter(collect, pred) {
  const type = typof(collect)
  if (type === 'array') {
    return collect.filter(pred)
  } else if (type === 'object') {
    const obj = {}
    Object.keys(collect).forEach(k => {
      if (collect.hasOwnProperty(k)) {
        if (pred(collect[k], k, collect)) {
          obj[k] = collect[k]
        }
      }
    })
    return obj
  }
}
