import isEmpty from './isEmpty'

function compareNumber(t0, t1) {
  return t0 - t1
}

export default function min<T>(arr: T[], compare?: (t0: T, t1: T) => number): T {
  if (isEmpty(arr)) {
    return undefined
  } else {
    compare = compare || compareNumber
    return arr.reduce((pre: T, cur: T) => {
      return pre !== undefined && compare(pre, cur) <= 0 ? pre : cur
    }, undefined)
  }
}
