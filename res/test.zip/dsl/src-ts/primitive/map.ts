import typof from './typof'

export default function map(collect, iteratee) {
  const type = typof(collect)
  if (type === 'array') {
    return collect.map(iteratee)
  } else if (type === 'object') {
    const result = {}
    Object.keys(collect).forEach(k => {
      if (collect.hasOwnProperty(k)) {
        result[k] = iteratee(collect[k], k, collect)
      }
    })
    return result
  }
}
