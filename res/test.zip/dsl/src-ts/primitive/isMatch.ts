import equalsLoose from './equalsLoose'
import identical from './identical'
import prop from './prop'
import typof from './typof'

// cond is an object
function matchObject(target, cond): boolean {
  const typeTarget = typof(target)
  if (typeTarget === 'array') {
    const keys = Object.keys(cond)
    return keys.length === 1 && keys[0] === 'length' ? isMatch(target.length, cond.length, undefined) : false
  } else if (typeTarget === 'object') {
    for (const k in cond) {
      if (!isMatch(prop(k, target), prop(k, cond), undefined)) {
        return false
      }
    }
    return true
  } else {
    return false
  }
}

// cond is an array
function matchArray(target, cond): boolean {
  if (typof(target) === 'array') {
    for (const i in cond) {
      if (!isMatch(target[i], cond[i], undefined)) {
        return false
      }
    }
    return true
  }
  return false
}

// cond is a regexp
function matchRegexp(target, cond: RegExp): boolean {
  return cond.test(target)
}

// cond is an boolean
function matchBoolean(target, cond) {
  return !!target === cond
}

// cond is an other type
function matchPrimitive(target, cond, strict: boolean): boolean {
  return strict ? identical(target, cond) : equalsLoose(target, cond)
}

//
export default function isMatch(target: any, cond: any, strict: boolean): boolean {
  const type = typof(cond)
  return type === 'function'
    ? cond(target)
    : type === 'object'
      ? matchObject(target, cond)
      : type === 'array'
        ? matchArray(target, cond)
        : type === 'regexp' ? matchRegexp(target, cond) : type === 'boolean' ? matchBoolean(target, cond) : matchPrimitive(target, cond, strict)
}
