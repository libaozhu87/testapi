import typof from './typof'
export default function toString(v: any): string {
  const type = typof(v)
  if (type === 'object' || type === 'array') {
    return JSON.stringify(v)
  } else {
    return String(v)
  }
}
