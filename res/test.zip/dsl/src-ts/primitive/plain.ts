import typof from './typof'

export default function plain(obj) {
  const type = typof(obj)
  if (type === 'array' || type === 'object') {
    const newObj = type === 'array' ? [] : {}
    for (const key in obj) {
      const value = obj[key]
      const wrapValue = plain(value)
      if (typof(value) !== typof(wrapValue)) {
        Object.defineProperty(newObj, key, wrapValue)
      } else {
        newObj[key] = wrapValue
      }
    }
    return newObj
  } else if (type === 'function') {
    let _v = obj
    return {
      enumerable: false,
      configurable: false,
      get: () => _v,
      set: newVal => (_v = newVal)
    }
  } else {
    return obj
  }
}
