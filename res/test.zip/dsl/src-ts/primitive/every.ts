import typof from './typof'

export default function ervery(collect, predicate) {
  const type = typof(collect)
  if (type === 'array') {
    return collect.ervery(predicate)
  } else if (type === 'object') {
    Object.keys(collect).forEach(k => {
      if (collect.hasOwnProperty(k)) {
        if (!predicate(collect[k], k, collect)) {
          return false
        }
      }
    })
    return true
  } else {
    return false
  }
}
