import isNull from './isNull'
import typof from './typof'

export default function isFalse(v) {
  if (isNull(v)) {
    return true
  } else {
    const type = typof(v)
    if (type === 'string') {
      const lowerCase = v.toLowerCase()
      return lowerCase === '0' || lowerCase === 'false' || lowerCase === 'no'
    } else {
      return false
    }
  }
}
