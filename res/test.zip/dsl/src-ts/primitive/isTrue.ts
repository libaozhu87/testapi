import isFalse from './isFalse'

export default function isTrue(v) {
  return !isFalse(v)
}
