import { Match } from './Match'
import pred from './pred'
import toString from './toString'

export class Matcher {
  private _match: Match
  private _cache
  private _defaultReturn

  constructor() {
    this._match = new Match()
    this._cache = undefined
    this._defaultReturn = this
  }

  public preprocess(map) {
    this._match.preprocess(map)
    return this
  }

  public postprocess(map) {
    this._match.postprocess(map)
    return this
  }

  public cacheEnabled() {
    this._cache = {}
    return this
  }

  public strict(strict: boolean) {
    this._match.strict(strict)
    return this
  }

  public case(cond, tap?) {
    this._match.case.apply(this._match, arguments)
    return this
  }

  public default(tap) {
    this.case(pred.T, tap)
    return this._defaultReturn
  }

  public setDefaultReturn(defaultReturn) {
    return (this._defaultReturn = defaultReturn)
  }

  public invoke(...params) {
    if (this._cache) {
      const key = toString(params)
      let cache = this._cache[key]
      if (!cache) {
        cache = [this._match.invoke(...params)]
        this._cache[key] = cache
      }
      return cache[0]
    } else {
      return this._match.invoke(...params)
    }
  }

  public append(otherMatcher) {
    this._match.append(otherMatcher._match)
    return this
  }
}

export function matcher(): Matcher {
  return new Matcher()
}
