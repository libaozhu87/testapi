export default function contains(collect, value) {
  return collect && collect.indexOf(value) !== -1
}
