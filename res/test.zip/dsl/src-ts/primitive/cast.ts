import typof from './typof'
import isMatch from './isMatch'

function toFunction(v) {
  return typof(v) === 'function' ? v : v && v.invoke ? nv => v.invoke(nv) : () => v
}

function toValue(v, ...args) {
  return typof(v) === 'function'
    ? v(...args)
    : // : v && v.invoke
      //     ? v.invoke(...args)
      v
}

function toValue2(v, ...args) {
  return typof(v) === 'function' ? v(...args) : v && v.invoke ? v.invoke(...args) : v
}

function toArray(v): any[] {
  return Array.isArray(v) ? v : [v]
}

/**
 * convert a {function|object|array|regexp|primitive} to a pred function using strict strategy
 * @param {function|object|array|regexp|primitive} cond condition/pred
 * @param {string} strategy {'strict', 'loose'} default is 'strict'
 * @return {function} a pred function
 */
function toPred(cond, strict?: boolean): (...vs: any[]) => any {
  const type = typof(cond)
  return type === 'function'
    ? function() {
        return cond.apply(this, arguments)
      }
    : // type === 'boolean' ? () => cond :
      target => isMatch(target, cond, strict)
}

export default {
  toArray,
  toFunction,
  toValue,
  toValue2,
  toPred
}
