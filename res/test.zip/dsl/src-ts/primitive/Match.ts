import cast from './cast'
import { Exception } from './Exception'
import pred from './pred'
import isMatch from './isMatch'

export class Match {
  private _cases
  private _strict: boolean
  private _preprocess: (...params: any[]) => any
  private _postprocess: (param0: any, param1?: any) => any

  constructor() {
    this._cases = []
    this._strict = true
  }

  public preprocess(map) {
    this._preprocess = map
    return this
  }

  public postprocess(map) {
    this._postprocess = map
    return this
  }

  /***
   * @param {strict|loose} strict boolean
   * @return {Match} this
   */
  public strict(strict: boolean): Match {
    this._strict = strict
    return this
  }

  public case(condition, action) {
    this._cases.push(arguments.length <= 1 ? [condition] : [condition, action])
    return this
  }

  public append(otherMatch) {
    this._cases.concat(otherMatch._cases)
    return this
  }

  public default(action) {
    return this.case(pred.T, action)
  }

  public invoke(...params) {
    const input = this.handlePreprocess(...params)

    let matched = false
    for (const aCase of this._cases) {
      if (matched || isMatch(input, aCase[0], this._strict)) {
        matched = true
        if (aCase.length > 1) {
          const output = cast.toValue2(aCase[1], input)
          return this.handlePostprocess(output, input)
        }
      }
    }

    throw new Exception('NoMatchError')
  }

  private handlePreprocess(...params) {
    return this._preprocess ? this._preprocess(...params) : params[0]
  }

  private handlePostprocess(output, input) {
    return this._postprocess ? this._postprocess(output, input) : output
  }
}

export function match() {
  return new Match()
}
