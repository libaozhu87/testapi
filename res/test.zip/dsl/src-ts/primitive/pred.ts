import cmp from './cmp'
import curry from './curry'
import equalsIgnoreCase from './equalsIgnoreCase'
import isEmpty from './isEmpty'
import isType from './isType'
import logic from './logic'
import prop from './prop'

type Functor2 = (a0: any, a1: any) => any

/**
 * 参数反向的柯里化
 * @param func , func's length must be 2.
 * @return take one param
 */
function functor2(func: Functor2) {
  return (...args) => {
    return args.length === 0 ? func : args.length === 1 ? target => func(target, args[0]) : func(args[0], args[1])
  }
}

function functorRest(func: Functor2) {
  return (...args) => {
    return target => func(target, [].slice.call(args, 0))
  }
}

export default {
  eq: functor2(cmp.equals),
  gte: functor2(cmp.gte),
  gt: functor2(cmp.gt),
  lte: functor2(cmp.lte),
  lt: functor2(cmp.lt),
  feq: functor2(cmp.fequals),
  fgte: functor2(cmp.fgte),
  fgt: functor2(cmp.fgt),
  flte: functor2(cmp.flte),
  flt: functor2(cmp.flt),
  and: functorRest(logic.and),
  or: functorRest(logic.or),
  not: functor2(logic.not),
  equalsIgnoreCase: functor2(equalsIgnoreCase),
  T: logic.T,
  F: logic.F,
  isEmpty,
  isType: curry.curry(isType),
  prop: curry.curry(prop)
}
