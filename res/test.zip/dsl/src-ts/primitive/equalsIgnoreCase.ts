import identical from './identical.js'

export default function equalsIgnoreCase(a, b): boolean {
  return typeof a === 'string' && typeof b === 'string' ? a.toLowerCase() === b.toLowerCase() : identical(a, b)
}
