import typof from './typof.js'

export default function isType(type, v) {
  return typof(v) === type
}
