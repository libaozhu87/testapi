//[0,1,2], ['a', 'b', 'c'] => [[0,'a'], [0, 'b'], [0, 'c'], [1,'a'], [1, 'b'], [1, 'c'], [2,'a'], [2, 'b'], [2, 'c']]
export function zipMatrix<T, K>(arr0: T[], arr1: K[]): Array<[T, K]> {
  const merge: Array<[T, K]> = []
  for (const t of arr0) {
    for (const k of arr1) {
      merge.push([t, k])
    }
  }
  return merge
}

//[0,1,2,3] => [[0,1],[0,2], [0,3], [1,2], [1,3], [2,3]]
export function zipDiagonal<T>(arr0: T[], arr1: T[]): Array<[T, T]> {
  arr1 = arr1 || arr0
  const merge = []
  for (let i = 0; i < arr0.length; i++) {
    for (let j = i + 1; j < arr1.length; j++) {
      merge.push([arr0[i], arr1[j]])
    }
  }
  return merge
}

export function zipLong<T, K>(arr0: T[], arr1: K[]): Array<[T, K]> {
  const arrs = [arr0, arr1]
  const long = arrs.reduce((pre, arr) => Math.max(pre, arr.length), 0)
  const result = []
  for (let i = 0; i < long; i++) {
    result[i] = arrs.map(arr => arr[i])
  }
  return result
}

export function zipShort<T, K>(arr0: T[], arr1: K[]): Array<[T, K]> {
  const arrs = [arr0, arr1]
  const short = arrs.reduce((pre, arr) => Math.min(pre, arr.length), 4096)
  const result = []
  for (let i = 0; i < short; i++) {
    result[i] = arrs.map(arr => arr[i])
  }
  return result
}

export function zipBetween<T>(arr: T[]): Array<[T, T]> {
  const result = []
  for (let i = 0; i < arr.length - 1; i++) {
    result[i] = [arr[i], arr[i + 1]]
  }
  return result
}
