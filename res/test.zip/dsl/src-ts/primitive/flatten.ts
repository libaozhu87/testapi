export default function flatten(arr, deep = false): any[] {
  return arr.reduce(
    (flat, toFlatten) =>
      flat.concat(
        deep && Array.isArray(toFlatten) ? flatten(toFlatten, true) : toFlatten
      ),
    []
  )
}
