import equals from './equals'

const THRESHOLD = 0.0000001

export default {
  equals,
  gt: (a, b) => a > b,
  gte: (a, b) => a >= b,
  lt: (a, b) => a < b,
  lte: (a, b) => a <= b,
  fequals: (a, b) => Math.abs(a - b) <= THRESHOLD,
  fgt: (a, b) => a - b > THRESHOLD,
  fgte: (a, b) => a - b >= -THRESHOLD,
  flt: (a, b) => a - b < -THRESHOLD,
  flte: (a, b) => a - b <= THRESHOLD
}
