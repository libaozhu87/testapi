import cast from './cast'

function andOr(isAnd, preds, target) {
  for (const i in preds) {
    if (!!preds[i](target) !== isAnd) {
      return !isAnd
    }
  }
  return isAnd
}

// support rest-arguments ?
function and(target, preds) {
  preds = preds ? preds.map(cast.toPred) : []
  return andOr(true, preds, target)
}

function or(target, preds) {
  preds = preds ? preds.map(cast.toPred) : []
  return andOr(false, preds, target)
}

function not(target, cond) {
  const pred = cast.toPred(cond, undefined)
  return !pred(target)
}

function T() {
  return true
}

function F() {
  return false
}

export default {
  and,
  or,
  not,
  T,
  F
}
