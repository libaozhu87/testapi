export default function endsWith(str: string, suffix: string) {
  return str !== undefined && suffix !== undefined && str.indexOf(suffix, str.length - suffix.length) !== -1
}
