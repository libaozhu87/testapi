export default function identity(n) {
  return n
}
