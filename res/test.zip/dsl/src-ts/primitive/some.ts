import typof from './typof'

export default function some(collect, predicate) {
  const type = typof(collect)
  if (type === 'array') {
    return collect.some(predicate)
  } else if (type === 'object') {
    Object.keys(collect).forEach(k => {
      if (collect.hasOwnProperty(k)) {
        if (predicate(collect[k], k, collect)) {
          return true
        }
      }
    })
    return false
  } else {
    return false
  }
}
