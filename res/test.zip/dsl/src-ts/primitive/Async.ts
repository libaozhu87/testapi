import cast from './cast'
import logger from './logger'
import { Matcher } from './Matcher'
import { Moment } from './Moment'
import prop from './prop'
import toString from './toString'

export interface Ctxable {
  locals: object

  isDone(): boolean
  cancel(): Ctxable
  complete(e: any, v: any, level: DONE_LEVEL): Ctxable
}

export interface AdvancedCtxable extends Ctxable {
  next(v): Ctxable
  error(e): Ctxable
  accept(e, v): Ctxable

  break(v): Ctxable
  continue(v): Ctxable
}

export type Asyncable = (e: any, v: any, ctx: Ctxable, cb: Callbackable) => Ctxable

export type Callbackable = (e: any, v: any, ctx: Ctxable) => any

export type Executeable = (v: any, ctx: AdvancedCtxable) => any

export type Catchable = (e: any, ctx: AdvancedCtxable) => any

function noop(): Ctxable {
  return undefined
}

function identity(e: any, v: any, ctx: Ctxable, cb: Callbackable) {
  return cb(e, v, ctx)
}

function trust() {
  return true
}

function assert(cond, msg) {
  if (!cond) {
    throw new Error(msg)
  }
}

class SysError {
  constructor(public type: string, public message: string, public data: any) {}
}

class BreakError extends SysError {
  constructor(data: any) {
    super('break', 'break-error', data)
  }
}

class ContinueError extends SysError {
  constructor(data: any) {
    super('continue', 'continue-error', data)
  }
}

class CancelError extends SysError {
  constructor() {
    super('cancel', 'cancel-error', undefined)
  }
}

/*
 * swallow error level [0, 1, 2, 3] =>
 * [never-swallow, swallow-cancel-error, swallow-cancel&handled-error, swallow-all-error]
 * if (SWALLOW_ERROR_LEVEL >= DONE_LEVEL) swallow
 */
export enum DONE_LEVEL {
  CANCELED = 1,
  CATCHED,
  COMPLETED
}

export enum SWALLOW_ERROR_LEVEL {
  NEVER,
  CANCELED,
  CATCHED,
  ALL
}

function isUncatchable(e) {
  return e instanceof SysError
}

function series(a1: Asyncable, a2: Asyncable): Asyncable {
  return (e, v, ctx: Ctxable, cb: Callbackable) => a1(e, v, ctx, (ne, nv, nctx) => a2(ne, nv, nctx, cb))
}

function synthetise(executer: Executeable, catcher: Catchable): Asyncable {
  return (e: any, v: any, ctx: Ctxable, cb: Callbackable): Ctxable => {
    if (ctx.isDone()) {
      // ignored
      return ctx
    } else if (isUncatchable(e)) {
      // break or continue or cancel
      // until someone could handle it like loop-stage
      return cb(e, undefined, ctx)
    } else {
      if (e) {
        if (catcher) {
          let catched = false
          try {
            catcher(e, new AdvancedContext(ctx, cb))
            catched = true
          } catch (ne) {
            cb(ne, undefined, ctx)
          }
          // whenError ?
          if (catched) {
            ctx.complete(e, undefined, DONE_LEVEL.CATCHED)
          }
        } else {
          return cb(e, undefined, ctx)
        }
      } else {
        if (executer) {
          try {
            executer(v, new AdvancedContext(ctx, cb))
          } catch (ne) {
            cb(ne, undefined, ctx)
          }
        } else {
          cb(undefined, v, ctx)
        }
      }
    }

    return ctx
  }
}

interface Stageable {
  append(asyncable: Asyncable): this
  toAsyncable(): Asyncable
}

type AnyFunction = (...vs: any[]) => any

interface Caseable {
  condition: AnyFunction
  method: Asyncable
}

class Branches implements Stageable {
  private _cases: Caseable[] = []
  private _closed = false

  public case(cond: any, closed: boolean) {
    assert(this._closed === false, 'Unexpected "else/elseif" follows behind "else"')
    this._closed = closed
    const tuple = { condition: cast.toPred(cond), method: identity }
    this._cases.push(tuple)
  }

  public append(asyncable: Asyncable) {
    const top = this._cases[this._cases.length - 1]
    top.method = series(top.method, asyncable)
    return this
  }

  public toAsyncable(): Asyncable {
    return (e, v, ctx: Ctxable, cb: Callbackable): Ctxable => {
      if (ctx.isDone()) {
        return ctx
      }

      if (e) {
        return cb(e, undefined, ctx)
      }

      for (const tuple of this._cases) {
        const condition = tuple.condition
        const method = tuple.method
        if (condition(v, ctx)) {
          return method(undefined, v, ctx, cb)
        }
      }
      // no case match
      return cb(undefined, v, ctx)
    }
  }
}

class ErrorScope implements Stageable {
  private _method: Asyncable = identity

  public append(asyncable: Asyncable) {
    this._method = series(this._method, asyncable)
    return this
  }

  public toAsyncable(): Asyncable {
    return (e, v, ctx: Ctxable, cb: Callbackable): Ctxable => {
      if (ctx.isDone()) {
        return ctx
      }

      if (!e) {
        return cb(undefined, v, ctx)
      } else if (isUncatchable(e)) {
        return cb(e, undefined, ctx)
      }

      return this._method(undefined, e, ctx, cb)
    }
  }
}

interface IterResult {
  isDone: boolean
  value?: any
}

type Iteratorable = (v: any, ctx: Ctxable) => (v: any, ctx: Ctxable) => IterResult

class Looper implements Stageable {
  private _method: Asyncable
  private _iterator: Iteratorable

  constructor(iterator: Iteratorable) {
    this._iterator = iterator
    this._method = identity
  }

  public append(asyncable: Asyncable) {
    this._method = series(this._method, asyncable)
    return this
  }

  public toAsyncable(): Asyncable {
    const method = this._method

    return (e: any, v: any, ctx: Ctxable, cb: Callbackable): Ctxable => {
      if (ctx.isDone()) {
        return ctx
      }

      const iter = this._iterator(v, ctx)
      const flatMethod = (fe: any, fv: any, fctx: Ctxable): Ctxable => {
        if (fe instanceof BreakError) {
          return cb(undefined, fe.data, fctx)
        } else if (fe instanceof ContinueError) {
          return flatMethod(undefined, fe.data, ctx)
        } else if (fe) {
          return cb(fe, undefined, fctx)
        } else {
          const result = iter(fv, fctx)
          if (!result.isDone) {
            return method(undefined, result.value, fctx, flatMethod)
          } else {
            return cb(undefined, fv, fctx)
          }
        }
      }
      return flatMethod(e, v, ctx)
    }
  }
}

class Main implements Stageable {
  private _method: Asyncable = identity

  public append(asyncable: Asyncable): any {
    this._method = series(this._method, asyncable)
    return this
  }

  public toAsyncable(): Asyncable {
    return this._method
  }
}

class Context implements Ctxable {
  public locals: object = {}
  private _isDone = false
  private _outterCanceller
  private _callback: Callbackable
  private _swallowErrorLevel: SWALLOW_ERROR_LEVEL

  constructor(public global: object, outterCanceller, swallowErrorLevel: SWALLOW_ERROR_LEVEL, callback: Callbackable) {
    this._outterCanceller = outterCanceller
    this._callback = callback
    this._swallowErrorLevel = swallowErrorLevel
  }

  public isDone(): boolean {
    if (!this._isDone) {
      if (cast.toValue(this._outterCanceller)) {
        logger.log('outter-cancel')
        this.cancel()
      }
    }
    return this._isDone
  }

  public cancel() {
    logger.log('cancel')
    return this.complete(new CancelError(), undefined, DONE_LEVEL.CANCELED)
  }

  public complete(e: any, v: any, level: DONE_LEVEL) {
    if (!this._isDone) {
      logger.log('done', e, v)
      this._isDone = true
      this._outterCanceller = undefined
      const callback = this._callback
      this._callback = undefined

      if (!(e && this._swallowErrorLevel >= (level as number))) {
        return callback(e, v, this)
      }
    } else {
      logger.log('Unexpected done called again.')
    }
    return this
  }
}

export class AdvancedContext implements AdvancedCtxable {
  public locals: object
  private _ctx: Ctxable
  private _callback: Callbackable

  constructor(ctx: Ctxable, cb: Callbackable) {
    this.locals = ctx.locals
    this._ctx = ctx
    this._callback = cb
  }

  public break(v) {
    return this._callback(new BreakError(v), undefined, this._ctx)
  }

  public continue(v) {
    return this._callback(new ContinueError(v), undefined, this._ctx)
  }

  public next(v) {
    return this._callback(undefined, v, this._ctx)
  }

  public error(e) {
    return this._callback(e, undefined, this._ctx)
  }

  public accept(e, v) {
    return this._callback(e, v, this._ctx)
  }

  public isDone() {
    return this._ctx.isDone()
  }

  public cancel() {
    return this._ctx.cancel()
  }

  public complete(e: any, v: any, level: DONE_LEVEL = DONE_LEVEL.COMPLETED) {
    return this._ctx.complete(e, v, level)
  }
}

// for all/race api
interface Recordable {
  triggered: boolean
  arrived: number
  values: any[]
}

type Recevieable = (record: Recordable, index: number, v: any, ctx: AdvancedCtxable) => void

export class Async implements Stageable {
  private _stageStack: Stageable[]
  private _global: object
  private _outterCanceller: any
  private _lifeState: string
  private _swallowErrorLevel: SWALLOW_ERROR_LEVEL = SWALLOW_ERROR_LEVEL.CATCHED

  public constructor() {
    this._stageStack = [new Main()]
    this._global = {}
  }

  public append(asyncable: Asyncable): this {
    const topStage = this._stageStack[this._stageStack.length - 1]
    topStage.append(asyncable)
    return this
  }

  public toAsyncable(): Asyncable {
    assert(this._stageStack.length === 1, 'Expected "end".')
    return this._stageStack[0].toAsyncable()
  }

  public then(executer: Executeable, catcher?: Catchable): this {
    return this.append(synthetise(executer, catcher))
  }

  public maxConcurrency(max: any) {
    max = cast.toValue(max)
    if (max <= 0) {
      return this // no control
    }
    const conManager: { array: Ctxable[] } = { array: [] }
    return this.action((v, ctx) => {
      conManager.array = conManager.array.filter(con => !con.isDone())
      if (conManager.array.indexOf(ctx) === -1) {
        conManager.array.push(ctx)
        while (conManager.array.length > max) {
          const con = conManager.array.shift()
          logger.log('Canceled by max concurrency.')
          con.cancel()
        }
      }
    })
  }

  public setSwallowErrorLevel(swallowErrorLevel: SWALLOW_ERROR_LEVEL) {
    this._swallowErrorLevel = swallowErrorLevel
    return this
  }

  public invoke(v?: any, cb?: Callbackable): Ctxable {
    return this.accept(undefined, v, undefined, cb)
  }

  public accept(e: any, v: any, ctx: Ctxable, cb?: Callbackable): Ctxable {
    // fix invoke multi-arguments bug
    cb = typeof cb === 'function' ? cb : noop
    ctx = ctx === undefined ? this.newCtx(cb) : ctx

    const asyncable = this.toAsyncable()
    asyncable.call(this, e, v, ctx, (ne, nv) => ctx.complete(ne, nv, DONE_LEVEL.COMPLETED))
    return ctx
  }

  /**
   * fake async as a function for vue's event-apply
   */
  public apply(_this, args) {
    return this.invoke(args[0])
  }

  public call(_this, arg) {
    return this.invoke(arg)
  }

  public if(cond: any): this {
    const stage = new Branches()
    stage.case(cond, false)
    this._stageStack.push(stage)
    return this
  }

  public elseif(cond: any): this {
    const stage = this._stageStack[this._stageStack.length - 1]
    assert(stage instanceof Branches, '"elseif/else" must follows behind "if".')
    ;(stage as Branches).case(cond, false)
    return this
  }

  public else(): this {
    const stage = this._stageStack[this._stageStack.length - 1]
    assert(stage instanceof Branches, '"elseif/else" must follows behind "if".')
    ;(stage as Branches).case(trust, true)
    return this
  }

  public whenError(): this {
    const stage = new ErrorScope()
    this._stageStack.push(stage)
    return this
  }

  public end(): this {
    const stage0 = this._stageStack.pop()
    const stage1 = this._stageStack.pop()
    assert(stage0 && stage1, '"end" is expected in a loop/branches scope')
    this._stageStack.push(stage1.append(stage0.toAsyncable()))
    return this
  }

  public break(): this {
    assert(this.isInLooper(), `break is expected in a loop scope.`)
    return this.then((v, ctx) => ctx.break(v))
  }

  public continue(): this {
    assert(this.isInLooper(), `continue is expected in a loop scope.`)
    return this.then((v, ctx) => ctx.continue(v))
  }

  public repeat(value: any): this {
    const stage = new Looper((v: any, ctx: Ctxable) => {
      let n = Number(cast.toValue(value, v, ctx))
      return iv => ({ isDone: !(--n >= 0), value: iv })
    })
    this._stageStack.push(stage)
    return this
  }

  public forEach(): this {
    const stage = new Looper((v, ctx) => {
      let index = -1
      return () => (++index < v.length ? { value: v[index], isDone: false } : { isDone: true })
    })
    this._stageStack.push(stage)
    return this
  }

  public for(begin, end, step): this {
    step = step ? 1 : step
    const stage = new Looper(() => {
      let index = begin
      return () => {
        const ret = (step > 0 && index >= end) || (step < 0 && index <= end) ? { isDone: true } : { value: index, isDone: false }
        index = index + step
        return ret
      }
    })
    this._stageStack.push(stage)
    return this
  }

  public while(cond): this {
    const stage = new Looper((v, ctv) => {
      const pred = cast.toPred(cond, v)
      return (iv, ictx) => ({ isDone: !pred(iv, ictx), value: iv })
    })
    this._stageStack.push(stage)
    return this
  }

  public throttle(mills: number): this {
    const isInLoop = this.isInLooper()
    let mark = 0
    return this.then((v, ctx) => {
      const now = new Date().getTime()
      if (mark + mills <= now) {
        mark = now
        return ctx.next(v)
      } else {
        logger.log('swallow throttle.')
        if (isInLoop) {
          return ctx.continue(v)
        } else {
          return ctx.cancel()
        }
      }
    })
  }

  public debounce(mills: number): this {
    const isInLoop = this.isInLooper()
    let newestMap: object
    return this.action((v, ctx) => {
      newestMap = ctx.locals
    })
      .wait(mills)
      .then((v, ctx) => {
        if (newestMap === ctx.locals) {
          newestMap = undefined
          return ctx.next(v)
        } else {
          logger.log('swallow debounce.')
          if (isInLoop) {
            return ctx.continue(v)
          } else {
            ctx.cancel()
          }
        }
      })
  }

  public switch(): Matcher {
    const aMatcher = new Matcher()
    const next = this.then((v, ctx) => ctx.next(aMatcher.invoke(v)))
    aMatcher.setDefaultReturn(next)
    return aMatcher
  }

  public all(...workers: Async[]): this {
    const executeable = this.merge((context, index, v, ctx) => {
      context.arrived++
      context.values[index] = v
      if (context.arrived === workers.length) {
        context.triggered = true
        ctx.next(context.values)
      }
    }, workers)
    return this.append(executeable)
  }

  public race(...workers: Async[]): this {
    const executeable = this.merge((context, index, v, ctx) => {
      context.triggered = true
      ctx.next({ index, v })
    }, workers)
    return this.append(executeable)
  }

  public sequence(...workers: Async[]): this {
    const asyncable = workers.map(async => async.toAsyncable()).reduce(series, identity)
    return this.append(asyncable)
  }

  public callWorker(worker: Async) {
    return this.append((e, v, ctx, cb) => {
      const realWorker = typeof worker === 'function' ? (worker as (a: any, c: Ctxable) => any)(v, ctx) : worker
      return realWorker.accept(e, v, ctx, cb)
    })
  }
  // recurse - call - self, cb ?
  public recurse(): this {
    return this.then((v, ctx) => this.invoke(v, (ne, nv) => ctx.accept(ne, nv)))
  }

  public catch(catcher: Catchable) {
    return this.then(undefined, catcher)
  }

  public map(value) {
    return this.then((v, ctx) => ctx.next(cast.toValue(value, v, ctx)))
  }

  public throw(e?) {
    return this.then((v, ctx) => ctx.error(e === undefined ? v : cast.toValue(e, v, ctx)))
  }

  /**
   */
  public return(rv?) {
    const self = this
    let cur = self
    if (arguments.length > 0) {
      cur = this.map(rv)
    }
    return cur.then((v, ctx) => ctx.complete(undefined, v, DONE_LEVEL.COMPLETED))
  }

  public ifThenReturn(cond, rv) {
    if (arguments.length <= 1) {
      return this.if(cond)
        .return()
        .end()
    } else {
      return this.if(cond)
        .return(rv)
        .end()
    }
  }

  public ifThenThrow(cond, e) {
    return this.if(cond)
      .throw(e)
      .end()
  }

  public action(action: (v?: any, ctx?: AdvancedCtxable) => any) {
    return this.then((v, ctx) => {
      if (action) {
        action(v, ctx)
      }
      return ctx.next(v)
    })
  }

  public validate(action: (v?: any, ctx?: AdvancedCtxable) => any) {
    return this.action(action)
  }

  public whatever(action: (e?: any, v?: any, ctx?: AdvancedCtxable) => any) {
    return this.then(
      (v, ctx) => {
        if (action) {
          action(undefined, v, ctx)
        }
        return ctx.next(v)
      },
      (e, ctx) => {
        if (action) {
          action(e, undefined, ctx)
        }
        return ctx.error(e)
      }
    )
  }

  public wait(mills: number) {
    return this.then((v, ctx) => setTimeout(() => ctx.next(v), Math.round(cast.toValue(mills, v, ctx))))
  }

  public countDown(mills: number, fn) {
    let moment
    return this.action(() => {
      moment = moment || new Moment()
    })
      .wait(mills)
      .map((v, ctx) => fn(moment.mark(), v, ctx))
  }

  public stringify() {
    return this.map(toString)
  }

  public log(label: string = '', ctxlog: boolean = false) {
    return this.whatever((e, v, ctx) => {
      if (e) {
        logger.log(label + ' error:', e, ctxlog ? toString(ctx) : '')
      } else {
        logger.log(label, toString(v), ctxlog ? toString(ctx) : '')
      }
    })
  }

  public prop(k: string) {
    return this.then((v, ctx) => ctx.next(prop(k, v)))
  }

  public currentLimiting(limit: number, time: number = 1000) {
    const manager = {
      consumedTsArray: [], // store timestamp
      waitingArray: [], // store {v, ctx}
      isBatching: false,
      onRecv(v, ctx) {
        this.waitingArray.push({ v, ctx })
        this.consume()
      },
      consume() {
        const now = new Date().getTime()
        this.consumedTsArray = this.consumedTsArray.filter(consumed => consumed + time > now)
        const consumedLength = this.consumedTsArray.length
        for (let i = 0; i < limit - consumedLength && this.waitingArray.length > 0; i++) {
          const { v, ctx } = this.waitingArray.shift()
          ctx.next(v)
          this.consumedTsArray.push(now)
        }

        if (!this.isBatching && this.waitingArray.length > 0) {
          const headConsumed = this.consumedTsArray[0]
          const delay = headConsumed + time - now

          this.isBatching = true
          setTimeout(() => {
            this.isBatching = false
            this.consume()
          }, delay)
        }
      }
    }

    return this.then((v, ctx) => manager.onRecv(v, ctx))
  }

  public forward(worker: Async, asyncFlag?: boolean) {
    return this.then((v, ctx) => {
      const realWorker = typeof worker === 'function' ? (worker as (a: any, c: Ctxable) => any)(v, ctx) : worker
      if (!asyncFlag) {
        realWorker.invoke(v, noop)
        return ctx.next(v)
      } else {
        return realWorker.invoke(v, (ne, nv) => ctx.accept(ne, nv))
      }
    })
  }

  public bindOutterCanceller(outterCanceller) {
    this._outterCanceller = outterCanceller
    return this
  }

  // not implemented yet
  public bindLifeCircle(lifeCircle) {
    lifeCircle.on('created', () => (this._lifeState = 'created'))
    lifeCircle.on('destroyed', () => (this._lifeState = 'destroyed'))
    lifeCircle.on('paused', () => (this._lifeState = 'paused'))
    lifeCircle.on('resumed', () => (this._lifeState = 'resumed'))
  }

  private newCtx(cb: Callbackable): Ctxable {
    return new Context(this._global, this._outterCanceller, this._swallowErrorLevel, cb)
  }

  private isInLooper(): boolean {
    return this._stageStack.some(v => v instanceof Looper)
  }

  private merge(recevie: Recevieable, triggers: Async[]): Asyncable {
    if (!triggers || !triggers.length) {
      return identity
    }
    return (e: any, v: any, ctx: Ctxable, cb: Callbackable) => {
      const record = { arrived: 0, triggered: false, values: [] }
      triggers.forEach((trigger, index) => {
        trigger.invoke(v, (ne, nv) => {
          if (!record.triggered) {
            if (ne) {
              record.triggered = true
              cb(ne, nv, ctx)
            } else {
              recevie(record, index, nv, new AdvancedContext(ctx, cb))
            }
          }
          return ctx
        })
      })
      return ctx
    }
  }
}
