import typof from './typof'

export default function forEach(collect, iteratee) {
  const type = typof(collect)
  if (type === 'array') {
    return collect.forEach(iteratee)
  } else if (type === 'object') {
    Object.keys(collect).forEach(k => {
      if (collect.hasOwnProperty(k)) {
        iteratee(collect[k], k, collect)
      }
    })
    return collect
  }
}
