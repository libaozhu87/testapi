import typof from './typof'

export default function reduce(collect, iteratee, memo) {
  const type = typof(collect)
  if (type === 'array') {
    return collect.reduce(iteratee, memo)
  } else if (type === 'object') {
    Object.keys(collect).forEach(k => {
      if (collect.hasOwnProperty(k)) {
        memo = iteratee(memo, collect[k], k, collect)
      }
    })
    return memo
  } else {
  }
}
