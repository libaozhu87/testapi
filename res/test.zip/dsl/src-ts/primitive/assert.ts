import logger from './logger'

export default function assert(cond: boolean, ...msg) {
  if (!cond) {
    if (msg) {
      logger.log(...msg)
    }

    throw new Error(``)
  }
}
