import isEmpty from './isEmpty'
import filter from './filter'
import typof from './typof'

function isCompactable(v) {
  const type = typof(v)
  if (type === 'object') {
    return Object.keys(v).length === 0
  } else if (type === 'array' || type === 'string') {
    return v.length === 0
  } else if (v === undefined || v === null) {
    return true
  }
  return false
}

export default function compact(collect) {
  const type = typof(collect)
  if (type !== 'array' && type !== 'object') {
    return isEmpty(collect) ? undefined : collect
  } else {
    return filter(collect, item => !isCompactable(item))
  }
}
