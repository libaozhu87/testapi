export default function indexOf<T>(arr: T[], pred: (t: T, i?: number, col?: T[]) => boolean): number {
  if (arr) {
    if (typeof pred === 'function') {
      const { length } = arr
      for (let i = 0; i < length; i++) {
        if (pred(arr[i], i, arr)) {
          return i
        }
      }
    } else {
      return arr.indexOf(pred)
    }
  }

  return -1
}
