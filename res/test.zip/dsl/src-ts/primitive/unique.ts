export default function unique<T>(arr: T[]): T[] {
  return arr && arr.filter((v, index) => arr.indexOf(v) === index)
}
