import typof from './typof'
import isNull from './isNull'

export default function isEmpty(v) {
  if (isNull(v)) {
    return true
  } else {
    const type = typof(v)
    if (type === 'object') {
      return Object.keys(v).length === 0
    } else if (type === 'array' || type === 'string') {
      return v.length === 0
    }
    return false
  }
}
