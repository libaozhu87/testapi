import typof from './typof'
export default function size(collect) {
  const type = typof(collect)
  if (type === 'array' || type === 'string') {
    return collect.length
  } else if (type === 'object') {
    let count = 0
    Object.keys(collect).forEach(k => {
      if (collect.hasOwnProperty(k)) {
        count++
      }
    })
    return count
  }
  return 0
}
