import isEmpty from './isEmpty'

export default function count<T>(arr: T[], value): number {
  if (isEmpty(arr)) {
    return 0
  } else {
    return arr.reduce((pre, cur) => pre + (cur === value ? 1 : 0), 0)
  }
}
