# DSL

#### 一些基础定义

##### Frame

```
export interface Frame {
  width: number
  height: number
  x: number
  y: number
}
```

描述一个输入的 UI 组件的大小和位置。 x,y 为左上点坐标。

#### 基础 UI 元素

1.  Shape
    简单的矩形形状， 可以有圆角，描边，背景色，背景色渐变等描述。

2.  Text
    文字渲染的描述。

3.  Image
    图片渲染的描述。

#### 容器 UI 元素

1.  Group
    包含一组子元素，子元素的类型为基础 UI 元素或者容器 UI 元素。

结构上一个 UI 元素有一下几部分构成：

1.  content
    文字的内容， 图片的链接，复合元素的子元素。 注：Shape 元素没有内容。

2.  渲染样式
    形状的渲染样式（Stlye），文字的渲染样式（TextStyles），图片的渲染样式（ImageStyles）。详见下面的关于这些渲染样式的定义。

3.  布局属性
    width-height，margin，padding，flex-direction（主轴方向），等。沿用了经典 flexbox 的模型。目前是 flexbox 常见属性的一个子集。
    详见下面的关于 Layout 的定义。

### 出于和更多的 UI 体系相通， 并且让 UI 表达更加简洁，其中 Text 和 Group 可能同样会拥有 Shape 的渲染属性。

##渲染样式

##### Stlye

```
export interface Styles {
  opacity: number //透明度 [0-1]
  //border
  borderRadius: number //圆角半径
  borderStyle: string //solid,dashed,dotted,
  borderWidth: number //描边粗细
  borderColor: string //描边颜色
  //background
  backgroundColor: string //纯色
  backgroundImage: string //线性渐变， 有渐变色的时候，会覆盖纯色背景
}
```

描述一个 Shape 的渲染样式。

##### TextStyles

```
export interface TextStyles {
  lines: number //描述最大行数，可选项
  maxWidth: number //描述最大行宽，可选项
  maxHeight: number //描述最大高度，可选项
  color: string //描述字体颜色，如 #ff00ff (rgb)
  fontSize: number //描述字体大小，如 #ff00ff (rgb)
  fontStyle: string //normal, italic
  fontWeight: string //描述字体厚度，可选项
  lineHeight: number //描述每行高度，可选项
  textDecoration: string //可选项 overline,line-through,underline,blink
  textAlign: string //可选项 left, center, right
  fontFamily: string //可选项 描述字体类型，如 PingFangSC-Medium
  textOverflow: string //可选项 clip, ellipsis
}
```

描述一个 Text 的渲染样式。

##### ImageStyles

```
export interface ImageStyles {
  //目前关于图片渲染属性的定义为空
}
```

描述一个 Image 的渲染样式，目前无实际内容。

```
export interface Layout {
  flexDirection: string //描述流式方向，row, column
  justifyContent: string //描述主轴对齐方式，flex-start, flex-end, center, space-between
  alignItems: string //描述副轴对齐方式，flex-start, flex-end, center

  padding: number[]

  position: string //relative, absolute

  width: number
  height: number

  left: number
  right: number
  top: number
  bottom: number
  margin: number[]

  transform?: string //translateX(-50%), translateY(-50%), translate(-50%, -50%)

  //for self
  alignSelf: string //flex-start, flex-end, center
}
```

###关于布局属性的说明

1.  任何 UI 元素都有的属性

    1.  width， height， 如果给出，则定宽或定高。
    2.  padding，margin 属性 （参考盒模型）。
    3.  position 属性， 必选， 表明自身是在流式布局内的，还是在绝对坐标中（相对父容器而言）的。
    4.  left，right，top， bottom，相对父容器的偏移。 当处在绝对坐标中，才会有这些属性。
        如果给定了一个方向上的两个值， 说明在该方向上， 元素的长|宽，跟随父容器的大小。
    5.  transform， 当处在绝对坐标中，才可能会有这个属性。用来描述相对于某一点的居中。
    6.  alignSelf 当处在流式布局中，才可能会有该属性。用来描述自身在父容器中副轴上的对齐方式， 优先级更高，会覆盖父容器的 alignItems 属性。

2.  容器元素有的属性
    1.  flexDirection 必选，用来描述容器主轴上的方向，水平或者垂直。
    2.  justifyContent， 必选，用来描述容器主轴上的对齐方式。
    3.  alignItems， 可选，用来描述容器副轴上的对齐方式。

#### 输入

```
export interface InputNode {
  type: string // text|image|shape|group
  frame: Frame //相对页面绝对坐标
  layers: InputNode[] //子节点组 如果是 group 就会有
  value: string //text or image.src
  styles: Styles //描述 shape
  textStyles: TextStyles //描述 text
  imageStyles: ImageStyles //描述 image, 目前默认会空{}
}
```

输入中包含了， 最基本的 3 类 UI 元素， 包含它们的内容，它们的渲染样式，以及相对屏幕的坐标盒大小，层级结构和布局属性是缺失的，在算法的推导中给出。
输入是以上结构的一个类似为 InputNode 的 node-tree，虽然会有层级关系，但是会预处理将它们全部扁平化，变成一个 InputNode[]的数组。如果本身就是扁平化的，那么可以直接输入 InputNode[]数组。

#### 输出

```
export interface IClass {
name: string //css 名字
styles: object //css 描述
}
```

IClass.styles
是 UI 元素的渲染属性和布局属性的组合。在前端的实践中， 相当于 css 的部分。

```
export interface Node {
clazz: IClass
id: string
type: string // text|image|shape|group
layout: Layout
frame: Frame
}

export interface Text extends Node {
value: string // text or image.src
textStyles: TextStyles
styles?: Styles //描述 text 的 background (可以理解为 shape 和 text 的合并)
}

export interface Image extends Node {
value: string // text or image.src
imageStyles: ImageStyles
}

export interface Shape extends Node {
styles: Styles
}

export interface Group extends Node {
styles: Styles
children: Node[]
}
```

经过多层的算法处理， 输出的， 包含了 3 种基础 UI 元素和 1 种容器元素，完整的包含了它们的内容，渲染属性，布局属性，以及层级结构。 是以上结构的一个类型为 Node 的 node-tree 系。
