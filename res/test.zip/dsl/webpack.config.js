process.env.NODE_ENV = 'development'
module.exports = {
  entry: './src-js/index.js',
  devtool: '#hidden-source-map',
  mode: 'development',
  node: {
    console: false,
    fs: 'empty',
    net: 'empty',
    tls: 'empty'
  }
}
